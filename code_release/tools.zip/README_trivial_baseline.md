# 平凡基线强制报告协议(Trivial-Baseline Reporting Protocol)

> 本目录是本文**最小可行正面提案**的实现:把「模型是否真的学到了亲和力信息」变成一个
> **可执行、可复现、可批量接入**的检查。

## 一句话规则

> **任何声称「模型能排序亲和力」的评估,必须同时报告不含任何靶点信息的单一理化性质基线。**
> **若模型未显著跑赢该基线,则「模型学到了亲和力信息」这一主张不成立。**

## 为什么必要

在常规 DTI 评测集上,配体的实测效价常与**分子尺寸**共变 ——
在骨架上累加重原子通常通过非特异性体积接触带来亲和力的默认增长。
因此单用**分子量 / 重原子数**排序即可获得可观的逐靶点 ρ。

**本研究实测**:57 靶点基准上

| 排序依据 | 逐靶点 ρ 中位 |
|---|---|
| **重原子数**(不含任何靶点信息) | **0.191** |
| 分子量(不含任何靶点信息) | 0.187 |
| 氢键受体数 | 0.169 |
| …… | …… |
| **最好的 DTI 模型(cnn_cnn)** | **0.194** |

两者 95% CI 重叠 ⇒ **模型未跑赢平凡基线**。
若不报告基线,「ρ≈0.2」这类结果**无法区分**「模型有用」与「基准自带趋势」。

## 安装与使用

无额外依赖(python ≥3.9):`numpy`、`scipy`、`rdkit`。无需 GPU。

### 命令行

```bash
# 只跑基线
python trivial_baseline.py --eval-set eval.csv --out baseline.json

# 基线 + 模型对比(模型列名 predicted)
python trivial_baseline.py --eval-set eval.csv \
    --model-col predicted --model-name MyModel --out report.json
```

**输入 CSV 必需列**:`target`, `smiles`, `activity`
(`activity` 为「越大越强」的标度,如 pChEMBL);可选 `predicted`。

### 作为库(一行接入任意评测脚本)

```python
from trivial_baseline import run_protocol

rep = run_protocol("eval.csv", model_col="predicted", model_name="MyModel")
assert rep["verdict"]["beats_baseline_strict"], rep["verdict"]["statement"]
```

### 输出

- 每个基线的:逐靶点 ρ 中位数/均值、bootstrap 95% CI、正相关比例、符号与 Wilcoxon 检验 p
- 最强基线(按中位 ρ)
- 若有模型:**判定** —— `beats_baseline_strict` 为真当且仅当
  **模型中位 ρ 更高 _且_ 其 95% CI 下界高于基线的 95% CI 上界**(完全分离)

## 判据的保守性

本协议故意采用**严格判据**(要求 CI 完全分离)。理由:基线之间、基线与会话噪声之间
存在相关性,宽松判据容易把「持平」误判为「胜出」。若模型与基线 CI 重叠,
结论应表述为「**未证明**模型超出平凡趋势」,而不是「模型等效于分子量」。

## 与既往基准的关系

- 诱饵设计文献早已注意到**性质匹配**的重要性(若诱饵与真配体性质分布不同,
  富集会被人为抬高)——但常规做法止于「让两侧性质**匹配**」。
- 本协议把它反过来用:既然性质能影响富集,那么**性质单独能达到的排序能力,
  必须作为任何模型报告的下限对照**。

## 自测

```bash
python ../scripts/129_demo_trivial_baseline.py
```

预期:重原子数 ρ≈0.191、分子量 ρ≈0.187、cnn_cnn ρ≈0.194,
判定输出「模型未跑赢平凡基线」。
