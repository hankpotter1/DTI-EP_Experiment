# -*- coding: utf-8 -*-
"""
平凡基线强制报告协议(Trivial-Baseline Reporting Protocol)
============================================================
本模块是「DTI 亲和力排序评估」的最小可行正面提案:

**规则**:任何声称「模型能排序亲和力」的评估,必须同时报告**不含靶点信息的单一理化性质基线**
(分子量 / logP / TPSA / 氢键供体 / 可旋转键 / 芳环数)。
**若模型未显著跑赢该基线,则「模型学到了亲和力信息」的主张不成立。**

背景(为何必要):在常规 DTI 评测集上,配体的实测效价常与分子尺寸共变
(在骨架上累加重原子通常带来非特异性体积接触增益)。因此单用分子量排序即可获得
可观的逐靶点 ρ —— 若不报告该基线,ρ≈0.2 这类结果无法区分「模型有用」与「基准自带趋势」。

用法
----
命令行::

    python trivial_baseline.py --eval-set eval.csv --out baseline.json
    python trivial_baseline.py --eval-set eval.csv --model-col predicted --model-name MyModel

作为库::

    from trivial_baseline import run_protocol
    report = run_protocol("eval.csv", model_col="predicted", model_name="MyModel")
    print(report["verdict"])

输入 CSV 需含列:``target``, ``smiles``, ``activity``
(pChEMBL 之类的「越大越强」标度);可选 ``predicted``(模型分数)与 ``model``。

输出:逐靶点 ρ 的分布、bootstrap 95% CI、符号检验 p、以及与基线的对比判定。
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
from collections import defaultdict

import numpy as np

__all__ = ["load_eval_set", "compute_properties", "run_protocol", "BASELINE_PROPS"]

# 基线性质(全部只依赖配体,不含任何靶点信息)
BASELINE_PROPS = ["MW", "logP", "TPSA", "HBD", "HBA", "RotB", "ArRings", "HeavyAtoms"]
_ZH = {"MW": "分子量", "logP": "logP", "TPSA": "TPSA", "HBD": "氢键供体", "HBA": "氢键受体",
       "RotB": "可旋转键", "ArRings": "芳香环数", "HeavyAtoms": "重原子数"}


def _rdkit():
    from rdkit import Chem, RDLogger
    from rdkit.Chem import Crippen, Descriptors, rdMolDescriptors
    RDLogger.DisableLog("rdApp.*")
    return Chem, Descriptors, Crippen, rdMolDescriptors


def compute_properties(smiles: str) -> dict | None:
    """由 SMILES 计算基线性质;解析失败返回 None。"""
    Chem, Descriptors, Crippen, rd = _rdkit()
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        return None
    return {
        "MW": Descriptors.MolWt(m),
        "logP": Crippen.MolLogP(m),
        "TPSA": rd.CalcTPSA(m),
        "HBD": rd.CalcNumHBD(m),
        "HBA": rd.CalcNumHBA(m),
        "RotB": rd.CalcNumRotatableBonds(m),
        "ArRings": rd.CalcNumAromaticRings(m),
        "HeavyAtoms": m.GetNumHeavyAtoms(),
    }


def load_eval_set(path: str, target_col="target", smiles_col="smiles", activity_col="activity",
                  score_col=None, min_per_target: int = 10):
    """读入评测集;返回 {(target): [(activity, smiles, score|None), ...]}"""
    by_t = defaultdict(list)
    with open(path, encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            try:
                act = float(r[activity_col])
            except (KeyError, TypeError, ValueError):
                continue
            smi = (r.get(smiles_col) or "").strip()
            t = (r.get(target_col) or "").strip()
            if not smi or not t:
                continue
            sc = None
            if score_col and r.get(score_col) not in (None, ""):
                try:
                    sc = float(r[score_col])
                except ValueError:
                    sc = None
            by_t[t].append((act, smi, sc))
    return {t: v for t, v in by_t.items() if len(v) >= min_per_target}


def _rho(x, y):
    from scipy.stats import spearmanr
    if len(set(x)) < 2 or len(set(y)) < 2:
        return None
    r = spearmanr(x, y)[0]
    return None if r != r else float(r)


def _summarize(vals, rng, n_boot: int = 4000):
    from scipy.stats import binomtest, wilcoxon
    a = np.asarray(vals, dtype=float)
    boot = [np.median(rng.choice(a, len(a), replace=True)) for _ in range(n_boot)]
    out = {
        "n_targets": int(len(a)),
        "median_rho": round(float(np.median(a)), 4),
        "mean_rho": round(float(a.mean()), 4),
        "ci95_median": [round(float(np.percentile(boot, 2.5)), 4),
                        round(float(np.percentile(boot, 97.5)), 4)],
        "frac_positive": round(float((a > 0).mean()), 4),
        "sign_p_vs_0": float(binomtest(int((a > 0).sum()), len(a), 0.5).pvalue),
        "wilcoxon_p_vs_0": float(wilcoxon(a).pvalue),
    }
    return out


def run_protocol(eval_set: str, model_col: str | None = None, model_name: str = "model",
                 target_col="target", smiles_col="smiles", activity_col="activity",
                 seed: int = 20260923, min_per_target: int = 10) -> dict:
    """执行协议:算全部平凡基线(+可选模型),并给出判定。"""
    rng = np.random.default_rng(seed)
    data = load_eval_set(eval_set, target_col, smiles_col, activity_col, model_col, min_per_target)
    if not data:
        raise ValueError("评测集为空或每靶点数不足")

    # 预计算性质
    prop_cache, keep = {}, {}
    for t, recs in data.items():
        keep[t] = []
        for act, smi, sc in recs:
            if smi not in prop_cache:
                prop_cache[smi] = compute_properties(smi)
            if prop_cache[smi] is not None:
                keep[t].append((act, smi, sc))
        keep = {k: v for k, v in keep.items() if len(v) >= min_per_target}

    result = {"eval_set": os.path.basename(eval_set), "n_targets": len(keep), "baselines": {}}
    base_rho = {}
    for p in BASELINE_PROPS:
        vals = []
        for t, recs in keep.items():
            r = _rho([prop_cache[s][p] for _, s, _ in recs], [a for a, _, _ in recs])
            if r is not None:
                vals.append(r)
        if len(vals) >= 5:
            base_rho[p] = vals
            result["baselines"][p] = {**_summarize(vals, rng), "label_zh": _ZH[p]}

    best_prop = max(base_rho, key=lambda k: np.median(base_rho[k])) if base_rho else None
    result["strongest_baseline"] = None
    if best_prop:
        b = result["baselines"][best_prop]
        result["strongest_baseline"] = {
            "property": best_prop, "label_zh": _ZH[best_prop],
            "median_rho": b["median_rho"], "ci95_median": b["ci95_median"]}

    # 模型对比
    if model_col:
        vals = []
        for t, recs in keep.items():
            if any(s is None for _, _, s in recs):
                continue
            r = _rho([s for _, _, s in recs], [a for a, _, _ in recs])
            if r is not None:
                vals.append(r)
        if len(vals) >= 5:
            result["model"] = {"name": model_name, **_summarize(vals, rng)}
            if best_prop:
                m_med = result["model"]["median_rho"]
                b_med = result["baselines"][best_prop]["median_rho"]
                m_lo = result["model"]["ci95_median"][0]
                b_hi = result["baselines"][best_prop]["ci95_median"][1]
                beats = m_med > b_med and m_lo > b_hi   # 需中位更高且 CI 完全分离
                result["verdict"] = {
                    "model_median": m_med, "baseline_median": b_med,
                    "baseline_property": best_prop,
                    "beats_baseline_strict": bool(beats),
                    "statement": (
                        "模型显著跑赢了最强的平凡基线(中位更高且 95% CI 完全分离)"
                        if beats else
                        "**模型未跑赢平凡基线**:其排序能力可被不含靶点信息的单一性质解释,"
                        "不应据此主张「模型学到了亲和力信息」"
                    ),
                }
    return result


def main(argv=None):
    ap = argparse.ArgumentParser(description="平凡基线强制报告协议")
    ap.add_argument("--eval-set", required=True, help="CSV:target,smiles,activity[,predicted]")
    ap.add_argument("--target-col", default="target")
    ap.add_argument("--smiles-col", default="smiles")
    ap.add_argument("--activity-col", default="activity")
    ap.add_argument("--model-col", default=None, help="模型预测列名(可选)")
    ap.add_argument("--model-name", default="model")
    ap.add_argument("--out", default=None, help="输出 JSON 路径")
    ap.add_argument("--min-per-target", type=int, default=10)
    a = ap.parse_args(argv)

    rep = run_protocol(a.eval_set, a.model_col, a.model_name, a.target_col,
                       a.smiles_col, a.activity_col, min_per_target=a.min_per_target)

    print("评测集: %s | 靶点 %d" % (rep["eval_set"], rep["n_targets"]))
    print("\n%-14s %10s %18s %10s %10s" % ("平凡基线", "中位 ρ", "95% CI", "正相关%", "符号 p"))
    for p, v in sorted(rep["baselines"].items(), key=lambda kv: -kv[1]["median_rho"]):
        print("%-14s %10.3f  [%.3f, %.3f] %9.0f%% %10.3g" % (
            "%s(%s)" % (p, v["label_zh"]), v["median_rho"], v["ci95_median"][0],
            v["ci95_median"][1], 100 * v["frac_positive"], v["sign_p_vs_0"]))
    if "model" in rep:
        m = rep["model"]
        print("\n%-14s %10.3f  [%.3f, %.3f] %9.0f%% %10.3g" % (
            m["name"], m["median_rho"], m["ci95_median"][0], m["ci95_median"][1],
            100 * m["frac_positive"], m["sign_p_vs_0"]))
        v = rep.get("verdict")
        if v:
            print("\n判定(最强基线=%s): %s" % (v["baseline_property"], v["statement"]))
    if a.out:
        json.dump(rep, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print("\n落盘:", a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
