# ConPLex evaluation - how to reproduce (and how ProtBert was obtained)

The ConPLex (2023) evaluation in the manuscript was run with the authors' public code and weights:

* code: `conplex-dti` 0.1.12 (pip), Python 3.10, in its own conda environment `conplex`
  (torch 2.3.0+cpu; setuptools<81)
* weights: `ConPLex_v1_BindingDB.pt` (public release, ~12 MB)
* external dependency: **ProtBert** (`Rostlab/prot_bert`), a *public* protein language model
  (5 files; `pytorch_model.bin` = 1,606 MB)

## Obtaining ProtBert (publicly available)

ProtBert is publicly distributed with its model card.  In this project it was fetched through a
public mirror endpoint (`HF_ENDPOINT=https://hf-mirror.com`); the complete `pytorch_model.bin`
(1,684,058,277 B = 1.606 GB) was downloaded and verified by size, placed in `prot_bert_local/`, and
loaded fully offline (`HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`).  Note that ProtBert's vocabulary
really does contain only 30 tokens (25 amino acids + 5 specials), so an ~81-byte `vocab.txt` is
normal, not a truncated download.

**The 1.6 GB ProtBert weights are NOT redistributed in this repository.**

## Environment fixes required (a 2023 package on a 2026 dependency ecosystem)

1. `torch` pinned to **2.3.0+cpu** - newer torch fails to initialise `c10.dll` on Windows;
2. `setuptools < 81` - >= 81 removed `pkg_resources`, which the old `lightning_fabric` imports;
3. `transformers` >= 4.5x refuses to `torch.load` the `.bin` weights under torch < 2.6
   (CVE-2025-32434); the weights were therefore converted to `model.safetensors`
   (`scripts/_conv_protbert_safetensors.py`), which keeps the locked torch upper bound intact.

## Outputs in this archive

* `minimal_data_set/conplex_eval.json` - the recorded run: median per-target rho 0.0546;
  95% CI [-0.013, 0.112]; mean 0.1007; positive 59.6%; sign p 0.185; n = 57.
* `minimal_data_set/conplex_eval_v5.json` - recomputation from the archived per-pair predictions,
  adding the Tier-2 median-split AUC and the per-target rho values.
* `conplex/conplex_results.tsv` - the raw headerless CLI output (moleculeID, proteinID, prediction);
  1,425 rows.  The original parse treated the first row as a header, so the recorded run used
  1,424 of 1,425 pairs (0.07%); re-parsing all rows leaves the median unchanged (0.0546).

`analysis_scripts/133_eval_conplex.py` carries the authors' local mirror/proxy settings; adapt or
remove them before reuse.
