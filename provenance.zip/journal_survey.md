# DTI 基准评测 / 负结果稿件 —— 实证选刊调研报告

生成时间:2026-09-24(GMT+8)
项目根:`G:\HHH\openclaw-workspace\netpharm-toolkit`
数据来源:**Europe PMC REST**(`https://www.ebi.ac.uk/europepmc/webservices/rest/search`,可达,已用)+ **OpenAlex REST**(`https://api.openalex.org/works`、`/sources`,可达,已用)
脚本:`scripts/journal_survey.py` → `journal_survey_agg.py` → `journal_survey_precision.py` → `journal_survey_targeted.py` → `journal_survey_genre.py` → `journal_survey_final.py`
原始数据:`results/journal_survey.json`(终版聚合)、`results/journal_survey_genre.json`、`results/journal_survey_precision.json`、`results/journal_survey_targeted.json`

> **方法学声明**:本报告中出现的每一个期刊名、篇数、DOI 都来自上述 API 的**实际返回**。凡未检索到或未能确认的,一律标注 `未确认`,不作推测填充。

---

## 0. 检索设计(先讲方法,便于复核)

| 层 | 内容 | 命中量 |
|---|---|---|
| 宽口径检索 | 5 组检索词(Europe PMC + OpenAlex 各 100 条/组),覆盖:DTI 评测批判 / 划分与泄漏 / 诱饵偏差与富集 / 负结果与可复现性 / 平凡基线 | 994 条(其中预印本 93,正式出版物 901) |
| 精检(TITLE 域) | 5 组标题级扫描 + 18 个候选刊逐刊标题级扫描 | 见 §1、§2 |
| 定向核验 | 15 个"本类型经典/近邻论文"题名 → OpenAlex 反查其**实际发表刊** | 15 条 |

5 组宽口径检索词:

1. `G1_dti_benchmark_critique` — DTI + benchmark/benchmarking/evaluation/pitfalls/data leakage/shortcut learning + ML/DL
2. `G2_split_leakage_optimism` — scaffold split/data leakage/random split/analog bias/activity cliff + molecular property prediction/QSAR
3. `G3_decoy_enrichment_bias` — decoy + bias/artificial enrichment/enrichment factor + virtual screening/docking
4. `G4_negative_reproducibility` — negative results/reproducibility crisis/replication/benchmark + ML/DL/AI + drug discovery/cheminformatics/molecular
5. `G5_trivial_baseline` — simple baselines/trivial baseline/simple descriptors/outperform deep learning/classical ML + QSAR/ADMET

---

## 1. ① 同类论文实际发在哪(证据:API 计数)

### 1.1 宽口径 994 条命中的期刊分布(合并大小写变体;仅正式出版物,901 条)

| # | 期刊 | 命中数 |
|---|---|---|
| 1 | Journal of Cheminformatics | 61 |
| 2 | Journal of Chemical Information and Modeling (JCIM) | 58 |
| 3 | International Journal of Molecular Sciences | 33 |
| 4 | Briefings in Bioinformatics | 31 |
| 5 | Scientific Reports | 26 |
| 6 | Pharmaceuticals (MDPI) | 25 |
| 7 | ACS Omega | 19 |
| 8 | Nature Communications | 19 |
| 9 | Molecules (MDPI) | 19 |
| 10 | PLOS ONE | 18 |
| 11 | Chemical Science | 18 |
| 12 | Bioinformatics (OUP) | 14 |
| 13 | Journal of Computer-Aided Molecular Design | 14 |
| 14 | Pharmaceutics (MDPI) | 12 |
| 15 | Computational and Structural Biotechnology Journal | 12 |
| 16 | BMC Bioinformatics | 11 |
| 17 | Frontiers in Pharmacology | 11 |
| 18 | Advanced Science | 10 |
| 19 | Frontiers in Bioinformatics | 9 |
| 20 | Nature Machine Intelligence | 9 |
| 21 | Communications Chemistry | 9 |
| 22 | npj Computational Materials | 9 |

预印本分布(不计入期刊):arXiv 41、ChemRxiv 25、bioRxiv 19、Research Square 8。
另有 **15 条** Europe PMC core 记录缺少 `journalInfo` → 记为 `UNKNOWN / not indexed`,未强行归类。

### 1.2 高精度子集:题目本身即"批判/评测/负结果/偏差"的论文(n=156)

对 994 条命中做题目正则筛选(benchmark|evaluat|pitfall|leakage|bias|reproducib|critique|critical|re-evaluat|overestimat|no better than|trivial baseline|audit|flaw|misleading|lessons|failure…),得到 156 篇**性质最接近本稿**的论文,其期刊分布如下:

| # | 期刊 | 命中最接近本稿的论文数 |
|---|---|---|
| 1 | **Journal of Chemical Information and Modeling** | **13** |
| 2 | **Journal of Cheminformatics** | **12** |
| 3 | Pharmaceuticals (MDPI) | 7 |
| 4 | Briefings in Bioinformatics | 5 |
| 5 | International Journal of Molecular Sciences | 5 |
| 6 | ACS Omega | 5 |
| 7 | IEEE/ACM Transactions on Computational Biology and Bioinformatics | 3 |
| 8 | Molecules (MDPI) | 3 |
| 9 | Nature Communications | 3 |
| 10 | Acta Pharmaceutica Sinica B | 3 |
| 11 | Drug Design, Development and Therapy | 2 |
| 12 | CPT: Pharmacometrics & Systems Pharmacology | 2 |
| 13 | Scientific Data | 2 |
| 14 | Diagnostics (MDPI) | 2 |
| 15 | npj Computational Materials | 2 |
| 16 | BMC Bioinformatics | 2 |
| 17 | Nature Methods | 2 |
| 18 | Pharmacophore | 2 |

(其余各 1 篇:Chemical Science、Advanced Science、Cell Reports Medicine、Bioinformatics、npj Digital Medicine、Biometrical Journal、European Heart Journal – Digital Health、AI Magazine、Proceedings of AAAI/ACM AIES、Electronics 等)

### 1.3 与本文**类型几乎同款**的样例论文(全部为 API 实检结果,可直接点开核对)

| 期刊 | 年份 | 论文 | DOI |
|---|---|---|---|
| Bioinformatics | 2025 | Simple controls exceed best deep learning algorithms and reveal foundation model effectiveness for predicting… | `10.1093/bioinformatics/btaf317` |
| JCIM | 2026 | Overrepresentation Bias Leads to Performance Overestimation in Blood–Brain Barrier Permeability Prediction Models | `10.1021/acs.jcim.5c02891` |
| JCIM | 2026 | The Last Mile Problem: A Critical Assessment of Physics-Based and AI Tools for Small Molecule Binding Prediction in Virtual Screening | `10.1021/acs.jcim.6c00942` |
| JCIM | 2024 | Transformers for Molecular Property Prediction: Lessons Learned from the Past Five Years | `10.1021/acs.jcim.4c00747` |
| JCIM | 2022 | DOCKSTRING: Easy Molecular Docking Yields Better Benchmarks for Ligand Design | `10.1021/acs.jcim.1c01334` |
| Journal of Cheminformatics | 2025 | UMAP-based clustering split for rigorous evaluation of AI models for virtual screening on cancer cell lines | `10.1186/s13321-025-01039-8` |
| Journal of Cheminformatics | 2023 | Combatting over-specialization bias in growing chemical databases | `10.1186/s13321-023-00716-w` |
| Journal of Cheminformatics | 2025 | Benchmarking ML in ADMET predictions: the practical impact of feature representations | `10.1186/s13321-025-01041-0` |
| Journal of Cheminformatics | 2026 | ScrambleBench: a workflow for comparative assessment of structure-based de novo generative models | `10.1186/s13321-026-01254-x` |
| Chemical Science | 2026 | Auditing widely used biomolecular benchmarks reveals systematic data inconsistencies | `10.1039/d6sc01799a` |
| Briefings in Bioinformatics | 2026 | Reliable evaluation and learning in multi-input biological association prediction | `10.1093/bib/bbag376` |
| Briefings in Bioinformatics | 2023 | The five pillars of computational reproducibility: bioinformatics and beyond | `10.1093/bib/bbad375` |
| PLOS Computational Biology | 2023 | Ten quick tips for avoiding pitfalls in multi-omics data integration analyses | `10.1371/journal.pcbi.1011224` |
| Scientific Reports | 2024 | Applying oversampling before cross-validation will lead to high bias in radiomics | `10.1038/s41598-024-62585-z` |
| ACS Omega | 2023 | Latent Biases in Machine Learning Models for Predicting Binding Affinities Using Popular Data Sets | `10.1021/acsomega.2c06781` |
| Journal of Computer-Aided Molecular Design | 2026 | Reproducibility, validation, and failure modes across classical and AI-driven molecular docking | `10.1007/s10822-026-00849-8` |
| Nature Communications | 2026 | Critical evaluation of drug response prediction models with DrEval | `10.1038/s41467-026-72903-w` |
| Nature Communications | 2025 | Data splitting to avoid information leakage with DataSAIL | `10.1038/s41467-025-58606-8` |
| npj Computational Materials | 2023 | A critical examination of robustness and generalizability of machine learning prediction of materials properties | `10.1038/s41524-023-01012-9` |
| Patterns | 2023 | Leakage and the reproducibility crisis in machine-learning-based science | `10.1016/j.patter.2023.100804` |
| Patterns | 2024 | Avoiding common machine learning pitfalls | `10.1016/j.patter.2024.101046` |
| Nature Machine Intelligence | 2025 | Resolving data bias improves generalization in binding affinity prediction | `10.1038/s42256-025-01124-5` |
| Digital Discovery | 2025 | GEOM-drugs revisited: toward more chemically accurate benchmarks for 3D molecule generation | `10.1039/d5dd00206k` |
| Bioinformatics Advances | 2024 | WAS IT A MATch I SAW? Approximate palindromes lead to overstated false match rates in benchmarks | `10.1093/bioadv/vbae052` |
| Bioinformatics | 2026 | KG-bench: benchmarking graph neural network algorithms for drug repurposing | `10.1093/bioinformatics/btag159` |

### 1.4 该类型的"奠基性论文"实际发在哪(OpenAlex 反查题名,验证刊名)

| 期刊(API 返回) | 年份 | 论文 | DOI | 被引 |
|---|---|---|---|---|
| Journal of Chemical Information and Modeling | 2018 | Most Ligand-Based Classification Benchmarks Reward Memorization Rather than Generalization | `10.1021/acs.jcim.7b00403` | 258 |
| Journal of Chemical Information and Modeling | 2019 | In Need of Bias Control: Evaluating Chemical Data for ML in Structure-Based Virtual Screening | `10.1021/acs.jcim.8b00712` | 361 |
| Journal of Chemical Information and Modeling | 2020 | LIT-PCBA: An Unbiased Data Set for Machine Learning and Virtual Screening | `10.1021/acs.jcim.0c00155` | 280 |
| Journal of Cheminformatics | 2017 | Beyond the hype: deep neural networks outperform established methods (ChEMBL benchmark) | `10.1186/s13321-017-0232-0` | 351 |
| **PLOS ONE** | 2019 | Hidden bias in the DUD-E dataset leads to misleading performance of deep learning in structure-based virtual screening | `10.1371/journal.pone.0220113` | 283 |
| Patterns | 2023 | Leakage and the reproducibility crisis in machine-learning-based science | `10.1016/j.patter.2023.100804` | 1051 |

> 注:上表 2017–2020 的 6 篇**在 2022–2026 窗口之外**,仅作为"该类型论文的家在哪"的历史证据;窗口内证据见 §1.2/§1.3。
> `10.1371/journal.pone.0220113`(DUD-E 诱饵偏差)是**本稿诱饵/富集偏差部分最直接的历史先例,且它发在 PLOS ONE**。

---

## 2. ② 候选刊适配性核查

OA / DOAJ / APC / 出版社 / 规模来自 **OpenAlex `/sources`**;`题目级批判类命中`来自 **Europe PMC**(2023–2026,`SRC:MED`)。

| 候选刊 | OA | DOAJ | APC (USD, OpenAlex) | 出版社 | 规模(works) | 2023–26 题目级批判/评测命中 | 窗口内实例(DOI) |
|---|---|---|---|---|---|---|---|
| **Journal of Chemical Information and Modeling** | False | False | 4500 | American Chemical Society | 9,883 | **96** | `10.1021/acs.jcim.5c02891`、`10.1021/acs.jcim.6c00942`、`10.1021/acs.jcim.4c00747` |
| **Journal of Cheminformatics** | True | True | 2390 | BioMed Central | 1,896 | 18 | `10.1186/s13321-025-01039-8`、`10.1186/s13321-023-00716-w`、`10.1186/s13321-025-01041-0` |
| **Bioinformatics** | True | True | 3989 | Oxford University Press | 19,827 | **77** | `10.1093/bioinformatics/btaf317`(简单对照超越最优深度学习)、`10.1093/bioinformatics/btae618` |
| **Briefings in Bioinformatics** | True | True | 3885 | Oxford University Press | 5,949 | **119** | `10.1093/bib/bbad375`、`10.1093/bib/bbag376` |
| **Bioinformatics Advances** | True | True | 2726 | Oxford University Press | 1,154 | 35 | `10.1093/bioadv/vbae052`、`10.1093/bioadv/vbaf071` |
| **Briefings in Functional Genomics** | False | False | 3700(注:OA=False,数据自相矛盾) | Oxford University Press | 790 | **1**(证据极弱) | `10.1093/bfgp/elae039` |
| **BMC Bioinformatics** | True | True | 2990 | BioMed Central | 13,275 | 31 | `10.1186/s12859-026-06376-5` |
| **PLOS Computational Biology** | True | True | 3043 | Public Library of Science | 13,053 | **149** | `10.1371/journal.pcbi.1011224`(pitfalls 教程) |
| **PLOS ONE** | True | True | 2382 | Public Library of Science | 342,374 | 449(泛) | **出版社政策明确接收负结果**(见下);历史先例 `10.1371/journal.pone.0220113` |
| **Scientific Reports** | True | True | 2690 | Nature Portfolio | 314,267 | 875(泛) | `10.1038/s41598-024-62585-z`(CV 前过采样→高偏倚) |
| **Patterns** | True | True | 4900 | Elsevier BV | 1,000 | 20 | `10.1016/j.patter.2023.100804`(1051 引)、`10.1016/j.patter.2024.101046` |
| **Digital Discovery** | True | True | **null(未确认)** | Royal Society of Chemistry | 1,269 | 6 | `10.1039/d5dd00206k`、`10.1039/d3dd00175j` |
| **Molecular Systems Biology** | True | True | 7990 | Springer Nature | 1,670 | 5 | `10.1038/s44320-024-00069-y`(化学基因组筛选偏倚校正) |
| **Nature Machine Intelligence**(对照) | False | False | 12690 | Nature Portfolio | 1,306 | 4 | `10.1038/s42256-025-01124-5` |
| **Machine Learning: Science and Technology** | True | True | 3000 | IOP Publishing | 1,488 | **0** | 未确认(可能是索引覆盖问题,非确证无) |
| **Frontiers in Bioinformatics** | True | True | 3077 | Frontiers Media | 826 | 14 | `10.3389/fbinf.2026.1844838`、`10.3389/fbinf.2023.1248732` |
| **Frontiers in Pharmacology** | True | True | 3801 | Frontiers Media | 32,413 | 33 | `10.3389/fphar.2025.1599048`(重评估) |
| **Frontiers in Genetics** | True | True | 3801 | Frontiers Media | 17,205 | 30 | `10.3389/fgene.2025.1618891` |

### 2.1 出版社级"纯计算/无湿验证"政策门槛核查

| 出版社/刊 | 结论 | 证据 |
|---|---|---|
| **PLOS(PUB)** | ✅ **明确接收负结果**(查到原文) | PLOS ONE 出版标准原文:"**Studies reporting negative results** — In keeping with our mission to publish all valid research, **we consider negative and null results**." 来源 `https://journals.plos.org/plosone/s/criteria-for-publication`(2026-09-23 抓取)。该页同时明列接收 methods/software/databases/tools 类型;**未**发现要求湿实验验证的条款 |
| **Frontiers** | ⚠️ **证据冲突,不可一概而论** | ①**本方一手证据**:课题组 MR 稿在出版社层面被拒,理由是生物信息学分析缺独立验证(用户提供)。②**但本次 API 证据不支持"全系拒绝纯计算"**:Frontiers in Bioinformatics 有 14 篇窗口内 benchmark/评测论文、Frontiers in Pharmacology 33 篇、Frontiers in Genetics 30 篇,其中如 `10.3389/fbinf.2026.1844838` 为纯计算的去污染基准评测。→ 该门槛**看起来是栏目/体裁特异(MR、纯关联分析)**,**是否适用于基准批判稿 → 未确认**。③Frontiers 政策页未抓到可引用的"计算验证"条款原文 → 该条**未确认** |
| **OUP、ACS、RSC、Elsevier(Patterns)、BMC、Springer Nature、IOP** | `未确认` | 政策页抓取失败:OUP 返回 403(Cloudflare 拦截),Nature/Scientific Reports 与 BMC 出现重定向环。**未获得可引用的政策原文**,故不作"有/无门槛"的断言。可替代证据是**行为证据**(§2 表中"窗口内实例"列:这些刊实际发表了同类稿件) |

---

## 3. ③ 推荐阶梯

### 🚀 冲刺(stretch)

1. **Patterns**(Cell Press / Elsevier,OA,APC 4,900)
   理由:该刊发表了本类型的**标杆文献** `10.1016/j.patter.2023.100804`(ML 泄漏与可复现性危机,被引 1051)与 `10.1016/j.patter.2024.101046`(避免常见 ML 陷阱)。"数据科学方法论批判 + 基准评估"正是其核心范围。
   风险:需要把叙事从"DTI 领域"抬升到"分子 ML 评测方法论"层面;规模小(works ~1000)故门槛实际偏高。
2. **Nature Machine Intelligence**(对照项,APC 12,690,非 OA/非 DOAJ)
   理由:窗口内有 `10.1038/s42256-025-01124-5`(binding affinity 偏倚)。**仅作对照**;对"负结果 + 无新模型"的稿件新颖性门槛极高。

### ✅ 现实(主力投稿区)

3. **Journal of Cheminformatics**(OA,APC 2,390;BMC)——**首选现实目标**
   理由:高精度子集中**第 2 名(12 篇)**;窗口内直接同款证据密集(`10.1186/s13321-025-01039-8` 严谨评测用划分、`10.1186/s13321-023-00716-w` 过专化偏倚、`10.1186/s13321-025-01041-0` ADMET 基准)。OA、APC 在候选池中偏低。
4. **Journal of Chemical Information and Modeling (JCIM)**(非 OA,APC 4,500)
   理由:高精度子集中**第 1 名(13 篇)**;本类型三大奠基文献(Wallach&Heifets 2018、Sieg 2019 偏倚控制、LIT-PCBA 2020)全在此刊;窗口内还有 `10.1021/acs.jcim.5c02891`(过表示偏倚→性能高估,与本稿"平凡基线被高估"几乎同题)。
   风险:**hybrid/订阅制**,非 OA 路径需注意基金 OA 要求(具体费用结构 `未确认`)。
5. **Bioinformatics**(OUP,OA,APC 3,989)
   理由:窗口内存在**最接近本稿的单一实例** `10.1093/bioinformatics/btaf317`("简单对照超越最优深度学习算法")——正面对应"平凡单描述符基线"论点;另有 `10.1093/bioinformatics/btag159`(benchmark)、`10.1093/bioinformatics/btae618`(系统性偏倚)。
6. **Briefings in Bioinformatics**(OUP,OA,APC 3,885)——偏综述/benchmark 调查,窗口命中最多(119),但**以 review/benchmark 调查为主**,纯批判短文适配度需评估。
7. **Bioinformatics Advances**(OUP,OA,APC 2,726)——APC 最低的 OUP 选项;窗口内有 `10.1093/bioadv/vbae052`("基准中被高估的假匹配率"),体裁契合,门槛低于 Bioinformatics 正刊。

### 🛟 保底(backstop)

8. **Scientific Reports**(OA,APC 2,690,卷巨大 314k)
   理由:窗口内直系同款 `10.1038/s41598-024-62585-z`(CV 前过采样→高偏倚,纯方法学批判)。
   风险:容量大、声誉一般;需保证方法学严谨度而非新颖性。
9. **PLOS ONE**(OA,APC 2,382)
   理由:**唯一查到出版政策明文接收负/null 结果的刊**;且本类型历史先例 `10.1371/journal.pone.0220113`(DUD-E 诱饵偏差)就发在此。宽口径命中 18 篇,说明 DTI 相关稿在此有稳定出口。
   风险:不评判新颖性 → 对作者声誉加成有限;需按 PLOS 报告规范补齐。
10. **BMC Bioinformatics**(OA,APC 2,990)——宽口径 11 篇、题目级 31 篇,DTI/评测稿常规出口。

### ⛔ 不建议作为主力

- **Briefings in Functional Genomics**:窗口内题目级批判命中仅 **1** 篇,行为证据极弱;且 OpenAlex 显示 `is_oa=False` 却给出 APC 3,700(数据自相矛盾)→ 适配性 `未确认`。
- **Machine Learning: Science and Technology**:题目级命中 **0** 篇 → 证据不足,不宜押注。
- **Frontiers 全系(含 Frontiers in Bioinformatics/Pharmacology/Genetics)**:本方一手证据显示存在出版社级政策门槛(MR 稿被拒),**但本次 API 证据又显示这些刊确实在发纯计算基准评测稿** → 两者冲突,门槛适用范围 `未确认`。若考虑,建议**先向编辑部发 presubmission inquiry 确认是否接收"纯计算 + 无湿验证"的基准批判稿**,再决定是否投稿。

### 🆕 A 步浮现的新候选(原候选清单之外)

| 期刊 | 为什么值得考虑 | 证据 |
|---|---|---|
| Journal of Computer-Aided Molecular Design | 宽口径 14 篇;窗口内有 `10.1007/s10822-026-00849-8`(Reproducibility, validation, and failure modes across docking) | OpenAlex + Europe PMC |
| ACS Omega | 高精度子集 5 篇;`10.1021/acsomega.2c06781`(Latent Biases…Binding Affinities)| Europe PMC |
| Chemical Science | `10.1039/d6sc01799a`(审计主流生物分子基准发现系统性数据不一致)——与本稿"基准批判"高度同题 | OpenAlex 反查 |
| npj Computational Materials | 高精度子集 2 篇;`10.1038/s41524-023-01012-9`(ML 预测稳健性/泛化性批判)| Europe PMC |
| IEEE/ACM TCBB | 高精度子集 3 篇;有 DTI 去偏(debias)评测稿 | Europe PMC |
| Scientific Data | 若把"57 靶点基准"作为数据集/基准资源包发表,这是天然出口 | Europe PMC |

---

## 4. ④ 证据分级(务必区分)

### A. 查到的证据(API 实测,可复核)

- §1 全部期刊名与计数(Europe PMC 检索返回 / OpenAlex 返回)
- §1.3、§1.4、§2 表中全部 DOI
- §2 表中 OA / DOAJ / APC / 出版社 / works 数(OpenAlex `/sources`)
- **PLOS ONE 明文接收负结果**(原文已抓取,来源 URL 见 §2.1)
- 关键反直觉发现:**Frontiers 系刊物确有发表纯计算基准评测稿**(14/33/30 篇),与"Frontiers 全系拒绝纯计算"的既有假设**不一致**

### B. 推断(有证据但属解释)

- "Frontiers 的门槛是栏目/体裁特异(MR、纯关联分析),而非全社一刀切" —— 基于其刊物实际发表的论文反推
- 推荐阶梯的排序 —— 基于命中密度 + APC + 政策证据的组合判断,非 API 直接输出

### C. 未确认(明确清单)

1. **DIGITAL DISCOVERY 的 APC**(OpenAlex `apc_usd = null`)—— `未确认`
2. **所有候选刊的稿件类型清单**(是否接受 critique / negative results 作为正式 article type)—— 作者指南页抓取失败(OUP 403;Nature/BMC 重定向环)→ `未确认`;仅能以"实际已发表同类论文"作行为证据
3. **OUP / ACS / RSC / Elsevier(Patterns)/ BMC / Springer Nature / IOP 的"纯计算无验证"政策原文** —— `未确认`(页面不可达)
4. **Briefings in Functional Genomics 的 OA/APC 状态** —— OpenAlex 自身数据矛盾(`is_oa=False` 但 `apc_usd=3700`)→ `未确认`
5. **Machine Learning: Science and Technology 是否真的不发此类稿** —— 题目级命中 0,但可能只是索引覆盖问题 → `未确认`(不等于"不发")
6. **15 条 journal=UNKNOWN 的宽口径命中** —— Europe PMC core 记录无 `journalInfo` → 未归类
7. **Frontiers 出版社政策原文** —— `未确认`(仅有一手拒稿经验 + 反向行为证据)
8. **JCIM 非 OA 路径的实际费用结构** —— `未确认`

### D. 未能使用的工具(说明局限)

- `web_search` 在本环境**不可用**(provider 未配置),故政策核查改用直接 `web_fetch`;受站点反爬限制,覆盖面有限。
- 部分站点(OUP/Nature/BMC)抓取被拦,是本报告 §4.C 未确认项的主要成因。

---

## 5. 一句话结论

**该类型论文最常去的前两名是 JCIM(13)与 Journal of Cheminformatics(12)**,紧随其后是 MDPI 系(Pharmaceuticals/IJMS/ACS Omega 等);**Bioinformatics(OUP)与 Patterns 各有"同款"标杆论文**;而 **PLOS ONE 是唯一有明文政策接收负结果的候选**。建议主线:**Journal of Cheminformatics(现实首选,OA 低成本)→ Bioinformatics / JCIM(同款先例最密)→ Patterns(冲刺)**;保底 **Scientific Reports / PLOS ONE / BMC Bioinformatics**。**Frontiers 系须先做 presubmission inquiry**,因其政策门槛的适用范围本次**未能确认**。
