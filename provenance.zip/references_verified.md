# DTI 评测论文 —— 已核实参考文献（Europe PMC 检索）

所有条目均由 Europe PMC REST API 实检命中，附实际 query 与命中的 pmid/doi。未编造任何文献。

| # | 主题 | 作者 | 标题 | 期刊 年;卷:页 | DOI / PMID |
|---|---|---|---|---|---|
| 1 | DeepPurpose：DTI 深度学习工具包 | Huang K, Fu T, Glass LM, Zitnik M, Xiao C, Sun J. | DeepPurpose: a deep learning library for drug-target interaction prediction | Bioinformatics (Oxford, England) 2021;36:5545-5547 | DOI:10.1093/bioinformatics/btaa1005 / PMID:33275143 |
| 2 | MolTrans：分子交互 Transformer | Huang K, Xiao C, Glass LM, Sun J. | MolTrans: Molecular Interaction Transformer for drug-target interaction prediction | Bioinformatics (Oxford, England) 2021;37:830-836 | DOI:10.1093/bioinformatics/btaa880 / PMID:33070179 |
| 3 | ConPLex：对比学习 DTI（蛋白语言空间） | Singh R, Sledzieski S, Bryson B, Cowen L, Berger B. | Contrastive learning in protein language space predicts interactions between drugs and protein targets | Proceedings of the National Academy of Sciences of the United States of America 2023;120:e2220778120 | DOI:10.1073/pnas.2220778120 / PMID:37289807 |
| 4 | DTI/活性预测评测系统性缺陷：真实场景基准 | Tian T, Li S, Zhang Z, Chen L, Zou Z, Zhao D, Zeng J. | Benchmarking compound activity prediction for real-world drug discovery applications | Communications chemistry 2024;7:127 | DOI:10.1038/s42004-024-01204-4 / PMID:38834746 |
| 5 | DTI 机器学习方法与数据库综述（评测现状） | Bagherian M, Sabeti E, Wang K, Sartor MA, Nikolovska-Coleska Z, Najarian K. | Machine learning approaches and databases for prediction of drug-target interaction: a survey paper | Briefings in bioinformatics 2021;22:247-269 | DOI:10.1093/bib/bbz157 / PMID:31950972 |
| 6 | 随机划分/数据泄漏导致的乐观偏差（总论） | Kapoor S, Narayanan A. | Leakage and the reproducibility crisis in machine-learning-based science | Patterns (New York, N.Y.) 2023;4:100804 | DOI:10.1016/j.patter.2023.100804 / PMID:37720327 |
| 7 | 生物医学链路预测中的数据泄漏影响 | Brière G, Stosskopf T, Loire B, Baudot A. | Benchmarking the impact of data leakage on the performance of knowledge graph embedding models for biomedical link prediction | Bioinformatics (Oxford, England) 2026;42:btag608 | DOI:10.1093/bioinformatics/btag608 / PMID:42623034 |
| 8 | 诱饵偏差：DUD-E 隐藏偏倚导致深度学习假性高表现 | Chen L, Cruz A, Ramsey S, Dickson CJ, Duca JS, Hornak V, Koes DR, Kurtzman T. | Hidden bias in the DUD-E dataset leads to misleading performance of deep learning in structure-based virtual screening | PloS one 2019;14:e0220113 | DOI:10.1371/journal.pone.0220113 / PMID:31430292 |
| 9 | 诱饵/化学数据偏倚控制（SBVS 机器学习） | Sieg J, Flachsenberg F, Rarey M. | In Need of Bias Control: Evaluating Chemical Data for Machine Learning in Structure-Based Virtual Screening | Journal of chemical information and modeling 2019;59:947-961 | DOI:10.1021/acs.jcim.8b00712 / PMID:30835112 |
| 10 | 性质匹配诱饵生成：深度学习生成 property-matched decoys | Imrie F, Bradley AR, Deane CM. | Generating property-matched decoy molecules using deep learning | Bioinformatics (Oxford, England) 2021;37:2134-2141 | DOI:10.1093/bioinformatics/btab080 / PMID:33532838 |
| 11 | 虚拟筛选早期富集度量（EF/BEDROC）的优劣 | Truchon JF, Bayly CI. | Evaluating virtual screening methods: good and bad metrics for the "early recognition" problem | Journal of chemical information and modeling 2007;47:488-508 | DOI:10.1021/ci600426e / PMID:17288412 |
| 12 | 富集型度量（power metric）的方法学评论 | Šícho M, Voršilák M, Svozil D. | Comment on "The power metric: a new statistically robust enrichment-type metric for virtual screening applications with early recovery capability" | Journal of cheminformatics 2018;10:13 | DOI:10.1186/s13321-018-0267-x / PMID:29546531 |
| 13 | 机器学习中的复现性危机 / 负结果 | Hutson M. | Artificial intelligence faces reproducibility crisis | Science (New York, N.Y.) 2018;359:725-726 | DOI:10.1126/science.359.6377.725 / PMID:29449469 |
| 14 | BindingDB 数据库（Gilson et al. 2015 更新） | Gilson MK, Liu T, Baitaluk M, Nicola G, Hwang L, Chong J. | BindingDB in 2015: A public database for medicinal chemistry, computational chemistry and systems pharmacology | Nucleic acids research 2016;44:D1045-53 | DOI:10.1093/nar/gkv1072 / PMID:26481362 |
| 15 | BindingDB 原始数据库论文 | Liu T, Lin Y, Wen X, Jorissen RN, Gilson MK. | BindingDB: a web-accessible database of experimentally determined protein-ligand binding affinities | Nucleic acids research 2007;35:D198-201 | DOI:10.1093/nar/gkl999 / PMID:17145705 |
| 16 | ChEMBL 数据库（Zdrazil et al., NAR 2024） | Zdrazil B, Felix E, Hunter F, Manners EJ, Blackshaw J, Corbett S, de Veij M, Ioannidis H, Lopez DM, Mosquera JF, Magarinos MP, Bosc N, Arcila R, Kizilören T, Gaulton A, Bento AP, Adasme MF, Monecke P, Landrum GA, Leach AR. | The ChEMBL Database in 2023: a drug discovery platform spanning multiple bioactivity data types and time periods | Nucleic acids research 2024;52:D1180-D1192 | DOI:10.1093/nar/gkad1004 / PMID:37933841 |
| 17 | ChEMBL 原始大规模生物活性数据库 | Gaulton A, Bellis LJ, Bento AP, Chambers J, Davies M, Hersey A, Light Y, McGlinchey S, Michalovich D, Al-Lazikani B, Overington JP. | ChEMBL: a large-scale bioactivity database for drug discovery | Nucleic acids research 2012;40:D1100-7 | DOI:10.1093/nar/gkr777 / PMID:21948594 |
| 18 | DAVIS 激酶数据集（Davis et al. 2011） | Davis MI, Hunt JP, Herrgard S, Ciceri P, Wodicka LM, Pallares G, Hocker M, Treiber DK, Zarrinkar PP. | Comprehensive analysis of kinase inhibitor selectivity | Nature biotechnology 2011;29:1046-1051 | DOI:10.1038/nbt.1990 / PMID:22037378 |
| 19 | pChEMBL / 活性数据标准化与质量（ChEMBL 策展） | Papadatos G, Gaulton A, Hersey A, Overington JP. | Activity, assay and target data curation and quality in the ChEMBL database | Journal of computer-aided molecular design 2015;29:885-896 | DOI:10.1007/s10822-015-9860-5 / PMID:26201396 |
| 20 | ChEMBL 生物活性数据库更新（pChEMBL 来源） | Bento AP, Gaulton A, Hersey A, Bellis LJ, Chambers J, Davies M, Krüger FA, Light Y, Mak L, McGlinchey S, Nowotka M, Papadatos G, Santos R, Overington JP. | The ChEMBL bioactivity database: an update | Nucleic acids research 2014;42:D1083-90 | DOI:10.1093/nar/gkt1031 / PMID:24214965 |
| 21 | 蛋白组规模虚拟筛选（化学空间 × 蛋白组） | Westermaier Y, Barril X, Scapozza L. | Virtual screening: an in silico tool for interlacing the chemical universe with the proteome | Methods (San Diego, Calif.) 2015;71:44-57 | DOI:10.1016/j.ymeth.2014.08.001 / PMID:25193260 |
| 22 | 蛋白组范围靶点谱计算框架（结合数据驱动） | Kim D, Muvva C, Yang JS, Kwon HC, Pan CH, Kang K, Kim T, Park KC, Park K. | A computational framework for proteome-wide target profiling of natural products: mechanistic and therapeutic insights into ginsenosides | Briefings in bioinformatics 2026;27:bbag483 | DOI:10.1093/bib/bbag483 / PMID:42716492 |
| 23 | ESM-2 蛋白语言模型（Lin et al., Science 2023） | Lin Z, Akin H, Rao R, Hie B, Zhu Z, Lu W, Smetanin N, Verkuil R, Kabeli O, Shmueli Y, Dos Santos Costa A, Fazel-Zarandi M, Sercu T, Candido S, Rives A. | Evolutionary-scale prediction of atomic-level protein structure with a language model | Science (New York, N.Y.) 2023;379:1123-1130 | DOI:10.1126/science.ade2574 / PMID:36927031 |
| 24 | ProtTrans/ProtBert 蛋白语言模型（Elnaggar et al.） | Elnaggar A, Heinzinger M, Dallago C, Rehawi G, Wang Y, Jones L, Gibbs T, Feher T, Angerer C, Steinegger M, Bhowmik D, Rost B. | ProtTrans: Toward Understanding the Language of Life Through Self-Supervised Learning | IEEE transactions on pattern analysis and machine intelligence 2022;44:7112-7127 | DOI:10.1109/tpami.2021.3095381 / PMID:34232869 |
| 25 | EquiBind：几何深度学习蛋白-配体结合预测 | Li Y, Li L, Wang S, Tang X. | EQUIBIND: A geometric deep learning-based protein-ligand binding prediction method | Drug discoveries & therapeutics 2023;17:363-364 | DOI:10.5582/ddt.2023.01063 / PMID:37766553 |
| 26 | PIGNet：物理信息深度学习 DTI/结合亲和力 | Moon S, Zhung W, Yang S, Lim J, Kim WY. | PIGNet: a physics-informed deep learning model toward generalized drug-target interaction predictions | Chemical science 2022;13:3661-3673 | DOI:10.1039/d1sc06946b / PMID:35432900 |
| 27 | Therapeutics Data Commons 相关基准（Nature Chem Biol） | Huang K, Fu T, Gao W, Zhao Y, Roohani Y, Leskovec J, Coley CW, Xiao C, Sun J, Zitnik M. | Artificial intelligence foundation for therapeutic science | Nature chemical biology 2022;18:1033-1036 | DOI:10.1038/s41589-022-01131-2 / PMID:36131149 |
| 28 | 非特异性/泛筛干扰化合物（PAINS 子结构过滤） | Baell JB, Holloway GA. | New substructure filters for removal of pan assay interference compounds (PAINS) from screening libraries and for their exclusion in bioassays | Journal of medicinal chemistry 2010;53:2719-2740 | DOI:10.1021/jm901137j / PMID:20131845 |
| 29 | 类药性概念与分子性质-效力权衡（MW 相关） | Leeson PD, Springthorpe B. | The influence of drug-like concepts on decision-making in medicinal chemistry | Nature reviews. Drug discovery 2007;6:881-890 | DOI:10.1038/nrd2445 / PMID:17971784 |
| — | DrugBAN：双线性注意力 DTI 模型（2022, Nature Machine Intelligence） | NOT_FOUND | — | — | NOT_FOUND |

## 检索溯源（实际 query → 命中）

1. **DeepPurpose：DTI 深度学习工具包**
   - query: `TITLE:"DeepPurpose" AND TITLE:"drug-target interaction"`
   - 命中: PMID 33275143 | DOI 10.1093/bioinformatics/btaa1005
2. **MolTrans：分子交互 Transformer**
   - query: `TITLE:"MolTrans"`
   - 命中: PMID 33070179 | DOI 10.1093/bioinformatics/btaa880
3. **ConPLex：对比学习 DTI（蛋白语言空间）**
   - query: `TITLE:"Contrastive learning in protein language space predicts interactions between drugs and protein targets"`
   - 命中: PMID 37289807 | DOI 10.1073/pnas.2220778120
4. **DTI/活性预测评测系统性缺陷：真实场景基准**
   - query: `TITLE:"Benchmarking compound activity prediction for real-world drug discovery applications"`
   - 命中: PMID 38834746 | DOI 10.1038/s42004-024-01204-4
5. **DTI 机器学习方法与数据库综述（评测现状）**
   - query: `AUTH:"Bagherian" AND TITLE:"Machine learning approaches and databases for prediction of drug-target interaction"`
   - 命中: PMID 31950972 | DOI 10.1093/bib/bbz157
6. **随机划分/数据泄漏导致的乐观偏差（总论）**
   - query: `TITLE:"Leakage and the reproducibility crisis in machine-learning-based science"`
   - 命中: PMID 37720327 | DOI 10.1016/j.patter.2023.100804
7. **生物医学链路预测中的数据泄漏影响**
   - query: `data leakage duplicate compounds machine learning model evaluation overestimate`
   - 命中: PMID 42623034 | DOI 10.1093/bioinformatics/btag608
8. **诱饵偏差：DUD-E 隐藏偏倚导致深度学习假性高表现**
   - query: `TITLE:"Hidden bias in the DUD-E dataset leads to misleading performance of deep learning in structure-based virtual screening"`
   - 命中: PMID 31430292 | DOI 10.1371/journal.pone.0220113
9. **诱饵/化学数据偏倚控制（SBVS 机器学习）**
   - query: `TITLE:"In Need of Bias Control: Evaluating Chemical Data for Machine Learning in Structure-Based Virtual Screening"`
   - 命中: PMID 30835112 | DOI 10.1021/acs.jcim.8b00712
10. **性质匹配诱饵生成：深度学习生成 property-matched decoys**
   - query: `TITLE:"decoy" AND TITLE:"deep learning" AND virtual screening`
   - 命中: PMID 33532838 | DOI 10.1093/bioinformatics/btab080
11. **虚拟筛选早期富集度量（EF/BEDROC）的优劣**
   - query: `TITLE:"Evaluating virtual screening methods: good and bad metrics for the early recognition problem"`
   - 命中: PMID 17288412 | DOI 10.1021/ci600426e
12. **富集型度量（power metric）的方法学评论**
   - query: `TITLE:"enrichment" AND TITLE:"virtual screening" AND metric comparison`
   - 命中: PMID 29546531 | DOI 10.1186/s13321-018-0267-x
13. **机器学习中的复现性危机 / 负结果**
   - query: `TITLE:"Artificial intelligence faces reproducibility crisis"`
   - 命中: PMID 29449469 | DOI 10.1126/science.359.6377.725
14. **BindingDB 数据库（Gilson et al. 2015 更新）**
   - query: `TITLE:"BindingDB in"`
   - 命中: PMID 26481362 | DOI 10.1093/nar/gkv1072
15. **BindingDB 原始数据库论文**
   - query: `AUTH:"Gilson" AND TITLE:"BindingDB"`
   - 命中: PMID 17145705 | DOI 10.1093/nar/gkl999
16. **ChEMBL 数据库（Zdrazil et al., NAR 2024）**
   - query: `ChEMBL database in 2023 a drug discovery platform`
   - 命中: PMID 37933841 | DOI 10.1093/nar/gkad1004
17. **ChEMBL 原始大规模生物活性数据库**
   - query: `ChEMBL: a large-scale bioactivity database for drug discovery`
   - 命中: PMID 21948594 | DOI 10.1093/nar/gkr777
18. **DAVIS 激酶数据集（Davis et al. 2011）**
   - query: `TITLE:"Comprehensive analysis of kinase inhibitor selectivity"`
   - 命中: PMID 22037378 | DOI 10.1038/nbt.1990
19. **pChEMBL / 活性数据标准化与质量（ChEMBL 策展）**
   - query: `TITLE:"Activity, assay and target data curation and quality in the ChEMBL database"`
   - 命中: PMID 26201396 | DOI 10.1007/s10822-015-9860-5
20. **ChEMBL 生物活性数据库更新（pChEMBL 来源）**
   - query: `TITLE:"The ChEMBL bioactivity database: an update"`
   - 命中: PMID 24214965 | DOI 10.1093/nar/gkt1031
21. **蛋白组规模虚拟筛选（化学空间 × 蛋白组）**
   - query: `TITLE:"proteome" AND TITLE:"virtual screening"`
   - 命中: PMID 25193260 | DOI 10.1016/j.ymeth.2014.08.001
22. **蛋白组范围靶点谱计算框架（结合数据驱动）**
   - query: `proteome-wide compound protein interaction prediction dataset large scale`
   - 命中: PMID 42716492 | DOI 10.1093/bib/bbag483
23. **ESM-2 蛋白语言模型（Lin et al., Science 2023）**
   - query: `TITLE:"Evolutionary-scale prediction of atomic-level protein structure with a language model"`
   - 命中: PMID 36927031 | DOI 10.1126/science.ade2574
24. **ProtTrans/ProtBert 蛋白语言模型（Elnaggar et al.）**
   - query: `TITLE:"ProtTrans"`
   - 命中: PMID 34232869 | DOI 10.1109/tpami.2021.3095381
25. **EquiBind：几何深度学习蛋白-配体结合预测**
   - query: `TITLE:"EquiBind"`
   - 命中: PMID 37766553 | DOI 10.5582/ddt.2023.01063
26. **PIGNet：物理信息深度学习 DTI/结合亲和力**
   - query: `TITLE:"PIGNet"`
   - 命中: PMID 35432900 | DOI 10.1039/d1sc06946b
27. **Therapeutics Data Commons 相关基准（Nature Chem Biol）**
   - query: `AUTH:"Huang K" AND "therapeutic science" AND "machine learning"`
   - 命中: PMID 36131149 | DOI 10.1038/s41589-022-01131-2
28. **非特异性/泛筛干扰化合物（PAINS 子结构过滤）**
   - query: `TITLE:"New substructure filters for removal of pan assay interference compounds (PAINS)"`
   - 命中: PMID 20131845 | DOI 10.1021/jm901137j
29. **类药性概念与分子性质-效力权衡（MW 相关）**
   - query: `TITLE:"The influence of drug-like concepts on decision-making in medicinal chemistry"`
   - 命中: PMID 17971784 | DOI 10.1038/nrd2445

**NOT_FOUND — DrugBAN：双线性注意力 DTI 模型（2022, Nature Machine Intelligence）**
- 尝试过的 queries: TITLE:"DrugBAN"; DOI:"10.1038/s42256-022-00605-1"; TITLE:"bilinear attention network with domain adaptation"; "Interpretable bilinear attention network"; TITLE:"DrugBAN" OR ABSTRACT:"DrugBAN"; DrugBAN bilinear attention drug target interaction
- 说明: Europe PMC 未收录该原始论文。原因：DrugBAN 发表于 Nature Machine Intelligence，该刊未被 PubMed/MEDLINE 或 Europe PMC 收录，故按 PMID/DOI/标题检索均无原始记录（仅返回引用它的二次文献，不能充当原始引用）。按要求标记 NOT_FOUND，未用相近文献冒充。

