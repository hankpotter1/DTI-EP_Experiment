# -*- coding: utf-8 -*-
"""
扩展 ⑥:在 57 靶点大评测集上跑多模型基准(与 3 靶点、20 靶点同判据,构成规模阶梯)
"""
import csv
import json
import os
import random
import sys
import traceback

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
EVAL = os.path.join(RES, "bench_eval_set_large.csv")
random.seed(20260921)

rows = list(csv.DictReader(open(EVAL, encoding="utf-8-sig")))
by_t, seq_of, cls_of = {}, {}, {}
for r in rows:
    by_t.setdefault(r["target"], []).append(r)
    seq_of[r["target"]] = r["sequence"]
    cls_of[r["target"]] = r["cls"]
targets = sorted(by_t)
print("评测集: %d 靶点, %d 配体" % (len(targets), len(rows)), flush=True)

pairs = []
for t in targets:
    own = by_t[t]
    for r in own:
        pairs.append((t, r["molecule_chembl_id"], float(r["pchembl"]), 1, r["smiles"]))
    others = [r for u in targets if u != t for r in by_t[u]]
    for r in random.sample(others, min(25, len(others))):
        pairs.append((t, r["molecule_chembl_id"], float(r["pchembl"]), 0, r["smiles"]))
print("配对数: %d" % len(pairs), flush=True)

MODELS = [
    ("mpnn_cnn_bindingdb", "MPNN", "CNN"),
    ("cnn_cnn_bindingdb", "CNN", "CNN"),
    ("morgan_cnn_bindingdb", "Morgan", "CNN"),
    ("transformer_cnn_bindingdb", "Transformer", "CNN"),
    ("morgan_aac_bindingdb", "Morgan", "AAC"),
    ("daylight_aac_bindingdb", "Daylight", "AAC"),
]

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model
from sklearn.metrics import roc_auc_score
from scipy.stats import spearmanr

results = []
for model_name, drug_enc, tgt_enc in MODELS:
    print("\n=== %s ===" % model_name, flush=True)
    try:
        path = download_pretrained_model(model_name)
        model = DTI.model_pretrained(path)
        cfg = getattr(model, "config", {}) or {}
        drug_enc = cfg.get("drug_encoding", drug_enc)
        tgt_enc = cfg.get("target_encoding", tgt_enc)
    except Exception as e:
        print("  加载失败: %s" % str(e)[:140], flush=True)
        continue
    try:
        df = utils.data_process(X_drug=[p[4] for p in pairs], X_target=[seq_of[p[0]] for p in pairs],
                                y=[1.0] * len(pairs), drug_encoding=drug_enc,
                                target_encoding=tgt_enc, split_method="no_split")
        preds = [float(x) for x in model.predict(df)]
    except Exception as e:
        print("  推理失败: %s" % str(e)[:140], flush=True)
        traceback.print_exc(limit=2)
        continue
    print("  完成 %d 对打分" % len(preds), flush=True)

    idx_by_t = {}
    for i, p in enumerate(pairs):
        idx_by_t.setdefault(p[0], []).append(i)

    rho_each, auc2_each, auc1_each, rho_cls = [], [], [], {}
    for t in targets:
        ii = idx_by_t[t]
        own = [i for i in ii if pairs[i][3] == 1]
        frn = [i for i in ii if pairs[i][3] == 0]
        if len(own) >= 5:
            rho, _ = spearmanr([preds[i] for i in own], [pairs[i][2] for i in own])
            rho_each.append(float(rho))
            rho_cls.setdefault(cls_of[t], []).append(float(rho))
        med = sorted(pairs[i][2] for i in own)[len(own) // 2]
        y2 = [1 if pairs[i][2] >= med else 0 for i in own]
        if len(set(y2)) == 2:
            auc2_each.append(roc_auc_score(y2, [preds[i] for i in own]))
        y1 = [1] * len(own) + [0] * len(frn)
        s1 = [preds[i] for i in own] + [preds[i] for i in frn]
        if len(set(y1)) == 2:
            auc1_each.append(roc_auc_score(y1, s1))

    r = {"model": model_name, "enc": "%s/%s" % (drug_enc, tgt_enc),
         "n_targets": len(targets), "n_pairs": len(pairs),
         "tier1_cross_auc_mean": round(sum(auc1_each) / len(auc1_each), 3) if auc1_each else None,
         "tier2_within_auc_mean": round(sum(auc2_each) / len(auc2_each), 3) if auc2_each else None,
         "tier3_spearman_mean": round(sum(rho_each) / len(rho_each), 3) if rho_each else None,
         "tier3_spearman_median": round(sorted(rho_each)[len(rho_each) // 2], 3) if rho_each else None,
         "tier3_by_class": {k: round(sum(v) / len(v), 3) for k, v in rho_cls.items()},
         "n_positive_rho": sum(1 for x in rho_each if x > 0), "n_rho": len(rho_each)}
    results.append(r)
    print("  T1=%.3f  T2=%.3f  T3=%.3f (中位 %.3f)  正ρ %d/%d" % (
        r["tier1_cross_auc_mean"], r["tier2_within_auc_mean"], r["tier3_spearman_mean"],
        r["tier3_spearman_median"], r["n_positive_rho"], r["n_rho"]), flush=True)

with open(os.path.join(RES, "multimodel_benchmark_57t.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print("\n落盘: results/multimodel_benchmark_57t.json", flush=True)
print("\n==== 汇总(57 靶点)====", flush=True)
for r in results:
    print("%-30s %-16s T1=%.3f T2=%.3f T3=%.3f" % (r["model"], r["enc"],
          r["tier1_cross_auc_mean"], r["tier2_within_auc_mean"], r["tier3_spearman_mean"]), flush=True)
