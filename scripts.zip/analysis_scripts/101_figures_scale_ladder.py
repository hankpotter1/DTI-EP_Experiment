# -*- coding: utf-8 -*-
"""
扩展 ⑦:规模阶梯图 —— 3 → 20 → 57 靶点,结论如何随评测集规模收敛
这是全篇的核心图。
"""
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"

import plotly.graph_objects as go

DARK, RED, BLUE, GREY, GREEN, ORANGE = "#2C3E50", "#E74C3C", "#2471A3", "#7F8C8D", "#1E8449", "#E67E22"
FONT = "Arial"

j3 = {r["model"]: r for r in json.load(open(os.path.join(RES, "multimodel_benchmark.json"), encoding="utf-8"))}
j20 = {r["model"]: r for r in json.load(open(os.path.join(RES, "multimodel_benchmark_20t.json"), encoding="utf-8"))}
j57 = {r["model"]: r for r in json.load(open(os.path.join(RES, "multimodel_benchmark_57t.json"), encoding="utf-8"))}

MODELS = list(j57.keys())
XS = ["3 targets\n(42 pairs)", "20 targets\n(500 ligands)", "57 targets\n(1425 ligands)"]
COLS = [RED, BLUE, GREEN, ORANGE, GREY, DARK]

# ---------- Fig: 规模阶梯 ----------
fig = go.Figure()
for i, m in enumerate(MODELS):
    ys = [j3.get(m, {}).get("tier3_spearman_mean", None),
          j20.get(m, {}).get("tier3_spearman_mean", None),
          j57.get(m, {}).get("tier3_spearman_mean", None)]
    fig.add_trace(go.Scatter(x=XS, y=ys, mode="lines+markers", name=m.replace("_bindingdb", ""),
                             line=dict(color=COLS[i], width=2.5), marker=dict(size=11)))
fig.add_hline(y=0.4, line=dict(color=GREEN, width=1.6, dash="dash"),
              annotation_text="usable ranking threshold (rho = 0.4)", annotation_position="top right")
fig.add_hline(y=0.0, line=dict(color=DARK, width=1))
fig.add_annotation(x=1.0, y=0.62, text="apparent success on a small set", showarrow=True,
                   arrowhead=2, ax=-95, ay=-25, font=dict(size=12, color=DARK), bgcolor="white")
fig.add_annotation(x=1.9, y=0.22, text="all models converge to rho ~ 0.1", showarrow=False,
                   font=dict(size=13, color=GREY, family=FONT))
fig.update_layout(template="simple_white", width=1120, height=600,
                  title=dict(text="<b>Apparent performance collapses as the evaluation set grows</b>",
                             font=dict(size=19, family=FONT)),
                  yaxis_title="Mean Spearman rho (predicted vs measured affinity)",
                  yaxis_range=[-0.3, 0.75],
                  font=dict(family=FONT, size=13),
                  margin=dict(l=80, r=40, t=80, b=90),
                  legend=dict(x=0.60, y=0.98, bgcolor="rgba(255,255,255,0.85)"))
fig.write_image(os.path.join(FIG, "fig_scale_ladder.png"), scale=3, width=1120, height=600)
fig.write_image(os.path.join(FIG, "fig_scale_ladder.pdf"), width=1120, height=600)
print("saved fig_scale_ladder", flush=True)

# ---------- 规模对比柱状 ----------
fig2 = go.Figure()
for i, m in enumerate(MODELS):
    fig2.add_trace(go.Bar(name=m.replace("_bindingdb", ""), x=XS,
                          y=[j3.get(m, {}).get("tier3_spearman_mean"),
                             j20.get(m, {}).get("tier3_spearman_mean"),
                             j57.get(m, {}).get("tier3_spearman_mean")],
                          marker_color=COLS[i]))
fig2.add_hline(y=0.4, line=dict(color=GREEN, width=1.6, dash="dash"))
fig2.add_hline(y=0.0, line=dict(color=DARK, width=1))
fig2.update_layout(template="simple_white", width=1150, height=580, barmode="group",
                   title=dict(text="<b>Model ranking ability by evaluation-set size (3 / 20 / 57 targets)</b>",
                              font=dict(size=17, family=FONT)),
                   yaxis_title="Mean Spearman rho", font=dict(family=FONT, size=12),
                   margin=dict(l=80, r=40, t=80, b=90), legend=dict(x=0.01, y=0.98))
fig2.write_image(os.path.join(FIG, "fig_scale_bars.png"), scale=3, width=1150, height=580)
fig2.write_image(os.path.join(FIG, "fig_scale_bars.pdf"), width=1150, height=580)
print("saved fig_scale_bars", flush=True)

# ---------- 图注 ----------
LEG = """# Figure legends — evaluation-set size dependence

**Figure A. Apparent model performance collapses as the evaluation set grows.**
Mean Spearman correlation between predicted and measured binding affinity for six publicly
available DTI models, evaluated with the identical three-tier protocol on three evaluation
sets: 3 targets x 14 ligands (42 pairs), 20 targets x 25 ligands (500 ligands), and
57 targets x 25 ligands (1425 ligands, seven target classes). Two models (morgan_cnn,
morgan_aac) appear to rank affinity well on the smallest set (rho = 0.60 and 0.52) but
converge to rho ~ 0.1 as the set grows. No model approaches the usable threshold (rho = 0.4)
at either of the larger evaluation sizes.

**Figure B. Same data, grouped bars.**
"""
open(os.path.join(RES, "figure_legends_scale_ladder.md"), "w", encoding="utf-8").write(LEG)
print("saved figure_legends_scale_ladder.md", flush=True)

print("\n=== 规模阶梯(排序 ρ)===", flush=True)
print("%-30s %10s %10s %10s" % ("模型", "3靶点", "20靶点", "57靶点"), flush=True)
for m in MODELS:
    print("%-30s %10s %10s %10s" % (m, j3.get(m, {}).get("tier3_spearman_mean"),
                                    j20.get(m, {}).get("tier3_spearman_mean"),
                                    j57.get(m, {}).get("tier3_spearman_mean")), flush=True)
