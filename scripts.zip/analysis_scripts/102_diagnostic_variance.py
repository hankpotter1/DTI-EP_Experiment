# -*- coding: utf-8 -*-
"""
诊断:模型在「同靶点内」的预测方差 —— 判断其失败机制
假设:预测在同靶点内近乎常数(输出靶点偏置,而非配体-靶点相互作用)

做法:在 57 靶点评测集上重跑 morgan_cnn(表现最好的模型之一),
     保存逐对预测,比较「预测的靶点内标准差」与「实测的靶点内标准差」。
"""
import csv
import json
import os
import random
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
random.seed(20260921)

rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
by_t, seq_of = {}, {}
for r in rows:
    by_t.setdefault(r["target"], []).append(r)
    seq_of[r["target"]] = r["sequence"]
targets = sorted(by_t)

# 只用各靶点自身的 25 个配体(观察靶点内行为)
pairs = [(t, r["molecule_chembl_id"], float(r["pchembl"]), r["smiles"])
         for t in targets for r in by_t[t]]
print("靶点 %d,配对 %d(仅自身配体)" % (len(targets), len(pairs)), flush=True)

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model

MODEL = "morgan_cnn_bindingdb"
model = DTI.model_pretrained(download_pretrained_model(MODEL))
cfg = getattr(model, "config", {}) or {}
drug_enc, tgt_enc = cfg.get("drug_encoding", "Morgan"), cfg.get("target_encoding", "CNN")
print("模型 %s (%s/%s)" % (MODEL, drug_enc, tgt_enc), flush=True)

df = utils.data_process(X_drug=[p[3] for p in pairs], X_target=[seq_of[p[0]] for p in pairs],
                        y=[1.0] * len(pairs), drug_encoding=drug_enc,
                        target_encoding=tgt_enc, split_method="no_split")
preds = [float(x) for x in model.predict(df)]
print("打分完成 %d" % len(preds), flush=True)

import statistics as st
from scipy.stats import spearmanr, pearsonr

recs = []
for (t, mid, pv, smi), p in zip(pairs, preds):
    recs.append({"target": t, "molecule": mid, "measured": pv, "predicted": p})

with open(os.path.join(RES, "diagnostic_within_target_variance.csv"), "w",
          encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["target", "molecule", "measured", "predicted"])
    w.writeheader()
    w.writerows(recs)

# 逐靶点统计
print("\n%-9s %8s %8s %8s %8s %8s" % ("靶点", "实测SD", "预测SD", "实测跨度", "预测跨度", "ρ"), flush=True)
sd_ratio, rho_list = [], []
for t in targets:
    sub = [r for r in recs if r["target"] == t]
    ms = [r["measured"] for r in sub]
    ps = [r["predicted"] for r in sub]
    sd_m = st.pstdev(ms)
    sd_p = st.pstdev(ps)
    rho, _ = spearmanr(ps, ms)
    rho_list.append(rho)
    sd_ratio.append(sd_p / sd_m if sd_m else float("nan"))
    print("%-9s %8.3f %8.3f %8.2f %8.2f %8.3f" % (
        t, sd_m, sd_p, max(ms) - min(ms), max(ps) - min(ps), rho), flush=True)

print("\n=== 汇总 ===", flush=True)
print("  预测 SD / 实测 SD 的比值: 中位 %.3f  平均 %.3f" % (
    st.median(sd_ratio), sum(sd_ratio) / len(sd_ratio)), flush=True)
print("  靶点内平均实测跨度: %.2f pChEMBL" % (
    sum(max(r["measured"] for r in recs if r["target"] == t) -
        min(r["measured"] for r in recs if r["target"] == t) for t in targets) / len(targets)), flush=True)
print("  靶点内平均预测跨度: %.3f" % (
    sum(max(r["predicted"] for r in recs if r["target"] == t) -
        min(r["predicted"] for r in recs if r["target"] == t) for t in targets) / len(targets)), flush=True)
print("  靶点内平均 ρ: %.3f  中位 %.3f" % (sum(rho_list) / len(rho_list), st.median(rho_list)), flush=True)

# 预测值在靶点间的离散 vs 靶点内离散
allp = [r["predicted"] for r in recs]
btw = st.pstdev([sum(r["predicted"] for r in recs if r["target"] == t) /
                 len([r for r in recs if r["target"] == t]) for t in targets])
print("\n=== 方差分解(关键)===", flush=True)
print("  预测值总体 SD        : %.3f" % st.pstdev(allp), flush=True)
print("  靶点间均值 SD        : %.3f  <-- 输出主要随靶点变化" % btw, flush=True)
print("  靶点内 SD(平均)      : %.3f  <-- 配体带来的变化很小" % (sum(st.pstdev([r["predicted"] for r in recs if r["target"] == t]) for t in targets) / len(targets)), flush=True)
print("  靶点间方差占比       : %.1f%%" % (btw ** 2 / (st.pstdev(allp) ** 2) * 100), flush=True)
