# -*- coding: utf-8 -*-
"""
阳性对照:用**完全相同的评测代码**在模型主场(DAVIS)上测量
  对照 A:DAVIS 域内数据  -> 若 ρ 高,证明评测代码可测出真信号
  对照 B:打乱实测标签    -> 若 ρ≈0,证明指标不会凭空产生相关性
两者合起来排除"评测流程本身失效"这一解释。
"""
import csv
import json
import os
import random
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
random.seed(20260922)

from DeepPurpose import DTI, utils, dataset
from DeepPurpose.utils import download_pretrained_model
from scipy.stats import spearmanr

print("=== 载入 DAVIS(模型主场)===", flush=True)
X_d, X_t, y = dataset.load_process_DAVIS(path="./data", convert_to_log=True)
print("  DAVIS 配对: %d" % len(y), flush=True)

# 按蛋白序列分组 -> 每个蛋白取至多 25 个配体(让设计与我们的评测集同构)
by_prot = {}
for d, t, v in zip(X_d, X_t, y):
    by_prot.setdefault(t, []).append((d, float(v)))
prots = [p for p, v in by_prot.items() if len(v) >= 15]
random.shuffle(prots)
prots = prots[:40]
sel = []
for p in prots:
    vs = by_prot[p]
    vs = random.sample(vs, min(25, len(vs)))
    for d, v in vs:
        sel.append((p, d, v))
print("  取样: %d 个蛋白 × 至多 25 配体 = %d 对" % (len(prots), len(sel)), flush=True)

MODELS = ["mpnn_cnn_bindingdb", "cnn_cnn_bindingdb", "morgan_cnn_bindingdb",
          "transformer_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb"]

results = []
for model_name in MODELS:
    print("\n=== %s ===" % model_name, flush=True)
    try:
        model = DTI.model_pretrained(download_pretrained_model(model_name))
        cfg = getattr(model, "config", {}) or {}
        de = cfg.get("drug_encoding", "Morgan")
        te = cfg.get("target_encoding", "CNN")
    except Exception as e:
        print("  加载失败:", str(e)[:120], flush=True)
        continue
    try:
        df = utils.data_process(X_drug=[s[1] for s in sel], X_target=[s[0] for s in sel],
                                y=[1.0] * len(sel), drug_encoding=de, target_encoding=te,
                                split_method="no_split")
        preds = [float(x) for x in model.predict(df)]
    except Exception as e:
        print("  推理失败:", str(e)[:120], flush=True)
        continue

    idx = {}
    for i, s in enumerate(sel):
        idx.setdefault(s[0], []).append(i)

    rhos, rhos_shuf, n_const = [], [], 0
    for p in idx:
        ii = idx[p]
        if len(ii) < 10:
            continue
        ps = [preds[i] for i in ii]
        ms = [sel[i][2] for i in ii]
        if len(set(ps)) < 2:                 # 预测在蛋白内为常数:
            n_const += 1                      # 退化,计入统计
            continue
        r, _ = spearmanr(ps, ms)
        rhos.append(float(r))
        ms2 = ms[:]
        random.shuffle(ms2)              # 打乱标签对照
        r2, _ = spearmanr(ps, ms2)
        rhos_shuf.append(float(r2))

    import statistics as st
    r = {"model": model_name, "enc": "%s/%s" % (de, te), "n_proteins": len(rhos),
         "n_constant_prediction_proteins": n_const,
         "davis_rho_mean": round(sum(rhos) / len(rhos), 3) if rhos else None,
         "davis_rho_median": round(st.median(rhos), 3) if rhos else None,
         "davis_rho_pos_frac": round(sum(1 for x in rhos if x > 0) / len(rhos), 3) if rhos else None,
         "shuffled_rho_mean": round(sum(rhos_shuf) / len(rhos_shuf), 3) if rhos_shuf else None,
         "shuffled_rho_median": round(st.median(rhos_shuf), 3) if rhos_shuf else None}
    results.append(r)
    print("  DAVIS ρ: 均值 %.3f  中位 %.3f  正相关 %.0f%%  |  打乱标签 均值 %.3f 中位 %.3f  |  常数预测蛋白 %d" % (
        r["davis_rho_mean"], r["davis_rho_median"], r["davis_rho_pos_frac"] * 100,
        r["shuffled_rho_mean"], r["shuffled_rho_median"], n_const), flush=True)

with open(os.path.join(RES, "positive_control_davis.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("\n==== 阳性对照汇总 ====", flush=True)
print("%-30s %10s %10s %10s %10s" % ("模型", "DAVIS均值", "DAVIS中位", "正相关%", "打乱对照"), flush=True)
for r in results:
    print("%-30s %10.3f %10.3f %9.0f%% %10.3f" % (
        r["model"], r["davis_rho_mean"], r["davis_rho_median"],
        r["davis_rho_pos_frac"] * 100, r["shuffled_rho_mean"]), flush=True)
print("\n对照:同一批模型在我们 57 靶点评测集上 ρ = 0.006–0.142", flush=True)
print("落盘: results/positive_control_davis.json", flush=True)
