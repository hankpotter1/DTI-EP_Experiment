# -*- coding: utf-8 -*-
"""
批判性自查 —— 验三条最可能推翻结论的问题:
  ① 蛋白序列截断:DeepPurpose 的 MAX_SEQ_PROTEIN 是多少?我们 57 个靶点有多少被截掉?
     (若截断掉关键结构域,则"域外失败"可能只是输入不完整造成的假象)
  ② 统计显著性:正相关靶点比例是否显著偏离 50%?均值/中位的自助置信区间?
     ("没有能力" vs "能力很弱" 是两个不同结论)
  ③ 小评测集"翻转"是否只是"规模"造成的 —— 用 57 靶点做子集抽样,
     看子集规模与 ρ 的关系(排除"靶点构成"这一混淆)
"""
import csv
import json
import os
import random
import sys
from collections import Counter

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"

# ---------- ① 序列截断 ----------
from DeepPurpose import DTI
import DeepPurpose.utils as U

MAXP = getattr(U, "MAX_SEQ_PROTEIN", None) or getattr(DTI, "MAX_SEQ_PROTEIN", None)
print("=== ① 蛋白序列截断 ===", flush=True)
print("  DeepPurpose MAX_SEQ_PROTEIN = %s" % MAXP, flush=True)

rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
seqlen = {}
for r in rows:
    seqlen[r["target"]] = len(r["sequence"])
lens = sorted(seqlen.values())
print("  我们 57 靶点序列长度: 最短 %d, 中位 %d, 最长 %d" % (lens[0], lens[len(lens) // 2], lens[-1]), flush=True)
if MAXP:
    over = [t for t, L in seqlen.items() if L > MAXP]
    print("  超过 MAX_SEQ_PROTEIN 的靶点: %d / %d" % (len(over), len(seqlen)), flush=True)
    if over:
        print("    ", ", ".join("%s(%d)" % (t, seqlen[t]) for t in sorted(over, key=lambda x: -seqlen[x])[:25]), flush=True)

# DAVIS 对照的序列长度
print("\n  --- DAVIS 侧序列长度(对照)---", flush=True)
try:
    from DeepPurpose import dataset
    Xd, Xt, y = dataset.load_process_DAVIS(path="./data", convert_to_log=True)
    dl = sorted({len(t) for t in Xt})
    print("  DAVIS 蛋白序列长度: 最短 %d, 中位 %d, 最长 %d (唯一数 %d)" % (
        dl[0], dl[len(dl) // 2], dl[-1], len(dl)), flush=True)
except Exception as e:
    print("  载入 DAVIS 失败:", str(e)[:80], flush=True)

# ---------- ② 统计显著性 ----------
print("\n=== ② 统计显著性 ===", flush=True)
from scipy.stats import binomtest, wilcoxon
per_target = None
diag = os.path.join(RES, "diagnostic_within_target_variance.csv")
if os.path.isfile(diag):
    from scipy.stats import spearmanr
    rec = list(csv.DictReader(open(diag, encoding="utf-8-sig")))
    byt = {}
    for r in rec:
        byt.setdefault(r["target"], []).append((float(r["predicted"]), float(r["measured"])))
    vals = []
    for t, v in byt.items():
        if len(v) >= 10:
            rho, _ = spearmanr([a for a, _ in v], [b for _, b in v])
            if rho == rho:
                vals.append(float(rho))
    per_target = vals
    pos = sum(1 for x in vals if x > 0)
    n = len(vals)
    bt = binomtest(pos, n, 0.5)
    print("  [morgan_cnn, 57 靶点] 正相关 %d/%d, 符号检验 p = %.4g" % (pos, n, bt.pvalue), flush=True)
    print("    中位 ρ = %.3f,  均值 ρ = %.3f" % (sorted(vals)[n // 2], sum(vals) / n), flush=True)
    # 自助置信区间
    random.seed(1)
    bs_med, bs_mean = [], []
    for _ in range(5000):
        s = [random.choice(vals) for _ in range(n)]
        bs_med.append(sorted(s)[n // 2])
        bs_mean.append(sum(s) / n)
    bs_med.sort(); bs_mean.sort()
    print("    中位 ρ 95%% 自助CI: [%.3f, %.3f]" % (bs_med[125], bs_med[-125]), flush=True)
    print("    均值 ρ 95%% 自助CI: [%.3f, %.3f]" % (bs_mean[125], bs_mean[-125]), flush=True)
    w = wilcoxon(vals)
    print("    Wilcoxon 符号秩检验(对 0): p = %.4g" % w.pvalue, flush=True)

# ---------- ③ 子集抽样:规模 vs 靶点构成 ----------
print("\n=== ③ 子集抽样(用 morgan_cnn 的逐靶点 ρ,排除靶点构成混淆)===", flush=True)
if per_target:
    random.seed(7)
    for k in (3, 5, 10, 20, 40, 57):
        if k > len(per_target):
            continue
        meds = []
        for _ in range(2000 if k < 40 else 500):
            s = random.sample(per_target, k)
            meds.append(sorted(s)[k // 2])
        meds.sort()
        print("  子集 %2d 个靶点: 中位ρ 的分布 5%%=%.3f  中位=%.3f  95%%=%.3f  (≥0.4 的比例 %.1f%%)" % (
            k, meds[int(len(meds) * .05)], meds[len(meds) // 2], meds[int(len(meds) * .95)],
            sum(1 for x in meds if x >= 0.4) / len(meds) * 100), flush=True)
