# -*- coding: utf-8 -*-
"""
补验:① 截断靶点 vs 未截断靶点的 ρ 差异(判断截断是否解释失败)
     ② 原始 3 靶点在随机子集分布中的分位(判断"小评测集"说法是否成立)
"""
import csv
import os
import random
import sys
from statistics import median

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
from scipy.stats import spearmanr, mannwhitneyu

rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
seqlen = {r["target"]: len(r["sequence"]) for r in rows}

diag = list(csv.DictReader(open(os.path.join(RES, "diagnostic_within_target_variance.csv"), encoding="utf-8-sig")))
byt = {}
for r in diag:
    byt.setdefault(r["target"], []).append((float(r["predicted"]), float(r["measured"])))
rho = {}
for t, v in byt.items():
    if len(v) >= 10:
        r, _ = spearmanr([a for a, _ in v], [b for _, b in v])
        if r == r:
            rho[t] = float(r)

TRUNC = 1000
tr = [t for t in rho if seqlen.get(t, 0) > TRUNC]
nt = [t for t in rho if seqlen.get(t, 0) <= TRUNC]
print("=== ① 序列截断(>%d aa)对 ρ 的影响 ===" % TRUNC, flush=True)
print("  被截断靶点 %d 个: 中位 ρ = %.3f" % (len(tr), median([rho[t] for t in tr])), flush=True)
print("  未截断靶点 %d 个: 中位 ρ = %.3f" % (len(nt), median([rho[t] for t in nt])), flush=True)
u = mannwhitneyu([rho[t] for t in tr], [rho[t] for t in nt])
print("  Mann-Whitney p = %.3f  -> %s" % (u.pvalue, "无显著差异" if u.pvalue > 0.05 else "有显著差异"), flush=True)
print("  被截断靶点明细:", ", ".join("%s(%.2f)" % (t, rho[t]) for t in sorted(tr, key=lambda x: -seqlen[x])), flush=True)

print("\n=== ② 原始 3 靶点在随机子集分布中的位置 ===", flush=True)
orig = ["CA2", "ABL1", "PTGS2"]
have = [t for t in orig if t in rho]
print("  原始 3 靶点逐靶点 ρ:", ", ".join("%s=%.3f" % (t, rho[t]) for t in have), flush=True)
o_mean = sum(rho[t] for t in have) / len(have)
o_med = median([rho[t] for t in have])
print("  原始 3 靶点: 均值 %.3f  中位 %.3f" % (o_mean, o_med), flush=True)

allv = list(rho.values())
random.seed(11)
sims_mean, sims_med = [], []
for _ in range(20000):
    s = random.sample(allv, 3)
    sims_mean.append(sum(s) / 3)
    sims_med.append(sorted(s)[1])
sims_mean.sort(); sims_med.sort()
p_mean = sum(1 for x in sims_mean if x >= o_mean) / len(sims_mean)
p_med = sum(1 for x in sims_med if x >= o_med) / len(sims_med)
print("  随机 3 靶点(20000 次): 均值分布 5%%=%.3f 中位=%.3f 95%%=%.3f" % (
    sims_mean[1000], sims_mean[10000], sims_mean[-1000]), flush=True)
print("  -> 原始 3 靶点均值 %.3f 的分位: 第 %.1f 百分位" % (o_mean, (1 - p_mean) * 100), flush=True)
print("     (即 %.1f%% 的随机三靶点组合会 >= 这个值)" % (p_mean * 100), flush=True)
print("  -> 原始 3 靶点中位 %.3f 的分位: %.1f%% 的随机组合会 >= 这个值" % (o_med, p_med * 100), flush=True)
print("\n  结论指向:", flush=True)
print("    若 p 很小 -> 原始 3 靶点并非'小样本运气',而是**特定靶点组合本身偏好**(选择性偏倚)", flush=True)
print("    随机三靶点的中位数 = %.3f, 与 57 靶点全集中位 %.3f 接近" % (
    sims_med[10000], median(allv)), flush=True)
