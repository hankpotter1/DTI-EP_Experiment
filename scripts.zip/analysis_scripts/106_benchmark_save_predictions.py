# -*- coding: utf-8 -*-
"""
必做项的数据基础:在 57 靶点集上重跑 6 模型,**保存逐对预测**
后续所有分析(抽样曲线、激酶子集、Tier1 重构)都从这份预测导出。

输出:results/predictions_57t.csv  (target, molecule, own, measured, predicted, model)
"""
import csv
import json
import os
import random
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
EVAL = os.path.join(RES, "bench_eval_set_large.csv")
random.seed(20260921)          # 与之前保持一致,便于对比

rows = list(csv.DictReader(open(EVAL, encoding="utf-8-sig")))
by_t, seq_of = {}, {}
for r in rows:
    by_t.setdefault(r["target"], []).append(r)
    seq_of[r["target"]] = r["sequence"]
targets = sorted(by_t)

pairs = []      # (被预测靶点, 分子, 实测, 是否自身配体, smiles, 配体原生靶点)
for t in targets:
    for r in by_t[t]:
        pairs.append((t, r["molecule_chembl_id"], float(r["pchembl"]), 1, r["smiles"], t))
    others = [r for u in targets if u != t for r in by_t[u]]
    for r in random.sample(others, min(25, len(others))):
        pairs.append((t, r["molecule_chembl_id"], float(r["pchembl"]), 0, r["smiles"], r["target"]))
print("靶点 %d,配对 %d" % (len(targets), len(pairs)), flush=True)

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model

MODELS = ["mpnn_cnn_bindingdb", "cnn_cnn_bindingdb", "morgan_cnn_bindingdb",
          "transformer_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb"]

out_path = os.path.join(RES, "predictions_57t.csv")
with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["model", "target", "molecule", "is_own", "native_target", "measured", "predicted"])
    for model_name in MODELS:
        print("\n=== %s ===" % model_name, flush=True)
        try:
            model = DTI.model_pretrained(download_pretrained_model(model_name))
            cfg = getattr(model, "config", {}) or {}
            de = cfg.get("drug_encoding", "Morgan")
            te = cfg.get("target_encoding", "CNN")
        except Exception as e:
            print("  加载失败:", str(e)[:120], flush=True)
            continue
        try:
            df = utils.data_process(X_drug=[p[4] for p in pairs], X_target=[seq_of[p[0]] for p in pairs],
                                    y=[1.0] * len(pairs), drug_encoding=de,
                                    target_encoding=te, split_method="no_split")
            preds = [float(x) for x in model.predict(df)]
        except Exception as e:
            print("  推理失败:", str(e)[:120], flush=True)
            continue
        for (t, mid, meas, own, smi, nat), pr in zip(pairs, preds):
            w.writerow([model_name, t, mid, own, nat, meas, pr])
        f.flush()
        print("  已保存 %d 条预测" % len(preds), flush=True)

print("\n落盘:", out_path, flush=True)
