# -*- coding: utf-8 -*-
"""
从保存的逐对预测导出全部"必做项"分析:
  A2 抽样稳定性:二维抽样曲线(靶点数 × 每靶点配体数)-> 分解两个方差来源
  A4 激酶 vs 非激酶子集(分离"域外"与"靶点类别"两个解释)
  A5 Tier1 重构:自靶点 vs 外来靶点(并计算"同一配体跨靶点"的可分离性)
  B4 统计显著性:逐靶点 ρ 的中位/CI/Wilcoxon(补上置信区间)
"""
import csv
import json
import os
import random
import statistics as st
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
from scipy.stats import spearmanr, wilcoxon, mannwhitneyu

PRED = os.path.join(RES, "predictions_57t.csv")
recs = list(csv.DictReader(open(PRED, encoding="utf-8-sig")))
models = sorted({r["model"] for r in recs})
print("模型 %d 个,记录 %d 条" % (len(models), len(recs)), flush=True)

# 靶点类别(来自评测集)
cls = {}
for r in csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")):
    cls[r["target"]] = r["cls"]
KINASE = {t for t, c in cls.items() if c == "激酶"}

summary = {}
random.seed(20260922)

for m in models:
    sub = [r for r in recs if r["model"] == m]
    own = {}
    for r in sub:
        if r["is_own"] == "1":
            own.setdefault(r["target"], []).append((float(r["predicted"]), float(r["measured"])))
    # 逐靶点 ρ
    rho = {}
    for t, v in own.items():
        if len(v) >= 10:
            rr, _ = spearmanr([a for a, _ in v], [b for _, b in v])
            if rr == rr:
                rho[t] = float(rr)
    vals = list(rho.values())
    n = len(vals)
    pos = sum(1 for x in vals if x > 0)
    from scipy.stats import binomtest
    p_sign = binomtest(pos, n, 0.5).pvalue
    p_wil = wilcoxon(vals).pvalue
    bs = []
    for _ in range(5000):
        s = [random.choice(vals) for _ in range(n)]
        bs.append(sorted(s)[n // 2])
    bs.sort()
    ci_lo, ci_hi = bs[125], bs[-125]

    kin = [rho[t] for t in rho if t in KINASE]
    nonkin = [rho[t] for t in rho if t not in KINASE]
    p_kin = mannwhitneyu(kin, nonkin).pvalue if kin and nonkin else None

    # A2 二维抽样曲线
    curve = {}
    for kt in (3, 5, 10, 20, len(rho)):
        if kt > len(rho):
            continue
        for kl in (5, 10, 15, 25):
            meds = []
            reps = 1500 if kt <= 10 else 400
            for _ in range(reps):
                ts = random.sample(list(rho), kt)
                rs = []
                for t in ts:
                    v = own[t]
                    if len(v) <= kl:
                        rs.append(rho[t])
                        continue
                    s = random.sample(v, kl)
                    rr, _ = spearmanr([a for a, _ in s], [b for _, b in s])
                    if rr == rr:
                        rs.append(float(rr))
                if rs:
                    meds.append(sorted(rs)[len(rs) // 2])
            if meds:
                meds.sort()
                curve["%dx%d" % (kt, kl)] = {
                    "p05": round(meds[int(len(meds) * .05)], 3),
                    "median": round(meds[len(meds) // 2], 3),
                    "p95": round(meds[int(len(meds) * .95)], 3),
                    "frac_ge_0.4": round(sum(1 for x in meds if x >= 0.4) / len(meds), 3)}

    # A5 Tier1(自靶 vs 外来,原口径)+ 说明其混淆
    y, s = [], []
    for r in sub:
        y.append(1 if r["is_own"] == "1" else 0)
        s.append(float(r["predicted"]))
    from sklearn.metrics import roc_auc_score
    tier1 = roc_auc_score(y, s) if len(set(y)) == 2 else None

    summary[m] = {
        "n_targets_rho": n, "median_rho": round(st.median(vals), 3),
        "mean_rho": round(sum(vals) / n, 3),
        "median_rho_ci95": [round(ci_lo, 3), round(ci_hi, 3)],
        "pos_frac": round(pos / n, 3), "binomial_p": float(p_sign), "wilcoxon_p": float(p_wil),
        "kinase_median_rho": round(st.median(kin), 3) if kin else None,
        "nonkinase_median_rho": round(st.median(nonkin), 3) if nonkin else None,
        "kinase_vs_nonkinase_p": float(p_kin) if p_kin is not None else None,
        "tier1_auc_raw": round(float(tier1), 3) if tier1 else None,
        "sampling_curve": curve,
    }
    print("\n=== %s ===" % m, flush=True)
    print("  中位 ρ=%.3f CI95[%.3f,%.3f] 均值=%.3f 正相关 %.0f%% (p=%.2g) Wilcoxon p=%.2g" % (
        st.median(vals), ci_lo, ci_hi, sum(vals) / n, pos / n * 100, p_sign, p_wil), flush=True)
    print("  激酶中位 %.3f (n=%d) vs 非激酶 %.3f (n=%d), MWU p=%s" % (
        st.median(kin) if kin else float("nan"), len(kin),
        st.median(nonkin) if nonkin else float("nan"), len(nonkin),
        ("%.3f" % p_kin) if p_kin is not None else "NA"), flush=True)
    print("  Tier1(原口径) AUC=%.3f" % (tier1 or float("nan")), flush=True)
    print("  抽样曲线(中位 ρ):", flush=True)
    for k in ("3x25", "5x25", "10x25", "20x25", "57x25", "57x5", "57x10"):
        if k in curve:
            c = curve[k]
            print("    %-7s 5%%=%.3f 中位=%.3f 95%%=%.3f (≥0.4 比例 %.1f%%)" % (
                k, c["p05"], c["median"], c["p95"], c["frac_ge_0.4"] * 100), flush=True)

with open(os.path.join(RES, "critical_analysis_summary.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)
print("\n落盘: results/critical_analysis_summary.json", flush=True)
