# -*- coding: utf-8 -*-
"""
修正版图:抽样稳定性(替代原"规模阶梯")
  Panel A: 靶点数 vs 中位 ρ 的分布(5-95%)—— 每靶点 25 配体
  Panel B: 每靶点配体数 vs 中位 ρ 的分布 —— 固定 57 靶点
  Panel C: 参数(激酶 vs 非激酶)对比
"""
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"

import plotly.graph_objects as go
from plotly.subplots import make_subplots

S = json.load(open(os.path.join(RES, "critical_analysis_summary.json"), encoding="utf-8"))
NAMES = list(S.keys())
SHORT = [n.replace("_bindingdb", "") for n in NAMES]
COLS = ["#E74C3C", "#2471A3", "#1E8449", "#E67E22", "#7F8C8D", "#2C3E50"]
DARK, GREEN = "#2C3E50", "#1E8449"

fig = make_subplots(rows=1, cols=3,
                    subplot_titles=("<b>A. Effect of number of targets</b><br>(25 ligands/target)",
                                    "<b>B. Effect of ligands per target</b><br>(57 targets)",
                                    "<b>C. Kinase vs non-kinase</b><br>(57 targets)"))

# ---- A: 靶点数 ----
xs = [3, 5, 10, 20, 57]
for i, n in enumerate(NAMES):
    c = S[n]["sampling_curve"]
    keys = [("%dx25" % k) for k in xs]
    med = [c[k]["median"] if k in c else None for k in keys]
    lo = [c[k]["p05"] if k in c else None for k in keys]
    hi = [c[k]["p95"] if k in c else None for k in keys]
    fig.add_trace(go.Scatter(x=xs, y=hi, mode="lines", line=dict(width=0), showlegend=False,
                             hoverinfo="skip"), row=1, col=1)
    fig.add_trace(go.Scatter(x=xs, y=lo, mode="lines", line=dict(width=0), fill="tonexty",
                             fillcolor=COLS[i].replace(")", ",0.12)").replace("rgb", "rgba") if COLS[i].startswith("rgb") else None,
                             showlegend=False, hoverinfo="skip"), row=1, col=1)
    fig.add_trace(go.Scatter(x=xs, y=med, mode="lines+markers", name=SHORT[i],
                             line=dict(color=COLS[i], width=2.4), marker=dict(size=8),
                             legendgroup=SHORT[i]), row=1, col=1)

# 用填充分隔重画带(简化:改为误差线)
fig.data = tuple(t for t in fig.data if t.mode == "lines+markers" or t.mode == "lines+markers")

fig2 = go.Figure()
for i, n in enumerate(NAMES):
    c = S[n]["sampling_curve"]
    keys = [("%dx25" % k) for k in xs]
    med = [c[k]["median"] if k in c else None for k in keys]
    lo = [c[k]["p05"] if k in c else None for k in keys]
    hi = [c[k]["p95"] if k in c else None for k in keys]
    fig2.add_trace(go.Scatter(x=xs, y=med, mode="lines+markers", name=SHORT[i],
                              line=dict(color=COLS[i], width=2.6), marker=dict(size=9),
                              error_y=dict(type="data", symmetric=False,
                                           array=[h - m for h, m in zip(hi, med)],
                                           arrayminus=[m - l for m, l in zip(med, lo)],
                                           color=COLS[i], thickness=1, width=3)))
fig2.add_hline(y=0.4, line=dict(color=GREEN, width=1.6, dash="dash"),
               annotation_text="usable ranking threshold (rho = 0.4)", annotation_position="top right")
fig2.add_hline(y=0.0, line=dict(color=DARK, width=1))
fig2.update_layout(template="simple_white", width=1180, height=600,
                   title=dict(text="<b>Sampling stability: apparent performance depends on how many targets you happen to pick</b>",
                              font=dict(size=17, family="Arial")),
                   xaxis=dict(title="Number of targets sampled (25 ligands each)", type="log",
                              tickvals=xs, ticktext=[str(k) for k in xs]),
                   yaxis=dict(title="Median Spearman rho (5-95% of resamples)", range=[-0.35, 0.55]),
                   font=dict(family="Arial", size=12), margin=dict(l=80, r=40, t=90, b=70),
                   legend=dict(x=0.60, y=0.02, bgcolor="rgba(255,255,255,0.9)"))
fig2.write_image(os.path.join(FIG, "fig_sampling_stability.png"), scale=3, width=1180, height=600)
fig2.write_image(os.path.join(FIG, "fig_sampling_stability.pdf"), width=1180, height=600)
print("saved fig_sampling_stability", flush=True)

# ---- C: 激酶 vs 非激酶 ----
fig3 = go.Figure()
k = [S[n]["kinase_median_rho"] for n in NAMES]
nk = [S[n]["nonkinase_median_rho"] for n in NAMES]
fig3.add_trace(go.Bar(name="Kinase targets (n=13)", x=SHORT, y=k, marker_color="#E74C3C"))
fig3.add_trace(go.Bar(name="Non-kinase targets (n=44)", x=SHORT, y=nk, marker_color="#2471A3"))
fig3.add_hline(y=0.0, line=dict(color=DARK, width=1))
fig3.update_layout(template="simple_white", width=1050, height=540, barmode="group",
                   title=dict(text="<b>Kinase vs non-kinase: no consistent advantage</b> (Mann-Whitney p = 0.05-0.80)",
                              font=dict(size=16, family="Arial")),
                   yaxis_title="Median Spearman rho", font=dict(family="Arial", size=12),
                   margin=dict(l=80, r=40, t=80, b=110), legend=dict(x=0.02, y=0.98))
fig3.update_xaxes(tickangle=-18)
fig3.write_image(os.path.join(FIG, "fig_kinase_vs_nonkinase.png"), scale=3, width=1050, height=540)
fig3.write_image(os.path.join(FIG, "fig_kinase_vs_nonkinase.pdf"), width=1050, height=540)
print("saved fig_kinase_vs_nonkinase", flush=True)

# ---- 图注 ----
LEG = """# Figure legends - sampling stability (corrected)

**Figure S1. Sampling stability of the benchmark conclusion.**
For each of the six models, the median Spearman rho is recomputed on repeated random
subsets drawn from the 57-target evaluation set. Error bars span the 5th-95th percentile of
resamples. At 3 targets the median rho ranges from about -0.19 to +0.41 across resamples,
and 0-8% of draws reach the usable threshold (rho >= 0.4). At 20-57 targets the interval
collapses. This replaces an earlier, misleading presentation in which a three-target result
(rho = 0.60) was attributed to evaluation-set size; subsampling shows the three original
targets were a favourably selected trio rather than a typical small sample.

**Figure S2. Kinase versus non-kinase targets.**
Median rho computed separately on the 13 kinase and 44 non-kinase targets. Mann-Whitney
p-values range from 0.05 to 0.80 with no consistent direction, so the DAVIS-versus-benchmark
gap cannot be attributed to the kinase content of DAVIS alone.

**Note on Tier 1.** The cross-target AUC (raw scores, own vs foreign ligands) is 0.507-0.521
for all six models, including models with statistically significant within-target ranking
(median rho up to 0.19). Raw-score cross-target AUC therefore conflates discrimination with
cross-target calibration and is NOT used as evidence of failure in this work.
"""
open(os.path.join(RES, "figure_legends_sampling_corrected.md"), "w", encoding="utf-8").write(LEG)
print("saved figure_legends_sampling_corrected.md", flush=True)
