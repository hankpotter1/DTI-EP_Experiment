# -*- coding: utf-8 -*-
"""
高优先级项 B:把 Tier 1 重构为**配体→靶点检索指标**(尺度无关、语义明确)

设计:从评测集分层抽取 N_LIG 个配体(每个配体有其"真实靶点"),
     对每个配体与**全部 57 个靶点**打分 -> 对 57 个分数排序
     指标:Top-1 / Top-5 / Top-10 命中率、MRR(平均倒数秩)
     随机基线:Top-1 = 1/57 ≈ 1.8%,MRR = H(57)/57 ≈ 0.066

这直接回答"给定一个化合物,模型能否指出它作用于哪个靶点" —— 即中药靶点预测的实际用法。
"""
import csv
import json
import os
import random
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
N_LIG = 100
random.seed(20260922)

rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
by_t, seq_of = {}, {}
for r in rows:
    by_t.setdefault(r["target"], []).append(r)
    seq_of[r["target"]] = r["sequence"]
targets = sorted(by_t)

# 分层抽样:每靶点抽若干,凑够 N_LIG
per = max(1, N_LIG // len(targets))
probe = []
for t in targets:
    for r in random.sample(by_t[t], min(per, len(by_t[t]))):
        probe.append((r["molecule_chembl_id"], t, r["smiles"]))
probe = probe[:N_LIG]
print("检索评测: %d 个配体 × %d 个靶点 = %d 对/模型" % (len(probe), len(targets), len(probe) * len(targets)), flush=True)

# 展开成 (配体索引, 靶点) 对
pairs = []
for li, (mid, nat, smi) in enumerate(probe):
    for t in targets:
        pairs.append((li, t, smi, seq_of[t]))
print("配对数: %d" % len(pairs), flush=True)

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model

MODELS = ["mpnn_cnn_bindingdb", "cnn_cnn_bindingdb", "morgan_cnn_bindingdb",
          "transformer_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb"]

out = {}
raw_rows = []
for m in MODELS:
    print("\n=== %s ===" % m, flush=True)
    try:
        model = DTI.model_pretrained(download_pretrained_model(m))
        cfg = getattr(model, "config", {}) or {}
        de, te = cfg.get("drug_encoding", "Morgan"), cfg.get("target_encoding", "CNN")
    except Exception as e:
        print("  加载失败:", str(e)[:110], flush=True)
        continue
    try:
        df = utils.data_process(X_drug=[p[2] for p in pairs], X_target=[p[3] for p in pairs],
                                y=[1.0] * len(pairs), drug_encoding=de,
                                target_encoding=te, split_method="no_split")
        preds = [float(x) for x in model.predict(df)]
    except Exception as e:
        print("  推理失败:", str(e)[:110], flush=True)
        continue

    scores = {}
    for (li, t, _, _), p in zip(pairs, preds):
        scores.setdefault(li, {})[t] = p
        raw_rows.append([m, li, probe[li][0], probe[li][1], t, p])

    hits1 = hits5 = hits10 = 0
    rr = 0.0
    for li, (mid, nat, smi) in enumerate(probe):
        sc = scores[li]
        ranked = sorted(sc.items(), key=lambda kv: -kv[1])
        rank = [t for t, _ in ranked].index(nat) + 1
        if rank == 1:
            hits1 += 1
        if rank <= 5:
            hits5 += 1
        if rank <= 10:
            hits10 += 1
        rr += 1.0 / rank
    n = len(probe)
    out[m] = {"n_ligands": n, "n_targets": len(targets),
              "top1": round(hits1 / n, 4), "top5": round(hits5 / n, 4),
              "top10": round(hits10 / n, 4), "mrr": round(rr / n, 4)}
    print("  Top-1=%.1f%%  Top-5=%.1f%%  Top-10=%.1f%%  MRR=%.4f" % (
        hits1 / n * 100, hits5 / n * 100, hits10 / n * 100, rr / n), flush=True)

with open(os.path.join(RES, "retrieval_tier1.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
with open(os.path.join(RES, "retrieval_raw_scores.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["model", "ligand_index", "molecule", "native_target", "scored_target", "score"])
    w.writerows(raw_rows)

print("\n==== 检索指标汇总(随机基线 Top-1=1.8%%, MRR=0.066)====", flush=True)
for m, v in out.items():
    print("%-30s Top1=%6.2f%%  Top5=%6.2f%%  Top10=%6.2f%%  MRR=%.4f" % (
        m, v["top1"] * 100, v["top5"] * 100, v["top10"] * 100, v["mrr"]), flush=True)
print("落盘: results/retrieval_tier1.json", flush=True)
