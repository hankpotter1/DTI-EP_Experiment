# -*- coding: utf-8 -*-
"""
高优先级项 C + A4(均基于已保存的逐对预测,无需重跑)

C 零假设升级:把"打乱实测标签"(近乎无信息)换成**蛋白置换对照**
  · 匹配 scores:配体 vs 其**自身靶点**的分数
  · 置换 scores:同一配体 vs **其它靶点**的平均分数
  若"匹配 ρ"显著高于"置换 ρ" -> 信号确实依赖正确的靶点信息(真实)
  若两者相近 -> 所谓信号只是配体化学性质驱动(伪信号)

A4 三分解:分离"靶点类别"与"数据来源"
  DAVIS(全激酶) vs 本评测集激酶 vs 本评测集非激酶
"""
import csv
import json
import os
import statistics as st
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
from scipy.stats import spearmanr, wilcoxon

recs = list(csv.DictReader(open(os.path.join(RES, "predictions_57t.csv"), encoding="utf-8-sig")))
models = sorted({r["model"] for r in recs})
cls = {r["target"]: r["cls"] for r in csv.DictReader(
    open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig"))}
KIN = {t for t, c in cls.items() if c == "激酶"}

out = {}
print("=== C 蛋白置换对照(匹配 vs 置换)===", flush=True)
print("%-30s %10s %10s %10s %10s" % ("模型", "匹配ρ中位", "置换ρ中位", "差值", "Wilcoxon p"), flush=True)
for m in models:
    rows = [r for r in recs if r["model"] == m]
    # 每个配体在不同靶点下的分数
    bymol = {}
    for r in rows:
        bymol.setdefault(r["molecule"], []).append((r["target"], float(r["predicted"]), float(r["measured"])))
    matched, swapped = [], []
    for t in sorted({r["target"] for r in rows}):
        # 该靶点的自身配体
        own = [r for r in rows if r["is_own"] == "1" and r["target"] == t]
        ms, ss, ys = [], [], []
        for r in own:
            mid = r["molecule"]
            s_match = float(r["predicted"])
            others = [p for (tt, p, _) in bymol.get(mid, []) if tt != t]
            if not others:
                continue
            ms.append(s_match)
            ss.append(sum(others) / len(others))
            ys.append(float(r["measured"]))
        if len(ys) >= 10:
            r1, _ = spearmanr(ms, ys)
            r2, _ = spearmanr(ss, ys)
            if r1 == r1:
                matched.append(float(r1))
            if r2 == r2:
                swapped.append(float(r2))
    mm, sm = st.median(matched), st.median(swapped)
    try:
        p = wilcoxon(matched, swapped[:len(matched)]).pvalue if len(matched) == len(swapped) else None
    except Exception:
        p = None
    print("%-30s %10.3f %10.3f %10.3f %10s" % (
        m, mm, sm, mm - sm, ("%.3g" % p) if p else "NA"), flush=True)
    out.setdefault("protein_swap", {})[m] = {
        "matched_median_rho": round(mm, 3), "swapped_median_rho": round(sm, 3),
        "difference": round(mm - sm, 3),
        "wilcoxon_p_matched_vs_swapped": float(p) if p else None}

# ---- A4 三分解 ----
Dav = {r["model"]: r for r in json.load(open(os.path.join(RES, "positive_control_davis.json"), encoding="utf-8"))}
CR = json.load(open(os.path.join(RES, "critical_analysis_summary.json"), encoding="utf-8"))

print("\n=== A4 三分解:靶点类别 与 数据来源 分离 ===", flush=True)
print("%-30s %14s %14s %14s" % ("模型", "DAVIS(激酶)", "ChEMBL 激酶", "ChEMBL 非激酶"), flush=True)
for m in models:
    d = Dav.get(m, {}).get("davis_rho_median")
    k = CR.get(m, {}).get("kinase_median_rho")
    nk = CR.get(m, {}).get("nonkinase_median_rho")
    print("%-30s %14s %14s %14s" % (m, d, k, nk), flush=True)
    out.setdefault("three_way", {})[m] = {
        "davis_all_kinase": d, "chembl_kinase": k, "chembl_nonkinase": nk,
        "kinase_source_gap": round(d - k, 3) if (d is not None and k is not None) else None,
        "within_chembl_class_gap": round(k - nk, 3) if (k is not None and nk is not None) else None}

with open(os.path.join(RES, "high_priority_analyses.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("\n落盘: results/high_priority_analyses.json", flush=True)
