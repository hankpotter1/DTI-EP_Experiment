# -*- coding: utf-8 -*-
"""
高优先级项 A:阳性对照的污染问题 —— 时间外验证

逻辑:六个模型训练于 2020–2021 年的 BindingDB。若抓取 **2022 年后**发表的 ChEMBL 活性数据,
     这些数据几乎不可能进入训练集 -> 构成**干净的外部测试**。
   · 若时间外 ρ 也很高 -> 模型确有可迁移能力(DAVIS 的 0.69 不是记忆)
   · 若时间外 ρ ≈ 0   -> 支持"DAVIS 的 0.69 含记忆成分",即阳性对照只能作为管线验证
两方结果对论文都成立,故该实验风险有界。
"""
import csv
import json
import os
import sys
import time
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

CACHE = r"G:\HHH\openclaw-workspace\netpharm-toolkit\cache\temporal"
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
os.makedirs(CACHE, exist_ok=True)
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
UA = {"User-Agent": "netpharm-temporal"}
YEAR_MIN = 2022
N_PER = 25

TARGETS = [("EGFR", "CHEMBL203"), ("KDR", "CHEMBL279"), ("ABL1", "CHEMBL1862"),
           ("CDK2", "CHEMBL301"), ("JAK2", "CHEMBL2971"), ("SRC", "CHEMBL267"),
           ("ESR1", "CHEMBL206"), ("AR", "CHEMBL1871"), ("DRD2", "CHEMBL217"),
           ("ACHE", "CHEMBL220")]


def fetch(url, name, attempts=4, timeout=90):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        try:
            return json.load(open(cf, encoding="utf-8"))
        except Exception:
            os.remove(cf)
    last = None
    for k in range(attempts):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8"))
            json.dump(d, open(cf + ".tmp", "w", encoding="utf-8"))
            os.replace(cf + ".tmp", cf)
            time.sleep(0.3)
            return d
        except Exception as e:
            last = e
            time.sleep(1.2 * (k + 1))
    raise last


print("=== 抓取 %d 年后发表的活性数据 ===" % YEAR_MIN, flush=True)
lig = {}
for g, cid in TARGETS:
    try:
        d = fetch("%s/activity.json?target_chembl_id=%s&pchembl_value__gte=5&standard_relation=%%3D&document_year__gte=%d&limit=1000"
                  % (CHEMBL, cid, YEAR_MIN), "act_%s_%d.json" % (g, YEAR_MIN))
        acts = d.get("activities", [])
    except Exception as e:
        print("  %-6s 抓取失败 %s" % (g, str(e)[:50]), flush=True)
        continue
    best = {}
    for a in acts:
        try:
            yr = int(a.get("document_year") or 0)
        except Exception:
            yr = 0
        if yr < YEAR_MIN:
            continue
        mid, pv = a.get("molecule_chembl_id"), a.get("pchembl_value")
        if not mid or pv is None:
            continue
        try:
            pv = float(pv)
        except Exception:
            continue
        if mid not in best or pv > best[mid]:
            best[mid] = pv
    ordered = sorted(best.items(), key=lambda kv: -kv[1])
    if len(ordered) < 10:
        print("  %-6s 新数据不足(%d)" % (g, len(ordered)), flush=True)
        continue
    if len(ordered) >= N_PER:
        idx = [round(i * (len(ordered) - 1) / (N_PER - 1)) for i in range(N_PER)]
        sel = [ordered[i] for i in sorted(set(idx))]
    else:
        sel = ordered
    lig[g] = sel
    print("  %-6s 新配体 %3d -> 取 %2d (pChEMBL %.2f-%.2f)" % (g, len(best), len(sel), sel[-1][1], sel[0][1]), flush=True)

# SMILES
mids = sorted({m for v in lig.values() for m, _ in v})
print("\n取 SMILES: %d 个分子" % len(mids), flush=True)
smiles = {}
for i in range(0, len(mids), 20):
    try:
        d = fetch("%s/molecule.json?molecule_chembl_id__in=%s&limit=100" % (CHEMBL, ",".join(mids[i:i + 20])),
                  "mol_%05d.json" % i)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st:
                smiles[mid] = st
    except Exception as e:
        print("   [warn] 批 %d: %s" % (i, str(e)[:40]), flush=True)
print("  得 %d / %d" % (len(smiles), len(mids)), flush=True)

# 序列(用评测集里已有的)
seq_of = {}
for r in csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")):
    seq_of[r["target"]] = r["sequence"]

pairs = [(g, mid, pv, smiles[mid]) for g, v in lig.items() for mid, pv in v if mid in smiles and g in seq_of]
print("\n时间外评测对: %d" % len(pairs), flush=True)

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model
from scipy.stats import spearmanr
import statistics as st

MODELS = ["morgan_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb",
          "cnn_cnn_bindingdb", "transformer_cnn_bindingdb", "mpnn_cnn_bindingdb"]
out = {}
for m in MODELS:
    print("\n=== %s ===" % m, flush=True)
    try:
        model = DTI.model_pretrained(download_pretrained_model(m))
        cfg = getattr(model, "config", {}) or {}
        de, te = cfg.get("drug_encoding", "Morgan"), cfg.get("target_encoding", "CNN")
        df = utils.data_process(X_drug=[p[3] for p in pairs], X_target=[seq_of[p[0]] for p in pairs],
                                y=[1.0] * len(pairs), drug_encoding=de,
                                target_encoding=te, split_method="no_split")
        preds = [float(x) for x in model.predict(df)]
    except Exception as e:
        print("  失败:", str(e)[:110], flush=True)
        continue
    byt = {}
    for (g, mid, pv, _), pr in zip(pairs, preds):
        byt.setdefault(g, []).append((pr, pv))
    rhos = []
    for g, v in byt.items():
        if len(v) >= 10:
            r, _ = spearmanr([a for a, _ in v], [b for _, b in v])
            if r == r:
                rhos.append(float(r))
    med = round(st.median(rhos), 3) if rhos else None
    out[m] = {"n_targets": len(rhos), "temporal_median_rho": med,
              "pos_frac": round(sum(1 for x in rhos if x > 0) / len(rhos), 3) if rhos else None}
    print("  时间外中位 ρ = %s (n=%d, 正相关 %.0f%%)" % (
        med, len(rhos), (out[m]["pos_frac"] or 0) * 100), flush=True)

Dav = {r["model"]: r for r in json.load(open(os.path.join(RES, "positive_control_davis.json"), encoding="utf-8"))}
print("\n==== 时间外 vs 域内(DAVIS)====", flush=True)
print("%-30s %14s %14s" % ("模型", "DAVIS(域内)", "%d年后(时间外)" % YEAR_MIN), flush=True)
for m in MODELS:
    print("%-30s %14s %14s" % (m, Dav.get(m, {}).get("davis_rho_median"), out.get(m, {}).get("temporal_median_rho")), flush=True)

json.dump(out, open(os.path.join(RES, "temporal_validation.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("\n落盘: results/temporal_validation.json", flush=True)
