# -*- coding: utf-8 -*-
"""
中优先级项 2+3:重建评测集
  · 严格活性筛选:assay_type=B(binding)、target_organism=Homo sapiens、
    单一 standard_type(优先 Ki)、pchembl>=5、standard_relation "="
    (分三级回退,记录每靶点实际采用的严格程度)
  · 随机取样(自然分布),替代原来的"按效价等距取样"
  · 性质匹配诱饵:从 ChEMBL 随机分子池中,按 (MW ±25, logP ±1) 为每个真配体配一个诱饵

输出:results/bench_eval_set_strict.csv(target, molecule, is_decoy, pchembl, smiles, ...)
"""
import csv
import json
import os
import random
import sys
import time
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")
CACHE = r"G:\HHH\openclaw-workspace\netpharm-toolkit\cache\strict"
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
os.makedirs(CACHE, exist_ok=True)
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
UA = {"User-Agent": "netpharm-strict"}
N_PER = 25
random.seed(20260923)

# 沿用 57 靶点
rows0 = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
targets = {r["target"]: (r["chembl_target"], r["uniprot"], r["cls"], r["sequence"]) for r in rows0}
print("靶点 %d 个" % len(targets), flush=True)


def fetch(url, name, attempts=4, timeout=90):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        try:
            return json.load(open(cf, encoding="utf-8"))
        except Exception:
            os.remove(cf)
    last = None
    for k in range(attempts):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8"))
            json.dump(d, open(cf + ".tmp", "w", encoding="utf-8"))
            os.replace(cf + ".tmp", cf)
            time.sleep(0.3)
            return d
        except Exception as e:
            last = e
            time.sleep(1.2 * (k + 1))
    raise last


# 三级筛选(逐级放宽),记录采用级别
LEVELS = [
    ("L1_Ki_B_Human", "&standard_type=Ki&assay_type=B&target_organism=Homo+sapiens"),
    ("L2_Ki_Human", "&standard_type=Ki&target_organism=Homo+sapiens"),
    ("L3_Ki", "&standard_type=Ki"),
]

print("\n=== 严格筛选 + 随机取样 ===", flush=True)
lig, lvl_used = {}, {}
for g, (cid, acc, cls, seq) in sorted(targets.items()):
    for lname, extra in LEVELS:
        try:
            d = fetch("%s/activity.json?target_chembl_id=%s&pchembl_value__gte=5&standard_relation=%%3D%s&limit=1000"
                      % (CHEMBL, cid, extra), "act_%s_%s.json" % (g, lname))
            acts = d.get("activities", [])
        except Exception as e:
            print("  %-8s %-14s 失败 %s" % (g, lname, str(e)[:40]), flush=True)
            continue
        best = {}
        for a in acts:
            mid, pv = a.get("molecule_chembl_id"), a.get("pchembl_value")
            if not mid or pv is None:
                continue
            try:
                pv = float(pv)
            except Exception:
                continue
            if mid not in best or pv > best[mid]:
                best[mid] = pv
        if len(best) >= 15:
            sel = random.sample(sorted(best.items(), key=lambda kv: -kv[1]), min(N_PER, len(best)))
            lig[g] = sel
            lvl_used[g] = lname
            print("  %-8s %-14s 可用 %4d -> 随机取 %2d" % (g, lname, len(best), len(sel)), flush=True)
            break
    else:
        print("  %-8s 三级筛选后仍不足" % g, flush=True)

# ---- SMILES(真配体)----
def _f(v):
    """ChEMBL API 的 mw/logp 有时返回字符串,统一转 float;失败返回 None。"""
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


mids = sorted({m for v in lig.values() for m, _ in v})
print("\n真配体分子: %d,取 SMILES" % len(mids), flush=True)
smiles = {}
for i in range(0, len(mids), 20):
    try:
        d = fetch("%s/molecule.json?molecule_chembl_id__in=%s&limit=100" % (CHEMBL, ",".join(mids[i:i + 20])),
                  "mol_%05d.json" % i)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            pr = m.get("molecule_properties") or {}
            if mid and st:
                smiles[mid] = {"smiles": st, "mw": _f(pr.get("mw_freebase")), "logp": _f(pr.get("alogp"))}
    except Exception as e:
        print("   [warn] 批 %d: %s" % (i, str(e)[:40]), flush=True)
print("  得 %d / %d" % (len(smiles), len(mids)), flush=True)

# ---- 诱饵池:随机 ChEMBL 分子 ----
print("\n=== 构建诱饵池 ===", flush=True)
pool = {}
for off in range(0, 4000, 1000):
    try:
        d = fetch("%s/molecule.json?molecule_properties__mw_freebase__gte=150&molecule_properties__mw_freebase__lte=700&limit=1000&offset=%d"
                  % (CHEMBL, off), "pool_%05d.json" % off)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            pr = m.get("molecule_properties") or {}
            if mid and st and pr.get("mw_freebase") and pr.get("alogp") is not None:
                pool[mid] = {"smiles": st, "mw": float(pr["mw_freebase"]), "logp": float(pr["alogp"])}
        print("  offset %d -> 池内 %d" % (off, len(pool)), flush=True)
    except Exception as e:
        print("  [warn] offset %d: %s" % (off, str(e)[:40]), flush=True)

# ---- 为每个真配体配一个性质匹配诱饵 ----
print("\n=== 性质匹配诱饵 ===", flush=True)
known = {m for v in lig.values() for m, _ in v}
pool_items = [(m, v) for m, v in pool.items() if m not in known]
out_rows = []
n_decoy = 0
for g, sel in lig.items():
    cid, acc, cls, seq = targets[g]
    for mid, pv in sel:
        info = smiles.get(mid)
        if not info:
            continue
        out_rows.append({"target": g, "chembl_target": cid, "uniprot": acc, "cls": cls,
                         "sequence": seq, "molecule_chembl_id": mid, "is_decoy": 0,
                         "pchembl": pv, "smiles": info["smiles"], "filter_level": lvl_used[g]})
        # 诱饵:MW ±25, logP ±1(两侧均需为数值,避免字符串减法)
        cand = []
        if info["mw"] is not None and info["logp"] is not None:
            for dm, dv in pool_items:
                if dv["mw"] is None or dv["logp"] is None:
                    continue
                if abs(dv["mw"] - info["mw"]) <= 25 and abs(dv["logp"] - info["logp"]) <= 1.0:
                    cand.append((dm, dv))
        if cand:
            dm, dv = random.choice(cand)
            out_rows.append({"target": g, "chembl_target": cid, "uniprot": acc, "cls": cls,
                             "sequence": seq, "molecule_chembl_id": dm, "is_decoy": 1,
                             "pchembl": "", "smiles": dv["smiles"], "filter_level": lvl_used[g]})
            n_decoy += 1

out = os.path.join(RES, "bench_eval_set_strict.csv")
with open(out, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["target", "chembl_target", "uniprot", "cls", "sequence",
                                      "molecule_chembl_id", "is_decoy", "pchembl", "smiles", "filter_level"])
    w.writeheader()
    w.writerows(out_rows)

from collections import Counter
c = Counter(r["target"] for r in out_rows if r["is_decoy"] == 0)
lv = Counter(lvl_used.values())
print("\n=== 汇总 ===", flush=True)
print("  靶点 %d,真配体 %d,诱饵 %d" % (len(c), sum(c.values()), n_decoy), flush=True)
print("  筛选级别分布:", dict(lv), flush=True)
print("  落盘:", out, flush=True)
