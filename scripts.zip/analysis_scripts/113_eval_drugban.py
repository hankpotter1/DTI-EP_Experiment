# -*- coding: utf-8 -*-
"""
DrugBAN 在 netpharm 57 靶点基准上的评测(官方代码 + 官方权重)

流程严格对齐 DrugBAN 官方 dataloader:
  · 药物:smiles_to_bigraph + CanonicalAtomFeaturizer/BondFeaturizer + 虚拟节点填充(MAX_NODES) + self-loop
  · 蛋白:integer_label_protein(整数编码,长度 1200)
  · 输出:二分类 logits -> sigmoid 概率,作为**排序分数**

注意:DrugBAN 在 BindingDB 上是**二分类**(结合/不结合),不是亲和力回归。
      用其概率对配体做排序是虚拟筛选常规做法,但不是其原训练目标 —— 会在文中披露。

输出:results/drugban_eval.json(三层指标)+ results/drugban_predictions.csv
"""
import csv
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

DB = r"G:\HHH\openclaw-workspace\netpharm-toolkit\thirdparty\drugban_extract\DrugBAN-main"
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
sys.path.insert(0, DB)
os.chdir(DB)

import numpy as np
import pandas as pd
import torch
import torch.utils.data as data
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.metrics import roc_auc_score
from functools import partial
from dgllife.utils import smiles_to_bigraph, CanonicalAtomFeaturizer, CanonicalBondFeaturizer

from models import DrugBAN
from utils import integer_label_protein, graph_collate_func, set_seed
from configs import get_cfg_defaults

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
CKPT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(DB, "result", "best_model_epoch_30.pth")
print("检查点:", CKPT, flush=True)
print("设备:", device, flush=True)


class PairDataset(data.Dataset):
    def __init__(self, df, max_drug_nodes=290):
        self.df = df.reset_index(drop=True)
        self.max_drug_nodes = max_drug_nodes
        self.atom_featurizer = CanonicalAtomFeaturizer()
        self.bond_featurizer = CanonicalBondFeaturizer(self_loop=True)
        self.fc = partial(smiles_to_bigraph, add_self_loop=True)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        row = self.df.iloc[index]
        v_d = self.fc(smiles=row["smiles"], node_featurizer=self.atom_featurizer,
                      edge_featurizer=self.bond_featurizer)
        nf = v_d.ndata.pop("h")
        n = nf.shape[0]
        nf = torch.cat((nf, torch.zeros([n, 1])), 1)
        v_d.ndata["h"] = nf
        n_virt = self.max_drug_nodes - n
        if n_virt > 0:
            v_d.add_nodes(n_virt, {"h": torch.cat((torch.zeros(n_virt, 74), torch.ones(n_virt, 1)), 1)})
        v_d = v_d.add_self_loop()
        v_p = integer_label_protein(row["sequence"])
        return v_d, v_p, 0


cfg = get_cfg_defaults()
cfg.merge_from_file(os.path.join(DB, "configs", "DrugBAN.yaml"))
set_seed(cfg.SOLVER.SEED)

recs = list(csv.DictReader(open(os.path.join(RES, "predictions_57t.csv"), encoding="utf-8-sig")))
# 从评测集表关联 SMILES 与 sequence(预测表里没有这两列)
seq_of, smi_of = {}, {}
for r in csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")):
    seq_of[r["target"]] = r["sequence"]
    smi_of[r["molecule_chembl_id"]] = r["smiles"]

pairs = []
seen = set()
for r in recs:
    # 只用"自身配体对":外来行的 measured 是该配体对**自己靶点**的亲和力,不能用于本靶点的排序
    if str(r.get("is_own", "1")) != "1":
        continue
    t, m = r["target"], r["molecule"]
    if t not in seq_of or m not in smi_of:
        continue
    key = (t, m)
    if key in seen:
        continue
    seen.add(key)
    pairs.append({"target": t, "cls": r.get("cls", ""), "molecule": m,
                  "smiles": smi_of[m], "sequence": seq_of[t], "measured": float(r["measured"])})
print("自身逐对评测: %d 对 / %d 靶点" % (len(pairs), len({p['target'] for p in pairs})), flush=True)

df = pd.DataFrame(pairs)
ds = PairDataset(df)
dl = data.DataLoader(ds, batch_size=64, shuffle=False, num_workers=0, collate_fn=graph_collate_func)

model = DrugBAN(**cfg).to(device)
sd = torch.load(CKPT, map_location=device)
model.load_state_dict(sd)
model.eval()
print("模型加载完成", flush=True)

probs = []
with torch.no_grad():
    for i, (v_d, v_p, labels) in enumerate(dl):
        v_d, v_p = v_d.to(device), v_p.to(device)
        # 官方 forward(mode="eval") 返回 4 个值:(v_d, v_p, score, att)
        _, _, score, _ = model(v_d, v_p, mode="eval")
        p = torch.sigmoid(score).squeeze(-1).cpu().numpy()
        probs.extend(p.tolist())
        if (i + 1) % 5 == 0:
            print("  批 %d/%d" % (i + 1, len(dl)), flush=True)

df["predicted"] = probs
df.to_csv(os.path.join(RES, "drugban_predictions.csv"), index=False, encoding="utf-8-sig")

# ---- 三层指标(与 DeepPurpose 评测口径一致)----
def rho(x, y):
    if len(set(x)) < 2 or len(set(y)) < 2:
        return None
    r, _ = spearmanr(x, y)
    return None if r != r else float(r)

per_target = {}
for t, g in df.groupby("target"):
    if len(g) < 10:
        continue
    per_target[t] = rho(g["predicted"].tolist(), g["measured"].tolist())

rhos = [v for v in per_target.values() if v is not None]
import statistics as st
med = st.median(rhos)
# 自助 CI
rng = np.random.default_rng(20260922)
boot = [st.median(list(rng.choice(rhos, len(rhos), replace=True))) for _ in range(5000)]
lo, hi = float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))
pos = sum(1 for v in rhos if v > 0) / len(rhos)
from scipy.stats import binomtest
p_sign = binomtest(sum(1 for v in rhos if v > 0), len(rhos), 0.5).pvalue
w = mannwhitneyu(rhos, [0] * len(rhos)) if len(set(rhos)) > 1 else None

# Tier 2:中位分半
t2 = []
for t, g in df.groupby("target"):
    if len(g) < 10:
        continue
    m = g["measured"].median()
    hi_g, lo_g = g[g["measured"] > m], g[g["measured"] < m]
    if len(hi_g) and len(lo_g):
        y = [1] * len(hi_g) + [0] * len(lo_g)
        s = hi_g["predicted"].tolist() + lo_g["predicted"].tolist()
        try:
            t2.append(roc_auc_score(y, s))
        except Exception:
            pass

out = {
    "checkpoint": os.path.basename(CKPT),
    "n_pairs": len(df), "n_targets": len(rhos),
    "tier3_median_rho": round(med, 4),
    "tier3_ci95": [round(lo, 4), round(hi, 4)],
    "tier3_pos_frac": round(pos, 4),
    "tier3_sign_p": float(p_sign),
    "tier2_auc_median": round(float(np.median(t2)), 4) if t2 else None,
    "per_target_rho": {k: round(v, 4) for k, v in per_target.items() if v is not None},
}
json.dump(out, open(os.path.join(RES, "drugban_eval.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)

print("\n==== DrugBAN 在 57 靶点基准上的结果 ====", flush=True)
print("  逐靶点 ρ 中位 = %.3f  CI95[%.3f, %.3f]" % (med, lo, hi), flush=True)
print("  正相关比例 = %.0f%%  符号检验 p = %.3g" % (pos * 100, p_sign), flush=True)
print("  Tier2 分半 AUC 中位 = %s" % (out["tier2_auc_median"]), flush=True)
print("  (对照:DeepPurpose 六模型中位 ρ 0.01-0.19)", flush=True)
