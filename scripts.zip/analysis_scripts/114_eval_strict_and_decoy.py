# -*- coding: utf-8 -*-
"""
中优先级项 2+3 的评测:严格评测集上的
  (a) 逐靶点 ρ(仅真配体)—— 与等距取样版对比,看标签噪声/取样方式的影响
  (b) 真配体 vs 性质匹配诱饵 的判别 AUC —— 更贴近真实筛选场景的阴性对照

输入:results/bench_eval_set_strict.csv
输出:results/strict_and_decoy_eval.json + results/predictions_strict.csv
"""
import csv
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
EVAL = os.path.join(RES, "bench_eval_set_strict.csv")

rows = list(csv.DictReader(open(EVAL, encoding="utf-8-sig")))
seq_of = {r["target"]: r["sequence"] for r in rows}
targets = sorted({r["target"] for r in rows})
print("靶点 %d,记录 %d" % (len(targets), len(rows)), flush=True)

# 只保留同时含有真配体的靶点
pairs = []      # (target, molecule, smiles, sequence, is_decoy, measured_or_None)
for r in rows:
    if not r.get("smiles") or r["target"] not in seq_of:
        continue
    pairs.append((r["target"], r["molecule_chembl_id"], r["smiles"], r["sequence"],
                  int(r["is_decoy"]), float(r["pchembl"]) if r.get("pchembl") else None))
print("可用于评测的配对: %d" % len(pairs), flush=True)

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model

MODELS = ["mpnn_cnn_bindingdb", "cnn_cnn_bindingdb", "morgan_cnn_bindingdb",
          "transformer_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb"]

pred_store = {}
out_path = os.path.join(RES, "predictions_strict.csv")
with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["model", "target", "molecule", "is_decoy", "measured", "predicted"])
    for model_name in MODELS:
        print("\n=== %s ===" % model_name, flush=True)
        try:
            model = DTI.model_pretrained(download_pretrained_model(model_name))
            cfg = getattr(model, "config", {}) or {}
            de, te = cfg.get("drug_encoding", "Morgan"), cfg.get("target_encoding", "CNN")
        except Exception as e:
            print("  加载失败:", str(e)[:120], flush=True)
            continue
        try:
            df = utils.data_process(X_drug=[p[2] for p in pairs], X_target=[p[3] for p in pairs],
                                    y=[1.0] * len(pairs), drug_encoding=de,
                                    target_encoding=te, split_method="no_split")
            preds = [float(x) for x in model.predict(df)]
        except Exception as e:
            print("  推理失败:", str(e)[:120], flush=True)
            continue
        pred_store[model_name] = preds
        for p, pr in zip(pairs, preds):
            w.writerow([model_name, p[0], p[1], p[4], p[5] if p[5] is not None else "", pr])
        f.flush()
        print("  已保存 %d 条" % len(preds), flush=True)

# ---------- 指标 ----------
import statistics as st
import numpy as np
from scipy.stats import spearmanr, binomtest
from sklearn.metrics import roc_auc_score

def rho(x, y):
    if len(set(x)) < 2 or len(set(y)) < 2:
        return None
    r, _ = spearmanr(x, y)
    return None if r != r else float(r)

summary = {}
rng = np.random.default_rng(20260922)
for mn, preds in pred_store.items():
    by_t_true, by_t_dec = {}, {}
    for p, pr in zip(pairs, preds):
        if p[4] == 0 and p[5] is not None:
            by_t_true.setdefault(p[0], []).append((p[5], pr))
        elif p[4] == 1:
            by_t_dec.setdefault(p[0], []).append(pr)

    rhos, aucs = [], []
    for t, v in by_t_true.items():
        if len(v) >= 10:
            r = rho([a for a, _ in v], [b for _, b in v])
            if r is not None:
                rhos.append(r)
        # 诱饵判别:本靶点真配体 vs 本靶点诱饵
        dec = by_t_dec.get(t, [])
        if len(v) >= 5 and len(dec) >= 5:
            y = [1] * len(v) + [0] * len(dec)
            s = [b for _, b in v] + list(dec)
            try:
                aucs.append(roc_auc_score(y, s))
            except Exception:
                pass

    if not rhos:
        continue
    med = st.median(rhos)
    boot = [st.median(list(rng.choice(rhos, len(rhos), replace=True))) for _ in range(5000)]
    summary[mn] = {
        "n_targets_rho": len(rhos),
        "median_rho": round(med, 4),
        "ci95": [round(float(np.percentile(boot, 2.5)), 4), round(float(np.percentile(boot, 97.5)), 4)],
        "pos_frac": round(sum(1 for v in rhos if v > 0) / len(rhos), 4),
        "sign_p": float(binomtest(sum(1 for v in rhos if v > 0), len(rhos), 0.5).pvalue),
        "n_targets_auc": len(aucs),
        "median_decoy_auc": round(float(np.median(aucs)), 4) if aucs else None,
    }
    print("  %-28s ρ中位 %.3f  诱饵AUC中位 %s" % (mn, med, summary[mn]["median_decoy_auc"]), flush=True)

json.dump(summary, open(os.path.join(RES, "strict_and_decoy_eval.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)

print("\n==== 严格集 + 诱饵判别 结果汇总 ====", flush=True)
print("%-28s %8s %8s %8s %10s" % ("模型", "ρ中位", "正相关%", "诱饵AUC", "符号p"), flush=True)
for mn, v in sorted(summary.items(), key=lambda kv: -kv[1]["median_rho"]):
    print("%-28s %8.3f %7.0f%% %8s %10.2g" % (mn, v["median_rho"], v["pos_frac"] * 100,
                                              v["median_decoy_auc"], v["sign_p"]), flush=True)
print("\n注:诱饵 AUC=0.5 表示无法区分真配体与性质匹配的非结合物", flush=True)
