# -*- coding: utf-8 -*-
"""
① 训练集重叠量化:评测集 vs BindingDB(六模型 + DrugBAN 的训练数据来源)

背景:6 个 DeepPurpose 模型与 DrugBAN 均在 **BindingDB** 上训练;我们的评测配体来自 **ChEMBL**。
若不量化重叠,则"开箱模型跨域迁移失败"的主张可能被误判为"连见过的数据都排不好"。

本脚本先做**靶点层面**重叠(用 BindingDB_UniProt.txt)。
配体层面见 116 脚本(需 BindingDB_ChEMBL TSV)。

口径说明:BindingDB 当前为 2026-09 版,而模型训练于 2019–2021 →
用**当前版做重叠统计是保守上界**(当前版包含训练时不存在的新数据)。
"""
import csv
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
BDB = r"G:\HHH\openclaw-workspace\netpharm-toolkit\thirdparty\bindingdb"

# --- BindingDB 靶点清单 ---
bdb_up = set()
bdb_names = {}
for line in open(os.path.join(BDB, "BindingDB_UniProt.txt"), encoding="utf-8", errors="ignore"):
    parts = line.rstrip("\n").split("\t")
    if len(parts) < 2:
        continue
    up = parts[1].strip().upper()
    if re.fullmatch(r"[A-Z0-9]{6,10}", up or ""):
        bdb_up.add(up)
        bdb_names.setdefault(up, parts[2].strip() if len(parts) > 2 else "")
print("BindingDB 靶点(UniProt)数: %d" % len(bdb_up), flush=True)

# --- 我们的评测集 ---
rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
ours = {}
for r in rows:
    ours[r["target"]] = (r["uniprot"].strip().upper(), r["cls"], r["chembl_target"])
print("评测集靶点数: %d" % len(ours), flush=True)

hit, miss = [], []
for t, (up, cls, cid) in sorted(ours.items()):
    if up in bdb_up:
        hit.append({"target": t, "uniprot": up, "cls": cls, "bindingdb_name": bdb_names.get(up, "")})
    else:
        miss.append({"target": t, "uniprot": up, "cls": cls})

n = len(ours)
print("\n=== 靶点层面重叠 ===", flush=True)
print("  出现在 BindingDB 的靶点: %d / %d = %.1f%%" % (len(hit), n, 100.0 * len(hit) / n), flush=True)
print("  未出现的靶点:            %d / %d = %.1f%%" % (len(miss), n, 100.0 * len(miss) / n), flush=True)

from collections import Counter
print("\n  按类别:", flush=True)
ch, cm = Counter(x["cls"] for x in hit), Counter(x["cls"] for x in miss)
for c in sorted(set(list(ch) + list(cm))):
    print("    %-6s 命中 %2d / 共 %2d" % (c, ch.get(c, 0), ch.get(c, 0) + cm.get(c, 0)), flush=True)

print("\n  未命中的靶点:", flush=True)
for x in miss:
    print("    %-8s %s (%s)" % (x["target"], x["uniprot"], x["cls"]), flush=True)

out = {
    "bindingdb_snapshot": "202609",
    "note": "用当前 BindingDB 版做重叠统计是保守上界(模型训练于 2019-2021)",
    "n_targets_eval": n,
    "n_targets_in_bindingdb": len(hit),
    "frac_in_bindingdb": round(len(hit) / n, 4),
    "targets_in_bindingdb": hit,
    "targets_not_in_bindingdb": miss,
}
json.dump(out, open(os.path.join(RES, "bindingdb_target_overlap.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/bindingdb_target_overlap.json", flush=True)
