# -*- coding: utf-8 -*-
"""
① 训练集重叠量化(配体层面):评测集 vs BindingDB(ChEMBL 子集)

关键问题:我们的 1,409 个评测配体 / 1,425 个(靶点,配体)对,有多少出现在
6 个 DeepPurpose 模型 + DrugBAN 的训练数据(BindingDB)里?

两种口径:
  (a) **分子层面**:该配体是否出现在 BindingDB(任意靶点)
  (b) **配对层面**:该(靶点, 配体)对是否出现在 BindingDB —— 这才是"模型见过这条数据"

优先按 ChEMBL ID 比对(我们与 BindingDB 都有该字段);
若字段缺失,退化为 InChIKey(用 rdkit 从 SMILES 计算)。

流式读取,避免把 ~GB 级 TSV 全读进内存。
"""
import csv
import json
import os
import re
import sys
from collections import defaultdict

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
BDB = r"G:\HHH\openclaw-workspace\netpharm-toolkit\thirdparty\bindingdb"

# --- 找到 TSV ---
tsv = None
for f in os.listdir(BDB):
    if f.lower().endswith((".tsv", ".txt")) and "chembl" in f.lower() and "uniprot" not in f.lower():
        tsv = os.path.join(BDB, f)
        break
if tsv is None:
    print("!! 未找到 ChEMBL TSV,先完成下载与解压", flush=True)
    sys.exit(1)
print("TSV:", os.path.basename(tsv), "%.1f MB" % (os.path.getsize(tsv) / 1e6), flush=True)

# --- 逐行流式扫描 ---
hdr = None
col_up = col_up2 = col_up3 = col_lid = col_smiles = col_key = None
lig_all = set()                 # BindingDB 中出现过的配体 ChEMBL ID
pairs = set()                   # (UniProt, ligand ChEMBL ID)
lig_keys = set()                # InChIKey
n_line = 0

with open(tsv, encoding="utf-8", errors="ignore") as fh:
    for line in fh:
        n_line += 1
        parts = line.rstrip("\n").split("\t")
        if hdr is None:
            hdr = parts
            for i, h in enumerate(hdr):
                hl = h.lower()
                # 配体 ChEMBL ID
                if col_lid is None and hl == "chembl id of ligand":
                    col_lid = i
                # 靶点 UniProt:必须取 **Primary ID**(不是 Recommended Name)
                if "uniprot" in hl and "primary id" in hl and "chain 1" in hl:
                    if "swissprot" in hl and col_up is None:
                        col_up = i
                    elif "trembl" in hl and col_up2 is None:
                        col_up2 = i
                # 次级 ID 也纳入(靶点可能在 BindingDB 中以次登录号出现)
                if col_up3 is None and "uniprot" in hl and "secondary id" in hl and "chain 1" in hl:
                    col_up3 = i
                if col_smiles is None and hl == "ligand smiles":
                    col_smiles = i
                if col_key is None and hl == "ligand inchi key":
                    col_key = i
            print("  列定位: SwissProt主号=%s TrEMBL主号=%s 次级ID=%s 配体ChEMBL=%s InChIKey=%s" % (
                col_up, col_up2, col_up3, col_lid, col_key), flush=True)
            print("    -> 靶点列名: %r" % (hdr[col_up] if col_up is not None else None), flush=True)
            print("    -> 配体列名: %r" % (hdr[col_lid] if col_lid is not None else None), flush=True)
            if col_up is None or col_lid is None:
                print("!! 关键列未定位,中止", flush=True)
                sys.exit(2)
            continue
        need_idx = max(x for x in [col_up, col_up2, col_up3, col_lid, col_smiles, col_key] if x is not None)
        if len(parts) <= need_idx:
            parts = parts + [""] * (need_idx + 1 - len(parts))
        ups = set()
        for ci in (col_up, col_up2):
            if ci is not None and parts[ci].strip():
                ups.add(parts[ci].strip().upper())
        if col_up3 is not None and parts[col_up3].strip():
            for x in re.split(r"[;,|\s]+", parts[col_up3]):
                x = x.strip().upper()
                if re.fullmatch(r"[A-Z0-9]{6,10}", x):
                    ups.add(x)
        lid = parts[col_lid].strip().upper() if col_lid is not None else ""
        key = parts[col_key].strip().upper() if col_key is not None else ""
        if lid and lid != "NONE":
            lig_all.add(lid)
            for up in ups:
                pairs.add((up, lid))
        if key and key not in ("NONE", ""):
            lig_keys.add(key)
        if n_line % 500000 == 0:
            print("  已扫描 %d 行,配体 %d,配对 %d" % (n_line, len(lig_all), len(pairs)), flush=True)

print("扫描完成:%d 行;BindingDB 内配体 %d 个,配对 %d 条,InChIKey %d 个" % (
    n_line, len(lig_all), len(pairs), len(lig_keys)), flush=True)

# --- 我们的评测集 ---
rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
our_mols = {}      # chembl_id -> smiles
our_pairs = set()
for r in rows:
    mid = r["molecule_chembl_id"].strip().upper()
    our_mols[mid] = r["smiles"]
    our_pairs.add((r["uniprot"].strip().upper(), mid))
print("评测集:分子 %d 个,(靶点,配体)对 %d 条" % (len(our_mols), len(our_pairs)), flush=True)

hit_mol = {m for m in our_mols if m in lig_all}
hit_pair = {p for p in our_pairs if p in pairs}

# --- InChIKey 交叉验证(若 rdkit 可用)---
key_stats = None
key_our = None
try:
    from rdkit import Chem, RDLogger
    RDLogger.DisableLog("rdApp.*")
    key_our = {}
    for m, smi in our_mols.items():
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            key_our[m] = Chem.MolToInchiKey(mol)
    if key_our:
        key_stats = {"n_our_keys": len(key_our), "n_in_bindingdb": sum(1 for k in key_our.values() if k in lig_keys)}
except Exception as e:
    print("  (InChIKey 交叉验证跳过: %s)" % str(e)[:80], flush=True)

out = {
    "bindingdb_snapshot": "202609",
    "tsv": os.path.basename(tsv),
    "bindingdb_rows_scanned": n_line,
    "bindingdb_unique_ligands": len(lig_all),
    "bindingdb_pairs": len(pairs),
    "eval_unique_molecules": len(our_mols),
    "eval_pairs": len(our_pairs),
    "ligand_hit": len(hit_mol),
    "ligand_frac": round(len(hit_mol) / max(1, len(our_mols)), 4),
    "pair_hit": len(hit_pair),
    "pair_frac": round(len(hit_pair) / max(1, len(our_pairs)), 4),
    "inchikey_crosscheck": key_stats,
    "note": "BindingDB 当前版为重叠的保守上界(模型训练于 2019-2021)",
}
json.dump(out, open(os.path.join(RES, "bindingdb_ligand_overlap.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)

print("\n==== 配体/配对层面重叠 ====", flush=True)
print("  分子命中: %d / %d = %.1f%%" % (len(hit_mol), len(our_mols), 100.0 * len(hit_mol) / len(our_mols)), flush=True)
print("  配对命中: %d / %d = %.1f%%" % (len(hit_pair), len(our_pairs), 100.0 * len(hit_pair) / len(our_pairs)), flush=True)
if key_stats:
    print("  InChIKey 交叉验证: %d / %d = %.1f%%" % (key_stats["n_in_bindingdb"], key_stats["n_our_keys"],
                                                    100.0 * key_stats["n_in_bindingdb"] / key_stats["n_our_keys"]), flush=True)
print("落盘: results/bindingdb_ligand_overlap.json", flush=True)
