# -*- coding: utf-8 -*-
"""
③ 分离混杂:构建「严格筛选 + 等距取样」对照集

原 §7.2 的对比同时改了两个变量:
  (a) 筛选更严(单一测定类型 + 人源 + binding)
  (b) 取样方式(等距 → 随机)
本脚本固定 (a)=严格、把 (b) 改回**等距**(与原始集 99 脚本的算法逐行一致),
从而得到三方对照:
  原始(松筛选+等距) | 严格+等距(本脚本) | 严格+随机(§7.2)

等距算法(与 99_build_bench_eval_set_large.py 完全一致):
  ordered = 按 pchembl 降序;idx = [round(i*(n-1)/(N-1)) for i in range(N)];
  sel = [ordered[i] for i in sorted(set(idx))]

数据来源:复用 112 的活性缓存(cache/strict/act_<靶点>_<级别>.json)与 SMILES 缓存。
输出:results/bench_eval_set_strict_eq.csv
"""
import csv
import json
import os
import sys
import time
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")
CACHE = r"G:\HHH\openclaw-workspace\netpharm-toolkit\cache\strict"
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
UA = {"User-Agent": "netpharm-strict-eq"}
N_PER = 25

LEVELS = ["L1_Ki_B_Human", "L2_Ki_Human", "L3_Ki"]

rows0 = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
targets = {r["target"]: (r["chembl_target"], r["uniprot"], r["cls"], r["sequence"]) for r in rows0}
print("靶点 %d 个" % len(targets), flush=True)


def fetch(url, name, attempts=4, timeout=90):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        try:
            return json.load(open(cf, encoding="utf-8"))
        except Exception:
            os.remove(cf)
    last = None
    for k in range(attempts):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8"))
            json.dump(d, open(cf + ".tmp", "w", encoding="utf-8"))
            os.replace(cf + ".tmp", cf)
            time.sleep(0.3)
            return d
        except Exception as e:
            last = e
            time.sleep(1.2 * (k + 1))
    raise last


# ---- 1) 用严格筛选的缓存,按"等距"重取样 ----
print("\n=== 严格筛选 + 等距取样(与原始算法一致)===", flush=True)
lig, lvl_used = {}, {}
for g, (cid, acc, cls, seq) in sorted(targets.items()):
    for lname in LEVELS:
        cf = os.path.join(CACHE, "act_%s_%s.json" % (g, lname))
        if not os.path.isfile(cf):
            continue
        try:
            d = json.load(open(cf, encoding="utf-8"))
        except Exception:
            continue
        best = {}
        for a in d.get("activities", []):
            mid, pv = a.get("molecule_chembl_id"), a.get("pchembl_value")
            if not mid or pv is None:
                continue
            try:
                pv = float(pv)
            except Exception:
                continue
            if mid not in best or pv > best[mid]:
                best[mid] = pv
        if len(best) < 15:
            continue
        ordered = sorted(best.items(), key=lambda kv: -kv[1])
        if len(ordered) >= N_PER:
            idx = [round(i * (len(ordered) - 1) / (N_PER - 1)) for i in range(N_PER)]
            sel = [ordered[i] for i in sorted(set(idx))]
        else:
            sel = ordered
        lig[g] = sel
        lvl_used[g] = lname
        print("  %-8s %-14s 可用 %4d -> 等距取 %2d (pChEMBL %.2f-%.2f)"
              % (g, lname, len(best), len(sel), sel[-1][1], sel[0][1]), flush=True)
        break

print("\n  纳入靶点: %d" % len(lig), flush=True)

# ---- 2) SMILES:先吃缓存,缺的再抓 ----
smi = {}
for f in os.listdir(CACHE):
    if f.startswith("mol_") and f.endswith(".json"):
        try:
            d = json.load(open(os.path.join(CACHE, f), encoding="utf-8"))
        except Exception:
            continue
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st:
                smi[mid] = st
print("  缓存内 SMILES: %d" % len(smi), flush=True)

need = sorted({m for v in lig.values() for m, _ in v} - set(smi))
print("  尚缺 SMILES: %d,开始补抓" % len(need), flush=True)
for i in range(0, len(need), 20):
    try:
        d = fetch("%s/molecule.json?molecule_chembl_id__in=%s&limit=100" % (CHEMBL, ",".join(need[i:i + 20])),
                  "mol_eq_%05d.json" % i)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st:
                smi[mid] = st
    except Exception as e:
        print("   [warn] 补抓批 %d: %s" % (i, str(e)[:40]), flush=True)
print("  合计 SMILES: %d" % len(smi), flush=True)

# ---- 3) 落盘(列结构与严格集一致)----
out_rows = []
for g, sel in lig.items():
    cid, acc, cls, seq = targets[g]
    for mid, pv in sel:
        if mid in smi:
            out_rows.append({"target": g, "chembl_target": cid, "uniprot": acc, "cls": cls,
                             "sequence": seq, "molecule_chembl_id": mid, "is_decoy": 0,
                             "pchembl": pv, "smiles": smi[mid], "filter_level": lvl_used[g]})

out = os.path.join(RES, "bench_eval_set_strict_eq.csv")
with open(out, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["target", "chembl_target", "uniprot", "cls", "sequence",
                                      "molecule_chembl_id", "is_decoy", "pchembl", "smiles", "filter_level"])
    w.writeheader()
    w.writerows(out_rows)

from collections import Counter
c = Counter(r["target"] for r in out_rows)
print("\n=== 汇总 ===", flush=True)
print("  靶点 %d,记录 %d" % (len(c), len(out_rows)), flush=True)
print("  每靶点配体数分布:", dict(Counter(c.values())), flush=True)
print("  落盘:", out, flush=True)
