# -*- coding: utf-8 -*-
"""
① 训练集重叠 —— 严谨化两件事:

(A) **时间边界**:用 BindingDB 的 "Date in BindingDB" 列,把重叠限制到**模型训练之前**的条目。
    DeepPurpose 的 BindingDB 预训练模型发布于 2021(数据截至 2019–2020),
    故取 cutoff=2021-01-01 作为"模型可能见过"的界,并同时给 2020-01-01 的保守界。

(B) **标签一致性**:对重叠的 (靶点,配体) 对,比较 BindingDB 记录的亲和力(优先 Ki/IC50/Kd, nM)
    与我们评测集用的 ChEMBL pChEMBL 值。若两者本就打架,则"模型没排好"不能全归因于模型。

输出:results/bindingdb_overlap_refined.json
"""
import csv
import json
import math
import os
import re
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
BDB = r"G:\HHH\openclaw-workspace\netpharm-toolkit\thirdparty\bindingdb"
TSV = os.path.join(BDB, "BindingDB_ChEMBL.tsv")

CUTOFFS = {"2021-01-01": datetime(2021, 1, 1), "2020-01-01": datetime(2020, 1, 1),
           "2019-01-01": datetime(2019, 1, 1)}


def parse_date(s):
    """BindingDB 的 Date in BindingDB 是美式 M/D/YYYY(如 9/25/2019),不能直接字符串比较。"""
    s = (s or "").strip()
    if not s:
        return None
    for fmt in ("%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d", "%d-%b-%Y"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    return None

# --- 我们的评测集 ---
rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
our = {}          # (uniprot, chembl_id) -> (target, pchembl, smiles)
for r in rows:
    our[(r["uniprot"].strip().upper(), r["molecule_chembl_id"].strip().upper())] = (
        r["target"], float(r["pchembl"]), r["smiles"])
print("评测集配对: %d" % len(our), flush=True)

hdr = None
ci = {}
n_line = 0
pair_dates = {}          # (up, lid) -> 最早的 Date in BindingDB
pair_aff = {}            # (up, lid) -> 最小的 Ki/IC50/Kd (nM)
with open(TSV, encoding="utf-8", errors="ignore") as fh:
    for line in fh:
        n_line += 1
        parts = line.rstrip("\n").split("\t")
        if hdr is None:
            hdr = parts
            for i, h in enumerate(hdr):
                hl = h.lower()
                if hl == "uniprot (swissprot) primary id of target chain 1":
                    ci["up"] = i
                elif hl == "uniprot (trembl) primary id of target chain 1":
                    ci["up2"] = i
                elif hl == "chembl id of ligand":
                    ci["lid"] = i
                elif hl == "date in bindingdb":
                    ci["date"] = i
                elif hl in ("ki (nm)", "ic50 (nm)", "kd (nm)", "ec50 (nm)"):
                    ci[h.split()[0]] = i
            print("  列定位:", ci, flush=True)
            if "up" not in ci or "lid" not in ci:
                sys.exit(2)
            continue
        need = max(ci.values())
        if len(parts) <= need:
            parts = parts + [""] * (need + 1 - len(parts))
        up = parts[ci["up"]].strip().upper() or parts[ci["up2"]].strip().upper()
        lid = parts[ci["lid"]].strip().upper()
        if not up or not lid:
            continue
        k = (up, lid)
        if k not in our:
            continue
        d = parts[ci["date"]].strip() if "date" in ci else ""
        dt = parse_date(d)
        if dt is not None and (k not in pair_dates or dt < pair_dates[k]):
            pair_dates[k] = dt
        for nm in ("Ki", "IC50", "Kd", "EC50"):
            if nm in ci:
                v = parts[ci[nm]].strip()
                if v:
                    try:
                        f = float(v.replace(",", ""))
                        if f > 0:
                            p = 9.0 - math.log10(f)
                            if k not in pair_aff or p > pair_aff[k]:
                                pair_aff[k] = p      # 取最大 p(≈ 最强测定)
                    except Exception:
                        pass
        if n_line % 500000 == 0:
            print("  已扫 %d 行,命中配对 %d" % (n_line, len(pair_dates)), flush=True)

print("\n扫描完成:%d 行;评测集配对命中 %d / %d = %.1f%%" % (
    n_line, len(pair_dates), len(our), 100.0 * len(pair_dates) / len(our)), flush=True)

# --- (A) 时间边界 ---
by_cutoff = {}
for cut, cdt in CUTOFFS.items():
    n = sum(1 for k, d in pair_dates.items() if d is not None and d < cdt)
    by_cutoff[cut] = {"n": n, "frac": round(n / len(our), 4)}
    print("  在 %s 之前入库的命中: %d / %d = %.1f%%" % (cut, n, len(our), 100.0 * n / len(our)), flush=True)
undated = sum(1 for d in pair_dates.values() if d is None)
print("  (日期无法解析的命中: %d)" % undated, flush=True)

# --- (B) 标签一致性 ---
from scipy.stats import spearmanr, pearsonr
import numpy as np
both = [(our[k][1], pair_aff[k]) for k in pair_dates if k in pair_aff]
print("\n可比较标签的重叠配对: %d" % len(both), flush=True)
label_stats = None
if len(both) > 30:
    a = [x for x, _ in both]
    b = [y for _, y in both]
    sp = spearmanr(a, b)[0]
    pe = pearsonr(a, b)[0]
    dif = [y - x for x, y in both]
    label_stats = {
        "n": len(both),
        "spearman_bindingdb_vs_chembl": round(float(sp), 4),
        "pearson": round(float(pe), 4),
        "mean_diff_p": round(float(np.mean(dif)), 4),
        "sd_diff_p": round(float(np.std(dif)), 4),
        "within_1_log_frac": round(float(np.mean([abs(d) <= 1.0 for d in dif])), 4),
    }
    print("  BindingDB 与 ChEMBL 的标签一致性: Spearman %.3f / Pearson %.3f" % (sp, pe), flush=True)
    print("  平均偏差 %.2f log,|偏差|<=1 log 的比例 %.0f%%" % (
        np.mean(dif), 100.0 * np.mean([abs(d) <= 1.0 for d in dif])), flush=True)

out = {
    "bindingdb_snapshot": "202609",
    "n_eval_pairs": len(our),
    "n_pairs_in_bindingdb": len(pair_dates),
    "pair_overlap_frac": round(len(pair_dates) / len(our), 4),
    "by_cutoff": by_cutoff,
    "label_agreement": label_stats,
    "note": "BindingDB 当前版为重叠上界;cutoff 用 Date in BindingDB 限定到训练前;"
            "标签比较取 BindingDB 的最强测定 vs 评测集 ChEMBL pChEMBL",
}
json.dump(out, open(os.path.join(RES, "bindingdb_overlap_refined.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/bindingdb_overlap_refined.json", flush=True)
