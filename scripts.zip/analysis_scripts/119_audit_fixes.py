# -*- coding: utf-8 -*-
"""
独立审计后的三项可计算修正:

S1. Tier-1 随机基线 MRR 重算(E[1/rank],rank~U{1..57})—— 审计指出原值 0.066 算错
M3. 诱饵判别 AUC 补 bootstrap 置信区间与符号检验(审计指出只有中位数、无 CI)
S1b. 据此重判"是否优于随机"

输入:results/retrieval_tier1.json、results/predictions_strict.csv
输出:results/audit_fixes.json
"""
import csv
import json
import os
import sys
from collections import defaultdict

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"

import numpy as np
from scipy.stats import binomtest, wilcoxon
from sklearn.metrics import roc_auc_score

out = {}

# ---------- S1:随机基线 MRR ----------
N = 57
H = sum(1.0 / k for k in range(1, N + 1))
analytic = H / N
rng = np.random.default_rng(20260922)
mc = float(np.mean([np.mean(1.0 / rng.integers(1, N + 1, N)) for _ in range(4000)]))
print("=== S1 随机基线 MRR ===", flush=True)
print("  H(57)=%.6f  ->  解析值 H(57)/57 = %.6f" % (H, analytic), flush=True)
print("  蒙特卡洛(4000 次)      = %.6f" % mc, flush=True)
print("  审计指出的原值           = 0.0660  (错)", flush=True)

ret = json.load(open(os.path.join(RES, "retrieval_tier1.json"), encoding="utf-8"))
print("\n  模型 MRR 与正确基线比较:", flush=True)
mrrs = {}
if isinstance(ret, dict) and "per_model" in ret:
    items = ret["per_model"].items()
elif isinstance(ret, dict):
    items = [(k, v) for k, v in ret.items() if isinstance(v, dict) and "mrr" in v]
else:
    items = []
for mn, v in items:
    m = v.get("mrr")
    if m is None:
        continue
    mrrs[mn] = float(m)
    flag = "低于随机" if float(m) < analytic else "高于随机"
    print("    %-28s MRR %.4f  -> %s (差 %+.4f)" % (mn, float(m), flag, float(m) - analytic), flush=True)

out["S1_mrr_baseline"] = {
    "n_targets": N,
    "analytic_H_n_over_n": round(analytic, 6),
    "monte_carlo": round(mc, 6),
    "old_wrong_value": 0.066,
    "models_below_random": [k for k, v in mrrs.items() if v < analytic],
    "model_mrr": {k: round(v, 4) for k, v in mrrs.items()},
}

# ---------- M3:诱饵 AUC 的 CI 与检验 ----------
print("\n=== M3 诱饵判别 AUC 补 CI/检验 ===", flush=True)
p = os.path.join(RES, "predictions_strict.csv")
rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
by_m = defaultdict(lambda: defaultdict(lambda: {"t": [], "d": []}))
for r in rows:
    try:
        pr = float(r["predicted"])
    except Exception:
        continue
    try:
        dec = int(r["is_decoy"])
    except Exception:
        continue
    rec = by_m[r["model"]][r["target"]]
    (rec["d"] if dec == 1 else rec["t"]).append(pr)

decoy_stats = {}
for m, tg in by_m.items():
    aucs = []
    for t, rec in tg.items():
        if len(rec["t"]) >= 5 and len(rec["d"]) >= 5:
            y = [1] * len(rec["t"]) + [0] * len(rec["d"])
            s = rec["t"] + rec["d"]
            try:
                aucs.append(roc_auc_score(y, s))
            except Exception:
                pass
    if not aucs:
        continue
    a = np.array(aucs)
    boot = [np.median(rng.choice(a, len(a), replace=True)) for _ in range(5000)]
    lo, hi = float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))
    try:
        p_sign = float(binomtest(int((a > 0.5).sum()), len(a), 0.5).pvalue)
        p_wil = float(wilcoxon(a - 0.5).pvalue)
    except Exception:
        p_sign = p_wil = None
    decoy_stats[m] = {"n_targets": len(a), "median_auc": round(float(np.median(a)), 4),
                      "ci95": [round(lo, 4), round(hi, 4)],
                      "frac_above_0.5": round(float((a > 0.5).mean()), 4),
                      "sign_p": p_sign, "wilcoxon_p": p_wil}
    print("  %-28s AUC %.3f CI[%.3f,%.3f]  >0.5 比例 %.0f%%  p(sign)=%.3g" % (
        m, np.median(a), lo, hi, 100 * (a > 0.5).mean(), p_sign if p_sign is not None else float("nan")), flush=True)

out["M3_decoy_auc_ci"] = decoy_stats

json.dump(out, open(os.path.join(RES, "audit_fixes.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/audit_fixes.json", flush=True)
