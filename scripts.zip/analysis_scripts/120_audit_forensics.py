# -*- coding: utf-8 -*-
"""
按审计清单做三项取证:
  (1) 取出各模型的 mean_rho / median_rho,确定哪些表格行用错了统计量(S3)
  (2) 复算"截断 vs 未截断"逐靶点 ρ(N2:审计复算未截断组中位 0.108,文档写 0.094)
  (3) 核查 57 个靶点的物种身份(M6:99 脚本注释说"人类优先"但代码未做)
"""
import csv
import json
import os
import sys
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
import numpy as np
from scipy.stats import mannwhitneyu

out = {}

# ---------- (1) mean vs median ----------
cri = json.load(open(os.path.join(RES, "critical_analysis_summary.json"), encoding="utf-8"))
print("=== (1) 各模型 mean_rho vs median_rho ===", flush=True)
mm = {}
def walk(o, p=""):
    if isinstance(o, dict):
        if "mean_rho" in o or "median_rho" in o:
            name = o.get("model") or o.get("name") or p
            mm[str(name)] = {"mean": o.get("mean_rho"), "median": o.get("median_rho")}
        for k, v in o.items():
            walk(v, p + str(k) + ".")
    elif isinstance(o, list):
        for i, v in enumerate(o):
            walk(v, p + str(i) + ".")
walk(cri)
for k, v in mm.items():
    print("   %-32s mean=%s  median=%s" % (k, v["mean"], v["median"]), flush=True)
out["mean_median"] = mm

# ---------- (2) 截断组复算 ----------
print("\n=== (2) 截断 vs 未截断 逐靶点 ρ ===", flush=True)
v = list(csv.DictReader(open(os.path.join(RES, "diagnostic_within_target_variance.csv"), encoding="utf-8-sig")))
ev = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
seqlen = {}
for r in ev:
    seqlen[r["target"]] = len(r["sequence"])
col = [c for c in v[0].keys() if "rho" in c.lower() or "ρ" in c]
rcol = col[0] if col else None
groups = {"截断(>1000)": [], "未截断": []}
for r in v:
    try:
        x = float(r[rcol])
    except Exception:
        continue
    t = r.get("target") or r.get("Target")
    if t in seqlen:
        (groups["截断(>1000)"] if seqlen[t] > 1000 else groups["未截断"]).append(x)
for g, arr in groups.items():
    if arr:
        print("   %-12s n=%2d  中位 %.4f  均值 %.4f" % (g, len(arr), float(np.median(arr)), float(np.mean(arr))), flush=True)
try:
    p = mannwhitneyu(groups["截断(>1000)"], groups["未截断"]).pvalue
    print("   Mann-Whitney p = %.4f" % p, flush=True)
    out["truncation"] = {"n_trunc": len(groups["截断(>1000)"]), "n_untrunc": len(groups["未截断"]),
                         "median_trunc": round(float(np.median(groups["截断(>1000)"])), 4),
                         "median_untrunc": round(float(np.median(groups["未截断"])), 4),
                         "p": float(p)}
except Exception as e:
    print("   p 计算失败:", str(e)[:60], flush=True)

# ---------- (3) 物种核查 ----------
print("\n=== (3) 57 靶点物种核查(UniProt REST)===", flush=True)
ups = sorted({r["uniprot"].strip() for r in ev})
q = " OR ".join("accession:%s" % u for u in ups)
url = ("https://rest.uniprot.org/uniprotkb/search?format=json&size=100&fields=accession,organism_name,organism_id&query="
       + urllib.parse.quote(q))
orgs = {}
try:
    req = urllib.request.Request(url, headers={"User-Agent": "netpharm-audit"})
    with urllib.request.urlopen(req, timeout=120) as r:
        d = json.loads(r.read().decode("utf-8"))
    for res in d.get("results", []):
        acc = res.get("primaryAccession")
        org = (res.get("organism") or {})
        orgs[acc] = (org.get("scientificName"), org.get("taxonId"))
    print("  查到物种: %d / %d" % (len(orgs), len(ups)), flush=True)
except Exception as e:
    print("  UniProt 查询失败:", str(e)[:100], flush=True)

from collections import Counter
c = Counter(v[0] for v in orgs.values() if v and v[0])
for name, n in c.most_common():
    print("    %-40s %d" % (name, n), flush=True)
nonhuman = [(k, vv) for k, vv in orgs.items() if vv and vv[0] and "sapiens" not in vv[0]]
print("  ⚠️ 非人类靶点: %d %s" % (len(nonhuman), nonhuman[:6]), flush=True)
out["species"] = {"n_checked": len(orgs), "counts": dict(c), "nonhuman": nonhuman}

json.dump(out, open(os.path.join(RES, "audit_forensics.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/audit_forensics.json", flush=True)
