# -*- coding: utf-8 -*-
"""
审计清单的剩余取证计算:

N2. 截断 vs 未截断 逐靶点 ρ 复算(文档写未截断中位 0.094,审计复算 0.108)
N6. **配体侧单一性质基线**(MW / logP / TPSA / 可旋转键 各自单独用于排序)
    —— 若纯理化性质就能达到与 DTI 模型相当的 ρ,则"模型的信号"是平凡的。
    这是审计建议补的常识性对照,对核心结论很有说服力。

输入:results/diagnostic_within_target_variance.csv、results/bench_eval_set_large.csv
输出:results/audit_forensics2.json
"""
import csv
import json
import os
import sys
import statistics as st
from collections import defaultdict

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
import numpy as np
from scipy.stats import spearmanr, mannwhitneyu, binomtest
from rdkit import Chem, RDLogger
from rdkit.Chem import Descriptors, Crippen, rdMolDescriptors

RDLogger.DisableLog("rdApp.*")

ev = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
seqlen = {r["target"]: len(r["sequence"]) for r in ev}

out = {}


def rho(x, y):
    if len(set(x)) < 2 or len(set(y)) < 2:
        return None
    r = spearmanr(x, y)[0]
    return None if r != r else float(r)


# ---------------- N2:截断组 ----------------
print("=== N2 截断 vs 未截断(复算)===", flush=True)
dv = list(csv.DictReader(open(os.path.join(RES, "diagnostic_within_target_variance.csv"), encoding="utf-8-sig")))
by_t = defaultdict(lambda: {"m": [], "p": []})
for r in dv:
    by_t[r["target"]]["m"].append(float(r["measured"]))
    by_t[r["target"]]["p"].append(float(r["predicted"]))
trunc, untrunc = [], []
for t, d in by_t.items():
    v = rho(d["p"], d["m"])
    if v is None:
        continue
    (trunc if seqlen.get(t, 0) > 1000 else untrunc).append(v)
print("  截断(>1000):n=%d 中位 %.4f 均值 %.4f" % (len(trunc), st.median(trunc), st.mean(trunc)), flush=True)
print("  未截断:     n=%d 中位 %.4f 均值 %.4f" % (len(untrunc), st.median(untrunc), st.mean(untrunc)), flush=True)
p = float(mannwhitneyu(trunc, untrunc).pvalue)
print("  Mann-Whitney p = %.4f  (文档写 0.569,未截断中位写 0.094)" % p, flush=True)
out["N2_truncation"] = {"median_trunc": round(st.median(trunc), 4), "n_trunc": len(trunc),
                        "median_untrunc": round(st.median(untrunc), 4), "n_untrunc": len(untrunc),
                        "p": round(p, 4), "doc_value_untrunc": 0.094}

# ---------------- N6:配体性质基线 ----------------
print("\n=== N6 配体性质基线(单性质直接排序)===", flush=True)
ligs = {}
for r in ev:
    ligs.setdefault(r["molecule_chembl_id"], r["smiles"])
props = {}
for mid, smi in ligs.items():
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        continue
    props[mid] = {
        "MW": Descriptors.MolWt(mol),
        "logP": Crippen.MolLogP(mol),
        "TPSA": rdMolDescriptors.CalcTPSA(mol),
        "RotB": rdMolDescriptors.CalcNumRotatableBonds(mol),
        "HBD": rdMolDescriptors.CalcNumHBD(mol),
        "ArRings": rdMolDescriptors.CalcNumAromaticRings(mol),
    }
print("  算出性质的分子: %d / %d" % (len(props), len(ligs)), flush=True)

rows_by_t = defaultdict(list)
for r in ev:
    if r["molecule_chembl_id"] in props:
        rows_by_t[r["target"]].append((props[r["molecule_chembl_id"]], float(r["pchembl"])))

rng = np.random.default_rng(20260922)
base = {}
for pname in ("MW", "logP", "TPSA", "RotB", "HBD", "ArRings"):
    vals = []
    for t, arr in rows_by_t.items():
        if len(arr) < 10:
            continue
        v = rho([a[pname] for a, _ in arr], [b for _, b in arr])
        if v is not None:
            vals.append(v)
    if not vals:
        continue
    med = st.median(vals)
    boot = [st.median(list(rng.choice(vals, len(vals), replace=True))) for _ in range(3000)]
    posf = sum(1 for v in vals if v > 0) / len(vals)
    base[pname] = {"median_rho": round(med, 4),
                   "ci95": [round(float(np.percentile(boot, 2.5)), 4), round(float(np.percentile(boot, 97.5)), 4)],
                   "pos_frac": round(posf, 4), "n_targets": len(vals),
                   "sign_p": float(binomtest(sum(1 for v in vals if v > 0), len(vals), 0.5).pvalue)}
    print("  %-7s 逐靶点 ρ 中位 %.3f  CI[%.3f,%.3f]  正相关 %.0f%%  n=%d" % (
        pname, med, base[pname]["ci95"][0], base[pname]["ci95"][1], 100 * posf, len(vals)), flush=True)

out["N6_ligand_only_baseline"] = base
out["N6_note"] = "对照:六个 DTI 模型的中位 ρ 为 0.012–0.194(见主表);若单性质基线落在此区间,说明模型信号不高于平凡的理化趋势"

json.dump(out, open(os.path.join(RES, "audit_forensics2.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/audit_forensics2.json", flush=True)
