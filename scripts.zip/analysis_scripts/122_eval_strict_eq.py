# -*- coding: utf-8 -*-
"""
③ 严格集混杂分离:评测「严格筛选 + 等距取样」对照集

三方对照(同为 6 个 DeepPurpose 模型、同评测协议):
  A. 原始(松筛选 + 等距)     -> critical_analysis_summary.json 的中位
  B. 严格 + 随机(§7.2)       -> strict_and_decoy_eval.json
  C. 严格 + 等距(本脚本)     -> strict_eq_eval.json   ← 新增,用于分离两个变量

推论规则:
  · 若 C ≈ A:取样方式主导,C 与 B 的差应归于筛选
  · 若 C ≈ B:筛选主导
  · 若 C 居中:两个变量都有贡献

输入:results/bench_eval_set_strict_eq.csv
输出:results/strict_eq_eval.json + results/predictions_strict_eq.csv
"""
import csv
import json
import os
import statistics as st
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
EVAL = os.path.join(RES, "bench_eval_set_strict_eq.csv")

rows = list(csv.DictReader(open(EVAL, encoding="utf-8-sig")))
seq_of = {r["target"]: r["sequence"] for r in rows}
pairs = [(r["target"], r["molecule_chembl_id"], r["smiles"], r["sequence"], float(r["pchembl"]))
         for r in rows if r.get("smiles") and r["target"] in seq_of]
print("靶点 %d,配对 %d" % (len(seq_of), len(pairs)), flush=True)

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model

MODELS = ["mpnn_cnn_bindingdb", "cnn_cnn_bindingdb", "morgan_cnn_bindingdb",
          "transformer_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb"]

import numpy as np
from scipy.stats import spearmanr, binomtest

def rho(x, y):
    if len(set(x)) < 2 or len(set(y)) < 2:
        return None
    r = spearmanr(x, y)[0]
    return None if r != r else float(r)

rng = np.random.default_rng(20260922)
summary = {}
out_path = os.path.join(RES, "predictions_strict_eq.csv")
with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["model", "target", "molecule", "measured", "predicted"])
    for mn in MODELS:
        print("\n=== %s ===" % mn, flush=True)
        try:
            model = DTI.model_pretrained(download_pretrained_model(mn))
            cfg = getattr(model, "config", {}) or {}
            de, te = cfg.get("drug_encoding", "Morgan"), cfg.get("target_encoding", "CNN")
        except Exception as e:
            print("  加载失败:", str(e)[:110], flush=True)
            continue
        try:
            df = utils.data_process(X_drug=[p[2] for p in pairs], X_target=[p[3] for p in pairs],
                                    y=[1.0] * len(pairs), drug_encoding=de,
                                    target_encoding=te, split_method="no_split")
            preds = [float(x) for x in model.predict(df)]
        except Exception as e:
            print("  推理失败:", str(e)[:110], flush=True)
            continue
        for p, pr in zip(pairs, preds):
            w.writerow([mn, p[0], p[1], p[4], pr])
        f.flush()

        by_t = {}
        for p, pr in zip(pairs, preds):
            by_t.setdefault(p[0], []).append((p[4], pr))
        vals = []
        for t, arr in by_t.items():
            if len(arr) >= 10:
                v = rho([b for _, b in arr], [a for a, _ in arr])
                if v is not None:
                    vals.append(v)
        if not vals:
            continue
        med = st.median(vals)
        boot = [st.median(list(rng.choice(vals, len(vals), replace=True))) for _ in range(3000)]
        summary[mn] = {"n_targets": len(vals), "median_rho": round(med, 4),
                       "ci95": [round(float(np.percentile(boot, 2.5)), 4), round(float(np.percentile(boot, 97.5)), 4)],
                       "pos_frac": round(sum(1 for v in vals if v > 0) / len(vals), 4),
                       "sign_p": float(binomtest(sum(1 for v in vals if v > 0), len(vals), 0.5).pvalue)}
        print("  ρ中位 %.3f CI[%.3f,%.3f] n=%d" % (med, summary[mn]["ci95"][0], summary[mn]["ci95"][1], len(vals)), flush=True)

json.dump(summary, open(os.path.join(RES, "strict_eq_eval.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)

# 三方对照表
cri = json.load(open(os.path.join(RES, "critical_analysis_summary.json"), encoding="utf-8"))
def med_of(name):
    def walk(o):
        if isinstance(o, dict):
            if o.get("model") == name or name in str(o.get("name", "")):
                return o.get("median_rho")
            for v in o.values():
                r = walk(v)
                if r is not None:
                    return r
        elif isinstance(o, list):
            for v in o:
                r = walk(v)
                if r is not None:
                    return r
        return None
    return walk(cri)
sr = json.load(open(os.path.join(RES, "strict_and_decoy_eval.json"), encoding="utf-8"))
print("\n==== 三方对照(逐靶点 ρ 中位)====", flush=True)
print("%-30s %10s %10s %10s" % ("模型", "A松+等距", "B严+随机", "C严+等距"), flush=True)
for mn in MODELS:
    a = med_of(mn)
    b = (sr.get(mn) or {}).get("median_rho")
    c = (summary.get(mn) or {}).get("median_rho")
    print("%-30s %10s %10s %10s" % (mn, a, b, c), flush=True)
print("\n落盘: results/strict_eq_eval.json", flush=True)
