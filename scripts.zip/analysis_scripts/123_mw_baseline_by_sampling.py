# -*- coding: utf-8 -*-
"""
最深的潜在硬伤检验:**MW 基线是否只是"等距取样"的设计产物?**

逻辑链:
  · §7.5 发现"仅按分子量排序"就能得到 ρ=0.187,与最好的 DTI 模型相当。
  · 两种解释:(a) 模型弱;(b) **评测集设计有偏** —— 等距取样刻意拉大效价跨度,
    而效价跨度可能与分子量共变,于是"按 MW 排"就能蹭到高分,模型蹭到同样的分也就不奇怪。

可判定检验:在**随机取样(自然分布)**的集合上重算 MW 基线。
  · 若 MW 的 ρ 在随机集上大幅下降 → 原结论(模型≈MW)部分是取样设计的产物,须披露;
  · 若基本不变 → MW 趋势是数据本身的性质,原结论稳固。

三个集合(A/B/C 与 §7.2 三方对照一致):
  A. 松筛选+等距(原始)   bench_eval_set_large.csv
  B. 严格+随机            bench_eval_set_strict.csv(仅真配体)
  C. 严格+等距            bench_eval_set_strict_eq.csv

输出:results/mw_baseline_by_sampling.json
"""
import csv
import json
import os
import statistics as st
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
import numpy as np
from scipy.stats import spearmanr
from rdkit import Chem, RDLogger
from rdkit.Chem import Descriptors

RDLogger.DisableLog("rdApp.*")

SETS = {
    "A_松筛选_等距": ("bench_eval_set_large.csv", None),
    "B_严格_随机": ("bench_eval_set_strict.csv", "is_decoy"),
    "C_严格_等距": ("bench_eval_set_strict_eq.csv", "is_decoy"),
}


def rho(x, y):
    if len(set(x)) < 2 or len(set(y)) < 2:
        return None
    r = spearmanr(x, y)[0]
    return None if r != r else float(r)


rng = np.random.default_rng(20260922)
out = {}
for label, (fn, decoy_col) in SETS.items():
    p = os.path.join(RES, fn)
    rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
    if decoy_col:
        rows = [r for r in rows if str(r.get(decoy_col, "0")) == "0"]
    by_t = {}
    n_mw = 0
    for r in rows:
        mol = Chem.MolFromSmiles(r["smiles"])
        if mol is None:
            continue
        n_mw += 1
        by_t.setdefault(r["target"], []).append((Descriptors.MolWt(mol), float(r["pchembl"])))
    vals, spans = [], []
    for t, arr in by_t.items():
        if len(arr) < 10:
            continue
        v = rho([a for a, _ in arr], [b for _, b in arr])
        if v is not None:
            vals.append(v)
        spans.append(max(b for _, b in arr) - min(b for _, b in arr))
    med = float(np.median(vals))
    boot = [np.median(rng.choice(vals, len(vals), replace=True)) for _ in range(3000)]
    out[label] = {"n_targets": len(vals), "median_rho_MW": round(med, 4),
                  "ci95": [round(float(np.percentile(boot, 2.5)), 4), round(float(np.percentile(boot, 97.5)), 4)],
                  "median_pchembl_span": round(float(np.median(spans)), 2),
                  "n_pairs": n_mw}
    print("  %-16s MW 基线 ρ中位 %.3f CI[%.3f,%.3f] | 效价跨度中位 %.2f log | n=%d" % (
        label, med, out[label]["ci95"][0], out[label]["ci95"][1],
        np.median(spans), len(vals)), flush=True)

json.dump(out, open(os.path.join(RES, "mw_baseline_by_sampling.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/mw_baseline_by_sampling.json", flush=True)
