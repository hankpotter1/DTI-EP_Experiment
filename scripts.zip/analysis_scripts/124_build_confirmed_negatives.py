# -*- coding: utf-8 -*-
"""
M3(审计建议):用**实验确认的阴性物**重建诱饵

原 §7.3 的诱饵取自 ChEMBL 随机分子池、仅按性质匹配 —— **未验证其是否与靶点结合**,
因此 AUC 只是下界。本脚本改为:

  对每个严格集靶点,抓取该靶点**实测但弱**(pchembl < 5,即 > 10 µM)的化合物记录,
  作为「实验确认的弱结合/非结合物」诱饵;再按 (MW ±25, logP ±1) 与真配体配对。

分级回退(与 112 一致):L1 = assay_type=B + 人源;L2 = 人源;L3 = 不限。

输出:results/bench_eval_set_strict_neg.csv(真配体沿用严格集,诱饵替换为实测弱活性物)
"""
import csv
import json
import os
import random
import sys
import time
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")
CACHE = r"G:\HHH\openclaw-workspace\netpharm-toolkit\cache\strict"
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
UA = {"User-Agent": "netpharm-neg"}
PCH_MAX = 5.0        # 弱于 10 µM 视为阴性
MAX_CAND = 80        # 每靶点最多保留的阴性候选数(控制 API 调用量)
random.seed(20260923)


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def fetch(url, name, attempts=4, timeout=90):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        try:
            return json.load(open(cf, encoding="utf-8"))
        except Exception:
            os.remove(cf)
    last = None
    for k in range(attempts):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8"))
            json.dump(d, open(cf + ".tmp", "w", encoding="utf-8"))
            os.replace(cf + ".tmp", cf)
            time.sleep(0.3)
            return d
        except Exception as e:
            last = e
            time.sleep(1.2 * (k + 1))
    raise last


# 严格集(真配体侧,已建好)
strict = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_strict.csv"), encoding="utf-8-sig")))
true_rows = [r for r in strict if str(r["is_decoy"]) == "0"]
targets = {}
for r in true_rows:
    targets.setdefault(r["target"], {"chembl": r["chembl_target"], "uniprot": r["uniprot"],
                                     "cls": r["cls"], "seq": r["sequence"], "ligs": []})
    targets[r["target"]]["ligs"].append((r["molecule_chembl_id"], float(r["pchembl"]), r["smiles"]))
print("靶点 %d,真配体 %d" % (len(targets), len(true_rows)), flush=True)

LEVELS = [
    ("N1_B_Human", "&assay_type=B&target_organism=Homo+sapiens"),
    ("N2_Human", "&target_organism=Homo+sapiens"),
    ("N3_any", ""),
]

print("\n=== 抓取实测弱活性(阴性)记录 ===", flush=True)
neg, neglvl = {}, {}
for g, info in sorted(targets.items()):
    for lname, extra in LEVELS:
        try:
            d = fetch("%s/activity.json?target_chembl_id=%s&pchembl_value__lt=%s&standard_relation=%%3D%s&limit=1000"
                      % (CHEMBL, info["chembl"], PCH_MAX, extra), "neg_%s_%s.json" % (g, lname))
            acts = d.get("activities", [])
        except Exception as e:
            print("  %-8s %-12s 失败 %s" % (g, lname, str(e)[:40]), flush=True)
            continue
        best = {}
        for a in acts:
            mid, pv = a.get("molecule_chembl_id"), a.get("pchembl_value")
            if not mid or pv is None:
                continue
            v = _f(pv)
            if v is None or v >= PCH_MAX:
                continue
            if mid not in best or v < best[mid]:
                best[mid] = v      # 取该分子在该靶点的最弱记录
        if len(best) >= 15:
            items = sorted(best.items())
            if len(items) > MAX_CAND:
                items = sorted(random.sample(items, MAX_CAND))
            neg[g] = dict(items)
            neglvl[g] = lname
            print("  %-8s %-12s 阴性候选 %4d -> 取样 %2d" % (g, lname, len(best), len(items)), flush=True)
            break
    else:
        print("  %-8s 三级筛选后仍不足" % g, flush=True)

print("\n  取得阴性候选的靶点: %d / %d" % (len(neg), len(targets)), flush=True)

# --- 取 SMILES 与性质 ---
mids = sorted({m for v in neg.values() for m in v})
print("  阴性分子数: %d,取 SMILES/性质" % len(mids), flush=True)
info_neg = {}
for f in os.listdir(CACHE):
    if f.startswith("mol") and f.endswith(".json"):
        try:
            d = json.load(open(os.path.join(CACHE, f), encoding="utf-8"))
        except Exception:
            continue
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            pr = m.get("molecule_properties") or {}
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st and _f(pr.get("mw_freebase")) is not None and _f(pr.get("alogp")) is not None:
                info_neg[mid] = {"smiles": st, "mw": _f(pr["mw_freebase"]), "logp": _f(pr["alogp"])}
need = [m for m in mids if m not in info_neg]
print("    缓存 %d,尚缺 %d,补抓" % (len(info_neg), len(need)), flush=True)
for i in range(0, len(need), 20):
    try:
        d = fetch("%s/molecule.json?molecule_chembl_id__in=%s&limit=100" % (CHEMBL, ",".join(need[i:i + 20])),
                  "mol_neg_%05d.json" % i)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            pr = m.get("molecule_properties") or {}
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st and _f(pr.get("mw_freebase")) is not None and _f(pr.get("alogp")) is not None:
                info_neg[mid] = {"smiles": st, "mw": _f(pr["mw_freebase"]), "logp": _f(pr["alogp"])}
    except Exception as e:
        print("    [warn] 批 %d: %s" % (i, str(e)[:40]), flush=True)
print("    阴性分子含性质: %d / %d" % (len(info_neg), len(mids)), flush=True)

# --- 真配体性质(用于匹配)---
info_true = {}
for f in os.listdir(CACHE):
    if f.startswith("mol") and f.endswith(".json"):
        try:
            d = json.load(open(os.path.join(CACHE, f), encoding="utf-8"))
        except Exception:
            continue
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            pr = m.get("molecule_properties") or {}
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st and _f(pr.get("mw_freebase")) is not None and _f(pr.get("alogp")) is not None:
                info_true[mid] = {"smiles": st, "mw": _f(pr["mw_freebase"]), "logp": _f(pr["alogp"])}

# --- 配对 ---
print("\n=== 性质匹配(真配体 <-> 实测阴性)===", flush=True)
used = set()
out_rows = []
n_dec = 0
for g, info in sorted(targets.items()):
    if g not in neg:
        continue
    pool = [(m, info_neg[m]) for m in neg[g] if m in info_neg and m not in used]
    for mid, pv, smi in info["ligs"]:
        ti = info_true.get(mid)
        out_rows.append({"target": g, "chembl_target": info["chembl"], "uniprot": info["uniprot"],
                         "cls": info["cls"], "sequence": info["seq"], "molecule_chembl_id": mid,
                         "is_decoy": 0, "pchembl": pv, "smiles": smi, "decoy_type": "true_ligand"})
        if not ti:
            continue
        cand = [c for c in pool
                if c[0] not in used and abs(c[1]["mw"] - ti["mw"]) <= 25 and abs(c[1]["logp"] - ti["logp"]) <= 1.0]
        if not cand:
            cand = [c for c in pool if c[0] not in used][:200]      # 放宽:同靶点阴性
        if cand:
            dm, dv = random.choice(cand[:200])
            used.add(dm)
            out_rows.append({"target": g, "chembl_target": info["chembl"], "uniprot": info["uniprot"],
                             "cls": info["cls"], "sequence": info["seq"], "molecule_chembl_id": dm,
                             "is_decoy": 1, "pchembl": neg[g][dm], "smiles": dv["smiles"],
                             "decoy_type": "measured_weak_%s" % neglvl[g]})
            n_dec += 1

out = os.path.join(RES, "bench_eval_set_strict_neg.csv")
with open(out, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["target", "chembl_target", "uniprot", "cls", "sequence",
                                      "molecule_chembl_id", "is_decoy", "pchembl", "smiles", "decoy_type"])
    w.writeheader()
    w.writerows(out_rows)

from collections import Counter
c = Counter(r["is_decoy"] for r in out_rows)
print("\n=== 汇总 ===", flush=True)
print("  真配体 %d,实测阴性诱饵 %d" % (c.get(0, 0), c.get(1, 0)), flush=True)
print("  覆盖靶点 %d" % len({r["target"] for r in out_rows if r["is_decoy"] == 1}), flush=True)
print("  落盘:", out, flush=True)
