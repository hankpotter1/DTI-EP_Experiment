# -*- coding: utf-8 -*-
"""
S2(审计建议):Tier-1 检索扩探针,提高统计功效

原实验每靶点仅抽 **1** 个探针(N_LIG=100 但 per=100//57=1),共 57 个观测 ——
Top-1 命中只能取 0/1/2,功效极低。

本脚本:每靶点抽 **N_PROBE=5** 个探针(共 285 个),每个探针对全部 57 靶点打分,
考察其真实靶点的名次。观测数提升 5 倍,并给 bootstrap 置信区间与二项检验。

随机基线(解析):
    Top-1 = 1/57 = 1.754%   Top-5 = 5/57 = 8.772%   Top-10 = 10/57 = 17.544%
    MRR   = H(57)/57 = 0.081211

输入:results/bench_eval_set_large.csv
输出:results/tier1_expanded.json + results/tier1_expanded_scores.csv
"""
import csv
import json
import os
import random
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
N_PROBE = 5
random.seed(20260923)

rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
by_t, seq_of = {}, {}
for r in rows:
    by_t.setdefault(r["target"], []).append(r)
    seq_of[r["target"]] = r["sequence"]
targets = sorted(by_t)
print("靶点 %d" % len(targets), flush=True)

probes = []          # (ligand_smiles, true_target)
for t in targets:
    sel = random.sample(by_t[t], min(N_PROBE, len(by_t[t])))
    for r in sel:
        probes.append((r["smiles"], t))
print("探针 %d(每靶点 %d),配对 %d" % (len(probes), N_PROBE, len(probes) * len(targets)), flush=True)

pairs = [(smi, seq_of[t]) for smi, _ in probes for t in targets]
probe_true = [t for _, t in probes for _ in targets]
print("总配对 %d" % len(pairs), flush=True)

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model

MODELS = ["mpnn_cnn_bindingdb", "cnn_cnn_bindingdb", "morgan_cnn_bindingdb",
          "transformer_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb"]

import numpy as np
from scipy.stats import binomtest

N = len(targets)
def rand_mrr():
    H = sum(1.0 / k for k in range(1, N + 1))
    return H / N
BASE = {"top1": 1.0 / N, "top5": 5.0 / N, "top10": 10.0 / N, "mrr": rand_mrr()}
print("随机基线: Top1 %.4f Top5 %.4f Top10 %.4f MRR %.4f" % (
    BASE["top1"], BASE["top5"], BASE["top10"], BASE["mrr"]), flush=True)

rng = np.random.default_rng(20260923)
summary = {}
out_path = os.path.join(RES, "tier1_expanded_scores.csv")
with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["model", "true_target", "predicted_target", "score"])
    for mn in MODELS:
        print("\n=== %s ===" % mn, flush=True)
        try:
            model = DTI.model_pretrained(download_pretrained_model(mn))
            cfg = getattr(model, "config", {}) or {}
            de, te = cfg.get("drug_encoding", "Morgan"), cfg.get("target_encoding", "CNN")
        except Exception as e:
            print("  加载失败:", str(e)[:110], flush=True)
            continue
        try:
            df = utils.data_process(X_drug=[p[0] for p in pairs], X_target=[p[1] for p in pairs],
                                    y=[1.0] * len(pairs), drug_encoding=de,
                                    target_encoding=te, split_method="no_split")
            preds = [float(x) for x in model.predict(df)]
        except Exception as e:
            print("  推理失败:", str(e)[:110], flush=True)
            continue
        for (smi, seq), tt, pr in zip(pairs, probe_true, preds):
            w.writerow([mn, tt, "", pr])
        f.flush()

        # 逐探针排名
        ranks = []
        for i in range(len(probes)):
            seg = preds[i * N:(i + 1) * N]
            tt = probes[i][1]
            order = sorted(range(N), key=lambda j: -seg[j])
            ranks.append(order.index(targets.index(tt)) + 1)
        ranks = np.array(ranks)
        rr = 1.0 / ranks
        res = {"n_probes": len(ranks),
               "top1": float((ranks == 1).mean()), "top5": float((ranks <= 5).mean()),
               "top10": float((ranks <= 10).mean()), "mrr": float(rr.mean())}
        # bootstrap CI(按探针重采样)
        boot = {"top1": [], "top5": [], "top10": [], "mrr": []}
        for _ in range(3000):
            idx = rng.integers(0, len(ranks), len(ranks))
            r2 = ranks[idx]
            boot["top1"].append((r2 == 1).mean())
            boot["top5"].append((r2 <= 5).mean())
            boot["top10"].append((r2 <= 10).mean())
            boot["mrr"].append((1.0 / r2).mean())
        for k in boot:
            res[k + "_ci95"] = [round(float(np.percentile(boot[k], 2.5)), 4),
                                round(float(np.percentile(boot[k], 97.5)), 4)]
        # 二项检验(是否优于随机)
        for k, base in (("top1", BASE["top1"]), ("top5", BASE["top5"]), ("top10", BASE["top10"])):
            hits = int({"top1": (ranks == 1), "top5": (ranks <= 5), "top10": (ranks <= 10)}[k].sum())
            res[k + "_p_vs_random"] = float(binomtest(hits, len(ranks), base, alternative="greater").pvalue)
            res[k + "_hits"] = hits
        summary[mn] = res
        print("  Top1 %.2f%% CI[%.2f,%.2f] | Top5 %.2f%% | Top10 %.2f%% | MRR %.4f | p(Top1) %.3g" % (
            100 * res["top1"], 100 * res["top1_ci95"][0], 100 * res["top1_ci95"][1],
            100 * res["top5"], 100 * res["top10"], res["mrr"], res["top1_p_vs_random"]), flush=True)

out = {"n_targets": N, "n_probe_per_target": N_PROBE, "n_probes": len(probes),
       "random_baseline": BASE, "per_model": summary,
       "note": "随机基线为解析值;p 为单侧二项检验(优于随机)"}
json.dump(out, open(os.path.join(RES, "tier1_expanded.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/tier1_expanded.json", flush=True)
