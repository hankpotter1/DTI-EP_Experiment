# -*- coding: utf-8 -*-
"""
M3 评测:用「实验确认的弱活性阴性物」作诱饵,重算判别 AUC

与 §7.3(随机性质匹配诱饵)对比:若 AUC 明显下降,说明原 AUC 被
「诱饵池里混有真实活化物」抬高了(即原值是上偏的);若持平,说明原结论稳健。

同时报告:真配体 vs 阴性诱饵 的逐靶点 AUC 中位 + bootstrap CI + 符号检验。

输入:results/bench_eval_set_strict_neg.csv
输出:results/strict_neg_eval.json + results/predictions_strict_neg.csv
"""
import csv
import json
import os
import statistics as st
import sys

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
EVAL = os.path.join(RES, "bench_eval_set_strict_neg.csv")

rows = list(csv.DictReader(open(EVAL, encoding="utf-8-sig")))
seq_of = {r["target"]: r["sequence"] for r in rows}
useful = [r for r in rows if r.get("smiles") and r["target"] in seq_of]
print("靶点 %d,记录 %d(真 %d / 阴性诱饵 %d)" % (
    len({r["target"] for r in useful}), len(useful),
    sum(1 for r in useful if str(r["is_decoy"]) == "0"),
    sum(1 for r in useful if str(r["is_decoy"]) == "1")), flush=True)

from DeepPurpose import DTI, utils
from DeepPurpose.utils import download_pretrained_model

MODELS = ["mpnn_cnn_bindingdb", "cnn_cnn_bindingdb", "morgan_cnn_bindingdb",
          "transformer_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb"]

import numpy as np
from scipy.stats import binomtest, wilcoxon
from sklearn.metrics import roc_auc_score

rng = np.random.default_rng(20260923)
summary = {}
out_path = os.path.join(RES, "predictions_strict_neg.csv")
with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["model", "target", "molecule", "is_decoy", "pchembl", "predicted"])
    for mn in MODELS:
        print("\n=== %s ===" % mn, flush=True)
        try:
            model = DTI.model_pretrained(download_pretrained_model(mn))
            cfg = getattr(model, "config", {}) or {}
            de, te = cfg.get("drug_encoding", "Morgan"), cfg.get("target_encoding", "CNN")
        except Exception as e:
            print("  加载失败:", str(e)[:110], flush=True)
            continue
        try:
            df = utils.data_process(X_drug=[r["smiles"] for r in useful],
                                    X_target=[seq_of[r["target"]] for r in useful],
                                    y=[1.0] * len(useful), drug_encoding=de,
                                    target_encoding=te, split_method="no_split")
            preds = [float(x) for x in model.predict(df)]
        except Exception as e:
            print("  推理失败:", str(e)[:110], flush=True)
            continue
        for r, pr in zip(useful, preds):
            w.writerow([mn, r["target"], r["molecule_chembl_id"], r["is_decoy"], r["pchembl"], pr])
        f.flush()

        by_t = {}
        for r, pr in zip(useful, preds):
            d = by_t.setdefault(r["target"], {"t": [], "d": []})
            (d["t"] if str(r["is_decoy"]) == "0" else d["d"]).append(pr)
        aucs = []
        for t, d in by_t.items():
            if len(d["t"]) >= 5 and len(d["d"]) >= 5:
                try:
                    aucs.append(roc_auc_score([1] * len(d["t"]) + [0] * len(d["d"]), d["t"] + d["d"]))
                except Exception:
                    pass
        if not aucs:
            continue
        a = np.array(aucs)
        boot = [np.median(rng.choice(a, len(a), replace=True)) for _ in range(5000)]
        summary[mn] = {
            "n_targets": len(a), "median_auc": round(float(np.median(a)), 4),
            "ci95": [round(float(np.percentile(boot, 2.5)), 4), round(float(np.percentile(boot, 97.5)), 4)],
            "frac_above_0.5": round(float((a > 0.5).mean()), 4),
            "sign_p": float(binomtest(int((a > 0.5).sum()), len(a), 0.5).pvalue),
            "wilcoxon_p": float(wilcoxon(a - 0.5).pvalue),
        }
        print("  AUC %.3f CI[%.3f,%.3f] n=%d >0.5 占 %.0f%% p=%.3g" % (
            np.median(a), summary[mn]["ci95"][0], summary[mn]["ci95"][1], len(a),
            100 * (a > 0.5).mean(), summary[mn]["sign_p"]), flush=True)

json.dump(summary, open(os.path.join(RES, "strict_neg_eval.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)

# 与随机诱饵版对比
old = json.load(open(os.path.join(RES, "audit_fixes.json"), encoding="utf-8")).get("M3_decoy_auc_ci", {})
print("\n==== 对比:随机诱饵 vs 实测弱活性诱饵 ====", flush=True)
print("%-28s %12s %12s" % ("模型", "随机诱饵AUC", "实测阴性AUC"), flush=True)
for mn in MODELS:
    o = (old.get(mn) or {}).get("median_auc")
    n = (summary.get(mn) or {}).get("median_auc")
    print("%-28s %12s %12s" % (mn.replace("_bindingdb", ""), o, n), flush=True)
print("\n落盘: results/strict_neg_eval.json", flush=True)
