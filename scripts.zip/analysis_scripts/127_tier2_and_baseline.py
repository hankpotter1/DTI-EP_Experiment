# -*- coding: utf-8 -*-
"""
补齐 Tier-2(同靶点强/弱结合剂中位分半 AUC),并加入**平凡基线对照**。

动机(来自批判性评估):
  · 原报告主叙事完全围绕 Tier-3 排序,Tier-2 仅以「均值」出现(无 CI、无检验);
  · 若 Tier-2 AUC 显著高于 0.5,审稿人会问「是否说明模型仍有微弱但有用的二分类能力?」
  · 关键检验:若**分子量基线**的 Tier-2 也达同水平,则该能力同样不具模型特异性。

做法:直接从 results/predictions_57t.csv 重算(无需重新推理)。
  每个 模型 × 靶点:按 measured pchembl 中位分半 -> 强/弱两组 -> 用 predicted 算 AUC。
  同时用 MW(由 SMILES 经 rdkit 计算)替代 predicted,得到平凡基线 Tier-2。

输出:results/tier2_with_baseline.json
"""
import csv
import json
import os
import statistics as st
import sys
from collections import defaultdict

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
import numpy as np
from scipy.stats import binomtest, wilcoxon
from sklearn.metrics import roc_auc_score
from rdkit import Chem, RDLogger
from rdkit.Chem import Descriptors

RDLogger.DisableLog("rdApp.*")
rng = np.random.default_rng(20260923)

# --- 评测集(取 SMILES 以算 MW)---
ev = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
smiles = {r["molecule_chembl_id"]: r["smiles"] for r in ev}
mw = {}
for mid, smi in smiles.items():
    m = Chem.MolFromSmiles(smi)
    if m is not None:
        mw[mid] = Descriptors.MolWt(m)
print("分子量可用: %d / %d" % (len(mw), len(smiles)), flush=True)

# --- 预测 ---
rows = list(csv.DictReader(open(os.path.join(RES, "predictions_57t.csv"), encoding="utf-8-sig")))
print("预测行: %d;列: %s" % (len(rows), list(rows[0].keys())), flush=True)


def tier2_by_target(pairs):
    """pairs: list of (measured, score) 逐靶点 -> 中位分半 AUC"""
    by_t = defaultdict(list)
    for t, me, sc in pairs:
        by_t[t].append((me, sc))
    out = {}
    for t, arr in by_t.items():
        arr = sorted(arr)
        if len(arr) < 8:
            continue
        half = len(arr) // 2
        weak, strong = arr[:half], arr[-half:]
        y = [1] * len(strong) + [0] * len(weak)
        s = [b for _, b in strong] + [b for _, b in weak]
        if len(set(s)) < 2:
            continue
        out[t] = float(roc_auc_score(y, s))
    return out


def summarize(name, per_target):
    a = np.array(list(per_target.values()))
    if len(a) < 5:
        return None
    boot = [np.mean(rng.choice(a, len(a), replace=True)) for _ in range(4000)]
    return {
        "n_targets": len(a),
        "mean_auc": round(float(a.mean()), 4),
        "median_auc": round(float(np.median(a)), 4),
        "ci95": [round(float(np.percentile(boot, 2.5)), 4), round(float(np.percentile(boot, 97.5)), 4)],
        "frac_above_0.5": round(float((a > 0.5).mean()), 4),
        "sign_p": float(binomtest(int((a > 0.5).sum()), len(a), 0.5).pvalue),
        "wilcoxon_p": float(wilcoxon(a - 0.5).pvalue),
    }


summary = {}
# 各模型 Tier-2
models = sorted({r["model"] for r in rows})
for mn in models:
    pairs = [(r["target"], float(r["measured"]), float(r["predicted"]))
             for r in rows if r["model"] == mn and str(r.get("is_own", "1")) == "1"]
    res = summarize(mn, tier2_by_target(pairs))
    if res:
        summary[mn] = res
        print("  %-28s Tier2 AUC 均 %.3f 中位 %.3f CI[%.3f,%.3f] n=%d p=%.3g" % (
            mn.replace("_bindingdb", ""), res["mean_auc"], res["median_auc"],
            res["ci95"][0], res["ci95"][1], res["n_targets"], res["sign_p"]), flush=True)

# 平凡基线:MW 作为分数
pairs_mw = [(r["target"], float(r["measured"]), mw[r["molecule"]])
            for r in rows if r["model"] == models[0] and str(r.get("is_own", "1")) == "1"
            and r["molecule"] in mw]
base = summarize("MW_baseline", tier2_by_target(pairs_mw))
summary["MW_baseline"] = base
print("\n  平凡基线(分子量)         Tier2 AUC 均 %.3f 中位 %.3f CI[%.3f,%.3f] n=%d p=%.3g" % (
    base["mean_auc"], base["median_auc"], base["ci95"][0], base["ci95"][1], base["n_targets"], base["sign_p"]), flush=True)

# DrugBAN(若有自身预测)
db = os.path.join(RES, "drugban_predictions.csv")
if os.path.isfile(db):
    dr = list(csv.DictReader(open(db, encoding="utf-8-sig")))
    cols = list(dr[0].keys())
    print("\n  DrugBAN 预测列:", cols, flush=True)
    key_t = "target" if "target" in cols else cols[1]
    key_m = next((c for c in cols if "molecule" in c.lower() or "chembl" in c.lower()), None)
    key_p = next((c for c in cols if "pred" in c.lower() or "score" in c.lower()), None)
    key_y = next((c for c in cols if "measur" in c.lower() or "pchembl" in c.lower()), None)
    if all([key_m, key_p, key_y]):
        dp = [(r[key_t], float(r[key_y]), float(r[key_p])) for r in dr if str(r.get("is_own", "1")) == "1"]
        res = summarize("DrugBAN", tier2_by_target(dp))
        if res:
            summary["DrugBAN_ep43"] = res
            print("  DrugBAN Tier2 AUC 均 %.3f CI[%.3f,%.3f] n=%d p=%.3g" % (
                res["mean_auc"], res["ci95"][0], res["ci95"][1], res["n_targets"], res["sign_p"]), flush=True)

json.dump(summary, open(os.path.join(RES, "tier2_with_baseline.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/tier2_with_baseline.json", flush=True)
