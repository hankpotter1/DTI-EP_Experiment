# -*- coding: utf-8 -*-
"""
阈值文献锚定:ρ ≥ 0.4 作为「可用排序能力」的依据从何而来?

用 Europe PMC REST API(本环境 web_search 不可用,但 EBI 可达)做定向检索,
汇总与「虚拟筛选排序性能阈值 / Spearman 与富集的关系」相关的文献线索。

输出:results/threshold_literature.json(+ 打印摘要)
"""
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
API = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
UA = {"User-Agent": "netpharm-lit"}
PROXY = "http://127.0.0.1:7897"
os.environ.setdefault("HTTPS_PROXY", PROXY)

QUERIES = {
    "VS_Spearman_EF": '(TITLE_ABS:"virtual screening") AND (TITLE_ABS:"Spearman") AND (TITLE_ABS:"enrichment factor")',
    "VS_ranking_benchmark": '(TITLE_ABS:"virtual screening") AND (TITLE_ABS:"ranking") AND (TITLE_ABS:"benchmark")',
    "DTI_eval_flaw": '(TITLE_ABS:"drug-target interaction") AND (TITLE_ABS:"benchmark") AND (TITLE_ABS:("flaw" OR "pitfall" OR "evaluation"))',
    "decoys_bias": '(TITLE_ABS:"decoy") AND (TITLE_ABS:("bias" OR "artificial enrichment")) AND (TITLE_ABS:"virtual screening")',
    "ML_neg_results": '(TITLE_ABS:"machine learning") AND (TITLE_ABS:("negative results" OR "does not improve")) AND (TITLE_ABS:"benchmark")',
    "DTI_generalization": '(TITLE_ABS:"drug-target interaction") AND (TITLE_ABS:("generalization" OR "generalisation" OR "out-of-distribution"))',
}

out = {}
for key, q in QUERIES.items():
    url = API + "?" + urllib.parse.urlencode({
        "query": q, "format": "json", "pageSize": "8", "resultType": "core"})
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=60) as r:
            d = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        print("  [%s] 检索失败: %s" % (key, str(e)[:80]), flush=True)
        continue
    n = d.get("hitCount")
    items = []
    for res in d.get("resultList", {}).get("result", []):
        items.append({
            "title": res.get("title"),
            "journal": (res.get("journalInfo") or {}).get("journal", {}).get("title") or res.get("journalTitle"),
            "year": res.get("pubYear"),
            "doi": res.get("doi"),
            "pmid": res.get("pmid"),
            "abstract_snippet": (res.get("abstractText") or "")[:600],
        })
    out[key] = {"query": q, "hitCount": n, "items": items}
    print("\n=== %s (命中 %s) ===" % (key, n), flush=True)
    for it in items:
        print("  · [%s %s] %s" % (it["year"], (it["journal"] or "")[:34], (it["title"] or "")[:96]), flush=True)
    time.sleep(0.4)

json.dump(out, open(os.path.join(RES, "threshold_literature.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/threshold_literature.json", flush=True)
