# -*- coding: utf-8 -*-
"""平凡基线协议的演示与自测:用本研究数据验证模块行为。"""
import csv
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
RES = os.path.join(BASE, "results")
sys.path.insert(0, os.path.join(BASE, "tools"))

from trivial_baseline import run_protocol

# 组装兼容 CSV:target, smiles, activity, predicted(取 cnn_cnn 自身配体对)
ev = {r["molecule_chembl_id"]: r["smiles"] for r in
      csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig"))}
pred = list(csv.DictReader(open(os.path.join(RES, "predictions_57t.csv"), encoding="utf-8-sig")))
demo = os.path.join(RES, "_demo_trivial_baseline.csv")
n = 0
with open(demo, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["target", "smiles", "activity", "predicted", "model"])
    for r in pred:
        if r["model"] != "cnn_cnn_bindingdb" or str(r.get("is_own", "1")) != "1":
            continue
        smi = ev.get(r["molecule"])
        if not smi:
            continue
        w.writerow([r["target"], smi, r["measured"], r["predicted"], r["model"]])
        n += 1
print("演示集: %d 行" % n, flush=True)

rep = run_protocol(demo, model_col="predicted", model_name="cnn_cnn_bindingdb")
print("\n=== 结果 ===", flush=True)
print("  靶点 %d" % rep["n_targets"], flush=True)
for p, v in sorted(rep["baselines"].items(), key=lambda kv: -kv[1]["median_rho"]):
    print("  %-18s 中位 ρ %.3f  CI[%.3f,%.3f]" % (
        "%s(%s)" % (p, v["label_zh"]), v["median_rho"], v["ci95_median"][0], v["ci95_median"][1]), flush=True)
m = rep["model"]
print("  %-18s 中位 ρ %.3f  CI[%.3f,%.3f]" % (m["name"], m["median_rho"],
                                               m["ci95_median"][0], m["ci95_median"][1]), flush=True)
print("\n  判定: %s" % rep["verdict"]["statement"], flush=True)
print("  (模型中位 %.3f vs 基线 %s 中位 %.3f)" % (
    rep["verdict"]["model_median"], rep["verdict"]["baseline_property"], rep["verdict"]["baseline_median"]), flush=True)

json.dump(rep, open(os.path.join(RES, "trivial_baseline_demo.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/trivial_baseline_demo.json", flush=True)
