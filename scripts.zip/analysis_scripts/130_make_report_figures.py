# -*- coding: utf-8 -*-
"""
为「完整实验报告」生成新增图表(Plotly -> PNG/PDF)。
本机无 matplotlib,统一用 Plotly + kaleido。
"""
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"
os.makedirs(FIG, exist_ok=True)

import plotly.graph_objects as go

C_BLUE, C_RED, C_GREY, C_GREEN, C_ORANGE = "#2c6fbb", "#c0392b", "#7f8c8d", "#27ae60", "#e67e22"


def save(fig, name, w=900, h=520):
    for ext in ("png", "pdf"):
        fig.write_image(os.path.join(FIG, "%s.%s" % (name, ext)), width=w, height=h, scale=2)
    print("  已出图:", name, flush=True)


def J(fn):
    return json.load(open(os.path.join(RES, fn), encoding="utf-8"))


# ---------- 图 F1:训练集重叠 ----------
ref = J("bindingdb_overlap_refined.json")
lig = J("bindingdb_ligand_overlap.json")
tgt = J("bindingdb_target_overlap.json")
labels = ["靶点\n(43/57)", "分子\n(1,107/1,409)", "(靶点,配体)对\n(1,097/1,425)",
          "对·入库<2021\n(1,093/1,425)", "对·入库<2019\n(1,087/1,425)"]
vals = [tgt["frac_in_bindingdb"] * 100, lig["ligand_frac"] * 100, lig["pair_frac"] * 100,
        ref["by_cutoff"]["2021-01-01"]["frac"] * 100, ref["by_cutoff"]["2019-01-01"]["frac"] * 100]
fig = go.Figure(go.Bar(x=labels, y=vals, marker_color=[C_BLUE, C_BLUE, C_RED, C_RED, C_RED],
                       text=["%.1f%%" % v for v in vals], textposition="outside"))
fig.update_layout(title="图 F1|评测集与模型训练数据(BindingDB)的重叠 —— <b>并非域外</b>",
                  yaxis_title="出现在 BindingDB 的比例 (%)", yaxis_range=[0, 100],
                  template="plotly_white", font=dict(size=14), showlegend=False)
save(fig, "fig_report_F1_bindingdb_overlap")

# ---------- 图 F2:配体性质基线 vs 六个 DTI 模型 ----------
f2 = J("audit_forensics2.json")["N6_ligand_only_baseline"]
props = [("MW", "分子量"), ("ArRings", "芳香环数"), ("HBD", "氢键供体"), ("RotB", "可旋转键"),
         ("TPSA", "TPSA"), ("logP", "logP")]
names = [zh for _, zh in props] + ["<b>cnn_cnn</b>", "<b>morgan_aac</b>", "<b>morgan_cnn</b>",
                                   "<b>daylight_aac</b>", "<b>transformer_cnn</b>", "<b>mpnn_cnn</b>"]
mvals = [(f2[k]["median_rho"], f2[k]["ci95"]) for k, _ in props]
model_med = [0.194, 0.167, 0.132, 0.123, 0.089, 0.012]
err_plus = [m[1][1] - m[0] for m in mvals] + [0] * 6
err_minus = [m[0] - m[1][0] for m in mvals] + [0] * 6
fig = go.Figure()
fig.add_trace(go.Bar(x=names, y=[m[0] for m in mvals] + model_med,
                     error_y=dict(type="data", symmetric=False, array=err_plus, arrayminus=err_minus),
                     marker_color=[C_ORANGE] * 6 + [C_BLUE] * 6,
                     text=["%.3f" % (m[0]) for m in mvals] + ["%.3f" % v for v in model_med],
                     textposition="outside"))
fig.add_hline(y=0.187, line_dash="dash", line_color=C_RED,
              annotation_text="分子量基线 ρ=0.187", annotation_position="top left")
fig.update_layout(title="图 F2|平凡性质基线 vs 六个 DTI 模型(逐靶点 ρ 中位)",
                  yaxis_title="逐靶点 Spearman ρ(中位)", yaxis_range=[-0.05, 0.32],
                  template="plotly_white", font=dict(size=13), showlegend=False)
save(fig, "fig_report_F2_ligand_baseline")

# ---------- 图 F3:三方对照(筛选 × 取样) ----------
se = J("strict_eq_eval.json")
sd = J("strict_and_decoy_eval.json")
cri = J("critical_analysis_summary.json")


def med_lookup(name):
    def walk(o):
        if isinstance(o, dict):
            if o.get("model") == name:
                return o.get("median_rho")
            for v in o.values():
                r = walk(v)
                if r is not None:
                    return r
        elif isinstance(o, list):
            for v in o:
                r = walk(v)
                if r is not None:
                    return r
        return None
    return walk(cri)


order = ["morgan_aac_bindingdb", "cnn_cnn_bindingdb", "daylight_aac_bindingdb",
         "morgan_cnn_bindingdb", "transformer_cnn_bindingdb", "mpnn_cnn_bindingdb"]
A = [med_lookup(m) or 0 for m in order]
B = [(sd.get(m) or {}).get("median_rho") or 0 for m in order]
Cc = [(se.get(m) or {}).get("median_rho") or 0 for m in order]
fig = go.Figure()
fig.add_trace(go.Bar(name="A 松筛选+等距(原)", x=order, y=A, marker_color=C_GREY))
fig.add_trace(go.Bar(name="B 严格+随机", x=order, y=B, marker_color=C_BLUE))
fig.add_trace(go.Bar(name="C 严格+等距(新)", x=order, y=Cc, marker_color=C_RED))
fig.update_layout(title="图 F3|筛选严格度 × 取样方式 的三方对照 —— 两变量互相纠缠",
                  yaxis_title="逐靶点 ρ 中位", barmode="group", template="plotly_white",
                  font=dict(size=12), xaxis_tickangle=-20)
save(fig, "fig_report_F3_three_way")

# ---------- 图 F4:MRR 与正确随机基线 ----------
rt = J("retrieval_tier1.json")
af = J("audit_fixes.json")
mr = af["S1_mrr_baseline"]["model_mrr"]
base = af["S1_mrr_baseline"]["analytic_H_n_over_n"]
ms = sorted(mr.items(), key=lambda kv: -kv[1])
fig = go.Figure(go.Bar(x=[k.replace("_bindingdb", "") for k, _ in ms], y=[v for _, v in ms],
                       marker_color=[C_RED if v < base else C_BLUE for _, v in ms],
                       text=["%.4f" % v for _, v in ms], textposition="outside"))
fig.add_hline(y=base, line_dash="dash", line_color=C_GREEN,
              annotation_text="正确随机基线 0.0812", annotation_position="top right")
fig.update_layout(title="图 F4|Tier-1 检索 MRR:更正基线后 <b>3/6 模型低于随机</b>",
                  yaxis_title="MRR", yaxis_range=[0, 0.115], template="plotly_white",
                  font=dict(size=13), showlegend=False)
save(fig, "fig_report_F4_mrr")

# ---------- 图 F5:诱饵判别 AUC(带 CI) ----------
dec = af["M3_decoy_auc_ci"]
ds = sorted(dec.items(), key=lambda kv: -kv[1]["median_auc"])
fig = go.Figure()
fig.add_trace(go.Scatter(x=[v["median_auc"] for _, v in ds],
                         y=[k.replace("_bindingdb", "") for k, _ in ds],
                         mode="markers",
                         error_x=dict(type="data", symmetric=False,
                                      array=[v["ci95"][1] - v["median_auc"] for _, v in ds],
                                      arrayminus=[v["median_auc"] - v["ci95"][0] for _, v in ds]),
                         marker=dict(size=12, color=C_BLUE)))
fig.add_vline(x=0.5, line_dash="dash", line_color=C_RED, annotation_text="随机 0.5")
fig.update_layout(title="图 F5|诱饵判别 AUC(真配体 vs 性质匹配诱饵)—— 远低于可用水平",
                  xaxis_title="逐靶点 AUC 中位(95% CI)", xaxis_range=[0.45, 0.65],
                  template="plotly_white", font=dict(size=13), showlegend=False)
save(fig, "fig_report_F5_decoy_auc", w=900, h=460)

# ---------- 图 F6:DrugBAN 域内 vs 迁移落差 ----------
e43 = J("drugban_eval_ep43.json")
e30 = J("drugban_eval_ep30.json")
fig = go.Figure()
fig.add_trace(go.Bar(name="域内 AUROC(BindingDB 验证集)", x=["DrugBAN"], y=[0.9624], marker_color=C_GREEN,
                     text=["0.962"], textposition="outside"))
fig.add_trace(go.Bar(name="迁移到 57 靶点基准:ρ(epoch 43)", x=["DrugBAN"], y=[e43["tier3_median_rho"]],
                     marker_color=C_BLUE, text=["%.3f" % e43["tier3_median_rho"]], textposition="outside"))
fig.add_trace(go.Bar(name="迁移到 57 靶点基准:ρ(epoch 30)", x=["DrugBAN"], y=[e30["tier3_median_rho"]],
                     marker_color=C_GREY, text=["%.3f" % e30["tier3_median_rho"]], textposition="outside"))
fig.update_layout(title="图 F6|现代 SOTA 模型 DrugBAN(2022):域内 0.96 → 本基准 <b>0.165–0.188</b>",
                  yaxis_title="AUROC / Spearman ρ", yaxis_range=[0, 1.05],
                  barmode="group", template="plotly_white", font=dict(size=13))
save(fig, "fig_report_F6_drugban_gap")

# ---------- 图 F7:主结果总览(6 模型 ρ + CI)----------
main = [("cnn_cnn", 0.194, 0.050, 0.238), ("morgan_aac", 0.167, 0.043, 0.242),
        ("morgan_cnn", 0.132, 0.061, 0.243), ("daylight_aac", 0.123, 0.048, 0.195),
        ("transformer_cnn", 0.089, 0.022, 0.132), ("mpnn_cnn", 0.012, -0.063, 0.102)]
fig = go.Figure()
fig.add_trace(go.Scatter(x=[m[1] for m in main], y=[m[0] for m in main], mode="markers",
                         error_x=dict(type="data", symmetric=False,
                                      array=[m[3] - m[1] for m in main],
                                      arrayminus=[m[1] - m[2] for m in main]),
                         marker=dict(size=13, color=C_BLUE)))
fig.add_vline(x=0, line_color=C_GREY, line_dash="dot")
fig.add_vline(x=0.4, line_color=C_RED, line_dash="dash",
              annotation_text="可用阈值 ρ=0.4", annotation_position="top right")
fig.update_layout(title="图 F7|主结果:六个开箱 DTI 模型的逐靶点 ρ(中位 + 95% CI)",
                  xaxis_title="逐靶点 Spearman ρ", xaxis_range=[-0.15, 0.5],
                  template="plotly_white", font=dict(size=13), showlegend=False)
save(fig, "fig_report_F7_main_rho", w=900, h=460)

print("\n全部新增图表完成 ->", FIG, flush=True)
