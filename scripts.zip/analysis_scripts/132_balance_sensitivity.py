# -*- coding: utf-8 -*-
"""
敏感性分析:结论是否依赖「严格集的非平衡设计」(批判性评估第 4 条)

审稿人可质疑:严格集实际基于 52 个靶点(CASP3 因 n≥10 门槛被剔除),
且每靶点配体数 2–25 不等 —— 这种非平衡会不会驱动了结论?

做法:在严格集与严格等距集上,按「每靶点配体数」分层重算逐靶点 ρ,
      检验结论(ρ 仍远低于可用阈值)是否只在某个规模层成立。

输入:results/predictions_strict.csv、predictions_strict_eq.csv
输出:results/balance_sensitivity.json
"""
import csv
import json
import os
import statistics as st
import sys
from collections import Counter, defaultdict

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
import numpy as np
from scipy.stats import spearmanr, mannwhitneyu


def rho(x, y):
    if len(set(x)) < 2 or len(set(y)) < 2:
        return None
    r = spearmanr(x, y)[0]
    return None if r != r else float(r)


out = {}
for fn, label, decoy_col in (("predictions_strict.csv", "严格+随机", "is_decoy"),
                             ("predictions_strict_eq.csv", "严格+等距", None)):
    p = os.path.join(RES, fn)
    if not os.path.isfile(p):
        continue
    rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
    by_m = defaultdict(lambda: defaultdict(list))
    for r in rows:
        if decoy_col and str(r.get(decoy_col, "0")) == "1":
            continue
        try:
            by_m[r["model"]][r["target"]].append((float(r["measured"]), float(r["predicted"])))
        except (ValueError, KeyError):
            continue

    print("=== %s ===" % label, flush=True)
    res = {"ligands_per_target": {}, "models": {}}
    counts = Counter(len(v) for m in by_m.values() for v in m.values())
    res["ligands_per_target"] = dict(sorted(counts.items()))
    print("  每靶点配体数分布:", dict(sorted(counts.items())), flush=True)

    for mn, tg in by_m.items():
        full, big15, big20 = [], [], []
        for t, arr in tg.items():
            if len(arr) < 10:
                continue
            v = rho([b for _, b in arr], [a for a, _ in arr])
            if v is None:
                continue
            full.append(v)
            if len(arr) >= 15:
                big15.append(v)
            if len(arr) >= 20:
                big20.append(v)
        if not full:
            continue
        res["models"][mn] = {
            "all_targets": {"n": len(full), "median_rho": round(float(np.median(full)), 4)},
            "ge15_ligands": {"n": len(big15), "median_rho": round(float(np.median(big15)), 4) if big15 else None},
            "ge20_ligands": {"n": len(big20), "median_rho": round(float(np.median(big20)), 4) if big20 else None},
        }
        try:
            pv = float(mannwhitneyu(full, big15).pvalue) if big15 else None
        except Exception:
            pv = None
        res["models"][mn]["mw_p_all_vs_ge15"] = pv
        print("  %-28s 全(%d) %.3f | ≥15配体(%d) %.3f | ≥20配体(%d) %s | MW p=%.3f" % (
            mn.replace("_bindingdb", ""), len(full), np.median(full),
            len(big15), (np.median(big15) if big15 else float("nan")),
            len(big20), ("%.3f" % np.median(big20)) if big20 else "n/a",
            pv if pv is not None else float("nan")), flush=True)
    out[label] = res

json.dump(out, open(os.path.join(RES, "balance_sensitivity.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/balance_sensitivity.json", flush=True)
