# -*- coding: utf-8 -*-
"""
用 ConPLex 官方预训练权重评测 57 靶点基准(批判性评估后补齐模型覆盖)

流程:建官方输入(proteinID/moleculeID/seq/SMILES)-> 调 conplex-dti predict
      -> 解析输出 -> 逐靶点 ρ + bootstrap CI + 符号检验 -> 与既有 8 个模型并列

注:首次运行需生成 ProtBert 与 Morgan 特征(HF 走镜像)。
输出:results/conplex_eval.json + results/conplex_predictions.tsv
"""
import csv
import json
import os
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
RES = os.path.join(BASE, "results")
WORK = os.path.join(BASE, "thirdparty", "conplex")
CLI = r"C:\Users\<user>\miniforge3\envs\conplex\Scripts\conplex-dti.exe"
PY = r"C:\Users\<user>\miniforge3\envs\conplex\python.exe"

# ---------- 1) 建输入 ----------
rows = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
inp = os.path.join(WORK, "pairs_57t.tsv")
with open(inp, "w", encoding="utf-8", newline="") as f:
    for r in rows:
        # proteinID / moleculeID / sequence / smiles(制表符分隔)
        f.write("%s\t%s\t%s\t%s\n" % (r["target"], r["molecule_chembl_id"], r["sequence"], r["smiles"]))
print("输入: %d 对 -> %s" % (len(rows), inp), flush=True)

# ---------- 2) 调官方 predict ----------
out_tsv = os.path.join(WORK, "conplex_results.tsv")
env = dict(os.environ)
env["HF_ENDPOINT"] = "https://hf-mirror.com"
env["HTTPS_PROXY"] = env["HTTP_PROXY"] = "http://127.0.0.1:7897"
cmd = [CLI, "predict", "--data-file", inp, "--model-path",
       os.path.join(WORK, "models", "ConPLex_v1_BindingDB.pt"),
       "--outfile", out_tsv, "--data-cache-dir", WORK, "--device", "cpu", "--batch-size", "64"]
print("执行:", " ".join(cmd), flush=True)
p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", env=env)
print("  returncode:", p.returncode, flush=True)
print("  stdout 尾:", (p.stdout or "")[-800:], flush=True)
print("  stderr 尾:", (p.stderr or "")[-800:], flush=True)

if not os.path.isfile(out_tsv):
    print("!! 未产出结果文件,终止", flush=True)
    sys.exit(1)

# ---------- 3) 解析 + 指标 ----------
import numpy as np
from scipy.stats import spearmanr, binomtest

res_rows = list(csv.DictReader(open(out_tsv, encoding="utf-8"), delimiter="\t"))
print("结果列:", list(res_rows[0].keys()), flush=True)
print("结果行:", len(res_rows), flush=True)

# 官方输出为 [moleculeID] [proteinID] [prediction](列名可能缺失/无意义)→ 按位置兵底
cols = list(res_rows[0].keys())
pred_col = next((c for c in cols if c.lower() in ("pred", "prediction", "score", "y_pred")), None)
ki = next((c for c in cols if "protein" in c.lower() and "id" in c.lower()), None)
mi = next((c for c in cols if "molecule" in c.lower() and "id" in c.lower()), None)
if pred_col is None:
    cands = [c for c in cols if "pred" in c.lower() or "score" in c.lower()]
    pred_col = cands[0] if cands else cols[-1]
if ki is None or mi is None:
    # 按位置:[moleculeID] [proteinID] [prediction]
    mi, ki, pred_col = cols[0], cols[1], (pred_col if pred_col else cols[2])
print("列映射: moleculeID=%s proteinID=%s prediction=%s" % (mi, ki, pred_col), flush=True)
true_map = {(r["target"], r["molecule_chembl_id"]): float(r["pchembl"]) for r in rows}


def rho(x, y):
    if len(set(x)) < 2 or len(set(y)) < 2:
        return None
    v = spearmanr(x, y)[0]
    return None if v != v else float(v)


by_t = {}
for r in res_rows:
    t = r.get(ki)
    m = r.get(mi)
    if t is None or m is None:
        continue
    try:
        pr = float(r[pred_col])
    except (TypeError, ValueError):
        continue
    if (t, m) in true_map:
        by_t.setdefault(t, []).append((true_map[(t, m)], pr))

rng = np.random.default_rng(20260923)
vals = [v for t, arr in by_t.items() if len(arr) >= 10
        for v in [rho([b for _, b in arr], [a for a, _ in arr])] if v is not None]
if vals:
    a = np.array(vals)
    boot = [np.median(rng.choice(a, len(a), replace=True)) for _ in range(4000)]
    out = {"model": "ConPLex_v1_BindingDB(官方权重)", "n_targets": len(a),
           "median_rho": round(float(np.median(a)), 4),
           "mean_rho": round(float(a.mean()), 4),
           "ci95_median": [round(float(np.percentile(boot, 2.5)), 4),
                           round(float(np.percentile(boot, 97.5)), 4)],
           "pos_frac": round(float((a > 0).mean()), 4),
           "sign_p": float(binomtest(int((a > 0).sum()), len(a), 0.5).pvalue)}
    print("\n==== ConPLex 结果 ====", flush=True)
    print("  逐靶点 ρ 中位 %.3f CI[%.3f,%.3f] | 正相关 %.0f%% | 符号 p=%.3g | n=%d" % (
        out["median_rho"], out["ci95_median"][0], out["ci95_median"][1],
        100 * out["pos_frac"], out["sign_p"], out["n_targets"]), flush=True)
    json.dump(out, open(os.path.join(RES, "conplex_eval.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print("落盘: results/conplex_eval.json", flush=True)
else:
    print("!! 无法计算 ρ(配对未匹配上?)", flush=True)
