# -*- coding: utf-8 -*-
"""
路线 A 第一步:绕开 HF API,用直链把 ProtBert 拉到本地目录。

背景:hf-mirror.com 只镜像了**文件直链**(resolve/main/...),**没有镜像 API**(/api/models/...),
而 transformers/huggingface_hub 必须走 API 解析 revision -> 失败。
解法:直接按文件名下载,组成标准 transformers 模型目录,然后 from_pretrained(本地路径)。
"""
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")

DEST = r"G:\HHH\openclaw-workspace\netpharm-toolkit\thirdparty\conplex\prot_bert_local"
BASE = "https://hf-mirror.com/Rostlab/prot_bert/resolve/main"
FILES = ["config.json", "vocab.txt", "tokenizer_config.json", "special_tokens_map.json",
         "pytorch_model.bin"]

os.makedirs(DEST, exist_ok=True)
os.environ.setdefault("HTTPS_PROXY", "http://127.0.0.1:7897")
os.environ.setdefault("HTTP_PROXY", "http://127.0.0.1:7897")

import requests

s = requests.Session()
s.proxies = {"http": "http://127.0.0.1:7897", "https": "http://127.0.0.1:7897"}
s.trust_env = True

for fn in FILES:
    dst = os.path.join(DEST, fn)
    if os.path.isfile(dst) and os.path.getsize(dst) > 0:
        print("  跳过(已存在): %s (%.1f MB)" % (fn, os.path.getsize(dst) / 1048576), flush=True)
        continue
    url = "%s/%s" % (BASE, fn)
    ok = False
    for attempt in range(4):
        try:
            t0 = time.time()
            with s.get(url, stream=True, timeout=300) as r:
                r.raise_for_status()
                total = int(r.headers.get("content-length") or 0)
                tmp = dst + ".part"
                got = 0
                with open(tmp, "wb") as f:
                    for chunk in r.iter_content(1024 * 512):
                        if chunk:
                            f.write(chunk)
                            got += len(chunk)
                os.replace(tmp, dst)
            print("  ✅ %-26s %.1f MB  (%.1fs%s)" % (
                fn, got / 1048576, time.time() - t0,
                ", 期望 %.1f MB" % (total / 1048576) if total else ""), flush=True)
            ok = True
            break
        except Exception as e:
            print("  ⚠️ %s 第 %d 次失败: %s" % (fn, attempt + 1, str(e)[:90]), flush=True)
            time.sleep(2 * (attempt + 1))
    if not ok:
        print("  ❌ %s 最终失败" % fn, flush=True)

print("\n=== 结果 ===", flush=True)
for fn in FILES:
    p = os.path.join(DEST, fn)
    print("  %-28s %s" % (fn, ("%.1f MB" % (os.path.getsize(p) / 1048576)) if os.path.isfile(p) else "缺失"), flush=True)
