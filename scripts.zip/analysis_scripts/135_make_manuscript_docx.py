# -*- coding: utf-8 -*-
"""
把实验报告 Markdown 转为 Word(.docx),嵌入全部图表。
本机无 pandoc,用 python-docx 自建轻量转换(支持:标题/段落/粗体/表格/列表/引用/图片/分隔线)。
"""
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
SRC = os.path.join(BASE, "manuscript", "DTI_manuscript_v2.md")
OUT = os.path.join(BASE, "manuscript", "DTI_manuscript_v2.docx")

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

from docx.oxml.ns import qn
doc = Document()
st = doc.styles["Normal"]
# 关键修复:此前用 Microsoft YaHei 作正文西文字体,该字体缺 Greek 字形 -> ρ 被丢成 "p"。
# 改为西文 Times New Roman(含 Greek)+ 中文 eastAsia=YaHei。
st.font.name = "Times New Roman"
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
st.font.size = Pt(10.5)

lines = open(SRC, encoding="utf-8").read().split("\n")


def add_runs(par, text):
    """处理 **粗体** 与 `代码`"""
    for part in re.split(r"(\*\*.+?\*\*|`[^`]+`)", text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            r = par.add_run(part[2:-2])
            r.bold = True
        elif part.startswith("`") and part.endswith("`"):
            r = par.add_run(part[1:-1])
            r.font.name = "Consolas"
        else:
            par.add_run(part)


i = 0
n_img = 0
n_tab = 0
while i < len(lines):
    ln = lines[i].rstrip()

    # 图片
    m = re.match(r"^!\[(.*?)\]\((.+?)\)\s*$", ln)
    if m:
        alt, rel = m.group(1), m.group(2)
        p = os.path.normpath(os.path.join(BASE, "manuscript", rel))
        if os.path.isfile(p):
            doc.add_picture(p, width=Inches(6.2))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap = doc.add_paragraph()
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = cap.add_run(alt)
            r.italic = True
            r.font.size = Pt(9)
            r.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
            n_img += 1
        else:
            doc.add_paragraph("[缺图: %s]" % rel)
        i += 1
        continue

    # 表格
    if ln.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:\-|]+\|$", lines[i + 1].strip()):
        rows = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            if not re.match(r"^\|[\s:\-|]+\|$", lines[i].strip()):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
            i += 1
        if rows:
            ncol = max(len(r) for r in rows)
            t = doc.add_table(rows=0, cols=ncol)
            t.style = "Light Grid Accent 1"
            t.alignment = WD_TABLE_ALIGNMENT.CENTER
            for ri, row in enumerate(rows):
                cells = t.add_row().cells
                for ci in range(ncol):
                    txt = row[ci] if ci < len(row) else ""
                    par = cells[ci].paragraphs[0]
                    add_runs(par, txt)
                    for r in par.runs:
                        r.font.size = Pt(8.5)
                        if ri == 0:
                            r.bold = True
            doc.add_paragraph()
            n_tab += 1
        continue

    # 标题
    if ln.startswith("#"):
        lvl = len(ln) - len(ln.lstrip("#"))
        txt = ln.lstrip("#").strip()
        h = doc.add_heading("", level=min(lvl, 4))
        add_runs(h, txt)
        i += 1
        continue

    # 分隔线
    if re.match(r"^-{3,}$", ln):
        doc.add_paragraph("─" * 40)
        i += 1
        continue

    # 引用
    if ln.startswith(">"):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.3)
        add_runs(p, ln.lstrip("> ").strip())
        for r in p.runs:
            r.italic = True
            r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
        i += 1
        continue

    # 列表
    if re.match(r"^(\s*)[-*] ", ln) or re.match(r"^(\s*)\d+\. ", ln):
        txt = re.sub(r"^\s*([-*]|\d+\.)\s+", "", ln)
        p = doc.add_paragraph(style="List Bullet")
        add_runs(p, txt)
        i += 1
        continue

    if ln.strip():
        p = doc.add_paragraph()
        add_runs(p, ln.strip())
    i += 1

doc.save(OUT)
print("已生成:", OUT, flush=True)
print("  嵌入图 %d 张 / 表格 %d 个" % (n_img, n_tab), flush=True)
print("  大小: %.1f KB" % (os.path.getsize(OUT) / 1024), flush=True)
