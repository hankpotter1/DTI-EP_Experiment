# -*- coding: utf-8 -*-
"""
Analysis 1 (reviewer-driven): statistical independence correction.

Problem: per-target Spearman rho are NOT independent because ~16 molecules are
shared across targets. Naive sign tests / Wilcoxon / iid bootstrap understate
the variance. We recompute the Tier-3 primary endpoint (median per-target rho)
with a *cluster* bootstrap, both by target and by ligand (the shared unit), and
apply Benjamini-Hochberg and Bonferroni correction to:
  (a) Tier-3 primary endpoint, 8 evaluation objects
      (6 DeepPurpose weights + DrugBAN ep43 + DrugBAN ep30)
  (b) Tier-1 retrieval, 18 comparisons (6 models x {top1, top5, top10})

Outputs: results/independence_and_ma_correction.json
"""
import csv
import json
import os
import statistics as st
import sys

import numpy as np
from scipy.stats import spearmanr, binomtest, wilcoxon

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
NBOOT = 10000          # target-cluster bootstrap (cheap)
NBOOT_HEAVY = 2000     # ligand-cluster and pair-level bootstrap (recomputes rho)
RNG_SEED = 20260924

DEEPPURPOSE = ["mpnn_cnn_bindingdb", "cnn_cnn_bindingdb", "morgan_cnn_bindingdb",
               "transformer_cnn_bindingdb", "morgan_aac_bindingdb", "daylight_aac_bindingdb"]


def med(x):
    return float(st.median(x))


# ---------------------------------------------------------------- load Tier-3
# DeepPurpose: rebuild per-target rho from the raw prediction table
rows = list(csv.DictReader(open(os.path.join(RES, "predictions_57t.csv"), encoding="utf-8-sig")))
own = [r for r in rows if str(r.get("is_own", "1")) == "1"]
by_mt = {}
for r in own:
    by_mt.setdefault(r["model"], {}).setdefault(r["target"], []).append(
        (r["molecule"], float(r["measured"]), float(r["predicted"])))

objects = {}          # name -> {"per_target": {t: rho}, "pairs": {t: [(molecule,measured,pred)]}}
for m in DEEPPURPOSE:
    pt, pp = {}, {}
    for t, v in by_mt.get(m, {}).items():
        if len(v) < 5:
            continue
        x = [a for _, a, _ in v]
        y = [b for _, _, b in v]
        if len(set(x)) < 2 or len(set(y)) < 2:
            continue
        pt[t] = float(spearmanr(y, x)[0])
        pp[t] = v
    objects[m] = {"per_target": pt, "pairs": pp}

# DrugBAN: per-target rho taken from the recorded evaluation jsons
for tag, fn in (("drugban_ep43", "drugban_eval_ep43.json"),
                ("drugban_ep30", "drugban_eval_ep30.json")):
    d = json.load(open(os.path.join(RES, fn), encoding="utf-8"))
    pt = {k: float(v) for k, v in d["per_target_rho"].items()}
    objects[tag] = {"per_target": pt, "pairs": None}

print("Tier-3 objects: %d" % len(objects), flush=True)


# ------------------------------------------------- shared-ligand diagnostics
def shared_ligand_stats():
    seen = {}
    for r in own:
        seen.setdefault(r["molecule"], set()).add(r["target"])
    mols = list(seen)
    multi = {m: sorted(t) for m, t in seen.items() if len(t) > 1}
    return {"n_unique_molecules": len(mols),
            "n_shared_across_targets": len(multi),
            "shared_examples": dict(list(sorted(multi.items()))[:20])}


shared = shared_ligand_stats()
print("shared ligands: %d / %d" % (shared["n_shared_across_targets"], shared["n_unique_molecules"]), flush=True)


# ------------------------------------------------------- bootstrap machinery
def boot_by_target(rhos, rng, nboot=NBOOT):
    a = np.asarray(rhos, dtype=float)
    n = len(a)
    idx = rng.integers(0, n, size=(nboot, n))
    meds = np.median(a[idx], axis=1)
    return meds


def rho_of(vals):
    """vals: list of (measured, predicted) 2-tuples."""
    x = [v[0] for v in vals]
    y = [v[1] for v in vals]
    if len(vals) < 5 or len(set(x)) < 2 or len(set(y)) < 2:
        return None
    return float(spearmanr(y, x)[0])


def boot_by_ligand_real(pairs, rng, nboot=NBOOT_HEAVY):
    targets = sorted(pairs)
    pool = sorted({m for t in targets for (m, _, _) in pairs[t]})
    pos = {m: i for i, m in enumerate(pool)}
    # per-target arrays of (pool position -> multiplicity handled via index list)
    targ_idx = {t: [pos[m] for (m, _, _) in pairs[t]] for t in targets}
    targ_val = {t: [(a, b) for (_, a, b) in pairs[t]] for t in targets}
    P = len(pool)
    meds = []
    for _ in range(nboot):
        draw = rng.integers(0, P, size=P)
        cnt = np.bincount(draw, minlength=P)
        rhos = []
        for t in targets:
            idxs = targ_idx[t]
            take = []
            for k, ix in enumerate(idxs):
                c = cnt[ix]
                if c:
                    take.extend([targ_val[t][k]] * int(c))
            r = rho_of(take)
            if r is not None:
                rhos.append(r)
        if rhos:
            meds.append(float(st.median(rhos)))
    return np.asarray(meds)


def boot_by_pair(pairs, rng, nboot=NBOOT_HEAVY):
    """iid pair-level bootstrap (the naive/incorrect one) - reference only."""
    targets = sorted(pairs)
    flat = [(t, m, a, b) for t in targets for (m, a, b) in pairs[t]]
    meds = []
    for _ in range(nboot):
        samp = [flat[i] for i in rng.integers(0, len(flat), size=len(flat))]
        grp = {}
        for t, m, a, b in samp:
            grp.setdefault(t, []).append((a, b))
        rhos = [rho_of(v) for v in grp.values()]
        rhos = [x for x in rhos if x is not None]
        if rhos:
            meds.append(float(st.median(rhos)))
    return np.asarray(meds)


def summarize(rhos, pairs, rng):
    obs = med(rhos)
    b_t = boot_by_target(rhos, rng)
    ci_t = [float(np.percentile(b_t, 2.5)), float(np.percentile(b_t, 97.5))]
    out = {
        "n_targets": len(rhos),
        "median_rho": round(obs, 4),
        "pos_frac": round(sum(1 for x in rhos if x > 0) / len(rhos), 4),
        "cluster_bootstrap_by_target": {
            "n_boot": int(len(b_t)),
            "ci95": [round(x, 4) for x in ci_t],
            "p_median_le_0": round(float(np.mean(b_t <= 0)), 5),
        },
    }
    if pairs is not None:
        b_l = boot_by_ligand_real(pairs, rng)
        b_p = boot_by_pair(pairs, rng)
        out["cluster_bootstrap_by_ligand"] = {
            "n_boot": int(len(b_l)),
            "ci95": [round(float(np.percentile(b_l, 2.5)), 4), round(float(np.percentile(b_l, 97.5)), 4)],
            "p_median_le_0": round(float(np.mean(b_l <= 0)), 5),
        }
        out["iid_pair_bootstrap_reference"] = {
            "n_boot": int(len(b_p)),
            "ci95": [round(float(np.percentile(b_p, 2.5)), 4), round(float(np.percentile(b_p, 97.5)), 4)],
            "p_median_le_0": round(float(np.mean(b_p <= 0)), 5),
        }
    # uncorrected tests
    npos = sum(1 for x in rhos if x > 0)
    out["sign_test_p"] = float(binomtest(npos, len(rhos), 0.5).pvalue)
    nz = [x for x in rhos if x != 0]
    out["wilcoxon_p"] = float(wilcoxon(nz).pvalue) if len(nz) >= 1 else None
    return out


rng = np.random.default_rng(RNG_SEED)
tier3 = {}
for name, o in objects.items():
    tier3[name] = summarize(list(o["per_target"].values()), o["pairs"], rng)
    s = tier3[name]
    print("  %-28s median=%.3f  sign_p=%.3g  targetCI=%s  ligandCI=%s" % (
        name, s["median_rho"], s["sign_test_p"], s["cluster_bootstrap_by_target"]["ci95"],
        s.get("cluster_bootstrap_by_ligand", {}).get("ci95")), flush=True)


# ------------------------------------------------------- multiple testing
def bh_adjust(pvals):
    m = len(pvals)
    order = sorted(range(m), key=lambda i: pvals[i])
    adj = [0.0] * m
    prev = 1.0
    for rank in range(m - 1, -1, -1):
        i = order[rank]
        val = min(prev, pvals[i] * m / (rank + 1))
        adj[i] = val
        prev = val
    return [min(1.0, max(0.0, x)) for x in adj]


names = list(tier3)
raw = [tier3[n]["sign_test_p"] for n in names]
bh = bh_adjust(raw)
bonf = [min(1.0, p * len(raw)) for p in raw]
for n, p, b, bf in zip(names, raw, bh, bonf):
    tier3[n]["sign_p_bh"] = float(b)
    tier3[n]["sign_p_bonferroni"] = float(bf)


# ------------------------------------------------------- Tier-1 retrieval
t1 = json.load(open(os.path.join(RES, "tier1_expanded.json"), encoding="utf-8"))
t1rows = []
for m, v in t1["per_model"].items():
    for metric in ("top1", "top5", "top10"):
        t1rows.append({"model": m, "metric": metric,
                       "value": round(v[metric], 4),
                       "p_uncorrected": float(v["%s_p_vs_random" % metric])})
t1p = [r["p_uncorrected"] for r in t1rows]
t1bh = bh_adjust(t1p)
t1bonf = [min(1.0, p * len(t1p)) for p in t1p]
for r, b, bf in zip(t1rows, t1bh, t1bonf):
    r["p_bh"] = float(b)
    r["p_bonferroni"] = float(bf)
    r["survives_bh_0.05"] = bool(b < 0.05)
    r["survives_bonferroni_0.05"] = bool(bf < 0.05)

print("\nTier-1: %d comparisons, min raw p=%.4g, min BH p=%.4g, min Bonferroni p=%.4g" % (
    len(t1rows), min(t1p), min(t1bh), min(t1bonf)), flush=True)

out = {
    "description": "Independence correction (cluster bootstrap) and multiple-testing "
                   "correction for the DTI revision.",
    "shared_ligand_dependence": {
        "n_unique_molecules": shared["n_unique_molecules"],
        "n_molecules_shared_across_targets": shared["n_shared_across_targets"],
        "examples": shared["shared_examples"],
        "note": "cluster unit for the dependence correction is the shared molecule",
    },
    "tier3_primary_endpoint": {
        "n_objects": len(tier3),
        "correction_family_size": len(tier3),
        "bootstrap_reps_target_cluster": NBOOT,
        "bootstrap_reps_ligand_cluster_and_pair": NBOOT_HEAVY,
        "rng_seed": RNG_SEED,
        "objects": tier3,
    },
    "tier1_retrieval": {
        "n_comparisons": len(t1rows),
        "family": "6 models x {top1, top5, top10}, one-sided binomial vs random baseline",
        "comparisons": t1rows,
    },
}
json.dump(out, open(os.path.join(RES, "independence_and_ma_correction.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\nwrote results/independence_and_ma_correction.json", flush=True)
