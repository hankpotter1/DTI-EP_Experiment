# -*- coding: utf-8 -*-
"""校验 docx 转换结果:ρ 字符是否保留、表格是否完整、关键数字是否落盘。"""
import sys

sys.stdout.reconfigure(encoding="utf-8")
import re

import docx

P = r"G:\HHH\openclaw-workspace\netpharm-toolkit\manuscript\DTI_manuscript_v2.docx"
d = docx.Document(P)
para = "\n".join(x.text for x in d.paragraphs)
tab = "\n".join(c.text for t in d.tables for r in t.rows for c in r.cells)
allt = para + "\n" + tab

print("段落数: %d | 表格数: %d" % (len(d.paragraphs), len(d.tables)))
print()
print("=== 字符保真(Greek rho)===")
print("  'ρ' 出现次数: %d" % allt.count("ρ"))
print("  'ρ 0.191' 存在: %s" % ("ρ 0.191" in allt))
bad = re.findall(r"(?<![A-Za-z])p\s+0\.\d{3}", allt)
print("  可疑 'p 0.xxx' 残留: %d 处" % len(bad))
for b in bad[:5]:
    print("     -", b)
print()
print("=== 本轮新增内容是否落盘 ===")
for label, needle in [
    ("DrugBAN 重叠 3.58%", "3.58%"),
    ("训练集重叠 2.46%", "2.46%"),
    ("Davis 重叠 42.4%", "42.4%"),
    ("Bonferroni", "Bonferroni"),
    ("重原子数 ρ 0.191", "0.191"),
    ("数据库≠训练集表述", "not training membership"),
    ("重写后的 §3.9 标题", "Overlap with the training-source database"),
]:
    print("  %-24s %s" % (label, "✅" if needle in allt else "❌"))
print()
print("=== 表格完整性(每表行数)===")
for i, t in enumerate(d.tables, 1):
    print("  Table %d: %d 行 x %d 列" % (i, len(t.rows), len(t.columns)))
