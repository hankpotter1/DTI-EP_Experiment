# -*- coding: utf-8 -*-
"""
Analysis 2 (reviewer-driven): does the Davis positive control overlap the models'
training corpus?

Steps
 A. Reproduce the exact Davis panel used as the in-domain positive control
    (script 103: 40 proteins x <=25 ligands, seed 20260922), from the local
    DeepPurpose-format Davis files.
 B. Map Davis ligands (SMILES) -> PubChem CID -> ChEMBL ID (RDKit InChIKey +
    ChEMBL API).
 C. Map Davis target sequences -> gene symbol (from the Davis target keys) ->
    UniProt accession (UniProt REST API).
 D. Single streaming pass over thirdparty/bindingdb/BindingDB_ChEMBL.tsv to
    intersect (UniProt, ligand ChEMBL ID) pairs, restricted to entries deposited
    before the models' training period.
 E. Label consistency for overlapping pairs (Davis pKd vs BindingDB pKd).

Anything that cannot be computed is reported as FAILED with the blocking step.
Output: results/davis_overlap.json
"""
import csv
import json
import math
import os
import random
import statistics as st
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime

from rdkit import Chem, RDLogger
from rdkit.Chem import inchi

RDLogger.DisableLog("rdApp.*")
sys.stdout.reconfigure(encoding="utf-8")

ROOT = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
RES = os.path.join(ROOT, "results")
DAVIS = os.path.join(ROOT, "scripts", "data", "DAVIS")
BDB = os.path.join(ROOT, "thirdparty", "bindingdb")
TSV = os.path.join(BDB, "BindingDB_ChEMBL.tsv")
CACHE = os.path.join(ROOT, "cache", "davis_map")
os.makedirs(CACHE, exist_ok=True)

UA = {"User-Agent": "netpharm-davis-overlap"}
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
UNIPROT = "https://rest.uniprot.org/uniprotkb/search"

CUTOFFS = {"2021-01-01": datetime(2021, 1, 1), "2020-01-01": datetime(2020, 1, 1)}
failed = {}

# ============================================================ A. Davis panel
aff = [l.split() for l in open(os.path.join(DAVIS, "affinity.txt"), encoding="utf-8").read().splitlines() if l.strip()]
targets = json.load(open(os.path.join(DAVIS, "target_seq.txt"), encoding="utf-8-sig"))
drugs = json.load(open(os.path.join(DAVIS, "SMILES.txt"), encoding="utf-8-sig"))
tgt_seq = list(targets.values())
drug_smi = list(drugs.values())
print("Davis raw: affinity %dx%d, %d targets, %d drugs" % (
    len(aff), len(aff[0]), len(tgt_seq), len(drug_smi)), flush=True)

# replicate load_process_DAVIS pair construction (drug-major)
by_prot = {}
for i in range(len(drug_smi)):
    for j in range(len(tgt_seq)):
        by_prot.setdefault(tgt_seq[j], []).append((drug_smi[i], float(aff[i][j])))
prots = [p for p, v in by_prot.items() if len(v) >= 15]
print("unique protein sequences with >=15 ligands: %d" % len(prots), flush=True)

random.seed(20260922)
random.shuffle(prots)
prots = prots[:40]
sel = []
for p in prots:
    vs = by_prot[p]
    vs = random.sample(vs, min(25, len(vs)))
    for d, v in vs:
        sel.append((p, d, v))
print("reproduced panel: %d proteins x <=25 ligands = %d pairs" % (len(prots), len(sel)), flush=True)

seq2keys = {}
for k, s in targets.items():
    seq2keys.setdefault(s, []).append(k)


def gene_of(key):
    g = key.split("(")[0].strip()
    if g.endswith("p") and len(g) > 2:
        g = g[:-1]
    return g


panel_genes = sorted({gene_of(k) for p in prots for k in seq2keys.get(p, [])})
panel_smiles = sorted({d for _, d, _ in sel})
print("panel genes: %d, panel ligands: %d" % (len(panel_genes), len(panel_smiles)), flush=True)


# ============================================================ helpers
def fetch_json(url, name, attempts=4, timeout=60):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        try:
            return json.load(open(cf, encoding="utf-8"))
        except Exception:
            os.remove(cf)
    last = None
    for k in range(attempts):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8"))
            with open(cf + ".tmp", "w", encoding="utf-8") as f:
                json.dump(d, f)
            os.replace(cf + ".tmp", cf)
            time.sleep(0.25)
            return d
        except Exception as e:
            last = e
            time.sleep(1.0 * (k + 1))
    raise last


def inchikey(smi):
    m = Chem.MolFromSmiles(smi)
    if m is None:
        return None, None
    try:
        full = inchi.MolToInchiKey(m)
    except Exception:
        full = None
    big = max(Chem.GetMolFrags(m, asMols=True), key=lambda x: x.GetNumHeavyAtoms())
    try:
        parent = inchi.MolToInchiKey(big)
    except Exception:
        parent = None
    return full, parent


# ============================================================ B. ligand -> ChEMBL
smi2cid = {}
for cid, s in drugs.items():
    smi2cid.setdefault(s, cid)

lig_map = {}
lig_fail = []
for smi in panel_smiles:
    full, parent = inchikey(smi)
    mid, how = None, None
    for key, tag in ((full, "full_inchikey"), (parent, "parent_fragment_inchikey")):
        if not key or mid:
            continue
        try:
            d = fetch_json("%s/molecule.json?molecule_structures__standard_inchi_key__iexact=%s&limit=1"
                           % (CHEMBL, urllib.parse.quote(key)), "mol_%s.json" % key)
        except Exception as e:
            lig_fail.append({"smiles": smi, "step": tag, "error": str(e)[:120]})
            continue
        ms = d.get("molecules") or []
        if ms:
            mid = ms[0].get("molecule_chembl_id")
            how = tag
    if mid:
        lig_map[smi] = {"pubchem_cid": smi2cid.get(smi), "chembl_id": mid, "match": how}
    else:
        lig_map[smi] = {"pubchem_cid": smi2cid.get(smi), "chembl_id": None, "match": None}
        lig_fail.append({"smiles": smi, "step": "chembl_lookup", "error": "no ChEMBL molecule for InChIKey"})
n_lig_mapped = sum(1 for v in lig_map.values() if v["chembl_id"])
print("ligands mapped to ChEMBL: %d / %d" % (n_lig_mapped, len(panel_smiles)), flush=True)

# ============================================================ C. gene -> UniProt
gene2up = {}
gene_fail = []
for g in panel_genes:
    q = urllib.parse.quote("gene_exact:%s AND organism_id:9606 AND reviewed:true" % g)
    try:
        d = fetch_json("%s?query=%s&fields=accession&format=json&size=5" % (UNIPROT, q), "uni_%s.json" % g)
        rs = d.get("results") or []
        gene2up[g] = rs[0]["primaryAccession"].upper() if rs else None
    except Exception as e:
        gene2up[g] = None
        gene_fail.append({"gene": g, "error": str(e)[:120]})
n_gene_mapped = sum(1 for v in gene2up.values() if v)
print("genes mapped to UniProt: %d / %d" % (n_gene_mapped, len(panel_genes)), flush=True)

# panel pairs in mapped space
lig_ids = {v["chembl_id"] for v in lig_map.values() if v["chembl_id"]}
uni_ids = {v for v in gene2up.values() if v}
panel_pairs = set()
pair_meta = {}
for p, smi, v in sel:
    cid = lig_map.get(smi, {}).get("chembl_id")
    for k in seq2keys.get(p, []):
        up = gene2up.get(gene_of(k))
        if cid and up:
            panel_pairs.add((up, cid))
            pair_meta.setdefault((up, cid), []).append(
                {"davis_target_key": k, "davis_nM": v, "smiles": smi})
print("panel pairs mappable to (UniProt, ChEMBL): %d" % len(panel_pairs), flush=True)

# ============================================================ D. BindingDB scan
def parse_date(s):
    s = (s or "").strip()
    if not s:
        return None
    for fmt in ("%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d", "%d-%b-%Y"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    return None


scan = {"lig_rows": 0, "pair_rows": 0, "target_rows": 0,
        "lig_dates": {}, "pair_dates": {}, "pair_aff": {}, "target_seen": set(),
        "n_lines": 0}
if not os.path.isfile(TSV):
    failed["bindingdb_scan"] = "BindingDB_ChEMBL.tsv not found"
else:
    hdr = None
    ci = {}
    t0 = time.time()
    with open(TSV, encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            scan["n_lines"] += 1
            parts = line.rstrip("\n").split("\t")
            if hdr is None:
                hdr = parts
                for i, h in enumerate(hdr):
                    hl = h.lower()
                    if hl == "uniprot (swissprot) primary id of target chain 1":
                        ci["up"] = i
                    elif hl == "uniprot (trembl) primary id of target chain 1":
                        ci["up2"] = i
                    elif hl == "chembl id of ligand":
                        ci["lid"] = i
                    elif hl == "date in bindingdb":
                        ci["date"] = i
                    elif hl in ("ki (nm)", "ic50 (nm)", "kd (nm)", "ec50 (nm)"):
                        ci[h.split()[0]] = i
                continue
            need = max(ci.values())
            if len(parts) <= need:
                continue
            lid = parts[ci["lid"]].strip().upper()
            if lid not in lig_ids:
                continue
            up = parts[ci["up"]].strip().upper() or parts[ci["up2"]].strip().upper()
            dt = parse_date(parts[ci["date"]]) if "date" in ci else None
            scan["lig_rows"] += 1
            if lid not in scan["lig_dates"] or (dt is not None and (scan["lig_dates"][lid] is None or dt < scan["lig_dates"][lid])):
                scan["lig_dates"][lid] = dt
            if up in uni_ids:
                scan["target_seen"].add(up)
                k = (up, lid)
                scan["pair_rows"] += 1
                if dt is not None and (k not in scan["pair_dates"] or dt < scan["pair_dates"][k]):
                    scan["pair_dates"][k] = dt
                for nm in ("Ki", "IC50", "Kd", "EC50"):
                    if nm in ci:
                        v = parts[ci[nm]].strip()
                        if v:
                            try:
                                f = float(v.replace(",", ""))
                                if f > 0:
                                    p = 9.0 - math.log10(f)
                                    if k not in scan["pair_aff"] or p > scan["pair_aff"][k]:
                                        scan["pair_aff"][k] = p
                            except Exception:
                                pass
            if scan["n_lines"] % 500000 == 0:
                print("   scanned %d lines (%.0fs), lig hits %d, pair hits %d" % (
                    scan["n_lines"], time.time() - t0, scan["lig_rows"], scan["pair_rows"]), flush=True)
    print("scan done: %d lines in %.0fs" % (scan["n_lines"], time.time() - t0), flush=True)

lig_hit = sorted(set(scan["lig_dates"]))
pair_hit_all = set(scan["pair_dates"])            # any panel-ligand x panel-target combo in BindingDB
pair_hit = pair_hit_all & panel_pairs             # the actual Davis panel pairs found in BindingDB
print("BindingDB hits: ligands %d/%d, panel pairs %d/%d, any target-ligand combo %d, targets %d/%d" % (
    len(lig_hit), len(lig_ids), len(pair_hit), len(panel_pairs), len(pair_hit_all),
    len(scan["target_seen"]), len(uni_ids)), flush=True)

by_cutoff = {}
for cut, cdt in CUTOFFS.items():
    lp = [k for k in pair_hit if scan["pair_dates"][k] is not None and scan["pair_dates"][k] < cdt]
    ll = [l for l in scan["lig_dates"] if scan["lig_dates"][l] is not None and scan["lig_dates"][l] < cdt]
    by_cutoff[cut] = {
        "n_pairs": len(lp),
        "pair_frac_of_mappable_panel": round(len(lp) / len(panel_pairs), 4) if panel_pairs else None,
        "n_ligands": len(ll),
        "ligand_frac_of_mapped": round(len(ll) / len(lig_ids), 4) if lig_ids else None,
    }

# ============================================================ E. label consistency
both = []
for k in pair_hit:
    if k in scan["pair_aff"]:
        for m in pair_meta.get(k, []):
            if m["davis_nM"] > 0:
                both.append((9.0 - math.log10(m["davis_nM"]), scan["pair_aff"][k]))
label = None
if len(both) > 5:
    from scipy.stats import spearmanr, pearsonr
    import numpy as np
    a = [x for x, _ in both]
    b = [y for _, y in both]
    dif = [y - x for x, y in both]
    label = {
        "n": len(both),
        "spearman_bindingdb_vs_davis": round(float(spearmanr(a, b)[0]), 4),
        "pearson": round(float(pearsonr(a, b)[0]), 4),
        "mean_diff_p": round(float(np.mean(dif)), 4),
        "sd_diff_p": round(float(np.std(dif)), 4),
        "within_1_log_frac": round(float(np.mean([abs(d) <= 1.0 for d in dif])), 4),
    }
    print("label consistency: %s" % label, flush=True)
else:
    label = {"n": len(both), "note": "too few overlapping pairs for agreement statistics"}

# ============================================================ output
out = {
    "question": "Is the Davis positive control (used as evidence that the evaluation "
                "pipeline can detect real signal) itself inside the models' training corpus?",
    "panel_reproduction": {
        "source": "scripts/data/DAVIS/{affinity,target_seq,SMILES}.txt (DeepPurpose format)",
        "procedure": "load_process_DAVIS pair order; proteins with >=15 ligands; "
                     "random.seed(20260922); shuffle; first 40; sample <=25 ligands each",
        "n_proteins": len(prots),
        "n_pairs": len(sel),
        "n_unique_ligands_in_panel": len(panel_smiles),
        "n_unique_genes": len(panel_genes),
    },
    "ligand_mapping": {
        "n_panel_ligands": len(panel_smiles),
        "n_mapped_to_chembl": n_lig_mapped,
        "frac_mapped": round(n_lig_mapped / len(panel_smiles), 4),
        "failures": lig_fail[:40],
        "n_failures": len(lig_fail),
        "map": {k: v for k, v in sorted(lig_map.items())},
    },
    "target_mapping": {
        "n_genes": len(panel_genes),
        "n_mapped_to_uniprot": n_gene_mapped,
        "frac_mapped": round(n_gene_mapped / len(panel_genes), 4),
        "failures": gene_fail,
        "gene_to_uniprot": gene2up,
        "caveat": "Davis proteins are wild-type and mutant kinase constructs; mapping is at the "
                  "gene/UniProt level, so mutant-specific BindingDB rows are counted as the same target.",
    },
    "mappable_panel_pairs": len(panel_pairs),
    "bindingdb_intersection": {
        "tsv": os.path.basename(TSV),
        "snapshot": "202609",
        "n_lines_scanned": scan["n_lines"],
        "n_bindingdb_rows_with_panel_ligand": scan["lig_rows"],
        "ligands_found_anywhere": len(lig_hit),
        "ligand_frac_found": round(len(lig_hit) / len(lig_ids), 4) if lig_ids else None,
        "targets_found_anywhere": sorted(scan["target_seen"]),
        "target_frac_found": round(len(scan["target_seen"]) / len(uni_ids), 4) if uni_ids else None,
        "pairs_found": len(pair_hit),
        "pair_frac_found": round(len(pair_hit) / len(panel_pairs), 4) if panel_pairs else None,
        "any_target_ligand_combos_found": len(pair_hit_all),
        "any_target_ligand_combos_frac": round(len(pair_hit_all) / len(panel_pairs), 4) if panel_pairs else None,
        "note_pairs": "pairs_found counts the specific Davis panel (UniProt, ligand) pairs present in "
                       "BindingDB; any_target_ligand_combos_found is the larger set of all pairs sharing a "
                       "panel target and a panel ligand regardless of the Davis pairing",
        "by_cutoff_pre_training": by_cutoff,
        "cutoff_rationale": "DeepPurpose BindingDB weights released 2021 (data to 2019-2020); "
                            "DrugBAN retrained on the authors' BindingDB split; 2021-01-01 is the "
                            "conservative 'could have been seen' boundary.",
    },
    "label_consistency_bindingdb_vs_davis": label,
    "pair_level_hits": sorted(
        [{"uniprot": u, "ligand_chembl_id": l,
          "bindingdb_date": scan["pair_dates"][(u, l)].strftime("%Y-%m-%d") if scan["pair_dates"][(u, l)] else None,
          "bindingdb_p": round(scan["pair_aff"][(u, l)], 3) if (u, l) in scan["pair_aff"] else None,
          "davis_p": [round(9.0 - math.log10(m["davis_nM"]), 3) for m in pair_meta.get((u, l), []) if m["davis_nM"] > 0]}
         for (u, l) in pair_hit], key=lambda d: (d["uniprot"], d["ligand_chembl_id"]))[:200],
    "FAILED": failed,
    "status": "COMPLETED" if not failed and n_lig_mapped > 0 and n_gene_mapped > 0 else "PARTIAL",
}
json.dump(out, open(os.path.join(RES, "davis_overlap.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\nstatus=%s  ligands %d/%d  genes %d/%d  pairs %d/%d" % (
    out["status"], n_lig_mapped, len(panel_smiles), n_gene_mapped, len(panel_genes),
    len(pair_hit), len(panel_pairs)), flush=True)
print("wrote results/davis_overlap.json", flush=True)
