# -*- coding: utf-8 -*-
"""
把文献编号合入 DTI_manuscript_v2.md:
  1) 用 results/key_to_number.json 把正文 [key] 占位符替换为 [n]
  2) 用 results/references_numbered.md 的 A 节内容替换 v2 的占位文献表
输出:manuscript/DTI_manuscript_v2.md(就地更新)+ 备份 v2.pre-numbering.md
"""
import json
import os
import re
import shutil
import sys

sys.stdout.reconfigure(encoding="utf-8")
BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
RES = os.path.join(BASE, "results")
MS = os.path.join(BASE, "manuscript", "DTI_manuscript_v2.md")

km = json.load(open(os.path.join(RES, "key_to_number.json"), encoding="utf-8"))
shutil.copy2(MS, os.path.join(BASE, "manuscript", "DTI_manuscript_v2.pre-numbering.md"))

src = open(MS, encoding="utf-8").read()
orig = src

# ---- 1) 占位符替换 ----
n_sub = 0


def repl(m):
    global n_sub
    keys = [k.strip() for k in re.split(r"[;,]\s*", m.group(1))]
    nums = []
    for k in keys:
        v = km.get(k)
        if v is None:
            print("  ⚠️ 未知 key:", k)
            return m.group(0)
        nums.extend(v if isinstance(v, list) else [v])
    if not nums:
        return m.group(0)
    n_sub += 1


    return "[" + ",".join(str(x) for x in nums) + "]"


src = re.sub(r"\[([a-z_0-9]+(?:\s*[;,]\s*[a-z_0-9]+)*)\]", repl, src)
print("占位符替换: %d 处" % n_sub)

# ---- 2) 替换文献表 ----
rn = open(os.path.join(RES, "references_numbered.md"), encoding="utf-8").read()
m = re.search(r"^##\s*A[\.．].*?$(.*?)^##\s*A\.1", rn, re.S | re.M)
if not m:
    m = re.search(r"^##\s*A[\.．].*?$(.*?)^##\s*B", rn, re.S | re.M)
if m:
    refblock = m.group(1).strip()
    marker = "## References"
    i = src.find(marker)
    if i >= 0:
        head = src[:i + len(marker)]
        src = head + "\n\n" + refblock + "\n\n---\n\n" + src[i + len(marker):].split("\n---\n", 1)[-1]
        print("文献表已插入(来自 references_numbered.md A 节)")
    else:
        print("⚠️ 未找到 ## References 标记")
else:
    print("⚠️ 未能从 references_numbered.md 提取 A 节")

open(MS, "w", encoding="utf-8").write(src)
print("已更新:", MS)
print("  原 %d 字符 -> 现 %d 字符" % (len(orig), len(src)))
print("  剩余 [key] 占位(应为 0):", len(re.findall(r"\[[a-z_]{3,}\]", src)))
