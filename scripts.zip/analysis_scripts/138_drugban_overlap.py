# -*- coding: utf-8 -*-
"""
Analysis 3 (reviewer-driven): DrugBAN self-check.

DrugBAN was trained with the authors' official BindingDB random split
(configs/DrugBAN.yaml, `--data bindingdb --split random`, SEED=42). The 57-target
benchmark may overlap that split. We intersect the benchmark (1,425 pairs) with
each DrugBAN split.

Matching method (explicit): DrugBAN's BindingDB csv has no ChEMBL or UniProt IDs
-- columns are SMILES, Protein(sequence), Y, drug_cluster, target_cluster.
  * protein  : exact full-length sequence equality against the 57 benchmark
               sequences (each maps 1:1 to a benchmark UniProt accession)
  * molecule : InChIKey (RDKit) of the SMILES; canonical-SMILES match is used
               as an independent cross-check
Pairs are matched on (UniProt, InChIKey).

Output: results/drugban_overlap.json
"""
import csv
import json
import os
import sys

import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import inchi

RDLogger.DisableLog("rdApp.*")
sys.stdout.reconfigure(encoding="utf-8")

ROOT = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
RES = os.path.join(ROOT, "results")
DBSPLIT = os.path.join(ROOT, "thirdparty", "drugban_extract", "DrugBAN-main", "datasets", "bindingdb", "random")


def inchikey(smi):
    if not isinstance(smi, str) or not smi.strip():
        return None
    m = Chem.MolFromSmiles(smi)
    if m is None:
        return None
    try:
        k = inchi.MolToInchiKey(m)
    except Exception:
        return None
    return k or None


def canon(smi):
    if not isinstance(smi, str) or not smi.strip():
        return None
    m = Chem.MolFromSmiles(smi)
    return Chem.MolToSmiles(m) if m is not None else None


# ------------------------------------------------------------------ benchmark
bench = list(csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")))
seq2up = {}
for r in bench:
    seq2up[r["sequence"]] = r["uniprot"].strip().upper()
print("benchmark: %d pairs, %d targets, %d sequences" % (len(bench), len({r["target"] for r in bench}), len(seq2up)), flush=True)

bench_keys, bench_lig, bench_up = set(), set(), set()
n_bad = 0
for r in bench:
    up = r["uniprot"].strip().upper()
    k = inchikey(r["smiles"])
    if k is None:
        n_bad += 1
        continue
    bench_keys.add((up, k))
    bench_lig.add(k)
    bench_up.add(up)
print("benchmark keys: %d pairs, %d ligands, %d uniprots (unparsable SMILES: %d)" % (
    len(bench_keys), len(bench_lig), len(bench_up), n_bad), flush=True)

bench_by_up_lig = {}
bench_canon = {}
for r in bench:
    k = inchikey(r["smiles"])
    if k:
        up = r["uniprot"].strip().upper()
        bench_by_up_lig.setdefault((up, k), []).append(r)
        bench_canon[(up, k)] = canon(r["smiles"])

bench_conn_pairs = {(up, k[:14]) for (up, k) in bench_keys}
bench_conn_lig = {k[:14] for k in bench_lig}

# ------------------------------------------------------------------ splits
result = {}
union_pairs, union_lig, union_up = set(), set(), set()
union_pairs_conn, union_lig_conn = set(), set()
for split in ("train", "val", "test"):
    d = pd.read_csv(os.path.join(DBSPLIT, split + ".csv"))
    sub = d[d["Protein"].isin(seq2up)]
    print("\n%s: %d rows, %d rows on benchmark proteins (%d unique seq)" % (
        split, len(d), len(sub), d["Protein"].nunique()), flush=True)
    spl_pairs, spl_pairs_conn = set(), set()
    spl_lig, spl_lig_conn, spl_up = set(), set(), set()
    db_canon = {}
    for r in sub.itertuples(index=False):
        up = seq2up[getattr(r, "Protein")]
        k = inchikey(getattr(r, "SMILES"))
        if k is None:
            continue
        spl_pairs.add((up, k))
        spl_pairs_conn.add((up, k[:14]))
        spl_lig.add(k)
        spl_lig_conn.add(k[:14])
        spl_up.add(up)
        db_canon[(up, k)] = canon(getattr(r, "SMILES"))

    hits = spl_pairs & bench_keys
    hits_conn = spl_pairs_conn & bench_conn_pairs
    # independent cross-check of the full-key hits by canonical-SMILES equality
    cs = sum(1 for h in hits if db_canon.get(h) is not None and db_canon.get(h) == bench_canon.get(h))
    result[split] = {
        "n_rows": int(len(d)),
        "n_rows_on_benchmark_proteins": int(len(sub)),
        "n_unique_sequences": int(d["Protein"].nunique()),
        "overlap_targets": sorted(spl_up & bench_up),
        "n_overlap_targets": len(spl_up & bench_up),
        "target_frac": round(len(spl_up & bench_up) / len(bench_up), 4),
        "n_overlap_ligands": len(spl_lig & bench_lig),
        "ligand_frac": round(len(spl_lig & bench_lig) / len(bench_lig), 4),
        "n_overlap_ligands_connectivity_only": len(spl_lig_conn & bench_conn_lig),
        "n_overlap_pairs": len(hits),
        "pair_frac": round(len(hits) / len(bench_keys), 4),
        "n_overlap_pairs_connectivity_only": len(hits_conn),
        "pair_frac_connectivity_only": round(len(hits_conn) / len(bench_keys), 4),
        "canonical_smiles_crosscheck_pair_hits": cs,
        "matching_method": "exact protein sequence -> UniProt; RDKit InChIKey for molecule; "
                           "pairs = (UniProt, InChIKey)",
    }
    union_pairs |= hits
    union_pairs_conn |= hits_conn
    union_lig |= (spl_lig & bench_lig)
    union_lig_conn |= (spl_lig_conn & bench_conn_lig)
    union_up |= (spl_up & bench_up)
    print("  overlap: targets %d/%d, ligands %d/%d, pairs %d/%d "
          "(connectivity-only pairs %d, canonical-SMILES crosscheck %d)" % (
              len(spl_up & bench_up), len(bench_up), len(spl_lig & bench_lig), len(bench_lig),
              len(hits), len(bench_keys), len(hits_conn), cs), flush=True)

# ------------------------------------------------------------------ summary
bench_targets_in_train = result["train"]["overlap_targets"]
out = {
    "dataset": "DrugBAN official BindingDB random split (authors' code, SEED=42)",
    "training_command": "python main.py --cfg configs/DrugBAN.yaml --data bindingdb --split random",
    "split_files": {s: "datasets/bindingdb/random/%s.csv" % s for s in ("train", "val", "test")},
    "matching_method": {
        "protein": "exact full-length sequence equality with the 57 benchmark sequences "
                   "(verified 1:1 to benchmark UniProt accessions)",
        "molecule": "RDKit InChIKey; canonical-SMILES equality used as independent cross-check",
        "pair_key": "(UniProt, InChIKey)",
        "caveat": "protein variants/isoforms whose BindingDB sequence differs from the benchmark "
                  "sequence would be missed; here all 57 benchmark sequences are present verbatim "
                  "in the DrugBAN corpus",
    },
    "benchmark": {
        "n_pairs": len(bench_keys),
        "n_targets": len(bench_up),
        "n_ligands": len(bench_lig),
        "n_unparsable_smiles": n_bad,
    },
    "splits": result,
    "union_train_val_test": {
        "n_overlap_pairs": len(union_pairs),
        "pair_frac": round(len(union_pairs) / len(bench_keys), 4),
        "n_overlap_pairs_connectivity_only": len(union_pairs_conn),
        "pair_frac_connectivity_only": round(len(union_pairs_conn) / len(bench_keys), 4),
        "n_overlap_ligands": len(union_lig),
        "ligand_frac": round(len(union_lig) / len(bench_lig), 4),
        "n_overlap_targets": len(union_up),
        "target_frac": round(len(union_up) / len(bench_up), 4),
    },
    "verdict": None,
}
tr, va, te = result["train"], result["val"], result["test"]
u = out["union_train_val_test"]
frac = u["pair_frac"]
out["verdict"] = {
    "training_only_pair_overlap_frac": tr["pair_frac"],
    "any_split_pair_overlap_frac": frac,
    "any_split_pair_overlap_frac_connectivity_only": u["pair_frac_connectivity_only"],
    "is_in_domain_by_this_criterion": bool(frac > 0.5),
    "statement": (
        "DrugBAN's own official BindingDB random split contains %.2f%% of the benchmark "
        "(target, ligand) pairs in its training file and %.2f%% across train+val+test "
        "(%.2f%% when stereochemistry is ignored). Although %.0f%% of the 57 benchmark targets "
        "appear in the split, the benchmark pairs are therefore largely OUTSIDE DrugBAN's own "
        "training corpus by this criterion. DrugBAN's benchmark rho 0.165/0.188 cannot be "
        "attributed to corpus overlap of the benchmark pairs; note this contrasts with the "
        "manuscript's >=76%% pair overlap measured against the FULL BindingDB release, which is "
        "much larger than any single model's actual training corpus."
        % (100 * tr["pair_frac"], 100 * frac, 100 * u["pair_frac_connectivity_only"],
           100 * u["target_frac"])),
}

json.dump(out, open(os.path.join(RES, "drugban_overlap.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n" + out["verdict"]["statement"], flush=True)
print("wrote results/drugban_overlap.json", flush=True)
