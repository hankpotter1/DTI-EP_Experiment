# -*- coding: utf-8 -*-
"""对用户报告的 4 条问题做定案取证:直接打印 v6 docx/pdf 中的真实字符串。"""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

def lines_of(text):
    return [l.strip() for l in text.splitlines() if l.strip()]

# ---- docx ----
import docx
D = r"G:\HHH\openclaw-workspace\netpharm-toolkit\manuscript\DTI_manuscript_v6.docx"
d = docx.Document(D)
dtext = "\n".join(p.text for p in d.paragraphs)
dtab = "\n".join(c.text for t in d.tables for r in t.rows for c in r.cells)

# ---- pdf ----
try:
    import pypdf
    r = pypdf.PdfReader(r"G:\HHH\openclaw-workspace\netpharm-toolkit\manuscript\DTI_manuscript_v6.pdf")
    ptext = "\n".join((p.extract_text() or "") for p in r.pages)
except Exception as e:
    ptext = ""
    print("pypdf 失败:", str(e)[:80])

print("=" * 60)
print("① Table 3 列名:该是 p 还是 ρ?")
print("=" * 60)
for label, txt in (("docx-tables", dtab), ("pdf", ptext)):
    for pat in ["sign p", "BH p", "Bonferroni p", "Wilcoxon p",
                "sign ρ", "BH ρ", "Bonferroni ρ", "Wilcoxon ρ"]:
        n = txt.count(pat)
        if n:
            print("  %-14s %-16s 出现 %d 次" % (label, pat, n))
    print("  " + "-" * 40)

print()
print("=" * 60)
print("② §3.5 标题出现次数(应为 1)")
print("=" * 60)
for label, txt in (("docx", dtext), ("pdf", ptext)):
    n = len(re.findall(r"3\.5\s+Cross-target retrieval", txt))
    print("  %-6s §3.5 标题: %d 次" % (label, n))

print()
print("=" * 60)
print("③ §6 Conclusions 编号(应 1-6)")
print("=" * 60)
for label, txt in (("docx", dtext), ("pdf", ptext)):
    nums = re.findall(r"^(\d{1,2})\.\s+(Within-target|The benchmark|Performance does|A modern|In-domain|Retrieval)", txt, re.M)
    print("  %-6s 编号: %s" % (label, [a for a, _ in nums] if nums else "未按行匹配到"))

print()
print("=" * 60)
print("④ 参考文献 [10] 是否缺左括号")
print("=" * 60)
for label, txt in (("docx", dtext), ("pdf", ptext)):
    bad = re.findall(r"(?m)^\s*10\)\s+\w", txt)
    good = re.findall(r"(?m)^\s*\[10\]\s+\w", txt)
    print("  %-6s  '[10] xxx' 正确形式: %d 处 | '10) xxx' 缺括号: %d 处" % (label, len(good), len(bad)))

print()
print("=" * 60)
print("⑤ 用户消息里出现的重复片段是否在文件中存在")
print("=" * 60)
for pat in ["拼写与 OCR 错误", "3. 6. Conclusions", "列名仍把 p 值标成"]:
    print("  「%s」 docx: %d 次 | pdf: %d 次" % (pat, dtext.count(pat) + dtab.count(pat), ptext.count(pat)))
