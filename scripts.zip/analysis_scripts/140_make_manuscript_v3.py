# -*- coding: utf-8 -*-
"""
DTI 稿件 v2 -> v3 修订(审稿意见逐条落实)。

输入 : manuscript/DTI_manuscript_v2.md
       results/*.json(真实数据,不编造)
输出 : manuscript/DTI_manuscript_v3.md

所有替换均断言"恰好命中一次";任何一条不命中立即报错退出。
"""
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
RES = os.path.join(BASE, "results")
MS = os.path.join(BASE, "manuscript")
SRC = os.path.join(MS, "DTI_manuscript_v2.md")
OUT = os.path.join(MS, "DTI_manuscript_v3.md")


def J(fn):
    return json.load(open(os.path.join(RES, fn), encoding="utf-8"))


src = open(SRC, encoding="utf-8").read()
orig_len = len(src)
log = []


def rep1(old, new, tag):
    """整段替换,必须恰好一次"""
    n = src.count(old)
    if n != 1:
        raise SystemExit("✗ [%s] 命中 %d 次(应为 1)" % (tag, n))
    log.append(tag)
    return src.replace(old, new, 1)


# =====================================================================
# 数据装载
# =====================================================================
ma = J("independence_and_ma_correction.json")["tier3_primary_endpoint"]["objects"]
t1 = J("tier1_expanded.json")
tb = J("trivial_baseline_demo.json")["baselines"]
t2 = J("tier2_with_baseline.json")

HEAVY = tb["HeavyAtoms"]
MWB = tb["MW"]

# 顺序 = 主结果表顺序(按 median rho 降序)
ORDER = ["cnn_cnn_bindingdb", "morgan_aac_bindingdb", "morgan_cnn_bindingdb",
         "daylight_aac_bindingdb", "transformer_cnn_bindingdb", "mpnn_cnn_bindingdb"]
SHORT = {k: k.replace("_bindingdb", "") for k in ORDER}

# 显示字符串(与 v2 一致)+ 断言底层数值吻合
MEDIAN_DISP = {"cnn_cnn": "0.194", "morgan_aac": "0.167", "morgan_cnn": "0.132",
               "daylight_aac": "0.123", "transformer_cnn": "0.089", "mpnn_cnn": "0.012"}
CI_DISP = {"cnn_cnn": "[0.050, 0.238]", "morgan_aac": "[0.043, 0.242]",
           "morgan_cnn": "[0.061, 0.243]", "daylight_aac": "[0.048, 0.195]",
           "transformer_cnn": "[0.022, 0.132]", "mpnn_cnn": "[\u22120.063, 0.102]"}
POS_DISP = {"cnn_cnn": "68%", "morgan_aac": "70%", "morgan_cnn": "75%",
            "daylight_aac": "70%", "transformer_cnn": "65%", "mpnn_cnn": "53%"}
SIGN_DISP = {"cnn_cnn": "0.0075", "morgan_aac": "0.0032", "morgan_cnn": "1.5e-4",
             "daylight_aac": "0.0032", "transformer_cnn": "0.033", "mpnn_cnn": "0.79"}
BH_DISP = {"cnn_cnn": "0.010", "morgan_aac": "0.0051", "morgan_cnn": "4.1e-4",
           "daylight_aac": "0.0051", "transformer_cnn": "0.038", "mpnn_cnn": "0.79"}
BONF_DISP = {"cnn_cnn": "0.060", "morgan_aac": "0.026", "morgan_cnn": "0.0012",
             "daylight_aac": "0.026", "transformer_cnn": "0.265", "mpnn_cnn": "1.0"}
WILCOX_DISP = {"cnn_cnn": "1.5e-4", "morgan_aac": "9.7e-5", "morgan_cnn": "7.1e-5",
               "daylight_aac": "0.0042", "transformer_cnn": "0.012", "mpnn_cnn": "0.68"}

# 断言:显示串与 JSON 数值一致(容差)
def close(a, b, d):
    return abs(a - b) <= d


for k in ORDER:
    s = SHORT[k]
    o = ma[k]
    assert close(o["median_rho"], float(MEDIAN_DISP[s]), 0.0006), (k, o["median_rho"])
    assert close(o["pos_frac"], float(POS_DISP[s].rstrip("%")) / 100, 0.005), k
    assert close(o["sign_test_p"], float(SIGN_DISP[s]), max(1e-9, o["sign_test_p"] * 0.06)), (k, "sign")
    assert close(o["sign_p_bh"], float(BH_DISP[s]), max(1e-9, o["sign_p_bh"] * 0.06)), (k, "bh", o["sign_p_bh"])
    assert close(o["sign_p_bonferroni"], float(BONF_DISP[s]), max(1e-9, o["sign_p_bonferroni"] * 0.06)), (k, "bonf")
    assert close(o["wilcoxon_p"], float(WILCOX_DISP[s]), max(1e-9, o["wilcoxon_p"] * 0.06)), (k, "wilcox")
print("✓ 主结果表(Table 2)显示值与 independence_and_ma_correction.json 一致")

# =====================================================================
# E1 删除重复关键词 + 内部草稿信息(「草稿 v2」「引用以 [key] 占位」「配套」)
# =====================================================================
n_kw = len(re.findall(r"^\*\*Keywords:\*\*", src, re.M))
assert n_kw == 2, "关键词行数 = %d" % n_kw
src = re.sub(r"\n\*\*Keywords:\*\*[^\n]*\n\n", "\n", src, count=1)
src = re.sub(r"\n> \*\*草稿 v2.*?\n> \*\*稿件类型.*?\n> \*\*配套.*?\n\n---\n", "\n", src,
             count=1, flags=re.S)
assert "草稿 v2" not in src and "稿件类型" not in src and "配套" not in src
assert len(re.findall(r"^\*\*Keywords:\*\*", src, re.M)) == 1
log.append("E1 删除：重复关键词行 + 顶部草稿信息块")

# =====================================================================
# E2 §2.1 评估集表格:补表注(列 CSV 文件名)
# =====================================================================
src = rep1(
    "| **Strict-equal** (`bench_eval_set_strict_eq.csv`) | 53 | 1,057 | potency-equal-spaced | strict | confound separation |\n\nTarget classes in the main set:",
    "| **Strict-equal** (`bench_eval_set_strict_eq.csv`) | 53 | 1,057 | potency-equal-spaced | strict | confound separation |\n\n"
    "*Table note.* The three sets are stored under `results/` as `bench_eval_set_large.csv` (Main), "
    "`bench_eval_set_strict.csv` (Strict) and `bench_eval_set_strict_eq.csv` (Strict-equal).\n\n"
    "Target classes in the main set:",
    "E2 §2.1 评估集表注 + CSV 文件名")

# =====================================================================
# E3 §2.2 DrugBAN checkpoint 说明段
# =====================================================================
old_db = ("**DrugBAN (2022)** [drugban], trained from the authors' code with their BindingDB split "
          "(SEED=42) on a single RTX 4080 SUPER, and then applied unchanged to this benchmark. "
          "Training and checkpoint details are given in Supplementary Note S1.")
new_db = old_db + "\n\n" + (
    "**DrugBAN checkpoints.** Two checkpoints from the same training run were evaluated, "
    "`best_model_epoch_43.pth` and `best_model_epoch_30.pth`. In both training runs the best epoch "
    "by validation AUROC was epoch 43 (AUROC 0.9624), and epochs 44\u201354 did not improve on it; "
    "the pair of checkpoints is therefore fixed by the validation curve and not pre-specified against "
    "this benchmark. Epoch 30 is an earlier point on the same validation curve and serves as a "
    "sensitivity check on checkpoint choice. Both checkpoints were applied unchanged to the 57-target "
    "benchmark, and their results are reported side by side (\u00a73.6, Table 5).")
src = rep1(old_db, new_db, "E3 §2.2 DrugBAN checkpoint 段")

# =====================================================================
# E4 Table 2:增加 BH / Bonferroni 校正 p 列(原有列全部保留)
# =====================================================================
t2_old = """| Model | median \u03c1 | 95% CI | positive | sign p | Wilcoxon p |
|---|---|---|---|---|---|
| cnn_cnn | 0.194 | [0.050, 0.238] | 68% | 0.0075 | 1.5e-4 |
| morgan_aac | 0.167 | [0.043, 0.242] | 70% | 0.0032 | 9.7e-5 |
| morgan_cnn | 0.132 | [0.061, 0.243] | 75% | 1.5e-4 | 7.1e-5 |
| daylight_aac | 0.123 | [0.048, 0.195] | 70% | 0.0032 | 0.0042 |
| transformer_cnn | 0.089 | [0.022, 0.132] | 65% | 0.033 | 0.012 |
| mpnn_cnn | 0.012 | [\u22120.063, 0.102] | 53% | 0.79 | 0.68 |"""

t2_new = ("| Model | median \u03c1 | 95% CI | positive | sign p | BH p | Bonferroni p | Wilcoxon p |\n"
          "|---|---|---|---|---|---|---|---|\n")
for k in ORDER:
    s = SHORT[k]
    t2_new += "| %s | %s | %s | %s | %s | %s | %s | %s |\n" % (
        s, MEDIAN_DISP[s], CI_DISP[s], POS_DISP[s], SIGN_DISP[s], BH_DISP[s], BONF_DISP[s],
        WILCOX_DISP[s])
t2_new = t2_new.rstrip("\n")
src = rep1(t2_old, t2_new, "E4 Table 2 增加 BH/Bonferroni 列")

# Table 2 表注:补校正说明
src = rep1(
    "Four of six models show a statistically detectable but very weak positive signal; the best median is 0.194.",
    "*Table note.* Correction is applied to the sign tests across the family of eight Tier-3 evaluation "
    "objects (Benjamini\u2013Hochberg and Bonferroni). Under Bonferroni, three of six models retain "
    "significance; `cnn_cnn` (0.060) and `transformer_cnn` (0.265) do not.\n\n"
    "Four of six models show a statistically detectable but very weak positive signal; the best median is 0.194.",
    "E4b Table 2 表注(校正说明)")

# =====================================================================
# E5 §3.5 MRR 更正为 285 探针口径 + 新增 Table 5(Top-k 对比表)
# =====================================================================
MRR_NEW = ("MRR was below the analytic expectation H(57)/57 = 0.0812 for one of the six models "
           "(`mpnn_cnn`, 0.074); for the remaining five the observed MRR is indistinguishable from "
           "that expectation (Figure 5, Table 5).")
src = rep1("MRR was below the analytic expectation H(57)/57 = 0.0812 for three of six models (Figure 5).",
           MRR_NEW, "E5 §3.5 MRR 更正(285 探针)")

TOP1_DISP = {"mpnn_cnn": "1.05%", "cnn_cnn": "0.70%", "morgan_cnn": "3.86%",
             "transformer_cnn": "1.75%", "morgan_aac": "2.81%", "daylight_aac": "2.46%"}
TOP5_DISP = {"mpnn_cnn": "8.07%", "cnn_cnn": "11.23%", "morgan_cnn": "11.23%",
             "transformer_cnn": "8.77%", "morgan_aac": "10.53%", "daylight_aac": "9.47%"}
MRR_DISP = {"mpnn_cnn": "0.074", "cnn_cnn": "0.085", "morgan_cnn": "0.104",
            "transformer_cnn": "0.084", "morgan_aac": "0.090", "daylight_aac": "0.094"}
for k in ORDER:
    s = SHORT[k]
    pm = t1["per_model"][k]
    assert close(pm["top1"] * 100, float(TOP1_DISP[s].rstrip("%")), 0.01), (k, "top1", pm["top1"])
    assert close(pm["top5"] * 100, float(TOP5_DISP[s].rstrip("%")), 0.01), (k, "top5", pm["top5"])
    assert close(pm["mrr"], float(MRR_DISP[s]), 0.0006), (k, "mrr", pm["mrr"])
print("✓ Top-k 表显示值与 tier1_expanded.json 一致")
assert close(t1["random_baseline"]["mrr"], 0.0812, 0.0001)
assert close(HEAVY["median_rho"], 0.191, 0.0006) and close(MWB["median_rho"], 0.187, 0.0006)

DRUG_ROWS = [("DrugBAN epoch 43", "drugban_ep43", "0.165"),
             ("DrugBAN epoch 30", "drugban_ep30", "0.189")]
for name, key, disp in DRUG_ROWS:
    assert close(ma[key]["median_rho"], float(disp), 0.0006), (key, ma[key]["median_rho"])

t5 = ["| Evaluation object | median \u03c1 | Top-1 | Top-5 | MRR | heavy-atom count \u03c1 | molecular weight \u03c1 | beats strict criterion? |",
      "|---|---|---|---|---|---|---|---|"]
for k in ORDER:
    s = SHORT[k]
    t5.append("| `%s` | %s | %s | %s | %s | 0.191 | 0.187 | **no** |" % (
        s, MEDIAN_DISP[s], TOP1_DISP[s], TOP5_DISP[s], MRR_DISP[s]))
for name, key, disp in DRUG_ROWS:
    t5.append("| %s | %s | not computed | not computed | not computed | 0.191 | 0.187 | **no** |" % (name, disp))
t5.append("| *(reference)* single-descriptor baseline (heavy-atom count) | 0.191 | not computed | not computed | "
          "not computed | \u2014 | \u2014 | \u2014 |")
t5.append("| *(reference)* molecular-weight baseline | 0.187 | not computed | not computed | not computed | "
          "\u2014 | \u2014 | \u2014 |")
t5.append("| *(reference)* random ranking | \u2014 | 1.75% | 8.77% | 0.0812 | \u2014 | \u2014 | \u2014 |")
t5 = "\n".join(t5)

t5_note = (
    "*Table note.* Top-1, Top-5 and MRR are computed over the 285-probe retrieval set (five probes per "
    "target; `results/tier1_expanded.json`); the random-ranking row gives the analytic expectations "
    "(1/57, 5/57, H(57)/57). **not computed** marks conditions that were not run: the two DrugBAN "
    "checkpoints were evaluated for within-target ranking and Tier-2 discrimination only, and the "
    "single-descriptor baselines were evaluated only as within-target rankings \u2014 no retrieval "
    "(Top-k/MRR) experiment was performed for them, so no Top-k or MRR value can be reported for those "
    "objects or for the baselines themselves. The strict criterion of \u00a74.5 requires both a higher "
    "median \u03c1 than the best single-descriptor baseline and a 95% CI entirely above that baseline's CI; "
    "the baseline intervals are heavy-atom count [0.104, 0.260] and molecular weight [0.091, 0.275]. "
    "All eight evaluation objects fail it.")

src = rep1(MRR_NEW,
           MRR_NEW + "\n\n**Table 5. Tier-1 retrieval and trivial-baseline comparison across all eight evaluation objects.**\n\n"
           + t5 + "\n\n" + t5_note,
           "E6 新增 Table 5(Top-k 对比表)")

# =====================================================================
# E7 §3.4 末句
# =====================================================================
src = rep1("The origin of that gap is quantified in \u00a73.9.",
           "The gap is attributable to dataset, ligand source and measurement conditions rather than to "
           "target class; its interpretation is discussed in \u00a73.9 and \u00a74.1.",
           "E7 §3.4 末句")

# =====================================================================
# E8 §3.9:1,096 vs 1,097 差 1 对
# =====================================================================
E8_OLD = ("For the 1,096 overlapping pairs with comparable values, the training-side and "
          "evaluation-side values agree almost exactly (Spearman 0.992; mean deviation 0.01 log units; "
          "99% within 1 log unit).")
E8_NEW = E8_OLD + (" The agreement analysis covers 1,096 rather than 1,097 pairs because one "
                   "overlapping pair carries no comparable value pair (its two recorded values are not "
                   "on a common scale) and is therefore excluded from the comparison.")
src = rep1(E8_OLD, E8_NEW, "E8 §3.9 1,096/1,097 说明")

# =====================================================================
# E9 §4.1 标题
# =====================================================================
src = rep1("### 4.1 Two revisions of the claim", "### 4.1 Three revisions of the claim",
           "E9 §4.1 标题")
src = rep1("The data forced two revisions relative to our starting hypothesis.",
           "The data forced three revisions relative to our starting hypothesis.",
           "E9b §4.1 首句 two->three")

# =====================================================================
# E10 §4.6 末句
# =====================================================================
src = rep1("Our results (maximum 0.194) remain below any plausible usable range for ranking.",
           "Our results (maximum 0.194) remain below the conservative reference line we used, and, more "
           "importantly, are not distinguishable from a trivial single-descriptor baseline.",
           "E10 §4.6 末句")

# =====================================================================
# E11/E12 结论第 5、6 条
# =====================================================================
src = rep1("5. Within-domain strength is substantially attenuated on post-training data",
           "5. In-domain Davis performance is substantially attenuated on post-training data",
           "E11 结论第 5 条")
src = rep1("6. Retrieval of a compound's target is at chance, and below the analytic MRR baseline for three of six models.",
           "6. Retrieval of a compound's target is at chance (Top-1 0.70\u20133.86% against 1.75% expected; "
           "nothing survives correction for 18 comparisons), and MRR lies below the analytic baseline for "
           "one of six models (`mpnn_cnn`).",
           "E12 结论第 6 条 MRR")

# =====================================================================
# E13 §3.7 的 Table 5 -> Table 6
# =====================================================================
src = rep1("**Table 5. Filter strictness \u00d7 sampling.**", "**Table 6. Filter strictness \u00d7 sampling.**",
           "E13 原 Table 5 -> Table 6")

# =====================================================================
# E14 Declarations 里的中文占位《待补》
# =====================================================================
n_tbd = src.count("\u300a\u5f85\u8865\u300b")
assert n_tbd == 3, "《待补》出现 %d 次" % n_tbd
src = src.replace("\u300a\u5f85\u8865\u300b", "[AUTHOR INPUT REQUIRED]")
log.append("E14 Declarations 中文占位 -> [AUTHOR INPUT REQUIRED] x3")

# =====================================================================
# E15 参考文献:编号回填 + 正文 [key] -> [n]
# =====================================================================
km = J("key_to_number.json")
rn = open(os.path.join(RES, "references_numbered.md"), encoding="utf-8").read().split("\n")
a_start = next(i for i, l in enumerate(rn) if l.startswith("## A."))
a_end = next(i for i, l in enumerate(rn) if l.startswith("### A.1"))
ref_items = [l.strip() for l in rn[a_start + 1:a_end] if l.strip()]
nums_seen = [int(re.match(r"^(\d+)\.", l).group(1)) for l in ref_items if re.match(r"^\d+\.", l)]
assert nums_seen == list(range(1, 15)), nums_seen
ref_block = "\n\n".join(ref_items)
print("✓ 参考文献条目 %d 条(编号 1-%d),来源 references_numbered.md" % (len(ref_items), max(nums_seen)))

# 正文占位符替换
subs = []


def repl(m):
    keys = [k.strip() for k in re.split(r"[;,]\s*", m.group(1))]
    nums = []
    for k in keys:
        if k not in km:
            return m.group(0)
        v = km[k]
        nums.extend(v if isinstance(v, list) else [v])
    subs.append((m.group(0), "[" + ",".join(str(x) for x in nums) + "]"))
    return "[" + ",".join(str(x) for x in nums) + "]"


head, tail = src.split("## References", 1)
head = re.sub(r"\[([a-z_]{3,}(?:\s*[;,]\s*[a-z_]{3,})*)\]", repl, head)
src = head + "## References" + tail
print("✓ 正文引用占位符替换 %d 处 -> 编号引用" % len(subs))
for a, b in subs:
    print("    %-46s -> %s" % (a, b))

# References 段 + 图目录整块重写
i = src.index("## References")
j = src.index("### \u56fe\u76ee\u5f55")
new_refs = "## References\n\n" + ref_block + "\n\n---\n\n"
src = src[:i] + new_refs + src[j:]

k = src.index("### \u56fe\u76ee\u5f55")
kend = src.index("*每个文件均有 PNG")
kend = src.index("\n", kend) + 1
fig_index = """### Figure index (13 figures; each is provided as PNG and PDF in `figures/`)

| Figure | File | Content |
|---|---|---|
| Fig 1 | `fig_report_F1_bindingdb_overlap` | Overlap with the BindingDB ChEMBL source corpus (targets / molecules / pairs, with date boundaries) |
| Fig 2 | `fig_report_F7_main_rho` | Main result: per-target \u03c1 for the six open-box DTI models (median + 95% CI) |
| Fig 3 | `fig_sampling_stability` | Sampling stability of the benchmark conclusion |
| Fig 4 | `fig_kinase_vs_nonkinase` | Kinase versus non-kinase targets |
| Fig 5 | `fig_report_F4_mrr` | Tier-1 MRR against the analytic random baseline |
| Fig 6 | `fig_report_F6_drugban_gap` | DrugBAN: in-domain validation AUROC versus this benchmark |
| Fig 7 | `fig_report_F3_three_way` | Filter strictness \u00d7 sampling: three-way comparison |
| Fig 8 | `fig_report_F5_decoy_auc` | Decoy discrimination AUC (true ligands vs property-matched decoys) |
| Fig 9 | `fig_report_F2_ligand_baseline` | Trivial physicochemical baselines versus the models |
| Fig 10 | `fig_bench_models` | Model-versus-model comparison |
| Fig 11 | `fig_bench_per_target` | Per-target \u03c1 dispersion |
| Fig 12 | `fig_bench_tiers` | Three-tier criteria overview |
| Fig 13 | `fig_bench_flip` | Effect of evaluation set size on median \u03c1 |

Every file is provided in both PNG (raster) and PDF (vector) form under `figures/`. The main text also contains six tables (Tables 1\u20136); Supplementary Notes S1\u2013S5 follow below.
"""
src = src[:k] + fig_index + src[kend:]
log.append("E15 参考文献编号回填 + 图目录改英文(Fig 13 描述修正)")

left = re.findall(r"(?<!!)\[[a-z_]{3,}\]", src)
assert not left, left
print("✓ 无未替换的 [key] 占位符残留")

# =====================================================================
# E16 补充材料 S1–S5 标题改英文
# =====================================================================
s_old_start = src.index("## Supplementary notes")
s_old_end = len(src)
supp_new = """## Supplementary notes

- **S1** Training and reproducibility details (DrugBAN training, checkpoints, software versions, GPU)
- **S2** Internal audit and errata record (`results/audit_response.md`)
- **S3** Reference implementation and self-test of the trivial-baseline protocol (`tools/trivial_baseline.py`, `tools/README_trivial_baseline.md`)
- **S4** Literature search for a \u03c1 threshold (six Europe PMC queries)
- **S5** Full experimental report (`results/DTI_experimental_report.md`)
"""
src = src[:s_old_start] + supp_new
log.append("E16 补充材料 S1-S5 标题改英文")

# =====================================================================
# E17 修订连贯性小修
# =====================================================================
src = rep1("(ii) A third revision was then forced by a reviewer-driven check",
           "(ii) A second revision was then forced by a reviewer-driven check",
           "E17a §4.1 (ii) third->second")
src = rep1("![fig_report_F5_decoy_auc.png](../figures/fig_report_F5_decoy_auc.png)",
           "![fig_report_F5_decoy_auc](../figures/fig_report_F5_decoy_auc.png)",
           "E17b 图注 alt 去 .png")
src = rep1("Bootstrap 95% confidence intervals were obtained by resampling **targets** (5,000 replicates).",
           "Bootstrap 95% confidence intervals were obtained by resampling **targets** (5,000 replicates for "
           "the primary analysis; 10,000 for the dependence-corrected re-analysis, with 2,000 for the "
           "ligand-clustered and iid pair-level variants).",
           "E17c §2.4 bootstrap 重抽样次数补全")

# =====================================================================
# 收尾:空白整理 + 落盘
# =====================================================================
src = re.sub(r"\n{4,}", "\n\n\n", src)
open(OUT, "w", encoding="utf-8", newline="\n").write(src)

print()
print("=" * 68)
print("已生成:", OUT)
print("  %d 字符 -> %d 字符" % (orig_len, len(src)))
print("完成条目:")
for t in log:
    print("  ✅", t)
