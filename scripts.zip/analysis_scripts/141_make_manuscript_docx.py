# -*- coding: utf-8 -*-
"""
DTI_manuscript_v3.md -> DTI_manuscript_v3.docx

稳健管线:Markdown --(python-markdown)--> HTML --(htmldocx)--> docx
不再使用自写的逐行解析器(旧版 131/135 会丢表、截断段落、重复标题)。

字体:西文 Times New Roman(含 Greek ρ)、中文 eastAsia = Microsoft YaHei。
转换完成后自动校验并打印:表格数(源码 vs docx)、每表行列数、ρ 计数、
占位符、重复标题、内部草稿信息、图片数。
"""
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

import docx
import markdown
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from htmldocx import HtmlToDocx

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
SRC = os.path.join(BASE, "manuscript", "DTI_manuscript_v3.md")
OUT = os.path.join(BASE, "manuscript", "DTI_manuscript_v3.docx")
LATIN, EASTASIA = "Times New Roman", "Microsoft YaHei"

src = open(SRC, encoding="utf-8").read()

# ------------------------------------------------------------------ 文档与样式
doc = Document()
normal = doc.styles["Normal"]
normal.font.name = LATIN
normal.font.size = Pt(10.5)
normal.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), EASTASIA)


def style_font(style, size=None):
    rpr = style.element.get_or_add_rPr()
    rf = rpr.get_or_add_rFonts()
    rf.set(qn("w:ascii"), LATIN)
    rf.set(qn("w:hAnsi"), LATIN)
    rf.set(qn("w:eastAsia"), EASTASIA)
    if size is not None:
        style.font.size = Pt(size)


for hname, hsize in (("Heading 1", 16), ("Heading 2", 13), ("Heading 3", 11.5),
                     ("Heading 4", 11), ("Heading 5", 10.5), ("Title", 17)):
    try:
        st = doc.styles[hname]
        style_font(st, hsize)
        st.font.color.rgb = RGBColor(0, 0, 0)
        st.font.bold = True
    except KeyError:
        pass

# ------------------------------------------------------------------ 解析:文本块 + 图片
IMG_RE = re.compile(r"^!\[(.*?)\]\((.+?)\)\s*$")
md = markdown.Markdown(extensions=["tables", "sane_lists", "attr_list", "nl2br"])
parser = HtmlToDocx()
parser.table_style = "Table Grid"

n_img = 0
lines = src.split("\n")
buf = []


def flush():
    global buf
    text = "\n".join(buf).strip()
    buf = []
    if not text:
        return
    md.reset()
    html = md.convert(text)
    parser.add_html_to_document(html, doc)


for ln in lines:
    m = IMG_RE.match(ln.strip())
    if m:
        flush()
        alt, rel = m.group(1), m.group(2)
        p = os.path.normpath(os.path.join(BASE, "manuscript", rel))
        if os.path.isfile(p):
            doc.add_picture(p, width=Inches(6.2))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap = doc.add_paragraph()
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = cap.add_run(alt)
            r.italic = True
            r.font.size = Pt(9)
            r.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
            n_img += 1
        else:
            doc.add_paragraph("[MISSING IMAGE: %s]" % rel)
        doc.add_paragraph()
        continue
    buf.append(ln)
flush()

# ------------------------------------------------------------------ 表格排版
for t in doc.tables:
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = True
    for row in t.rows:
        for cell in row.cells:
            for par in cell.paragraphs:
                par.paragraph_format.space_before = Pt(1)
                par.paragraph_format.space_after = Pt(1)
                for run in par.runs:
                    run.font.size = Pt(8.0)

doc.core_properties.title = ("Open-box drug-target interaction models do not reproduce "
                             "within-target affinity ranking on a 57-target benchmark")
doc.save(OUT)

# ================================================================== 自动校验
print("=" * 74)
print("转换完成:", OUT, "(%.1f MB)" % (os.path.getsize(OUT) / 1024 / 1024))
print("=" * 74)

# --- 源码里的表格数 ---
SEP = re.compile(r"^\|[\s:\-|]+\|$")
src_lines = src.split("\n")
src_tab_blocks, i = 0, 0
while i < len(src_lines):
    if src_lines[i].strip().startswith("|") and i + 1 < len(src_lines) and SEP.match(src_lines[i + 1].strip()):
        src_tab_blocks += 1
        i += 1
        while i < len(src_lines) and src_lines[i].strip().startswith("|"):
            i += 1
        continue
    i += 1

d = docx.Document(OUT)
paras = [p.text for p in d.paragraphs]
body = "\n".join(paras)
tab_txt = "\n".join(c.text for t in d.tables for r in t.rows for c in r.cells)
allt = body + "\n" + tab_txt

print()
print("【1】表格数量")
print("  源码(Markdown)表格数 : %d" % src_tab_blocks)
print("  docx 表格数           : %d" % len(d.tables))
print("  一致? %s" % ("✅" if src_tab_blocks == len(d.tables) else "❌ 不一致"))

print()
print("【2】每张表的行数 × 列数(与源码逐表对照)")
src_dims = []
i = 0
while i < len(src_lines):
    if src_lines[i].strip().startswith("|") and i + 1 < len(src_lines) and SEP.match(src_lines[i + 1].strip()):
        rows = 0
        while i < len(src_lines) and src_lines[i].strip().startswith("|"):
            rows += 1
            i += 1
        src_dims.append((rows - 1, len([c for c in src_lines[i - 1].strip().strip("|").split("|")])))
        continue
    i += 1
ok_tab = True
for k, t in enumerate(d.tables, 1):
    sr, sc = src_dims[k - 1] if k - 1 < len(src_dims) else (-1, -1)
    dr, dc = len(t.rows), len(t.columns)
    flag = "✅" if (sr, sc) == (dr, dc) else "❌"
    if flag == "❌":
        ok_tab = False
    print("  Table %2d: docx %2d 行 x %d 列  | 源码 %2d 行 x %d 列  %s" % (k, dr, dc, sr, sc, flag))

print()
print("【3】字符保真")
n_rho_src = src.count("\u03c1")
n_rho_doc = allt.count("\u03c1")
print("  'ρ' 源码 %d 次 / docx %d 次  %s" % (n_rho_src, n_rho_doc,
                                            "✅" if n_rho_doc == n_rho_src else "❌ 丢失"))
bad_p = re.findall(r"(?:Spearman|observed)\s+p(?![a-zA-Z])", allt)
for m in re.finditer(r"\bp\s+0\.0\d{2}\b", body):
    ctx = body[max(0, m.start() - 24):m.start()]
    if "Mann-Whitney" not in ctx and "Wilcoxon" not in ctx and "sign" not in ctx:
        bad_p.append(m.group(0))
print("  遗留 'Spearman p' / 'low observed p' / 误写 ρ:%d 处 %s" % (
    len(bad_p), "✅" if not bad_p else "❌ %s" % bad_p))
print("  段落数:%d(含标题、表注、图注)" % len(d.paragraphs))

print()
print("【4】占位符残留")
ph = sorted(set(re.findall(r"\[[A-Z_ ]{4,}\]", allt)))
key_ph = sorted(set(re.findall(r"(?<!!)\[[a-z_]{3,}\]", allt)))
print("  [key] 型占位      : %d %s" % (len(key_ph), "✅" if not key_ph else "❌ %s" % key_ph))
print("  其他方括号占位    : %s" % (ph if ph else "✅ 无"))
if ph:
    print("     (↑ 作者信息待填字段,无法由分析数据推出;已在报告中列为未完成项)")

print()
print("【5】重复标题")
heads = [p.text.strip() for p in d.paragraphs
         if p.style.name.startswith("Heading") and p.text.strip()]
dups = sorted({h for h in heads if heads.count(h) > 1})
print("  标题总数 %d;重复 %d %s" % (len(heads), len(dups), "✅" if not dups else "❌ %s" % dups))
consec = [heads[j] for j in range(1, len(heads)) if heads[j] == heads[j - 1]]
print("  连续重复标题      : %s" % ("✅ 无" if not consec else "❌ %s" % consec))

print()
print("【6】内部草稿信息")
draft = ["草稿", "待补", "配套", "本表尚未填写", "引用以", "占位符", "DRAFT", "TODO"]
hits = [w for w in draft if w in allt]
print("  命中: %s" % ("✅ 无" if not hits else "❌ %s" % hits))

print()
print("【7】图片与关键内容落盘")
n_img_src = len(re.findall(IMG_RE.pattern, src, re.M))
print("  图片:源码 %d 张 / 嵌入 %d 张 %s" % (n_img_src, n_img, "✅" if n_img == n_img_src else "❌"))
TYPO = ["dti_flows", "mppnn_cnn", "property_matched_decays", "bindingdb_verlap",
        "Spearman p ", "low observed p", "\\) 3.10", "Two revisions"]
for w in TYPO:
    print("  旧版拼写/错误 '%s' 已消除        %s" % (w, "✅" if w not in allt else "❌"))
for w in ["[3,4]", "property-matched", "fig_report_F1_bindingdb_overlap", "\u00a73.10", "Spearman \u03c1"]:
    print("  修正后写法 '%s' 存在             %s" % (w, "✅" if w in allt else "❌"))
checks = [
    ("§2.1 评估集三行", ["Main", "Strict-equal", "Filter strictness"]),
    ("Table 3 = 6 模型 + MW + DrugBAN", ["morgan_aac | 0.575", "--"]),
    ("Table 2 校正列", ["Bonferroni p", "BH p"]),
    ("新增 Top-k 对比表", ["Table 5. Tier-1 retrieval", "not computed"]),
    ("§2.2 checkpoint 段", ["best_model_epoch_43.pth", "0.9624"]),
    ("§4.1 标题", ["Three revisions of the claim"]),
    ("§4.6 末句", ["not distinguishable from a trivial single-descriptor baseline"]),
    ("§3.0 结尾完整", ["global ligand physicochemistry (\u00a73.5, \u00a73.10)"]),
    ("§3.1 Davis 分母", ["388/916"]),
    ("§3.9 1,096 说明", ["1,096 rather than 1,097"]),
    ("§3.4 末句", ["discussed in \u00a73.9 and \u00a74.1"]),
    ("结论第 5 条", ["In-domain Davis performance"]),
    ("补充材料 S1-S5 英文", ["Training and reproducibility details"]),
    ("图目录 Fig 13", ["Effect of evaluation set size on median"]),
]
for label, needles in checks:
    if label == "Table 3 = 6 模型 + MW + DrugBAN":
        ok = all(n in tab_txt for n in ["0.575", "0.581", "0.608"])
    else:
        ok = all(n in allt for n in needles)
    print("  %-32s %s" % (label, "✅" if ok else "❌"))

print()
print("=" * 74)
print("总判定: %s" % ("✅ 全部通过" if (src_tab_blocks == len(d.tables) and ok_tab
                                        and n_rho_doc == n_rho_src and not key_ph
                                        and not dups and not consec and not hits
                                        and n_img == n_img_src) else "❌ 存在失败项"))
