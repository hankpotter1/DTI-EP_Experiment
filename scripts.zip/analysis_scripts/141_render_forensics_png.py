# -*- coding: utf-8 -*-
"""把用户报告的 4 处渲染成 PNG 截图,直接看字形(绕开任何文本管线)。"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

import fitz  # pymupdf

PDF = r"G:\HHH\openclaw-workspace\netpharm-toolkit\manuscript\DTI_manuscript_v6.pdf"
OUT = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures\_forensics"
os.makedirs(OUT, exist_ok=True)

doc = fitz.open(PDF)
print("总页数:", doc.page_count)

targets = {
    "Table3_header": ["sign p", "Bonferroni p"],
    "sec35": ["3.5 Cross-target retrieval"],
    "conclusions": ["7. Conclusions", "Conclusions"],
    "ref10": ["[10] "],
}

for name, needles in targets.items():
    hit_pages = []
    for pno in range(doc.page_count):
        t = doc[pno].get_text()
        if all(n in t for n in needles[:1]) or any(n in t for n in needles):
            hit_pages.append(pno)
    print("  %-14s 命中页(0-based): %s" % (name, hit_pages[:4]))
    for pno in hit_pages[:1]:
        page = doc[pno]
        # 找到关键词所在矩形,放大渲染该区域
        rect = None
        for n in needles:
            r = page.search_for(n)
            if r:
                rect = r[0]
                break
        if rect is None:
            pix = page.get_pixmap(dpi=150)
            path = os.path.join(OUT, "%s_p%d_full.png" % (name, pno + 1))
        else:
            clip = fitz.Rect(max(0, rect.x0 - 40), max(0, rect.y0 - 60),
                             min(page.rect.x1, rect.x1 + 520),
                             min(page.rect.y1, rect.y1 + 160))
            pix = page.get_pixmap(dpi=260, clip=clip)
            path = os.path.join(OUT, "%s_p%d_zoom.png" % (name, pno + 1))
        pix.save(path)
        print("     -> %s  (%dx%d)" % (os.path.basename(path), pix.width, pix.height))

print("\n产物目录:", OUT)
