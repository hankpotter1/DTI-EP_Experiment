# -*- coding: utf-8 -*-
"""
重出报告图(图内中文 -> 英文;删除「可用阈值」暗示)。Plotly + kaleido。
覆盖 figures/ 下同名 PNG + PDF。

数据来源全部为 results/*.json(真实运行产物),不编造。
"""
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"
os.makedirs(FIG, exist_ok=True)

import plotly.graph_objects as go

C_BLUE, C_RED, C_GREY, C_GREEN, C_ORANGE = "#2c6fbb", "#c0392b", "#7f8c8d", "#27ae60", "#e67e22"


def J(fn):
    return json.load(open(os.path.join(RES, fn), encoding="utf-8"))


def save(fig, name, w=900, h=520):
    for ext in ("png", "pdf"):
        fig.write_image(os.path.join(FIG, "%s.%s" % (name, ext)), width=w, height=h, scale=2)
    print("  [ok] %s (.png + .pdf)" % name, flush=True)


TPL = dict(template="plotly_white", font=dict(size=13, family="Times New Roman, serif"))
made = []

# ==========================================================================
# F1 — Overlap with the BindingDB ChEMBL source corpus
# ==========================================================================
ref = J("bindingdb_overlap_refined.json")
lig = J("bindingdb_ligand_overlap.json")
tgt = J("bindingdb_target_overlap.json")
labels = ["Targets<br>(43/57)", "Molecules<br>(1,107/1,409)", "(Target, ligand) pairs<br>(1,097/1,425)",
          "Pairs deposited<br>before 2021<br>(1,093/1,425)", "Pairs deposited<br>before 2019<br>(1,087/1,425)"]
vals = [tgt["frac_in_bindingdb"] * 100, lig["ligand_frac"] * 100, lig["pair_frac"] * 100,
        ref["by_cutoff"]["2021-01-01"]["frac"] * 100, ref["by_cutoff"]["2019-01-01"]["frac"] * 100]
fig = go.Figure(go.Bar(x=labels, y=vals, marker_color=[C_BLUE, C_BLUE, C_RED, C_RED, C_RED],
                       text=["%.1f%%" % v for v in vals], textposition="outside"))
fig.update_layout(title="Overlap with the BindingDB ChEMBL source corpus",
                  yaxis_title="Fraction present in BindingDB (%)", yaxis_range=[0, 105],
                  showlegend=False, **TPL)
save(fig, "fig_report_F1_bindingdb_overlap")
made.append("F1")

# ==========================================================================
# F2 — Trivial physicochemical baselines vs the six DTI models
# ==========================================================================
tb = J("trivial_baseline_demo.json")["baselines"]
PROPS = [("MW", "Molecular weight"), ("ArRings", "Aromatic rings"), ("HBD", "H-bond donors"),
         ("RotB", "Rotatable bonds"), ("TPSA", "TPSA"), ("logP", "logP"),
         ("HBA", "H-bond acceptors"), ("HeavyAtoms", "Heavy-atom count")]
b_med = [tb[k]["median_rho"] for k, _ in PROPS]
b_lo = [tb[k]["ci95_median"][0] for k, _ in PROPS]
b_hi = [tb[k]["ci95_median"][1] for k, _ in PROPS]
ma = J("independence_and_ma_correction.json")["tier3_primary_endpoint"]["objects"]
MODELS = ["cnn_cnn_bindingdb", "morgan_aac_bindingdb", "morgan_cnn_bindingdb",
          "daylight_aac_bindingdb", "transformer_cnn_bindingdb", "mpnn_cnn_bindingdb"]
m_med = [ma[k]["median_rho"] for k in MODELS]
m_lo = [ma[k]["cluster_bootstrap_by_target"]["ci95"][0] for k in MODELS]
m_hi = [ma[k]["cluster_bootstrap_by_target"]["ci95"][1] for k in MODELS]
names = [lbl for _, lbl in PROPS] + ["<b>%s</b>" % k.replace("_bindingdb", "") for k in MODELS]
fig = go.Figure(go.Bar(
    x=names, y=b_med + m_med,
    error_y=dict(type="data", symmetric=False,
                 array=[h - m for m, h in zip(b_med + m_med, b_hi + m_hi)],
                 arrayminus=[m - l for m, l in zip(b_med + m_med, b_lo + m_lo)]),
    marker_color=[C_ORANGE] * len(PROPS) + [C_BLUE] * len(MODELS),
    text=["%.3f" % v for v in b_med + m_med], textposition="outside"))
fig.add_hline(y=tb["HeavyAtoms"]["median_rho"], line_dash="dash", line_color=C_RED,
              annotation_text="strongest single-descriptor baseline (heavy-atom count, \u03c1 = 0.191)",
              annotation_position="top left")
fig.update_layout(title="Trivial physicochemical baselines versus the six DTI models "
                        "(median per-target \u03c1, 95% CI)",
                  yaxis_title="Per-target Spearman \u03c1 (median)", yaxis_range=[-0.06, 0.34],
                  showlegend=False, **TPL)
fig.update_xaxes(tickangle=-25)
save(fig, "fig_report_F2_ligand_baseline", w=1050, h=520)
made.append("F2")

# ==========================================================================
# F3 — Filter strictness x sampling, three-way
# ==========================================================================
se = J("strict_eq_eval.json")
sd = J("strict_and_decoy_eval.json")
order = ["morgan_aac_bindingdb", "cnn_cnn_bindingdb", "daylight_aac_bindingdb",
         "morgan_cnn_bindingdb", "transformer_cnn_bindingdb", "mpnn_cnn_bindingdb"]
xl = [k.replace("_bindingdb", "") for k in order]
A = [ma[k]["median_rho"] for k in order]
B = [sd[k]["median_rho"] for k in order]
C = [se[k]["median_rho"] for k in order]
fig = go.Figure()
fig.add_trace(go.Bar(name="A: loose filter, equal spacing (main set)", x=xl, y=A, marker_color=C_GREY))
fig.add_trace(go.Bar(name="B: strict filter, random sampling", x=xl, y=B, marker_color=C_BLUE))
fig.add_trace(go.Bar(name="C: strict filter, equal spacing", x=xl, y=C, marker_color=C_RED))
fig.update_layout(title="Filter strictness \u00d7 sampling: three-way comparison "
                        "(no condition approaches a usable level)",
                  yaxis_title="Per-target \u03c1 (median)", barmode="group", **TPL)
fig.update_xaxes(tickangle=-20)
save(fig, "fig_report_F3_three_way")
made.append("F3")

# ==========================================================================
# F4 — Tier-1 MRR vs the analytic random baseline (285-probe set)
# ==========================================================================
t1 = J("tier1_expanded.json")
base = t1["random_baseline"]["mrr"]
mr = [(k.replace("_bindingdb", ""), v["mrr"]) for k, v in t1["per_model"].items()]
mr.sort(key=lambda kv: kv[1])
fig = go.Figure(go.Bar(x=[k for k, _ in mr], y=[v for _, v in mr],
                       marker_color=[C_RED if v < base else C_BLUE for _, v in mr],
                       text=["%.4f" % v for _, v in mr], textposition="outside"))
fig.add_hline(y=base, line_dash="dash", line_color=C_GREEN,
              annotation_text="analytic random baseline H(57)/57 = 0.0812",
              annotation_position="bottom right")
fig.update_layout(title="Tier-1 retrieval MRR (285 probes): one of six models below the "
                        "analytic random baseline",
                  yaxis_title="Mean reciprocal rank", yaxis_range=[0, 0.115],
                  showlegend=False, **TPL)
save(fig, "fig_report_F4_mrr")
made.append("F4")

# ==========================================================================
# F5 — Decoy discrimination AUC
# ==========================================================================
dec = J("audit_fixes.json")["M3_decoy_auc_ci"]
ds = sorted(dec.items(), key=lambda kv: -kv[1]["median_auc"])
fig = go.Figure()
fig.add_trace(go.Scatter(
    x=[v["median_auc"] for _, v in ds],
    y=[k.replace("_bindingdb", "") for k, _ in ds],
    mode="markers",
    error_x=dict(type="data", symmetric=False,
                 array=[v["ci95"][1] - v["median_auc"] for _, v in ds],
                 arrayminus=[v["median_auc"] - v["ci95"][0] for _, v in ds]),
    marker=dict(size=12, color=C_BLUE)))
fig.add_vline(x=0.5, line_dash="dash", line_color=C_RED, annotation_text="chance (AUC = 0.5)")
fig.update_layout(title="Decoy discrimination AUC (true ligands vs property-matched decoys) "
                        "\u2014 far below the model's own in-domain performance",
                  xaxis_title="Per-target AUC (median, 95% CI)", xaxis_range=[0.45, 0.65],
                  showlegend=False, **TPL)
save(fig, "fig_report_F5_decoy_auc", w=980, h=460)
made.append("F5")

# ==========================================================================
# F6 — DrugBAN: in-domain vs this benchmark
# ==========================================================================
e43 = J("drugban_eval_ep43.json")
e30 = J("drugban_eval_ep30.json")
fig = go.Figure()
fig.add_trace(go.Bar(name="In-domain AUROC (BindingDB validation set)", x=["DrugBAN"], y=[0.9624],
                     marker_color=C_GREEN, text=["0.962"], textposition="outside"))
fig.add_trace(go.Bar(name="This benchmark: median \u03c1 (epoch 43)", x=["DrugBAN"],
                     y=[e43["tier3_median_rho"]], marker_color=C_BLUE,
                     text=["%.3f" % e43["tier3_median_rho"]], textposition="outside"))
fig.add_trace(go.Bar(name="This benchmark: median \u03c1 (epoch 30)", x=["DrugBAN"],
                     y=[e30["tier3_median_rho"]], marker_color=C_GREY,
                     text=["%.3f" % e30["tier3_median_rho"]], textposition="outside"))
fig.update_layout(title="DrugBAN (2022): in-domain AUROC 0.962 versus \u03c1 0.165\u20130.188 "
                        "on this benchmark",
                  yaxis_title="AUROC / Spearman \u03c1", yaxis_range=[0, 1.08],
                  barmode="group", **TPL)
save(fig, "fig_report_F6_drugban_gap")
made.append("F6")

# ==========================================================================
# F7 — Main result: per-target rho
# ==========================================================================
main = [(k.replace("_bindingdb", ""), ma[k]["median_rho"],
         ma[k]["cluster_bootstrap_by_target"]["ci95"][0],
         ma[k]["cluster_bootstrap_by_target"]["ci95"][1])
        for k in ["cnn_cnn_bindingdb", "morgan_aac_bindingdb", "morgan_cnn_bindingdb",
                  "daylight_aac_bindingdb", "transformer_cnn_bindingdb", "mpnn_cnn_bindingdb"]]
fig = go.Figure()
fig.add_trace(go.Scatter(x=[m[1] for m in main], y=[m[0] for m in main], mode="markers",
                         error_x=dict(type="data", symmetric=False,
                                      array=[m[3] - m[1] for m in main],
                                      arrayminus=[m[1] - m[2] for m in main]),
                         marker=dict(size=13, color=C_BLUE)))
fig.add_vline(x=0, line_color=C_GREY, line_dash="dot")
fig.add_vline(x=0.4, line_color=C_RED, line_dash="dash",
              annotation_text="reference line (\u03c1 = 0.4; not a literature-established threshold)",
              annotation_position="top right")
fig.update_layout(title="Main result: per-target Spearman \u03c1 for six open-box DTI models "
                        "(median + 95% CI)",
                  xaxis_title="Per-target Spearman \u03c1", xaxis_range=[-0.15, 0.5],
                  showlegend=False, **TPL)
save(fig, "fig_report_F7_main_rho", w=980, h=460)
made.append("F7")

print("\n重出图完成 %d 张 -> %s" % (len(made), FIG))
print("  " + ", ".join(made))
