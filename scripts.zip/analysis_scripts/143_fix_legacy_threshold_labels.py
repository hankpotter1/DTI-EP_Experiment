# -*- coding: utf-8 -*-
"""
遗留图(official figures 里被正文引用的 6 张非 report 图)中,有 3 张仍把 ρ=0.4
标注成 "usable threshold",与稿件 §4.6「并非文献确立阈值」的立场冲突。
本脚本按原脚本 98/108 的同一数据源与画法重出,仅改动该标注措辞。

重出:fig_bench_flip / fig_bench_models / fig_bench_per_target / fig_sampling_stability
(fig_bench_tiers 与 fig_kinase_vs_nonkinase 无阈值措辞,内容已为英文,不再重出)
"""
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"

import plotly.graph_objects as go

DARK, RED, BLUE, GREY, GREEN, ORANGE = "#2C3E50", "#E74C3C", "#2471A3", "#7F8C8D", "#1E8449", "#E67E22"
FONT = "Arial"
REFLINE = "reference line (rho = 0.4; not a literature-established threshold)"


def J(fn):
    return json.load(open(os.path.join(RES, fn), encoding="utf-8"))


def save(fig, name, w, h, scale=3):
    fig.write_image(os.path.join(FIG, "%s.png" % name), scale=scale, width=w, height=h)
    fig.write_image(os.path.join(FIG, "%s.pdf" % name), width=w, height=h)
    print("  [ok] %s (.png + .pdf)" % name, flush=True)


j3 = J("multimodel_benchmark.json")
j20 = J("multimodel_benchmark_20t.json")
byname3 = {r["model"]: r for r in j3}
byname20 = {r["model"]: r for r in j20}
ORDER = [r["model"] for r in j20]
r3 = [byname3[m]["tier3_spearman_mean"] for m in ORDER]
r20 = [byname20[m]["tier3_spearman_mean"] for m in ORDER]

# ---------- fig_bench_flip ----------
fig = go.Figure()
fig.add_trace(go.Bar(name="3 targets x 14 ligands", x=ORDER, y=r3, marker_color=GREY))
fig.add_trace(go.Bar(name="20 targets x 25 ligands", x=ORDER, y=r20, marker_color=RED))
fig.add_hline(y=0, line=dict(color=DARK, width=1))
fig.add_hline(y=0.4, line=dict(color=GREEN, width=1.4, dash="dash"),
              annotation_text=REFLINE, annotation_position="top left")
fig.add_annotation(x="morgan_cnn_bindingdb", y=0.598, text="0.60 -> 0.17", showarrow=True,
                   arrowhead=2, ax=0, ay=-45, font=dict(size=12, color=DARK), bgcolor="white")
fig.update_layout(template="simple_white", width=1050, height=560, barmode="group",
                  title=dict(text="<b>The conclusion flips when the evaluation set grows</b>",
                             font=dict(size=19, family=FONT)),
                  yaxis_title="Mean Spearman rho (predicted vs measured affinity)",
                  xaxis_tickangle=-18, font=dict(family=FONT, size=12),
                  margin=dict(l=80, r=40, t=80, b=130), legend=dict(x=0.02, y=0.98))
fig.update_xaxes(tickfont=dict(size=10))
save(fig, "fig_bench_flip", 1050, 560)

# ---------- fig_bench_models ----------
fig2 = go.Figure()
fig2.add_trace(go.Bar(x=ORDER, y=r20, marker_color=RED))
fig2.add_hline(y=0.4, line=dict(color=GREEN, width=1.4, dash="dash"),
               annotation_text=REFLINE, annotation_position="top left")
fig2.add_hline(y=0.0, line=dict(color=DARK, width=1))
fig2.add_annotation(x=0.5, y=0.22, xref="paper", yref="y",
                    text="all models far below the reference line",
                    showarrow=False, font=dict(size=12, color=GREY, family=FONT))
fig2.update_layout(template="simple_white", width=1050, height=540,
                   title=dict(text="<b>Affinity-ranking performance, 6 public DTI models (20 targets, 500 ligands)</b>",
                              font=dict(size=17, family=FONT)),
                   yaxis_title="Mean Spearman rho", yaxis_range=[-0.1, 0.5],
                   xaxis_tickangle=-18, font=dict(family=FONT, size=12),
                   margin=dict(l=80, r=40, t=80, b=130), showlegend=False)
fig2.update_xaxes(tickfont=dict(size=10))
save(fig2, "fig_bench_models", 1050, 540)

# ---------- fig_bench_per_target ----------
fig3 = go.Figure()
for i, m in enumerate(ORDER):
    bd = byname20[m].get("tier3_by_class", {})
    ys = sorted(bd.values(), reverse=True)
    fig3.add_trace(go.Box(y=ys, name=m.replace("_bindingdb", ""), boxpoints="all",
                          jitter=0.5, pointpos=0,
                          marker_color=[RED, BLUE, GREEN, ORANGE, GREY, DARK][i]))
fig3.add_hline(y=0, line=dict(color=DARK, width=1))
fig3.add_hline(y=0.4, line=dict(color=GREEN, width=1.4, dash="dash"),
               annotation_text=REFLINE, annotation_position="top left")
fig3.update_layout(template="simple_white", width=1100, height=560,
                   title=dict(text="<b>Per-target rho spread: wide and sign-inconsistent = noise, not signal</b>",
                              font=dict(size=17, family=FONT)),
                   yaxis_title="Spearman rho (per target)", font=dict(family=FONT, size=12),
                   margin=dict(l=80, r=40, t=80, b=110), showlegend=False)
fig3.update_xaxes(tickangle=-18, tickfont=dict(size=10))
save(fig3, "fig_bench_per_target", 1100, 560)

# ---------- fig_sampling_stability ----------
S = J("critical_analysis_summary.json")
NAMES = list(S.keys())
SHORT = [n.replace("_bindingdb", "") for n in NAMES]
COLS = [RED, BLUE, GREEN, ORANGE, GREY, DARK]
xs = [3, 5, 10, 20, 57]
avail = sorted(S[NAMES[0]]["sampling_curve"].keys())
print("  sampling_curve keys:", avail, flush=True)
fig4 = go.Figure()
for i, n in enumerate(NAMES):
    c = S[n]["sampling_curve"]
    keys = ["%dx25" % k for k in xs]
    med = [c[k]["median"] if k in c else None for k in keys]
    lo = [c[k]["p05"] if k in c else None for k in keys]
    hi = [c[k]["p95"] if k in c else None for k in keys]
    fig4.add_trace(go.Scatter(x=xs, y=med, mode="lines+markers", name=SHORT[i],
                              line=dict(color=COLS[i], width=2.6), marker=dict(size=9),
                              error_y=dict(type="data", symmetric=False,
                                           array=[h - m for h, m in zip(hi, med)],
                                           arrayminus=[m - l for m, l in zip(med, lo)],
                                           color=COLS[i], thickness=1, width=3)))
fig4.add_hline(y=0.4, line=dict(color=GREEN, width=1.6, dash="dash"),
               annotation_text=REFLINE, annotation_position="top right")
fig4.add_hline(y=0.0, line=dict(color=DARK, width=1))
fig4.update_layout(template="simple_white", width=1180, height=600,
                   title=dict(text="<b>Sampling stability: apparent performance depends on how many targets you happen to pick</b>",
                              font=dict(size=17, family=FONT)),
                   xaxis=dict(title="Number of targets sampled (25 ligands each)", type="log",
                              tickvals=xs, ticktext=[str(k) for k in xs]),
                   yaxis=dict(title="Median Spearman rho (5-95% of resamples)", range=[-0.35, 0.55]),
                   font=dict(family=FONT, size=12), margin=dict(l=80, r=40, t=90, b=70),
                   legend=dict(x=0.60, y=0.02, bgcolor="rgba(255,255,255,0.9)"))
save(fig4, "fig_sampling_stability", 1180, 600)

print("\n完成:4 张图的 ρ=0.4 标注已由「可用阈值」改为非阈值的参考线。")
