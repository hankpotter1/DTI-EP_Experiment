# -*- coding: utf-8 -*-
"""
按检查点分别评测 DrugBAN,补齐 Tier-2 完整统计(mean/median AUC、bootstrap 95% CI、
符号检验 p、Wilcoxon p)+ Tier-3 复核。

背景(数据完整性问题):
  results/tier2_with_baseline.json 中的键 "DrugBAN_ep43" 实际由
  results/drugban_predictions.csv 计算,而该 CSV 是 2026-09-23 10:50 用
  best_model_epoch_30.pth 重跑产生的(mtime 与 drugban_eval_ep30.json 相同)。
  即 tier2_with_baseline 的 DrugBAN 行 = epoch 30,标签错误。

本脚本不覆盖任何既有文件,输出:
  results/drugban_predictions_ep43.csv
  results/drugban_predictions_ep30.csv
  results/drugban_eval_per_ckpt.json
"""
import csv
import json
import os
import statistics as st
import sys
from functools import partial

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
DB = os.path.join(BASE, "thirdparty", "drugban_extract", "DrugBAN-main")
RES = os.path.join(BASE, "results")
sys.path.insert(0, DB)
os.chdir(DB)

import numpy as np
import pandas as pd
import torch
import torch.utils.data as data
from scipy.stats import spearmanr, binomtest, wilcoxon
from sklearn.metrics import roc_auc_score
from dgllife.utils import smiles_to_bigraph, CanonicalAtomFeaturizer, CanonicalBondFeaturizer

from models import DrugBAN
from utils import integer_label_protein, graph_collate_func, set_seed
from configs import get_cfg_defaults

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("设备:", device, flush=True)


class PairDataset(data.Dataset):
    def __init__(self, df, max_drug_nodes=290):
        self.df = df.reset_index(drop=True)
        self.max_drug_nodes = max_drug_nodes
        self.atom_featurizer = CanonicalAtomFeaturizer()
        self.bond_featurizer = CanonicalBondFeaturizer(self_loop=True)
        self.fc = partial(smiles_to_bigraph, add_self_loop=True)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        row = self.df.iloc[index]
        v_d = self.fc(smiles=row["smiles"], node_featurizer=self.atom_featurizer,
                      edge_featurizer=self.bond_featurizer)
        nf = v_d.ndata.pop("h")
        n = nf.shape[0]
        nf = torch.cat((nf, torch.zeros([n, 1])), 1)
        v_d.ndata["h"] = nf
        n_virt = self.max_drug_nodes - n
        if n_virt > 0:
            v_d.add_nodes(n_virt, {"h": torch.cat((torch.zeros(n_virt, 74), torch.ones(n_virt, 1)), 1)})
        v_d = v_d.add_self_loop()
        v_p = integer_label_protein(row["sequence"])
        return v_d, v_p, 0


cfg = get_cfg_defaults()
cfg.merge_from_file(os.path.join(DB, "configs", "DrugBAN.yaml"))
set_seed(cfg.SOLVER.SEED)

recs = list(csv.DictReader(open(os.path.join(RES, "predictions_57t.csv"), encoding="utf-8-sig")))
seq_of, smi_of = {}, {}
for r in csv.DictReader(open(os.path.join(RES, "bench_eval_set_large.csv"), encoding="utf-8-sig")):
    seq_of[r["target"]] = r["sequence"]
    smi_of[r["molecule_chembl_id"]] = r["smiles"]

pairs, seen = [], set()
for r in recs:
    if str(r.get("is_own", "1")) != "1":
        continue
    t, m = r["target"], r["molecule"]
    if t not in seq_of or m not in smi_of:
        continue
    if (t, m) in seen:
        continue
    seen.add((t, m))
    pairs.append({"target": t, "cls": r.get("cls", ""), "molecule": m,
                  "smiles": smi_of[m], "sequence": seq_of[t], "measured": float(r["measured"])})
print("自身逐对评测: %d 对 / %d 靶点" % (len(pairs), len({p['target'] for p in pairs})), flush=True)

df = pd.DataFrame(pairs)
ds = PairDataset(df)
dl = data.DataLoader(ds, batch_size=64, shuffle=False, num_workers=0, collate_fn=graph_collate_func)

rng = np.random.default_rng(20260924)


def tier3(per_target):
    a = np.array([v for v in per_target.values() if v is not None])
    med = float(np.median(a))
    boot = [np.median(rng.choice(a, len(a), replace=True)) for _ in range(5000)]
    return {
        "n_targets": int(len(a)),
        "median_rho": round(med, 4),
        "ci95_median": [round(float(np.percentile(boot, 2.5)), 4),
                        round(float(np.percentile(boot, 97.5)), 4)],
        "pos_frac": round(float((a > 0).mean()), 4),
        "sign_p": float(binomtest(int((a > 0).sum()), len(a), 0.5).pvalue),
    }


def tier2(per_target):
    a = np.array(list(per_target.values()))
    boot_mean = [float(np.mean(rng.choice(a, len(a), replace=True))) for _ in range(4000)]
    boot_med = [float(np.median(rng.choice(a, len(a), replace=True))) for _ in range(4000)]
    return {
        "n_targets": int(len(a)),
        "mean_auc": round(float(a.mean()), 4),
        "median_auc": round(float(np.median(a)), 4),
        "ci95_mean": [round(float(np.percentile(boot_mean, 2.5)), 4),
                      round(float(np.percentile(boot_mean, 97.5)), 4)],
        "ci95_median": [round(float(np.percentile(boot_med, 2.5)), 4),
                        round(float(np.percentile(boot_med, 97.5)), 4)],
        "frac_above_0.5": round(float((a > 0.5).mean()), 4),
        "sign_p": float(binomtest(int((a > 0.5).sum()), len(a), 0.5).pvalue),
        "wilcoxon_p": float(wilcoxon(a - 0.5).pvalue),
    }


out = {}
for tag, ckpt_name in (("ep43", "best_model_epoch_43.pth"), ("ep30", "best_model_epoch_30.pth")):
    ckpt = os.path.join(DB, "result", ckpt_name)
    print("\n=== %s : %s ===" % (tag, ckpt), flush=True)
    model = DrugBAN(**cfg).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    probs = []
    with torch.no_grad():
        for i, (v_d, v_p, _) in enumerate(dl):
            _, _, score, _ = model(v_d.to(device), v_p.to(device), mode="eval")
            probs.extend(torch.sigmoid(score).squeeze(-1).cpu().numpy().tolist())
            if (i + 1) % 8 == 0:
                print("  批 %d/%d" % (i + 1, len(dl)), flush=True)
    d = df.copy()
    d["predicted"] = probs
    d.to_csv(os.path.join(RES, "drugban_predictions_%s.csv" % tag), index=False, encoding="utf-8-sig")

    rho_t, auc_t = {}, {}
    for t, g in d.groupby("target"):
        if len(g) < 10:
            continue
        if len(set(g["predicted"])) > 1 and len(set(g["measured"])) > 1:
            r, _ = spearmanr(g["predicted"].tolist(), g["measured"].tolist())
            if r == r:
                rho_t[t] = float(r)
        mid = g["measured"].median()
        hi_g, lo_g = g[g["measured"] > mid], g[g["measured"] < mid]
        if len(hi_g) and len(lo_g):
            y = [1] * len(hi_g) + [0] * len(lo_g)
            s = hi_g["predicted"].tolist() + lo_g["predicted"].tolist()
            if len(set(s)) > 1:
                auc_t[t] = float(roc_auc_score(y, s))
    out[tag] = {"checkpoint": ckpt_name, "n_pairs": int(len(d)), "n_targets": len(rho_t),
                "tier3": tier3(rho_t), "tier2": tier2(auc_t),
                "per_target_rho": {k: round(v, 4) for k, v in sorted(rho_t.items())}}
    print("  Tier-3 中位 ρ %.4f [%.4f, %.4f]" % (out[tag]["tier3"]["median_rho"],
          out[tag]["tier3"]["ci95_median"][0], out[tag]["tier3"]["ci95_median"][1]), flush=True)
    print("  Tier-2 均 %.4f 中位 %.4f  CI(mean)[%.4f, %.4f]  sign_p %.3g" % (
        out[tag]["tier2"]["mean_auc"], out[tag]["tier2"]["median_auc"],
        out[tag]["tier2"]["ci95_mean"][0], out[tag]["tier2"]["ci95_mean"][1],
        out[tag]["tier2"]["sign_p"]), flush=True)
    del model
    torch.cuda.empty_cache()

json.dump(out, open(os.path.join(RES, "drugban_eval_per_ckpt.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n落盘: results/drugban_eval_per_ckpt.json", flush=True)
