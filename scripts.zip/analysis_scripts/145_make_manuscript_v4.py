# -*- coding: utf-8 -*-
"""
DTI 稿件 v3 -> v4 修订。

输入 : manuscript/DTI_manuscript_v3.md
       results/*.json(真实数据)
输出 : manuscript/DTI_manuscript_v4.md

覆盖任务书条目:
  根因1 参考文献编号偏移 -> 条目改为字面 `[n] ` 文本(不用列表语法)
  根因3 标题重复         -> 源文件无重复,macOS/Word 自动编号风险由渲染器消除(见 147)
  条目5  §2.1 评估集表   -> 加表号 + 表注
  条目6  Tier-2 表       -> 6 模型 + MW 基线 + DrugBAN 两检查点(mean/median AUC, 95% CI, sign p)
  条目7  Tier-1 表       -> 8 个评估对象 + MRR 95% CI;方法里写明未做 Tier-1 的原因
  条目8  全表连续编号    -> Tables 1–10
  条目9  MRR 95% CI      -> 补 CI,改述为描述性比较
  条目10 §2.2 检查点矛盾 -> 统一为「两次训练、均以 epoch 43 为最优」
  条目11 §3.1 916 来源   -> 40 靶点 × ≤25 配体 = 1,000 对,经映射后 916
  条目12 残留删除        -> Limitations 改项目符号、Conclusions 1–6、4.4 逐条分行
  条目13 图例与 Tier 定义 -> fig_bench_tiers 图例重写(见 146)
  条目14 弱化 "usable"   -> 3.3 / 3.7 / 3.8 统一为 reference line 表述
  条目15 图目录          -> 描述与图内标题一致;Fig 1a 悬空引用修正
  条目16 关键词          -> 仅标题页一次

所有替换断言「恰好命中一次」,不命中即报错退出,绝不静默改错。
"""
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
RES = os.path.join(BASE, "results")
MS = os.path.join(BASE, "manuscript")
SRC = os.path.join(MS, "DTI_manuscript_v3.md")
OUT = os.path.join(MS, "DTI_manuscript_v4.md")

src = open(SRC, encoding="utf-8").read()
log = []


def rep1(old, new, tag):
    global src
    n = src.count(old)
    if n != 1:
        raise SystemExit("[FAIL] %s : 命中 %d 次(应为 1)\n--- old ---\n%r" % (tag, n, old[:200]))
    src = src.replace(old, new, 1)
    log.append(tag)


def J(fn):
    return json.load(open(os.path.join(RES, fn), encoding="utf-8"))


# =====================================================================
# 数据装载
# =====================================================================
per_ckpt = J("drugban_eval_per_ckpt.json")
t1 = J("tier1_expanded.json")
ma = J("independence_and_ma_correction.json")["tier3_primary_endpoint"]["objects"]

DB43_T2 = per_ckpt["ep43"]["tier2"]
DB30_T2 = per_ckpt["ep30"]["tier2"]
# 一致性断言:新跑的 epoch 30 必须与 tier2_with_baseline.json 里被误标为 "DrugBAN_ep43" 的行一致
_old = J("tier2_with_baseline.json")["DrugBAN_ep43"]
assert abs(_old["mean_auc"] - DB30_T2["mean_auc"]) < 0.002, (_old["mean_auc"], DB30_T2["mean_auc"])
assert abs(_old["median_auc"] - DB30_T2["median_auc"]) < 0.002
print("✓ 确认 v3 表中 '(reference) DrugBAN' 行 = epoch 30 的数值(标签错误,已在 v4 更正)")

F43, F30 = 0.1646, 0.1885
assert abs(ma["morgan_cnn_bindingdb"]["median_rho"] - 0.132) < 0.001
MRR_CI = {k.replace("_bindingdb", ""): v["mrr_ci95"] for k, v in t1["per_model"].items()}


def f3(x):
    """固定 3 位小数(不剥尾随 0,保证同表内数值宽度一致)"""
    return "%.3f" % x


# =====================================================================
# 根因 1:参考文献改字面文本
# =====================================================================
m = re.search(r"\n## References\n\n(.*?)\n\n---\n", src, re.S)
assert m, "找不到 References 段"
block = m.group(1)
n_refs = len(re.findall(r"(?m)^\d+\. ", block))
assert n_refs == 14, "参考文献条数 = %d" % n_refs
new_block = re.sub(r"(?m)^(\d+)\. ", lambda mm: "[%s] " % mm.group(1), block)
src = src.replace(block, new_block, 1)
log.append("根因1 References 14 条改为字面 [n] 文本")

# =====================================================================
# 条目 5 / 8:§2.1 表加表号
# =====================================================================
rep1("### 2.1 Evaluation sets\n\n| Set | Targets | Records | Sampling | Filter strictness | Purpose |",
     "### 2.1 Evaluation sets\n\n**Table 1. Evaluation sets.**\n\n"
     "| Set | Targets | Records | Sampling | Filter strictness | Purpose |",
     "条目5/8 §2.1 表加表号 Table 1")

rep1("*Table note.* The three sets are stored under `results/` as `bench_eval_set_large.csv` (Main), "
     "`bench_eval_set_strict.csv` (Strict) and `bench_eval_set_strict_eq.csv` (Strict-equal).",
     "*Table note.* `Records` counts (target, ligand) pairs; the Strict row lists its true actives and "
     "its decoys separately. The three sets are stored under `results/` as `bench_eval_set_large.csv` (Main), "
     "`bench_eval_set_strict.csv` (Strict) and `bench_eval_set_strict_eq.csv` (Strict-equal).",
     "条目5 §2.1 表注补充 Records 定义")

# =====================================================================
# 条目 10:§2.2 checkpoint 表述统一
# =====================================================================
rep1("Two checkpoints from the same training run were evaluated, ",
     "Two checkpoints, ", "条目10 §2.2 删『same training run』")
rep1("In both training runs the best epoch by validation AUROC was epoch 43 (AUROC 0.9624), and epochs 44",
     "Training was run twice with the authors' code and SEED=42, and both runs were terminated early "
     "(at epochs 51 and 55). In **both** runs the best epoch by validation AUROC was epoch 43 "
     "(AUROC 0.9624), and the second run reproduced the first exactly (deterministic seed), so the two "
     "checkpoint files are interchangeable. Epochs 44",
     "条目10 §2.2 两次训练事实统一")

# =====================================================================
# 条目 7:§2.3 写明 Tier-1 未做的原因
# =====================================================================
rep1("**Tier 3** (within-target affinity ranking): Spearman ρ between measured and predicted values "
     "within each target — the primary endpoint.",
     "**Tier 3** (within-target affinity ranking): Spearman ρ between measured and predicted values "
     "within each target — the primary endpoint. Tier-1 retrieval requires a full score matrix "
     "(285 probe ligands × 57 targets = 16,245 scores per model). It was computed for the six "
     "DeepPurpose weights but **not** for the two DrugBAN checkpoints or for the single-descriptor "
     "baselines, whose scoring was performed within target only; the corresponding cells of Table 6 "
     "therefore read `not computed`.",
     "条目7 §2.3 Tier-1 未做原因")

# =====================================================================
# 条目 8:表号顺序重排(caption 文本唯一,逐条替换)
# =====================================================================
for old_no, new_no, title in (
        (1, 2, "Positive control and temporal validation"),
        (2, 3, "Per-target Spearman ρ across the 57-target benchmark"),
        (4, 5, "Three-way decomposition (same target class, different data source)"),
        (5, 6, "Tier-1 retrieval and trivial-baseline comparison across all eight evaluation objects"),
        (6, 7, "Filter strictness × sampling")):
    rep1("**Table %d. %s.**" % (old_no, title),
         "**Table %d. %s.**" % (new_no, title),
         "条目8 Table %d->%d" % (old_no, new_no))

# =====================================================================
# 条目 11:§3.1 Davis 分母 916 来源
# =====================================================================
rep1("(Two caveats: 5/68 ligand SMILES had no ChEMBL molecule for their InChIKey, so denominators "
     "are 63/916; and target mapping is gene-level because the panel contains mutant constructs such "
     "as ABL1(E255K).)",
     "(Two caveats: 5 of the 68 panel ligand SMILES had no ChEMBL molecule for their InChIKey, so the "
     "ligand denominator is 63; and target mapping is gene-level because the panel contains mutant "
     "constructs such as ABL1(E255K).) The denominator 916 is the number of panel pairs that could be "
     "mapped to a (UniProt, ChEMBL) key: the reproduced panel is 40 kinase targets × up to 25 ligands "
     "= 1,000 (target, ligand) pairs, of which 916 survive the ligand→ChEMBL mapping step (40/40 targets "
     "mapped, 63/68 ligands mapped).",
     "条目11 §3.1 Davis 916 来源")

# 悬空的 Figure 1a 引用(正文 §3.1 未嵌任何图)
rep1("three of the six models reached median ρ 0.637–0.688 (Figure 1a)",
     "three of the six models reached median ρ 0.637–0.688 (Table 2)",
     "条目15 修正悬空引用 (Figure 1a)")

# =====================================================================
# 条目 6:Tier-2 表(Table 4)
# =====================================================================
rep1("**Table 3. Tier-2 within-target AUC versus a trivial baseline.**\n\n"
     "| Model | Tier-2 AUC (mean/median) | 95% CI | sign p |\n|---|---|---|---|",
     "**Table 4. Tier-2 within-target discrimination: six DeepPurpose weights, a trivial baseline "
     "and two DrugBAN checkpoints.**\n\n"
     "| Model | mean AUC | median AUC | 95% CI (mean) | sign p |\n|---|---|---|---|---|",
     "条目6 Table 4 表头/表号")

for short, mean, med, ci, sp in (
        ("morgan_aac", "0.575", "0.611", "[0.537, 0.609]", "0.0032"),
        ("cnn_cnn", "0.574", "0.576", "[0.538, 0.609]", "0.016"),
        ("morgan_cnn", "0.564", "0.569", "[0.531, 0.596]", "4.6e-4"),
        ("transformer_cnn", "0.550", "0.562", "[0.517, 0.583]", "0.29"),
        ("daylight_aac", "0.547", "0.562", "[0.509, 0.586]", "0.016"),
        ("mpnn_cnn", "0.508", "0.507", "[0.482, 0.533]", "0.79")):
    rep1("| %s | %s / %s | %s | %s |" % (short, mean, med, ci, sp),
         "| %s | %s | %s | %s | %s |" % (short, mean, med, ci, sp),
         "条目6 Table 4 行 %s" % short)

rep1("| **(trivial) MW** | **0.581 / 0.590** | **[0.540, 0.621]** | **0.0032** |",
     "| **(trivial) molecular weight** | **0.581** | **0.590** | **[0.540, 0.621]** | **0.0032** |",
     "条目6 Table 4 行 MW")

rep1("| *(reference) DrugBAN* | *0.608* | *[0.579, 0.636]* | *5.7e-10* |",
     "| *(reference)* DrugBAN, epoch 30 | %s | %s | [%s, %s] | 5.7e-10 |\n"
     "| *(reference)* DrugBAN, epoch 43 | %s | %s | [%s, %s] | 7.5e-7 |" % (
         f3(DB30_T2["mean_auc"]), f3(DB30_T2["median_auc"]),
         f3(DB30_T2["ci95_mean"][0]), f3(DB30_T2["ci95_mean"][1]),
         f3(DB43_T2["mean_auc"]), f3(DB43_T2["median_auc"]),
         f3(DB43_T2["ci95_mean"][0]), f3(DB43_T2["ci95_mean"][1])),
     "条目6 Table 4 行 DrugBAN 两检查点")

# §3.2 正文句
rep1("the **molecular-weight baseline alone reached 0.581 (median 0.590), exceeding five of the six "
     "models**; DrugBAN reached 0.608 with overlapping confidence intervals (Table 3). "
     "Tier-2 \"ability\" is thus not model-specific either.",
     "the **molecular-weight baseline alone reached 0.581 (median 0.590), exceeding five of the six "
     "models**; DrugBAN reached 0.608 (epoch 30) and 0.591 (epoch 43), with confidence intervals "
     "overlapping the baseline's (Table 4). Tier-2 \"ability\" is thus not model-specific either.",
     "条目6 §3.2 正文句修正(DrugBAN 两检查点 + 表号)")

# Table 4 表注
rep1("\n\n### 3.3 Sampling stability",
     "\n\n*Table note.* **Median-split definition.** Within each target the measured pChEMBL values are "
     "sorted and split at the target's median; the upper half is labelled strong (1), the lower half weak "
     "(0), and the AUC of the model's predicted score is computed per target (pairs exactly at the median, "
     "and targets with fewer than eight or ten pairs, are excluded; a score of 0.5 is chance). Intervals "
     "are bootstrap 95% CIs over targets (4,000 replicates); `sign p` is a two-sided binomial test of the "
     "proportion of targets with AUC > 0.5. DrugBAN is a binary classifier rather than a regression model, "
     "so its score is the sigmoid probability of binding; the two checkpoints are from the two training "
     "runs described in §2.2. Data: `results/tier2_with_baseline.json` (six DeepPurpose weights and the "
     "molecular-weight baseline) and `results/drugban_eval_per_ckpt.json` (DrugBAN).\n\n"
     "### 3.3 Sampling stability",
     "条目6 Table 4 表注(median-split 定义)")

# =====================================================================
# 条目 9 + 7:Tier-1 表(Table 6)与 MRR 文字
# =====================================================================
rep1("MRR was below the analytic expectation H(57)/57 = 0.0812 for one of the six models "
     "(`mpnn_cnn`, 0.074); for the remaining five the observed MRR is indistinguishable from that "
     "expectation (Figure 5, Table 5).",
     "MRR ranged from 0.074 to 0.104 against the analytic expectation H(57)/57 = 0.0812. The point "
     "estimate lies below the expectation only for `mpnn_cnn` (0.074, 95% CI [0.061, 0.089]), and five "
     "of the six models' 95% CIs contain the expectation; the single exception is `morgan_cnn` "
     "(0.104, 95% CI [0.083, 0.129]), whose interval lies just above it. **No permutation test was "
     "performed for MRR**, so this comparison is descriptive rather than a formal test "
     "(Figure 5, Table 6).",
     "条目9 §3.5 MRR 补 CI + 说明未做检验")

rep1("| Evaluation object | median ρ | Top-1 | Top-5 | MRR | heavy-atom count ρ | molecular weight ρ | "
     "beats strict criterion? |",
     "| Evaluation object | median ρ | Top-1 | Top-5 | MRR (95% CI) | heavy-atom ρ | MW ρ | "
     "beats strict criterion? |",
     "条目7/9 Table 6 表头(MRR 加 CI)")

for short in ("cnn_cnn", "morgan_aac", "morgan_cnn", "daylight_aac", "transformer_cnn", "mpnn_cnn"):
    o = t1["per_model"][short + "_bindingdb"]
    lo, hi = o["mrr_ci95"]
    rep1("| `%s` | %s | %s | %s | %s |" % (short, {"cnn_cnn": "0.194", "morgan_aac": "0.167",
                                                  "morgan_cnn": "0.132", "daylight_aac": "0.123",
                                                  "transformer_cnn": "0.089", "mpnn_cnn": "0.012"}[short],
                                          {"cnn_cnn": "0.70%", "morgan_aac": "2.81%", "morgan_cnn": "3.86%",
                                           "daylight_aac": "2.46%", "transformer_cnn": "1.75%",
                                           "mpnn_cnn": "1.05%"}[short],
                                          {"cnn_cnn": "11.23%", "morgan_aac": "10.53%", "morgan_cnn": "11.23%",
                                           "daylight_aac": "9.47%", "transformer_cnn": "8.77%",
                                           "mpnn_cnn": "8.07%"}[short],
                                          {"cnn_cnn": "0.085", "morgan_aac": "0.090", "morgan_cnn": "0.104",
                                           "daylight_aac": "0.094", "transformer_cnn": "0.084",
                                           "mpnn_cnn": "0.074"}[short]),
         "| `%s` | %s | %s | %s | %s [%s, %s] |" % (short,
                                                    {"cnn_cnn": "0.194", "morgan_aac": "0.167",
                                                     "morgan_cnn": "0.132", "daylight_aac": "0.123",
                                                     "transformer_cnn": "0.089", "mpnn_cnn": "0.012"}[short],
                                                    {"cnn_cnn": "0.70%", "morgan_aac": "2.81%",
                                                     "morgan_cnn": "3.86%", "daylight_aac": "2.46%",
                                                     "transformer_cnn": "1.75%", "mpnn_cnn": "1.05%"}[short],
                                                    {"cnn_cnn": "11.23%", "morgan_aac": "10.53%",
                                                     "morgan_cnn": "11.23%", "daylight_aac": "9.47%",
                                                     "transformer_cnn": "8.77%", "mpnn_cnn": "8.07%"}[short],
                                                    {"cnn_cnn": "0.085", "morgan_aac": "0.090",
                                                     "morgan_cnn": "0.104", "daylight_aac": "0.094",
                                                     "transformer_cnn": "0.084", "mpnn_cnn": "0.074"}[short],
                                                    f3(lo), f3(hi)),
         "条目9 Table 6 行 %s 加 MRR CI" % short)

rep1("| DrugBAN epoch 43 | 0.165 |", "| DrugBAN (epoch 43) | 0.165 |", "条目7 Table 6 DrugBAN43")
rep1("| DrugBAN epoch 30 | 0.189 |", "| DrugBAN (epoch 30) | 0.189 |", "条目7 Table 6 DrugBAN30")
rep1("| *(reference)* random ranking | — | 1.75% | 8.77% | 0.0812 | — | — | — |",
     "| *(reference)* random ranking | — | 1.75% | 8.77% | 0.0812 (analytic) | — | — | — |",
     "条目9 Table 6 随机基线行注明 analytic")

rep1("*Table note.* Top-1, Top-5 and MRR are computed over the 285-probe retrieval set "
     "(five probes per target; `results/tier1_expanded.json`); the random-ranking row gives the "
     "analytic expectations (1/57, 5/57, H(57)/57). **not computed** marks conditions that were not run: "
     "the two DrugBAN checkpoints were evaluated for within-target ranking and Tier-2 discrimination only, "
     "and the single-descriptor baselines were evaluated only as within-target rankings — no retrieval "
     "(Top-k/MRR) experiment was performed for them, so no Top-k or MRR value can be reported for those "
     "objects or for the baselines themselves.",
     "*Table note.* Top-1, Top-5 and MRR are computed over the 285-probe retrieval set (five probes per "
     "target; `results/tier1_expanded.json`); MRR intervals are bootstrap 95% CIs over probes "
     "(5,000 replicates), and the random-ranking row gives the analytic expectations (1/57, 5/57, "
     "H(57)/57), which carry no sampling interval. **not computed** marks conditions that were not run: "
     "Tier-1 retrieval requires a full 285 × 57 score matrix per model (§2.3), whereas the two DrugBAN "
     "checkpoints were evaluated for within-target ranking and Tier-2 discrimination only, and the "
     "single-descriptor baselines were evaluated only as within-target rankings — so no Top-k or MRR "
     "value can be reported for those objects or for the baselines themselves.",
     "条目7 Table 6 表注")

# =====================================================================
# 条目 14:弱化 "usable"
# =====================================================================
rep1("Small benchmark sub-samples therefore cannot be used to claim usable performance.",
     "Small benchmark sub-samples therefore cannot support a claim of performance above the "
     "reference line (§4.6).", "条目14 §3.3 usable -> reference line")

rep1("what is robust is that no condition approaches a usable level.",
     "what is robust is that **no condition approaches the conservative reference line (ρ = 0.4)** "
     "used in §4.6.",
     "条目14 §3.7 usable -> reference line")

rep1("The corrected value is therefore the true discrimination level, and it remains far below usable",
     "The corrected value is therefore the true discrimination level, and it remains far below both the "
     "model's own in-domain performance (AUROC 0.962) and the reference line",
     "条目14 §3.8 usable -> reference line")

# =====================================================================
# 条目 12:Limitations 改项目符号
# =====================================================================
m = re.search(r"\n## 5\. Limitations\n\n(.*?)\n\n---\n", src, re.S)
assert m, "找不到 Limitations 段"
lim = m.group(1)
n_items = len(re.findall(r"(?m)^\d+\. ", lim))
assert n_items == 11, "Limitations 条目数 = %d" % n_items
new_lim = re.sub(r"(?m)^(\d+)\. ", "- ", lim)
src = src.replace(lim, new_lim, 1)
log.append("条目12 Limitations 11 条改项目符号")

# Conclusions 编号保持 1–6(渲染器输出字面数字,见 147)
m = re.search(r"\n## 6\. Conclusions\n\n(.*?)\n\n---\n", src, re.S)
assert m, "找不到 Conclusions 段"
assert len(re.findall(r"(?m)^\d+\. ", m.group(1))) == 6, "Conclusions 条目数 != 6"
log.append("条目12 Conclusions 保持 1–6(字面编号)")

# =====================================================================
# 条目 15:Figure index 表格 -> 图注列表(描述 = 图内标题)
# =====================================================================
FIGS = [
    (1, "fig_report_F1_bindingdb_overlap", "Overlap with the BindingDB ChEMBL source corpus"),
    (2, "fig_report_F7_main_rho", "Main result: per-target Spearman ρ for six open-box DTI models "
                                  "(median + 95% CI)"),
    (3, "fig_sampling_stability", "Sampling stability: apparent performance depends on how many "
                                  "targets you happen to pick"),
    (4, "fig_kinase_vs_nonkinase", "Kinase vs non-kinase: no consistent advantage"),
    (5, "fig_report_F4_mrr", "Tier-1 retrieval MRR (285 probes): one of six models below the analytic "
                             "random baseline"),
    (6, "fig_report_F6_drugban_gap", "DrugBAN (2022): in-domain AUROC 0.962 versus ρ 0.165–0.188 on "
                                     "this benchmark"),
    (7, "fig_report_F3_three_way", "Filter strictness × sampling: three-way comparison (no condition "
                                   "approaches the conservative reference line)"),
    (8, "fig_report_F5_decoy_auc", "Decoy discrimination AUC (true ligands vs property-matched decoys) "
                                   "— far below the model's own in-domain performance"),
    (9, "fig_report_F2_ligand_baseline", "Trivial physicochemical baselines versus the six DTI models "
                                         "(median per-target ρ, 95% CI)"),
    (10, "fig_bench_models", "Affinity-ranking performance of the six public DTI models "
                             "(20-target pilot benchmark)"),
    (11, "fig_bench_per_target", "Per-target ρ spread: wide and sign-inconsistent"),
    (12, "fig_bench_tiers", "Three metric families on the 57-target benchmark (cross-target "
                            "discrimination AUC, within-target discrimination AUC, within-target "
                            "ranking ρ): no model clears any of them"),
    (13, "fig_bench_flip", "The conclusion flips when the evaluation set grows (3 targets × 14 ligands "
                           "versus 20 targets × 25 ligands)"),
]
missing = [f for _, f, _ in FIGS if not os.path.isfile(os.path.join(BASE, "figures", f + ".png"))]
assert not missing, "图文件缺失: %s" % missing

m = re.search(r"### Figure index \(13 figures; each is provided as PNG and PDF in `figures/`\)\n\n"
              r"\| Figure \| File \| Content \|\n\|---\|---\|---\|\n(?:\|.*\|\n)+\n"
              r"Every file is provided in both PNG \(raster\) and PDF \(vector\) form under `figures/`\. "
              r"The main text also contains six tables \(Tables 1–6\); Supplementary Notes S1–S5 follow below\.",
              src)
assert m, "找不到 Figure index 表"
fig_list = "\n".join("**Fig %d** — `%s` — %s" % (n, f, t) for n, f, t in FIGS)
new_fig = ("### Figure index\n\n"
           "All 13 figures are provided in both PNG (raster) and PDF (vector) form under `figures/`, "
           "under the file names given below.\n\n"
           + "\n\n".join("**Fig %d** — `%s` — %s" % (n, f, t) for n, f, t in FIGS) +
           "\n\nThe main text also contains ten tables (Tables 1–10); Supplementary Notes S1–S5 follow below.")
src = src.replace(m.group(0), new_fig, 1)
log.append("条目15 Figure index 改图注列表 + 文件名核对(13/13 存在)")

# =====================================================================
# 条目 15:植入图注(原标题为文件名,渲染后即文件名 -> 改为真实图题)
# =====================================================================
for n, f, t in FIGS:
    old = "![%s](../figures/%s.png)" % (f, f)
    if old not in src:
        # 文件名与 alt 文本可能不一致(旧稿遗留),分别处理
        mm = re.search(r"!\[[^\]]*\]\(\.\./figures/%s\.png\)" % re.escape(f), src)
        assert mm, "找不到图引用 %s" % f
        old = mm.group(0)
    rep1(old, "![Figure %d. %s](../figures/%s.png)" % (n, t, f), "条目15 图注 Fig %d" % n)

# =====================================================================
# 条目 13:§3.11 summary 说明图实际画的是什么
# =====================================================================
rep1("### 3.11 Summary\n\n![Figure 12.",
     "### 3.11 Summary\n\n"
     "Figure 12 summarises, on the 57-target benchmark, three different metric families side by side — "
     "cross-target discrimination AUC, within-target discrimination AUC (Tier 2) and within-target "
     "ranking ρ (Tier 3); Tier-1 retrieval (Top-k/MRR) is reported separately in §3.5 and Figure 5. "
     "Figure 13 shows the sampling dependence of the headline conclusion.\n\n![Figure 12.",
     "条目13 §3.11 说明图内容")

# =====================================================================
# 条目 8:§3.9 两张表 + §3.10 基线表 补表号与表注
# =====================================================================
rep1("and restricted to records deposited before training.\n\n| Level | In common / total | Fraction |",
     "and restricted to records deposited before training.\n\n"
     "**Table 8. Overlap of the 57-target benchmark with the BindingDB ChEMBL subset.**\n\n"
     "| Level | In common / total | Fraction |",
     "条目8 Table 8 表号")
rep1("| pairs deposited before 2019 | 1,087 / 1,425 | 76.3% |",
     "| pairs deposited before 2019 | 1,087 / 1,425 | 76.3% |\n\n"
     "*Table note.* Data: `results/bindingdb_overlap_refined.json`, "
     "`results/bindingdb_target_overlap.json`, `results/bindingdb_ligand_overlap.json`.",
     "条目8 Table 8 表注")

rep1("with canonical-SMILES cross-check):\n\n| Partition | Overlap with the 57-target benchmark |",
     "with canonical-SMILES cross-check):\n\n"
     "**Table 9. DrugBAN partition overlap with the 57-target benchmark.**\n\n"
     "| Partition | Overlap with the 57-target benchmark |",
     "条目8 Table 9 表号")
rep1("| **union** | **51 / 1,425 = 3.58%** |",
     "| **union** | **51 / 1,425 = 3.58%** |\n\n"
     "*Table note.* Data: `results/drugban_overlap.json`.",
     "条目8 Table 9 表注")

rep1("with no target information at all reproduces the models' performance:\n\n"
     "| Baseline | median per-target ρ | 95% CI |",
     "with no target information at all reproduces the models' performance:\n\n"
     "**Table 10. Target-agnostic single-descriptor baselines versus the six models.**\n\n"
     "| Baseline | median per-target ρ | 95% CI |",
     "条目8 Table 10 表号")
rep1("| *(models, for reference)* | *0.012 – 0.194* | |",
     "| *(models, for reference)* | *0.012 – 0.194* | |\n\n"
     "*Table note.* **Descriptor definitions and units** (all computed with RDKit, no target "
     "information used): heavy-atom count, H-bond donors, H-bond acceptors, aromatic rings and "
     "rotatable bonds are counts of the respective substructures; molecular weight is in Da (g/mol); "
     "TPSA is the topological polar surface area in Å²; logP is the Crippen logP (unitless). "
     "Intervals are bootstrap 95% CIs over targets of the median per-target ρ. "
     "Data: `results/trivial_baseline_demo.json`.",
     "条目8 Table 10 表注(描述符单位)")

# =====================================================================
# 收尾断言
# =====================================================================
assert src.count("**Keywords:**") == 1, "关键词出现 %d 次" % src.count("**Keywords:**")
log.append("条目16 关键词仅标题页一次")

for key in ("[1] ", "[14] ", "**Table 1.", "**Table 10.", "**Table 6."):
    assert key in src, "缺少 %s" % key
assert "same training run" not in src
assert "usable performance" not in src
assert "approaches a usable level" not in src
assert "far below usable" not in src

open(OUT, "w", encoding="utf-8").write(src)
print("\n".join("  ✓ " + x for x in log))
print("\n落盘: %s (%d 字符)" % (OUT, len(src)))
