# -*- coding: utf-8 -*-
"""
v4 图修正(仅重出 2 张,数据不变,不改其它图):

1) fig_report_F3_three_way
   原图题 "(no condition approaches a usable level)" - 与 §4.6「ρ=0.4 并非文献确立阈值」矛盾,
   且图内未画参考线。改为:画上保守参考线 ρ = 0.4,图题写 "conservative reference line"。
   数据源不变:independence_and_ma_correction.json / strict_and_decoy_eval.json / strict_eq_eval.json

2) fig_bench_tiers
   原图例 "Tier 1: cross-target AUC" 与方法 §2.3 定义的 Tier 1(检索 Top-k/MRR)冲突;
   且原图用 20 靶点预试集(multimodel_benchmark_20t.json),正文 §3.11 是 57 靶点主分析的总结。
   改为:用 57 靶点主数据(multimodel_benchmark_57t.json),图例写清「画的是什么」,
   并把 Tier-1 检索明确排除(由 Fig 5 承担)。
"""
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"

import plotly.graph_objects as go

C_BLUE, C_RED, C_GREY, C_GREEN, C_ORANGE = "#2c6fbb", "#c0392b", "#7f8c8d", "#27ae60", "#e67e22"
TPL = dict(template="plotly_white", font=dict(size=13, family="Times New Roman, serif"))


def J(fn):
    return json.load(open(os.path.join(RES, fn), encoding="utf-8"))


def save(fig, name, w=900, h=520):
    for ext in ("png", "pdf"):
        fig.write_image(os.path.join(FIG, "%s.%s" % (name, ext)), width=w, height=h, scale=2)
    print("  [ok] %s (.png + .pdf)" % name, flush=True)


# =====================================================================
# F3 — Filter strictness x sampling(同数据,换措辞 + 补参考线)
# =====================================================================
se = J("strict_eq_eval.json")
sd = J("strict_and_decoy_eval.json")
ma = J("independence_and_ma_correction.json")["tier3_primary_endpoint"]["objects"]
order = ["morgan_aac_bindingdb", "cnn_cnn_bindingdb", "daylight_aac_bindingdb",
         "morgan_cnn_bindingdb", "transformer_cnn_bindingdb", "mpnn_cnn_bindingdb"]
xl = [k.replace("_bindingdb", "") for k in order]
A = [ma[k]["median_rho"] for k in order]
B = [sd[k]["median_rho"] for k in order]
C = [se[k]["median_rho"] for k in order]
fig = go.Figure()
fig.add_trace(go.Bar(name="A: loose filter, equal spacing (main set)", x=xl, y=A, marker_color=C_GREY))
fig.add_trace(go.Bar(name="B: strict filter, random sampling", x=xl, y=B, marker_color=C_BLUE))
fig.add_trace(go.Bar(name="C: strict filter, equal spacing", x=xl, y=C, marker_color=C_RED))
fig.add_hline(y=0.4, line_dash="dash", line_color=C_GREEN,
              annotation_text="conservative reference line (\u03c1 = 0.4; not a literature-established threshold)",
              annotation_position="top left")
fig.update_layout(title="Filter strictness \u00d7 sampling: three-way comparison "
                        "(no condition approaches the conservative reference line)",
                  yaxis_title="Per-target \u03c1 (median)", yaxis_range=[-0.06, 0.46],
                  barmode="group", **TPL)
fig.update_xaxes(tickangle=-20)
save(fig, "fig_report_F3_three_way")

# =====================================================================
# fig_bench_tiers — 57 靶点主数据 + 图例与 §2.3 定义对齐
# =====================================================================
j57 = J("multimodel_benchmark_57t.json")
ORDER = [r["model"] for r in j57]
SHORT = [m.replace("_bindingdb", "") for m in ORDER]
cross = [r["tier1_cross_auc_mean"] for r in j57]
within = [r["tier2_within_auc_mean"] for r in j57]
rank = [r["tier3_spearman_mean"] for r in j57]

fig4 = go.Figure()
fig4.add_trace(go.Bar(name="Cross-target discrimination AUC (all pairs, targets pooled)",
                      x=SHORT, y=cross, marker_color=C_BLUE,
                      text=["%.3f" % v for v in cross], textposition="outside"))
fig4.add_trace(go.Bar(name="Tier 2: within-target discrimination AUC (median split)",
                      x=SHORT, y=within, marker_color=C_ORANGE,
                      text=["%.3f" % v for v in within], textposition="outside"))
fig4.add_trace(go.Bar(name="Tier 3: within-target ranking \u03c1 (mean)",
                      x=SHORT, y=rank, marker_color=C_RED,
                      text=["%.3f" % v for v in rank], textposition="outside"))
fig4.add_hline(y=0.5, line=dict(color=C_GREY, width=1.2, dash="dot"),
               annotation_text="chance (AUC = 0.5; \u03c1 has no comparable line here)",
               annotation_position="bottom left")
fig4.update_layout(template="plotly_white", width=1100, height=560, barmode="group",
                   title=dict(text="<b>Three metric families on the 57-target benchmark: "
                                   "no model clears any of them</b><br>"
                                   "<sup>Tier-1 retrieval (Top-k / MRR) is defined in \u00a72.3 and "
                                   "reported separately in Figure 5</sup>",
                              font=dict(size=16, family="Times New Roman, serif")),
                   yaxis_title="Score (AUC or \u03c1)", yaxis_range=[0, 0.72],
                   xaxis_tickangle=-18,
                   font=dict(size=13, family="Times New Roman, serif"),
                   margin=dict(l=80, r=40, t=110, b=130), legend=dict(x=0.02, y=0.98))
fig4.update_xaxes(tickfont=dict(size=11))
save(fig4, "fig_bench_tiers", 1100, 560)

print("\n完成:2 张图已重出(数据源均为 results/*.json,未编造)。")
