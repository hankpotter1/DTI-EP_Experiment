# -*- coding: utf-8 -*-
"""
v4 交付校验 —— 校验对象是 **PDF 抽取出来的文本**(用户看到的就是渲染结果)。

检查项:
  A) 逐表行数比对:markdown 源每张表的数据行,逐行用"整行去空白拼接串"在 PDF 文本中匹配
  B) 参考文献编号在 PDF 中必须 1..N 连续,正文引用编号不超过 N
  C) 标题重复:源文件每个标题在 PDF 中只能出现一次
  D) ρ / p 用法:统计所有 'p 0.xxx' 上下文,确认都是统计 p 值;确认 ρ 未丢失
  E) 占位符 / 内部草稿信息 / 旧版残留
输出:控制台报告 + results/v4_pdf_verification.txt
"""
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
from pypdf import PdfReader

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
MS = os.path.join(BASE, "manuscript")
MD = os.path.join(MS, "DTI_manuscript_v4.md")
PDF = os.path.join(MS, "DTI_manuscript_v4.pdf")
OUT = os.path.join(BASE, "results", "v4_pdf_verification.txt")

report = []
fails = []


def emit(s=""):
    print(s, flush=True)
    report.append(s)


def fail(tag, detail):
    fails.append("%s :: %s" % (tag, detail))


def norm(s):
    """去空白 + 统一破折号/引号,便于跨渲染器匹配"""
    s = s.replace("\u2212", "-").replace("\u2013", "-").replace("\u2014", "-")
    s = s.replace("\u2018", "'").replace("\u2019", "'")
    s = s.replace("\u201c", '"').replace("\u201d", '"')
    s = s.replace("\u00a0", " ")
    return re.sub(r"\s+", "", s)


src = open(MD, encoding="utf-8").read()
reader = PdfReader(PDF)
pages = [p.extract_text() or "" for p in reader.pages]
pdf_raw = "\n".join(pages)
pdf_n = norm(pdf_raw)

emit("=" * 78)
emit("DTI 稿件 v4 交付校验(基于 PDF 抽取文本)")
emit("=" * 78)
emit("PDF 页数: %d   抽取字符数: %d" % (len(pages), len(pdf_raw)))
emit()

# =============================================================== A) 表格行
emit("-" * 78)
emit("A) 逐表行数比对 (markdown 源 vs PDF 渲染文本)")
emit("-" * 78)
SEP = re.compile(r"^\|[\s:\-|]+\|$")
src_lines = src.split("\n")


def clean_cell(c):
    c = c.strip()
    c = re.sub(r"\*\*(.+?)\*\*", r"\1", c)
    c = re.sub(r"\*(.+?)\*", r"\1", c)
    c = c.replace("`", "")
    c = c.replace("(*", "").replace("*)", "")
    c = re.sub(r"^\*|\*$", "", c)
    return c.strip()


tables = []
i = 0
while i < len(src_lines):
    if src_lines[i].strip().startswith("|") and i + 1 < len(src_lines) and SEP.match(src_lines[i + 1].strip()):
        header = [clean_cell(c) for c in src_lines[i].strip().strip("|").split("|")]
        i += 2
        rows = []
        while i < len(src_lines) and src_lines[i].strip().startswith("|"):
            rows.append([clean_cell(c) for c in src_lines[i].strip().strip("|").split("|")])
            i += 1
        tables.append((header, rows))
        continue
    i += 1

emit("markdown 源表格数: %d" % len(tables))
total_rows = 0
matched_rows = 0
for k, (header, rows) in enumerate(tables, 1):
    m = 0
    missing = []
    for r in rows:
        sig = norm("".join(r))
        if sig and sig in pdf_n:
            m += 1
        else:
            missing.append(" | ".join(r)[:70])
    total_rows += len(rows)
    matched_rows += m
    emit("  Table %2d: 源 %2d 行 / PDF 命中 %2d 行  %s" % (
        k, len(rows), m, "OK" if m == len(rows) else "MISSING: %s" % missing[:3]))
    if m != len(rows):
        fail("A", "Table %d 有 %d 行未在 PDF 中匹配到" % (k, len(rows) - m))
emit("  合计: 源 %d 行 / PDF 命中 %d 行  -> %s" % (
    total_rows, matched_rows, "PASS" if matched_rows == total_rows else "FAIL"))
emit("  (PDF 为渲染产物,行完整性以整行拼接串匹配为准;源表格数 %d)" % len(tables))
emit()

# =============================================================== B) 参考文献
emit("-" * 78)
emit("B) 参考文献编号 (PDF 文本)")
emit("-" * 78)
m = re.search(r"References(.*?)Supplementary notes", pdf_raw, re.S)
if not m:
    fail("B", "PDF 中找不到 References 段落")
    refs_txt = ""
else:
    refs_txt = m.group(1)
ref_nums = [int(x) for x in re.findall(r"\[(\d{1,3})\]", refs_txt)]
emit("  References 段内 [n] 标记: %s" % (ref_nums[:20]))
if not ref_nums:
    fail("B", "References 段内没有 [n] 标记(编号可能仍由渲染器自动生成)")
else:
    uniq = sorted(set(ref_nums))
    emit("  去重排序后: %s   (共 %d 条)" % (uniq, len(uniq)))
    expect = list(range(1, len(uniq) + 1))
    if uniq == expect:
        emit("  -> 1..%d 连续 PASS" % len(uniq))
    else:
        emit("  -> 不连续 FAIL")
        fail("B", "参考文献编号非 1..N 连续: %s" % uniq)
    # 正文引用
    body = pdf_raw[:m.start()] if m else pdf_raw
    body_nums = set()
    for grp in re.findall(r"\[([\d,\s]+)\]", body):
        for x in grp.split(","):
            x = x.strip()
            if x.isdigit():
                body_nums.add(int(x))
    N = max(uniq) if uniq else 0
    over = sorted(n for n in body_nums if n > N)
    emit("  正文引用编号范围: %s (最大 %s)" % (
        "%d..%d" % (min(body_nums), max(body_nums)) if body_nums else "-", max(body_nums) if body_nums else "-"))
    emit("  超出 N=%d 的引用: %s" % (N, over if over else "无 -> PASS"))
    if over:
        fail("B", "正文引用编号超出参考文献总数: %s" % over)
    if len(uniq) != 14:
        fail("B", "参考文献条数 %d,预期 14" % len(uniq))
emit()

# =============================================================== C) 标题
emit("-" * 78)
emit("C) 标题重复检测 (PDF 文本)")
emit("-" * 78)
heads = re.findall(r"(?m)^(#{1,5})\s+(.*)$", src)
head_dups = []
for lvl, h in heads:
    hh = norm(re.sub(r"[*`]", "", h))
    cnt = pdf_n.count(hh)
    if cnt != 1:
        head_dups.append((h, cnt))
emit("  源标题数: %d" % len(heads))
if head_dups:
    for h, c in head_dups:
        emit("    !! '%s' 在 PDF 中出现 %d 次" % (h[:60], c))
        fail("C", "标题重复/缺失: %s x%d" % (h[:60], c))
else:
    emit("  每个标题在 PDF 中出现且仅出现一次 -> PASS")
# 顺序一致性
pos = [pdf_n.find(norm(re.sub(r"[*`]", "", h))) for _, h in heads]
emit("  标题位置单调递增: %s" % ("PASS" if pos == sorted(pos) else "FAIL %s" % pos))
if pos != sorted(pos):
    fail("C", "标题顺序与源文件不一致")
emit()

# =============================================================== D) rho / p
emit("-" * 78)
emit("D) ρ / p 用法")
emit("-" * 78)
emit("  PDF 中 'ρ' 出现次数: %d (源文件 %d)" % (pdf_n.count("\u03c1"), src.count("\u03c1")))
if pdf_n.count("\u03c1") < src.count("\u03c1") * 0.95:
    fail("D", "PDF 中 ρ 数量异常,可能被渲染器吞掉")
p_hits = []
for mm in re.finditer(r"p(\d\.\d+)", pdf_n):
    a = max(0, mm.start() - 45)
    ctx = pdf_raw.replace("\n", " ")
    ctx = re.sub(r"\s+", " ", ctx)
    p_hits.append(mm.group(0))
emit("  'p 0.xxx' 形式出现: %s" % (sorted(set(p_hits)) if p_hits else "无"))
for mm in re.finditer(r"\bp\s+0\.\d+", pdf_raw):
    a = max(0, mm.start() - 60)
    emit("     上下文: ...%s" % re.sub(r"\s+", " ", pdf_raw[a:mm.end() + 25]))
must = {
    "摘要 DrugBAN ρ 0.165-0.188": r"only\s*\u03c1\s*0\.165",
    "§3.0 stricter filtering does not raise ρ": r"does not raise\s*\u03c1",
    "Limitations Per-target ρ values": r"Per-target\s*\u03c1\s*values",
    "结论 median ρ 0.012-0.194": r"median\s*\u03c1\s*0\.012",
    "§4.6 ρ threshold": r"\u03c1 threshold",
    "§3.10 自然采样 0.179": r"sampling \(0\.179\)|still reaches 0\.179",
}
for label, pat in must.items():
    okk = re.search(pat, pdf_raw) is not None
    emit("  [%s] %s" % ("OK" if okk else "FAIL", label))
    if not okk:
        fail("D", "PDF 中未找到: %s" % label)
emit()

# =============================================================== E) 残留
emit("-" * 78)
emit("E) 占位符 / 内部草稿信息 / 旧版残留")
emit("-" * 78)
BAD = {
    "[key] 占位": r"\[[a-z_]{3,}\]",
    "草稿": r"\u8349\u7a3f",
    "引用以...占位": r"\u5f15\u7528\u4ee5",
    "配套": r"\u914d\u5957",
    "TODO/DRAFT": r"(?i)\b(todo|draft)\b",
    "usable level": r"usable level",
    "far below usable": r"far below usable",
    "same training run": r"same training run",
    "Table 1a/Figure 1a 悬空": r"Figure\s*1a",
}
for label, pat in BAD.items():
    hits = re.findall(pat, pdf_raw)
    emit("  %-28s %s" % (label, "无 PASS" if not hits else "命中 %d 次 FAIL %s" % (len(hits), hits[:3])))
    if hits:
        fail("E", "%s: %s" % (label, hits[:3]))
# 图表编号连续性
tbl_nums = sorted(int(x) for x in re.findall(r"Table (\d+)\.", pdf_raw))
emit("  PDF 中 Table 编号: %s" % tbl_nums)
if tbl_nums != list(range(1, 11)):
    fail("E", "Table 编号不是 1..10: %s" % tbl_nums)
fig_nums = sorted(set(int(x) for x in re.findall(r"Figure (\d+)\.", pdf_raw)))
emit("  PDF 中 Figure 编号: %s" % fig_nums)
if fig_nums != list(range(1, 14)):
    fail("E", "Figure 编号不是 1..13: %s" % fig_nums)
emit("  Keywords 次数: %d" % pdf_raw.count("Keywords"))
if pdf_raw.count("Keywords") != 1:
    fail("E", "关键词出现 %d 次(应为 1)" % pdf_raw.count("Keywords"))
emit()

# =============================================================== 汇总
emit("=" * 78)
if fails:
    emit("总判定: FAIL (%d 项)" % len(fails))
    for f in fails:
        emit("   - " + f)
else:
    emit("总判定: ALL PASS")
emit("关键数字: 表格行 %d/%d 命中;参考文献 1..%s;重复标题 %d 个" % (
    matched_rows, total_rows, (max(uniq) if ref_nums else 0), len(head_dups)))
emit("=" * 78)

open(OUT, "w", encoding="utf-8").write("\n".join(report) + "\n")
print("\n报告落盘:", OUT)
sys.exit(1 if fails else 0)
