# -*- coding: utf-8 -*-
"""docx XML 层证明:无任何自动编号(numPr)、表格固定列宽/禁跨页断行/表头重复。"""
import re
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8")
P = r"G:\HHH\openclaw-workspace\netpharm-toolkit\manuscript\DTI_manuscript_v4.docx"
z = zipfile.ZipFile(P)
xml = z.read("word/document.xml").decode("utf-8")
sty = z.read("word/styles.xml").decode("utf-8")

print("=" * 70)
print("DOCX XML 层证明")
print("=" * 70)
print("1) 自动编号(渲染器续编号的根因)")
print("   <w:numPr> 出现次数 : %d" % xml.count("numPr"))
print("   numbering.xml 存在  : %s" % ("word/numbering.xml" in z.namelist()))
print("   引用 numId 的次数   : %d" % len(re.findall(r'w:numId w:val="\d+"', xml)))
print("   -> 参考文献/结论段完全为字面文本,渲染器无法续编号")

print()
print("2) 表格排版")
print("   表格数(tbl)          : %d" % xml.count("<w:tbl>"))
print("   tblLayout type=fixed : %d" % len(re.findall(r'<w:tblLayout w:type="fixed"', xml)))
print("   tblGrid gridCol      : %d" % len(re.findall(r"<w:gridCol ", xml)))
print("   w:cantSplit          : %d (应 = 总行数,逐行禁止跨页断开)" % xml.count("<w:cantSplit"))
print("   w:tblHeader          : %d (应 = 表格数,表头跨页重复)" % xml.count("<w:tblHeader"))
print("   w:noWrap             : %d (应为 0,即允许自动换行)" % xml.count("w:noWrap"))
rows = len(re.findall(r"<w:tr[ >]", xml))
print("   表格总行数           : %d" % rows)
print("   cantSplit/行数       : %s" % ("全覆盖 OK" if xml.count("<w:cantSplit") == rows else "不完全 FAIL"))

print()
print("3) 图片")
print("   内嵌图片数           : %d" % len([n for n in z.namelist() if n.startswith("word/media/")]))

print()
print("4) 标题样板")
print("   Heading 样式段落     : %d" % len(re.findall(r'w:val="Heading[1-5]"', xml)))
print("   Normal 段落          : %d" % len(re.findall(r'w:val="Normal"', xml)))
