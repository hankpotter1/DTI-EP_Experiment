# -*- coding: utf-8 -*-
"""抽样打印 PDF 渲染文本片段,人工确认表格/编号/希腊字母的实际渲染效果。"""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
from pypdf import PdfReader

P = r"G:\HHH\openclaw-workspace\netpharm-toolkit\manuscript\DTI_manuscript_v4.pdf"
pages = [p.extract_text() or "" for p in PdfReader(P).pages]
txt = "\n".join(pages)


def show(label, pat, before=0, after=700, n=1):
    print("=" * 78)
    print(label)
    print("-" * 78)
    for i, m in enumerate(re.finditer(pat, txt)):
        if i >= n:
            break
        print(re.sub(r"[ \t]+", " ", txt[max(0, m.start() - before):m.end() + after]))
        print("...")
    if not re.search(pat, txt):
        print("(NOT FOUND)")


show("① Table 4(Tier-2,含 DrugBAN 两检查点)", r"Table 4\. Tier-2", after=900)
show("② Table 6(Tier-1 / MRR CI / not computed)", r"Table 6\. Tier-1", after=1500)
show("③ References 头两条(应为字面 [1] [2])", r"References", after=420)
show("④ Conclusions(应为字面 1.–6.)", r"6\. Conclusions", after=1200)
show("⑤ §3.9 Model-specific check(不应有前置 '1')", r"Model-specific check", before=120, after=200)
show("⑥ §4.4 逐条(3./4. 不应挤在一行)", r"4\.4 Practical recommendations", after=700)
show("⑦ Limitations 项目符号", r"5\. Limitations", after=600)
