# -*- coding: utf-8 -*-
"""
v5 figure fixes (data sources unchanged — only labels/title/reference lines):

1) fig_bench_tiers  (Figure 12)
   - legend line 1 renamed so it cannot be mistaken for the metric defined as
     "Tier 1" in §2.3 (Tier 1 = cross-target *retrieval*, Top-k / MRR, Figure 5)
   - title reworded to name both bars the models fail to clear
   Data: results/multimodel_benchmark_57t.json (unchanged)

2) fig_bench_flip  (Figure 13)
   - caption-only change is handled in the .md; the figure is redrawn only to make the
     two sampling configurations legible inside the plot (3x14 vs 20x25).
   Data: results/multimodel_benchmark.json, results/multimodel_benchmark_20t.json
"""
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"

import plotly.graph_objects as go

C_BLUE, C_RED, C_GREY, C_GREEN, C_ORANGE = "#2c6fbb", "#c0392b", "#7f8c8d", "#27ae60", "#e67e22"
SERIF = "Times New Roman, serif"


def J(fn):
    return json.load(open(os.path.join(RES, fn), encoding="utf-8"))


def save(fig, name, w, h):
    for ext in ("png", "pdf"):
        fig.write_image(os.path.join(FIG, "%s.%s" % (name, ext)), width=w, height=h, scale=2)
    print("  [ok] %s (.png + .pdf)" % name, flush=True)


# ======================================================= Figure 12 — tiers
j57 = J("multimodel_benchmark_57t.json")
ORDER = [r["model"] for r in j57]
SHORT = [m.replace("_bindingdb", "") for m in ORDER]
cross = [r["tier1_cross_auc_mean"] for r in j57]
within = [r["tier2_within_auc_mean"] for r in j57]
rank = [r["tier3_spearman_mean"] for r in j57]

fig = go.Figure()
fig.add_trace(go.Bar(
    name="Cross-target discrimination AUC (all pairs, targets pooled) \u2014 "
         "separate from Tier-1 retrieval, which is Top-k / MRR in Figure 5",
    x=SHORT, y=cross, marker_color=C_BLUE,
    text=["%.3f" % v for v in cross], textposition="outside"))
fig.add_trace(go.Bar(
    name="Tier 2: within-target discrimination AUC (median split)",
    x=SHORT, y=within, marker_color=C_ORANGE,
    text=["%.3f" % v for v in within], textposition="outside"))
fig.add_trace(go.Bar(
    name="Tier 3: within-target ranking \u03c1 (mean)",
    x=SHORT, y=rank, marker_color=C_RED,
    text=["%.3f" % v for v in rank], textposition="outside"))
fig.add_hline(y=0.4, line_dash="dash", line_color=C_GREEN,
              annotation_text="conservative reference line (\u03c1 = 0.4; not a literature-established threshold)",
              annotation_position="top left")
fig.add_hline(y=0.5, line=dict(color=C_GREY, width=1.2, dash="dot"),
              annotation_text="chance (AUC = 0.5; \u03c1 has no comparable line here)",
              annotation_position="bottom left")
fig.update_layout(
    template="plotly_white", width=1150, height=600, barmode="group",
    title=dict(text="<b>Three metric families on the 57-target benchmark: no model reaches the "
                    "conservative reference line (\u03c1 = 0.4), and the best model does not exceed "
                    "the trivial single-descriptor baseline beyond sampling error</b><br>"
                    "<sup>Metric definitions follow \u00a72.3; Tier-1 retrieval (Top-k / MRR) is "
                    "reported separately in Figure 5</sup>",
               font=dict(size=15, family=SERIF)),
    yaxis_title="Score (AUC or \u03c1)", yaxis_range=[0, 0.72],
    xaxis_tickangle=-18, font=dict(size=13, family=SERIF),
    margin=dict(l=80, r=40, t=125, b=150),
    legend=dict(x=0.01, y=0.99, font=dict(size=11)))
fig.update_xaxes(tickfont=dict(size=11))
save(fig, "fig_bench_tiers", 1150, 600)

# ======================================================= Figure 13 — flip
j3 = J("multimodel_benchmark.json")
j20 = J("multimodel_benchmark_20t.json")
b3 = {r["model"]: r for r in j3}
b20 = {r["model"]: r for r in j20}
ORD = [r["model"] for r in j20]
r3 = [b3[m]["tier3_spearman_mean"] for m in ORD]
r20 = [b20[m]["tier3_spearman_mean"] for m in ORD]

fig2 = go.Figure()
fig2.add_trace(go.Bar(name="3 targets \u00d7 14 ligands (42 pairs, original pilot)",
                      x=[m.replace("_bindingdb", "") for m in ORD], y=r3, marker_color=C_GREY))
fig2.add_trace(go.Bar(name="20 targets \u00d7 25 ligands (500 pairs, pilot benchmark)",
                      x=[m.replace("_bindingdb", "") for m in ORD], y=r20, marker_color=C_RED))
fig2.add_hline(y=0, line=dict(color="#2C3E50", width=1))
fig2.add_hline(y=0.4, line=dict(color=C_GREEN, width=1.4, dash="dash"),
               annotation_text="conservative reference line (\u03c1 = 0.4; not a literature-established threshold)",
               annotation_position="top left")
fig2.update_layout(
    template="plotly_white", width=1100, height=580, barmode="group",
    title=dict(text="<b>The conclusion flips when the evaluation set grows</b><br>"
                    "<sup>Fixed two-point contrast of the two pilot configurations; not the "
                    "57-target benchmark of Tables 3\u201310</sup>",
               font=dict(size=16, family=SERIF)),
    yaxis_title="Mean Spearman \u03c1 (predicted vs measured affinity)",
    yaxis_range=[-0.08, 0.68], xaxis_tickangle=-18,
    font=dict(family=SERIF, size=12), margin=dict(l=80, r=40, t=95, b=150),
    legend=dict(x=0.02, y=0.98, font=dict(size=11)))
fig2.update_xaxes(tickfont=dict(size=10))
save(fig2, "fig_bench_flip", 1100, 580)

print("\ndone: 2 figures redrawn from results/*.json (no data invented).")
