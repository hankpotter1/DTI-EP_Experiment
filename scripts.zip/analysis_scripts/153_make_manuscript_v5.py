# -*- coding: utf-8 -*-
"""
DTI_manuscript_v4.md  ->  DTI_manuscript_v5.md

Every edit below is an anchored replacement that must match *exactly once*; the script
aborts otherwise, so no edit can silently no-op.  No numeric value is invented: all
bootstrap replicate counts were read from the analysis scripts / results JSON that
produced the corresponding table (see the report).
"""
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
SRC = os.path.join(BASE, "manuscript", "DTI_manuscript_v4.md")
OUT = os.path.join(BASE, "manuscript", "DTI_manuscript_v5.md")

src = open(SRC, encoding="utf-8").read()
EDITS = []


def rep(old, new, tag):
    global src
    n = src.count(old)
    if n != 1:
        raise SystemExit("ABORT [%s]: pattern found %d times (expected 1):\n%s" % (tag, n, old[:160]))
    src = src.replace(old, new, 1)
    EDITS.append(tag)


# ---------------------------------------------------------------- 2.2 checkpoints
rep(
    "**DrugBAN checkpoints.** Two checkpoints, `best_model_epoch_43.pth` and "
    "`best_model_epoch_30.pth`. Training was run twice with the authors' code and SEED=42, "
    "and both runs were terminated early (at epochs 51 and 55). In **both** runs the best "
    "epoch by validation AUROC was epoch 43 (AUROC 0.9624), and the second run reproduced "
    "the first exactly (deterministic seed), so the two checkpoint files are interchangeable. "
    "Epochs 44\u201354 did not improve on it; the pair of checkpoints is therefore fixed by the "
    "validation curve and not pre-specified against this benchmark. Epoch 30 is an earlier "
    "point on the same validation curve and serves as a sensitivity check on checkpoint "
    "choice. Both checkpoints were applied unchanged to the 57-target benchmark, and their "
    "results are reported side by side (\u00a73.6, Table 5).",

    "**DrugBAN checkpoints.** Two checkpoints were evaluated: `best_model_epoch_43.pth` "
    "(the validation-best checkpoint) and `best_model_epoch_30.pth` (an earlier checkpoint "
    "from the same run). Training was run twice with SEED=42; both runs produced identical "
    "validation curves (deterministic seed), so the epoch-43 checkpoints from the two runs "
    "are interchangeable. Epoch 30 is reported as a sensitivity check on checkpoint choice. "
    "Both checkpoints were applied unchanged to the 57-target benchmark, and their results "
    "are reported side by side (\u00a73.2, \u00a73.6; Tables 4 and 6).",
    "2.2 checkpoint paragraph rewritten")

# ---------------------------------------------------------------- 2.4 bootstrap counts
rep(
    "Bootstrap 95% confidence intervals were obtained by resampling **targets** "
    "(5,000 replicates for the primary analysis; 10,000 for the dependence-corrected "
    "re-analysis, with 2,000 for the ligand-clustered and iid pair-level variants).",

    "Bootstrap 95% confidence intervals were obtained by resampling **targets**, with the "
    "number of replicates fixed separately for each analysis family and repeated in the "
    "corresponding table note: per-target ranking \u03c1 for the six DeepPurpose weights "
    "(Table 3), **10,000** target-cluster replicates, plus **2,000** for the ligand-clustered "
    "and iid pair-level variants of the dependence check; within-target discrimination AUC "
    "(Table 4), **4,000**; Tier-1 Top-1/Top-5/MRR (Table 6), **3,000**; the single-descriptor "
    "baselines and the model-versus-baseline comparison (Table 10), **4,000**; and the two "
    "DrugBAN checkpoints (Tables 4 and 6), **5,000**. No interval in this paper uses any "
    "other replicate count.",
    "2.4 bootstrap replicate counts made explicit and per-family")

# ---------------------------------------------------------------- 3.1 Davis denominator
rep(
    "The denominator 916 is the number of panel pairs that could be mapped to a "
    "(UniProt, ChEMBL) key: the reproduced panel is 40 kinase targets \u00d7 up to 25 ligands = "
    "1,000 (target, ligand) pairs, of which 916 survive the ligand\u2192ChEMBL mapping step "
    "(40/40 targets mapped, 63/68 ligands mapped).",

    "The denominator 916 is the number of panel pairs that could be mapped to a "
    "(UniProt, ChEMBL) key: the reproduced panel is 40 kinase targets \u00d7 up to 25 ligands = "
    "1,000 (target, ligand) pairs, of which 916 survive the ligand\u2192ChEMBL mapping step "
    "(40/40 targets mapped, 63/68 ligands mapped). The plausible-looking product "
    "40 \u00d7 63 = 2,520 is **not** this denominator: it would assume every one of the 63 "
    "mapped ligands had been tested against every one of the 40 targets, whereas the Davis "
    "panel is a single 40 \u00d7 25 measurement matrix, so only pairs that actually carry a "
    "measurement can enter the intersection. 916 is thus the number of *measured and "
    "mappable* (target, ligand) pairs in the panel, and 1,000 (40 \u00d7 25) is its design "
    "ceiling.",
    "3.1 Davis denominator 916 vs 40x63 reconciled")

# ---------------------------------------------------------------- 3.3 sampling reconciliation
rep(
    "Small benchmark sub-samples therefore cannot support a claim of performance above the "
    "reference line (\u00a74.6).",

    "Small benchmark sub-samples therefore cannot support a claim of performance above the "
    "reference line (\u00a74.6). Figure 3 sweeps the full resampling grid used here (targets "
    "3\u201357 \u00d7 ligands 5\u201325) and plots its 25-ligand slice; Figure 13 is a *different*, "
    "fixed two-point contrast of the two earlier pilot configurations (3 targets \u00d7 14 ligands "
    "and 20 targets \u00d7 25 ligands) and is therefore not a slice of Figure 3. The two figures "
    "share the resampling machinery but not their axis settings.",
    "3.3 sampling settings reconciled with Figure 13")

# ---------------------------------------------------------------- 3.4 duplicate sentence
rep(
    "Within kinases, however, values collapse from 0.64\u20130.69 (Davis) to 0.10\u20130.25 (this "
    "benchmark), a gap of \u22480.5 that is attributable to dataset, ligand source and "
    "measurement conditions rather than to target class. The gap is attributable to dataset, "
    "ligand source and measurement conditions rather than to target class; its interpretation "
    "is discussed in \u00a73.9 and \u00a74.1.",

    "Within kinases, however, values collapse from 0.64\u20130.69 (Davis) to 0.10\u20130.25 (this "
    "benchmark) \u2014 a gap of \u22480.5 that is attributable to dataset, ligand source and "
    "measurement conditions rather than to target class; its interpretation is discussed in "
    "\u00a73.9 and \u00a74.1.",
    "3.4 duplicated clause removed")

# ---------------------------------------------------------------- Figure 10 caption
rep(
    "![Figure 10. Affinity-ranking performance of the six public DTI models "
    "(20-target pilot benchmark)](../figures/fig_bench_models.png)",
    "![Figure 10. Affinity-ranking performance of the six public DTI models on the "
    "20-target pilot benchmark \u2014 a pilot benchmark, not the main 57-target benchmark used "
    "for Tables 3\u201310](../figures/fig_bench_models.png)",
    "Figure 10 caption flags it as a pilot benchmark")

# ---------------------------------------------------------------- Figure 12 caption
rep(
    "![Figure 12. Three metric families on the 57-target benchmark (cross-target "
    "discrimination AUC, within-target discrimination AUC, within-target ranking "
    "\u03c1): no model clears any of them](../figures/fig_bench_tiers.png)",
    "![Figure 12. Three metric families on the 57-target benchmark: no model reaches the "
    "conservative reference line (\u03c1 = 0.4), and the best model does not exceed the trivial "
    "single-descriptor baseline beyond sampling error](../figures/fig_bench_tiers.png)",
    "Figure 12 caption aligned with the redrawn figure")

# ---------------------------------------------------------------- Figure 13 caption
rep(
    "![Figure 13. The conclusion flips when the evaluation set grows "
    "(3 targets \u00d7 14 ligands versus 20 targets \u00d7 25 ligands)]"
    "(../figures/fig_bench_flip.png)",
    "![Figure 13. The conclusion flips when the evaluation set grows \u2014 fixed two-point "
    "contrast of the two pilot configurations (3 targets \u00d7 14 ligands versus 20 targets "
    "\u00d7 25 ligands; not the 57-target benchmark of Tables 3\u201310)]"
    "(../figures/fig_bench_flip.png)",
    "Figure 13 caption states its sampling settings")

# ---------------------------------------------------------------- Table 3 note
rep(
    "Under Bonferroni, three of six models retain significance; `cnn_cnn` (0.060) and "
    "`transformer_cnn` (0.265) do not.",
    "Under Bonferroni, three of six models retain significance; `cnn_cnn` (0.060) and "
    "`transformer_cnn` (0.265) do not. Intervals are bootstrap 95% CIs over targets "
    "(**10,000** target-cluster replicates; the ligand-clustered and iid pair-level variants "
    "of the dependence check use **2,000** separate resamplings \u2014 see \u00a72.4); `positive` is "
    "the fraction of targets with \u03c1 > 0; `sign p` is a two-sided sign test against "
    "\u03c1 = 0; `Wilcoxon p` is the signed-rank test on the same per-target \u03c1 values.",
    "Table 3 note carries its replicate count")

# ---------------------------------------------------------------- Table 6 note
rep(
    "MRR intervals are bootstrap 95% CIs over probes (5,000 replicates)",
    "MRR intervals are bootstrap 95% CIs over probes (3,000 replicates; see \u00a72.4)",
    "Table 6 note corrected 5,000 -> 3,000 (matches 125_tier1_expanded.py)")

# ---------------------------------------------------------------- Table 10 note
rep(
    "Intervals are bootstrap 95% CIs over targets of the median per-target \u03c1. "
    "Data: `results/trivial_baseline_demo.json`.",
    "Intervals are bootstrap 95% CIs over targets of the median per-target \u03c1 "
    "(**4,000** replicates; see \u00a72.4). Data: `results/trivial_baseline_demo.json`.",
    "Table 10 note carries its replicate count")

# ---------------------------------------------------------------- Figure index sync
rep("**Fig 10** \u2014 `fig_bench_models` \u2014 Affinity-ranking performance of the six public "
    "DTI models (20-target pilot benchmark)",
    "**Fig 10** \u2014 `fig_bench_models` \u2014 Affinity-ranking performance of the six public "
    "DTI models on the 20-target pilot benchmark \u2014 a pilot benchmark, not the main "
    "57-target benchmark used for Tables 3\u201310",
    "figure index Fig 10 synced")

rep("**Fig 12** \u2014 `fig_bench_tiers` \u2014 Three metric families on the 57-target benchmark "
    "(cross-target discrimination AUC, within-target discrimination AUC, within-target "
    "ranking \u03c1): no model clears any of them",
    "**Fig 12** \u2014 `fig_bench_tiers` \u2014 Three metric families on the 57-target benchmark: "
    "no model reaches the conservative reference line (\u03c1 = 0.4), and the best model does "
    "not exceed the trivial single-descriptor baseline beyond sampling error",
    "figure index Fig 12 synced")

rep("**Fig 13** \u2014 `fig_bench_flip` \u2014 The conclusion flips when the evaluation set grows "
    "(3 targets \u00d7 14 ligands versus 20 targets \u00d7 25 ligands)",
    "**Fig 13** \u2014 `fig_bench_flip` \u2014 The conclusion flips when the evaluation set grows "
    "\u2014 fixed two-point contrast of the two pilot configurations (3 targets \u00d7 14 ligands "
    "versus 20 targets \u00d7 25 ligands; not the 57-target benchmark of Tables 3\u201310)",
    "figure index Fig 13 synced")

# ---------------------------------------------------------------- global hygiene scan
before = src
src = src.replace("withindomain", "within-domain")
if src != before:
    EDITS.append("global: 'withindomain' -> 'within-domain'")

open(OUT, "w", encoding="utf-8").write(src)

# ---------------------------------------------------------------- report
print("=" * 78)
print("v5 written: %s  (%d chars, %d lines)" % (OUT, len(src), src.count("\n") + 1))
print("=" * 78)
for i, t in enumerate(EDITS, 1):
    print("  %2d. %s" % (i, t))

print()
print("--- residual checks on the v5 source ---")
for bad in ("withindomain", "1ttributable", "1e failure", "1indistinguishable",
            "For of six", "gk1999", "bzb157", "ConPlex", "1e failure"):
    print("  corrupt form %-20s occurrences = %d" % (bad, src.count(bad)))

# rho / p usage: every ' p ' that precedes a numeral must be a statistical p value
rhos = src.count("\u03c1")
print("  rho (\u03c1) count = %d (v4 had %d)" % (rhos, open(SRC, encoding="utf-8").read().count("\u03c1")))
suspect = []
for m in re.finditer(r"[^a-zA-Z]p[ =]\s*0?\.?\d", src):
    line = src[:m.start()].count("\n") + 1
    ctx = src[max(0, m.start() - 60):m.end() + 40].replace("\n", " ")
    suspect.append((line, re.sub(r"\s+", " ", ctx)))
print("  'p 0.xxx' / 'p = 0.xxx' contexts (each must be a real p value):")
for ln, c in suspect:
    print("     line %-4d ...%s..." % (ln, c))
