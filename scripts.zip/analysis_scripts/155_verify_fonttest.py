# -*- coding: utf-8 -*-
"""
Step 1 — MINIMUM FONT VERIFICATION for the Edge-headless PDF pipeline.

Checks, on the produced PDF itself:
  a) every font resource is embedded (FontFile / FontFile2 / FontFile3 present)
  b) Type0 fonts carry a /ToUnicode CMap; simple fonts carry /Encoding
  c) text layer of the sheet equals the expected strings (character-exact)
  d) the *drawn* glyph for the ambiguous characters is the right one
     (template match vs a known-same-font reference within the same PDF)
  e) OCR of the rendered page reads the strings that were reported corrupted
"""
import io
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
import pymupdf
from pypdf import PdfReader
from PIL import Image

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
PDF = os.path.join(BASE, "manuscript", "_fonttest_v5.pdf")
OUTD = os.path.join(BASE, "results", "_fonttest")
os.makedirs(OUTD, exist_ok=True)

fails = []
print("=" * 78)
print("STEP 1 — MINIMUM FONT VERIFICATION")
print("=" * 78)
print("file: %s  (%d bytes)" % (PDF, os.path.getsize(PDF)))

doc = pymupdf.open(PDF)
print("pages: %d" % doc.page_count)

# ---------------------------------------------------------------- a) embedding
print()
print("--- a) font embedding ---")
all_ok = True
xref_done = set()
for i, page in enumerate(doc):
    for f in page.get_fonts(full=True):
        xref, ext, ftype, basefont, name, enc = f[0], f[1], f[2], f[3], f[4], f[5]
        if xref in xref_done:
            continue
        xref_done.add(xref)
        # look for an embedded font program
        embedded = False
        desc = doc.xref_get_key(xref, "FontDescriptor")
        if doc.xref_get_key(xref, "Subtype")[1] == "/Type0":
            df = doc.xref_get_key(xref, "DescendantFonts")
            if df[1].startswith("["):
                d0 = int(re.findall(r"\d+", df[1])[0])
                desc = doc.xref_get_key(d0, "FontDescriptor")
                tout = doc.xref_get_key(xref, "ToUnicode")[1]
            else:
                d0 = None
        xr = re.findall(r"\d+", desc[1])[0] if desc[1].startswith("<<") is False and desc[1] else None
        if xr is None and desc[1]:
            m = re.search(r"(\d+) 0 R", desc[1])
            xr = m.group(1) if m else None
        if xr:
            for k in ("FontFile", "FontFile2", "FontFile3"):
                if doc.xref_get_key(int(xr), k)[1] not in ("null", ""):
                    embedded = True
        print("  xref %-4s %-9s %-32s enc=%-22s embedded=%s" % (
            xref, ftype, basefont, enc, embedded))
        if not embedded:
            all_ok = False
            fails.append("font not embedded: %s" % basefont)
print("  embedding: %s" % ("ALL EMBEDDED" if all_ok else "SOME NOT EMBEDDED"))
if not all_ok:
    fails.append("not all fonts embedded")

# ---------------------------------------------------------------- b) ToUnicode
print()
print("--- b) ToUnicode presence ---")
missing_tu = []
for i, page in enumerate(doc):
    for f in page.get_fonts(full=True):
        xref, ftype, basefont = f[0], f[2], f[3]
        if ftype == "/Type0":
            tu = doc.xref_get_key(xref, "ToUnicode")[1]
            if tu in ("null", ""):
                missing_tu.append(basefont)
print("  Type0 fonts without ToUnicode: %s" % (missing_tu if missing_tu else "none"))
if missing_tu:
    fails.append("Type0 without ToUnicode: %s" % missing_tu)

# ---------------------------------------------------------------- c) text layer
print()
print("--- c) text layer contents ---")
pym = "\n".join(p.get_text() for p in doc)
pyp = "\n".join((p.extract_text() or "") for p in PdfReader(PDF).pages)
print("  pymupdf chars=%d   pypdf chars=%d" % (len(pym), len(pyp)))

EXPECT = ["1 l I 0 O i j t f r n m", "\u03c1 \u03b1 \u03b2", "attributable",
          "Four of six models", "[13] Sieg J, Flack K, et al.", "ConPLex",
          "gkl999", "bbz157", "indistinguishable", "the failure", "within-domain",
          "10.1093/nar/gkl999", "10.1093/bib/bbz157", "\u03c1 0.194", "p = 0.0075",
          "\u22120.063", "1.5e-4", "\u03c1 = 0.4"]
for s in EXPECT:
    a = s in pym
    b = s in pyp
    tag = "OK " if (a and b) else "FAIL"
    if not (a and b):
        fails.append("text layer missing %r (pymupdf=%s pypdf=%s)" % (s, a, b))
    print("  [%s] %-34s pymupdf=%s pypdf=%s" % (tag, s, a, b))

BAD = ["1ttributable", "1e failure", "1indistinguishable", "For of six",
       "gk1999", "bbz157", "bzb157", "ConPlex", "withindomain"]
for s in BAD:
    hit = (s in pym) or (s in pyp)
    if hit and s not in ("bbz157",):
        fails.append("corrupt form present: %r" % s)
    print("  [%s] corrupt form %-20s present=%s" % ("FAIL" if hit and s != "bbz157" else "OK ", s, hit))

# ---------------------------------------------------------------- d) glyph test
print()
print("--- d) glyph identity (drawn glyph vs expected character) ---")


def chars_of(page):
    out = []
    d = page.get_text("rawdict")
    for b in d["blocks"]:
        for l in b.get("lines", []):
            for s in l.get("spans", []):
                for c in s.get("chars", []):
                    out.append({"c": c["c"], "bbox": c["bbox"], "font": s["font"],
                                "size": round(s["size"], 2)})
    return out


def render_char(page, info, dpi=900):
    r = pymupdf.Rect(info["bbox"])
    clip = pymupdf.Rect(r.x0 - 0.6, r.y0 - 0.6, r.x1 + 0.6, r.y1 + 0.6)
    pix = page.get_pixmap(clip=clip, dpi=dpi)
    return Image.open(io.BytesIO(pix.tobytes("png"))).convert("L")


def norm(img, size=(64, 64)):
    px = img.load()
    w, h = img.size
    xs, ys = [], []
    for y in range(h):
        for x in range(w):
            if px[x, y] < 160:
                xs.append(x)
                ys.append(y)
    if not xs:
        return None
    return img.crop((min(xs), min(ys), max(xs) + 1, max(ys) + 1)).resize(size, Image.LANCZOS)


def corr(a, b):
    n = a.size[0] * a.size[1]
    pa, pb = a.load(), b.load()
    va = [(255 - pa[x, y]) / 255.0 for y in range(a.size[1]) for x in range(a.size[0])]
    vb = [(255 - pb[x, y]) / 255.0 for y in range(b.size[1]) for x in range(b.size[0])]
    ma, mb = sum(va) / n, sum(vb) / n
    num = sum((va[i] - ma) * (vb[i] - mb) for i in range(n))
    da = sum((v - ma) ** 2 for v in va) ** 0.5
    db = sum((v - mb) ** 2 for v in vb) ** 0.5
    return num / (da * db) if da and db else 0.0


page0 = doc[0]
cs = chars_of(page0)

# d1) the 24 pt ambiguous line, rendered large, is OCR'd in the shell step
big = [c for c in cs if c["size"] > 20]
line = "".join(c["c"] for c in big)
print("  d1) 24pt line in text layer: %r" % line)
r0 = pymupdf.Rect(big[0]["bbox"])
r1 = pymupdf.Rect(big[-1]["bbox"])
strip = pymupdf.Rect(r0.x0 - 4, r0.y0 - 5, r1.x1 + 4, r1.y1 + 5)
doc[0].get_pixmap(clip=strip, dpi=600).save(os.path.join(OUTD, "ambiguous_line.png"))
print("      saved %s (OCR this in the shell step)" % os.path.join(OUTD, "ambiguous_line.png"))

# d2) same-font/same-size reference match for the reported 'gk[l->1]999'
#     the cropped DOI is 12 pt Times; find a known 'l' and a known '1' at the same size
small = [c for c in cs if 11.5 < c["size"] < 12.5 and "Times" in c["font"]]
stxt = "".join(c["c"] for c in small)

def find_ref(ch, window_has):
    for i, c in enumerate(small):
        if c["c"] != ch:
            continue
        ctx = stxt[max(0, i - 12):i + 12]
        if window_has in ctx:
            return c
    return None

ref_l = find_ref("l", "attributable") or find_ref("l", "indistinguishable")
ref_1 = find_ref("1", "1.5e-4") or find_ref("1", "0.194") or find_ref("1", "[13]")
print("  d2) reference glyphs at 12pt: 'l'=%s  '1'=%s" % (
    ref_l and "found", ref_1 and "found"))

i_d = stxt.find("gkl999")
if i_d >= 0 and ref_l and ref_1:
    q = small[i_d + 2]                      # text layer says 'l'
    nq = norm(render_char(page0, q))
    c_l = corr(nq, norm(render_char(page0, ref_l)))
    c_1 = corr(nq, norm(render_char(page0, ref_1)))
    verdict = "MATCHES 'l'" if c_l > c_1 else "MATCHES '1'  <-- CORRUPT"
    print("      DOI 'gkl999' char#2 (text layer %r): corr vs known 'l' = %.3f, "
          "vs known '1' = %.3f  -> %s" % (q["c"], c_l, c_1, verdict))
    if c_l <= c_1:
        fails.append("drawn glyph for DOI char#2 is '1', not 'l'")
else:
    fails.append("could not locate DOI/reference glyphs for the template match")


print()
print("=" * 78)
print("RESULT: %s" % ("PASS" if not fails else "FAIL (%d)" % len(fails)))
for f in fails:
    print("   - " + f)
print("=" * 78)
sys.exit(1 if fails else 0)
