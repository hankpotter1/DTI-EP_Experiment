# -*- coding: utf-8 -*-
"""
DTI_manuscript_v5.md  ->  DTI_manuscript_v6.md

v6 = v5 + the small-revision carry-over items.  Every edit below is an ANCHORED
replacement that must match exactly once (or an exact expected count); the script
aborts otherwise, so no edit can silently no-op.  No numeric value is invented:
the only numeric correction (DrugBAN epoch-30 median rho) is read from
results/drugban_eval_per_ckpt.json and its rendering follows the rounding convention
already used throughout the manuscript (Python "%.3f" of the recorded value).

Items whose reported defect is NOT reproducible in this source are deliberately NOT
touched (see results/v6_revision_report.md): a "p -> rho" regression, a duplicated
"5. Limitations" heading, "all \\(1\\geq 15 / \\geq 20\\)", "Mann-Whitney rho = 0.569",
"11) Davis", "fig bench titers", "Filter strictness sampling", "Fundings".
"""
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
MS = os.path.join(BASE, "manuscript")
SRC = os.path.join(MS, "DTI_manuscript_v5.md")
OUT = os.path.join(MS, "DTI_manuscript_v6.md")
RHO, SS, DASH, MINUS = "\u03c1", "\u00a7", "\u2013", "\u2212"

src = open(SRC, encoding="utf-8").read()
EDITS = []


def rep(old, new, tag, expect=1):
    global src
    n = src.count(old)
    if n != expect:
        raise SystemExit("ABORT [%s]: found %d (expected %d):\n%s" % (tag, n, expect, old[:200]))
    src = src.replace(old, new)
    EDITS.append("%s  (%d occurrence%s)" % (tag, n, "" if n == 1 else "s"))


# ------------------------------------------------------------------ B1  Table 4 note
# 2.2 says epoch 43 = validation-best (reproduced across two runs), epoch 30 = earlier
# point of the SAME run.  The old Table-4 note ("from the two training runs") contradicted it.
rep(
    "the two checkpoints are from the two training runs described in " + SS + "2.2.",
    "the epoch-43 checkpoint is from the validation-best epoch (reproduced across two runs "
    "with SEED=42), and the epoch-30 checkpoint is an earlier point from the same run, "
    "included as a sensitivity check.",
    "B1 Table 4 note: checkpoint provenance aligned with " + SS + "2.2",
)

# ------------------------------------------------------------------ B3  DrugBAN epoch-30 rho
# results/drugban_eval_per_ckpt.json: ep43 median_rho = 0.1646, ep30 median_rho = 0.1885.
# The manuscript renders these with "%.3f" (as it does for every other value:
# 0.1905->0.191 in Table 10, 0.2385->0.238 in Table 3, 0.1646->0.165 here), which gives
# 0.189 for 0.1885.  The bare "0.188" in the prose and in Figure 6's title was the outlier.
ck = json.load(open(os.path.join(BASE, "results", "drugban_eval_per_ckpt.json"),
                    encoding="utf-8"))
r43 = ck["ep43"]["tier3"]["median_rho"]
r30 = ck["ep30"]["tier3"]["median_rho"]
assert abs(r43 - 0.1646) < 1e-9 and abs(r30 - 0.1885) < 1e-9, (r43, r30)
f43, f30 = "%.3f" % r43, "%.3f" % r30
assert f43 == "0.165" and f30 == "0.189", (f43, f30)

rep("0.165" + DASH + "0.188", "0.165" + DASH + f30,
    "B3a DrugBAN rho range 0.165-0.188 -> 0.165-0.189 (prose + captions + figure index)", 5)
rep("0.165 (epoch 43) / 0.188 (epoch 30)", "0.165 (epoch 43) / %s (epoch 30)" % f30,
    "B3b " + SS + "3.6 per-checkpoint median rho", 1)
rep(
    "the baseline intervals are heavy-atom count [0.104, 0.260] and molecular weight "
    "[0.091, 0.275]. All eight evaluation objects fail it.",
    "the baseline intervals are heavy-atom count [0.104, 0.260] and molecular weight "
    "[0.091, 0.275]. All eight evaluation objects fail it. Median "
    + RHO + " values are given to three decimals from the recorded values "
    "(`results/drugban_eval_per_ckpt.json`: epoch 43 %s, epoch 30 %s)." % (r43, r30),
    "B3c Table 6 note: rounding convention + recorded values made explicit",
)

# ------------------------------------------------------------------ B2  Figure 12 is MEAN rho
rep(
    "within-target ranking " + RHO + " (Tier 3); Tier-1 retrieval (Top-k/MRR) is reported "
    "separately in " + SS + "3.5 and Figure 5.",
    "within-target ranking " + RHO + " (Tier 3); Tier-1 retrieval (Top-k/MRR) is reported "
    "separately in " + SS + "3.5 and Figure 5. Figure 12 shows **mean** " + RHO + " for the "
    "three metric families; Table 3 reports **median** " + RHO + " as the primary endpoint.",
    "B2a " + SS + "3.11 states that Figure 12 plots mean rho while Table 3 is median rho",
)
rep(
    "the best model does not exceed the trivial single-descriptor baseline beyond sampling "
    "error](../figures/fig_bench_tiers.png)",
    "the best model does not exceed the trivial single-descriptor baseline beyond sampling "
    "error; Tier 3 is **mean** " + RHO + ", whereas Table 3 reports **median** " + RHO
    + " as the primary endpoint](../figures/fig_bench_tiers.png)",
    "B2b Figure 12 caption states mean rho",
)
rep(
    "**Fig 12** \u2014 `fig_bench_tiers` \u2014 Three metric families on the 57-target "
    "benchmark: no model reaches the conservative reference line (" + RHO + " = 0.4), and "
    "the best model does not exceed the trivial single-descriptor baseline beyond sampling "
    "error",
    "**Fig 12** \u2014 `fig_bench_tiers` \u2014 Three metric families on the 57-target "
    "benchmark: no model reaches the conservative reference line (" + RHO + " = 0.4), and "
    "the best model does not exceed the trivial single-descriptor baseline beyond sampling "
    "error; Tier 3 is **mean** " + RHO + ", whereas Table 3 reports **median** " + RHO
    + " as the primary endpoint",
    "B2c figure index Fig 12 synced",
)

# ------------------------------------------------------------------ B4  wrong table number
rep("dropped to 0.21" + DASH + "0.29 (Table 1).", "dropped to 0.21" + DASH + "0.29 (Table 2).",
    "B4 " + SS + "3.1 Table 1 -> Table 2 (temporal validation is Table 2)")

# ------------------------------------------------------------------ C10 H-bond descriptor names
rep("H-bond donors/acceptors", "H-bond donor count / H-bond acceptor count",
    "C10 descriptor names expanded", 2)

# ------------------------------------------------------------------ D13 Figures 10/11 are the pilot
rep(
    "Per-target " + RHO + " is highly dispersed (morgan_cnn ranges from +0.52 to "
    + MINUS + "0.43; Figure 2).",
    "Per-target " + RHO + " is highly dispersed (morgan_cnn ranges from +0.52 to "
    + MINUS + "0.43; Figure 2). Figure 2 shows the main 57-target result; Figures 10 and 11 "
    "show the 20-target pilot benchmark for comparison.",
    "D13a " + SS + "3.2 distinguishes the main benchmark from the pilot figures",
)
rep(
    "![Figure 11. Per-target " + RHO + " spread: wide and sign-inconsistent]"
    "(../figures/fig_bench_per_target.png)",
    "![Figure 11. Per-target " + RHO + " spread: wide and sign-inconsistent (pilot "
    "benchmark, not the main 57-target benchmark)](../figures/fig_bench_per_target.png)",
    "D13b Figure 11 caption flags the pilot benchmark",
)
rep(
    "**Fig 11** \u2014 `fig_bench_per_target` \u2014 Per-target " + RHO + " spread: wide "
    "and sign-inconsistent",
    "**Fig 11** \u2014 `fig_bench_per_target` \u2014 Per-target " + RHO + " spread: wide "
    "and sign-inconsistent (pilot benchmark, not the main 57-target benchmark)",
    "D13c figure index Fig 11 synced",
)

# ------------------------------------------------------------------ D14 Table 6 title
rep(
    "**Table 6. Tier-1 retrieval and trivial-baseline comparison across all eight "
    "evaluation objects.**",
    "**Table 6. Tier-1 retrieval and trivial-baseline comparison across all eight "
    "evaluation objects, with reference baselines.**",
    "D14 Table 6 title names the reference-baseline rows",
)

open(OUT, "w", encoding="utf-8").write(src)

print("=" * 78)
print("v6 written: %s  (%d chars, %d lines)" % (OUT, len(src), src.count("\n") + 1))
print("=" * 78)
for i, t in enumerate(EDITS, 1):
    print("  %2d. %s" % (i, t))

print()
print("--- residual checks on the v6 source ---")
for bad in ("0.165" + DASH + "0.188", "0.165 (epoch 43) / 0.188 (epoch 30)",
            "the two checkpoints are from the two training runs",
            "H-bond donors/acceptors", "(Table 1) "):
    print("   stale form %-52s occurrences = %d" % (repr(bad)[:50], src.count(bad)))
print("   rho count = %d (v5 had %d)" % (src.count(RHO),
                                         open(SRC, encoding="utf-8").read().count(RHO)))
print("   'Table 6.' title  : %s" % [l for l in src.split("\n")
                                      if l.startswith("**Table 6.")][0][:110])
