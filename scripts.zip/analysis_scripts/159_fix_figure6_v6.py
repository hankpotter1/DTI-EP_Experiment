# -*- coding: utf-8 -*-
"""
Figure 6 (fig_report_F6_drugban_gap) — label-only correction.

The bar labels are data-driven ("%.3f" of the recorded medians: 0.1646 -> 0.165 and
0.1885 -> 0.189), so the drawn bars already read 0.165 / 0.189.  Only the hardcoded
title still said "0.165-0.188".  This script redraws Figure 6 with the title aligned to
the same values.  Nothing else changes: same data files, same trace order, same colours,
same canvas (900 x 520, scale 2) as the F6 block of scripts/142_make_report_figures_en.py.

Originals are backed up to figures/_backup_v5/ before being overwritten.
"""
import json
import os
import shutil
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"
BAK = os.path.join(FIG, "_backup_v5")
NAME = "fig_report_F6_drugban_gap"

import plotly.graph_objects as go

C_BLUE, C_RED, C_GREY, C_GREEN, C_ORANGE = "#2c6fbb", "#c0392b", "#7f8c8d", "#27ae60", "#e67e22"
TPL = dict(template="plotly_white", font=dict(size=13, family="Times New Roman, serif"))


def J(fn):
    return json.load(open(os.path.join(RES, fn), encoding="utf-8"))


def save(fig, name, w=900, h=520):
    for ext in ("png", "pdf"):
        fig.write_image(os.path.join(FIG, "%s.%s" % (name, ext)), width=w, height=h, scale=2)
    print("  [ok] %s (.png + .pdf)" % name, flush=True)


os.makedirs(BAK, exist_ok=True)
for ext in ("png", "pdf"):
    s = os.path.join(FIG, "%s.%s" % (NAME, ext))
    if os.path.exists(s) and not os.path.exists(os.path.join(BAK, os.path.basename(s))):
        shutil.copy2(s, BAK)
print("backup of the v5 figure -> %s" % BAK)

e43 = J("drugban_eval_ep43.json")
e30 = J("drugban_eval_ep30.json")
lo = "%.3f" % min(e43["tier3_median_rho"], e30["tier3_median_rho"])
hi = "%.3f" % max(e43["tier3_median_rho"], e30["tier3_median_rho"])
print("recorded medians: epoch 43 = %r -> %s ; epoch 30 = %r -> %s"
      % (e43["tier3_median_rho"], "%.3f" % e43["tier3_median_rho"],
         e30["tier3_median_rho"], "%.3f" % e30["tier3_median_rho"]))

fig = go.Figure()
fig.add_trace(go.Bar(name="In-domain AUROC (BindingDB validation set)", x=["DrugBAN"], y=[0.9624],
                     marker_color=C_GREEN, text=["0.962"], textposition="outside"))
fig.add_trace(go.Bar(name="This benchmark: median \u03c1 (epoch 43)", x=["DrugBAN"],
                     y=[e43["tier3_median_rho"]], marker_color=C_BLUE,
                     text=["%.3f" % e43["tier3_median_rho"]], textposition="outside"))
fig.add_trace(go.Bar(name="This benchmark: median \u03c1 (epoch 30)", x=["DrugBAN"],
                     y=[e30["tier3_median_rho"]], marker_color=C_GREY,
                     text=["%.3f" % e30["tier3_median_rho"]], textposition="outside"))
fig.update_layout(title="DrugBAN (2022): in-domain AUROC 0.962 versus \u03c1 %s\u2013%s "
                        "on this benchmark" % (lo, hi),
                  yaxis_title="AUROC / Spearman \u03c1", yaxis_range=[0, 1.08],
                  barmode="group", **TPL)
save(fig, NAME)
