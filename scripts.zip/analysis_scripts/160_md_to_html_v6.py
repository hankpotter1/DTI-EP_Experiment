# -*- coding: utf-8 -*-
"""
DTI_manuscript_v6.md  ->  DTI_manuscript_v6.html

Standalone HTML built for a real typesetting engine (Edge/Chromium headless
--print-to-pdf).  Deliberately:
  * every table row is wrapped in <tr> (never split by a renderer's auto-numbering),
  * tables carry an explicit <colgroup> with content-proportional widths and
    `table-layout: fixed`, so no column can push the table past the page box,
  * each table is wrapped together with its caption and note in a `keep` block so the
    header row cannot be stranded at the foot of a page (the v4 Table 3 defect),
  * <thead> repeats the header if a long table does have to break,
  * list markers are real <ol>/<ul> — each list restarts at 1, and no counter is
    inherited from a previous list (the v4 "References start at 16" defect),
  * no external CSS/JS/fonts: the page is self-contained and prints identically.
"""
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
SRC = os.path.join(BASE, "manuscript", "DTI_manuscript_v6.md")
OUT = os.path.join(BASE, "manuscript", "DTI_manuscript_v6.html")
USABLE_IN = 6.69          # A4 21 cm - 2 x 2 cm
TBL_FONT_PT = 7.5

raw = open(SRC, encoding="utf-8").read()
lines = raw.split("\n")

CSS = """
@page { size: A4; margin: 20mm; }
html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
body { font-family: "Times New Roman", "Liberation Serif", serif;
       font-size: 10.5pt; line-height: 1.34; color: #000; margin: 0; }
h1 { font-size: 15pt;  margin: 0 0 8pt 0; }
h2 { font-size: 12.5pt; margin: 14pt 0 5pt 0; page-break-after: avoid; }
h3 { font-size: 11pt;  margin: 12pt 0 4pt 0; page-break-after: avoid; }
h4, h5 { font-size: 10.5pt; margin: 10pt 0 4pt 0; page-break-after: avoid; }
p { margin: 0 0 6pt 0; text-align: justify; }
code { font-family: "Consolas", "Courier New", monospace; font-size: 0.94em; }
blockquote { margin: 6pt 0 6pt 14pt; font-style: italic; font-size: 9.5pt;
             background: #f4f4f4; border-left: 2pt solid #999; padding: 5pt 8pt; }
table { border-collapse: collapse; width: 100%; table-layout: fixed;
        margin: 3pt 0 7pt 0; }
caption { caption-side: top; text-align: left; font-weight: bold; font-size: 10.5pt;
          padding: 0 0 2pt 0; }
th, td { border: 0.5pt solid #000; padding: 1pt 3pt; font-size: 7.5pt;
         vertical-align: top; overflow-wrap: break-word; word-wrap: break-word; }
th { font-weight: bold; }
thead { display: table-header-group; }
tr { page-break-inside: avoid; }
.keep { page-break-inside: avoid; }
.caption { font-weight: bold; margin: 8pt 0 2pt 0; }
.note { font-size: 8.5pt; font-style: italic; margin: 3pt 0 10pt 0; text-align: justify; }
figure { margin: 9pt 0 10pt 0; page-break-inside: avoid; text-align: center; }
figure img { max-width: 100%; height: auto; }
figcaption { font-size: 8.5pt; font-style: italic; color: #555;
             margin-top: 3pt; text-align: center; }
ol, ul { margin: 0 0 6pt 0; padding-left: 17pt; }
li { margin-bottom: 3pt; text-align: justify; }
hr { border: none; border-top: 0.5pt solid #bbb; margin: 12pt 0; }
.tableblock { break-inside: avoid; page-break-inside: avoid; }
.tableblock > .caption { break-after: avoid; page-break-after: avoid; }
table { break-inside: avoid; page-break-inside: avoid; }
"""


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


INLINE = re.compile(r"(\*\*.+?\*\*|`[^`]+?`|\*[^*]+?\*)")


def inline(s):
    out = []
    for tok in INLINE.split(s):
        if not tok:
            continue
        if tok.startswith("**") and tok.endswith("**") and len(tok) > 4:
            out.append("<b>%s</b>" % esc(tok[2:-2]))
        elif tok.startswith("`") and tok.endswith("`") and len(tok) > 2:
            out.append("<code>%s</code>" % esc(tok[1:-1]))
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            out.append("<i>%s</i>" % esc(tok[1:-1]))
        else:
            out.append(esc(tok))
    return "".join(out)


def clean_cell(c):
    return c.strip()


def column_pct(rows, ncol):
    weights = []
    for c in range(ncol):
        m = max((len(r[c]) for r in rows if c < len(r)), default=1)
        weights.append(max(2.0, m ** 0.5))
    tot = sum(weights)
    pct = [100.0 * w / tot for w in weights]
    return pct


def table_html(rows, caption_before, note_after):
    ncol = max(len(r) for r in rows)
    rows = [r + [""] * (ncol - len(r)) for r in rows]
    pct = column_pct(rows, ncol)
    # Keep ONLY the caption with the table: including the (sometimes long) note would
    # make the block taller than a page, at which point Chromium ignores
    # break-inside:avoid and can still strand the header.
    h = []
    h.append("<table>")
    if caption_before:
        # a real <caption> travels with its table, so the header row can never be
        # stranded at the foot of a page (Chromium does not reliably honour
        # break-inside:avoid on a wrapping <div>)
        h.append("<caption>%s</caption>" % inline(caption_before))
    h.append("<colgroup>%s</colgroup>" % "".join(
        '<col style="width:%.3f%%">' % p for p in pct))
    h.append("<thead><tr>%s</tr></thead>" % "".join(
        "<th>%s</th>" % inline(c) for c in rows[0]))
    h.append("<tbody>")
    for r in rows[1:]:
        h.append("<tr>%s</tr>" % "".join("<td>%s</td>" % inline(c) for c in r))
    h.append("</tbody></table>")
    if note_after:
        h.append('<p class="note">%s</p>' % inline(note_after))
    return "\n".join(h)


IMG_RE = re.compile(r"^!\[(.*?)\]\((.+?)\)\s*$")
OL_RE = re.compile(r"^(\d+)\.\s+(.*)$")
SEP_RE = re.compile(r"^\|[\s:\-|]+\|$")
TBL_RE = re.compile(r"^\*\*(Table \d+\..*?)\*\*$")
NOTE_RE = re.compile(r"^\*(Table note.*?)\*$")

body = []
stats = {"tables": 0, "rows": [], "images": 0, "headings": [], "ol": 0, "ul": 0}
i = 0
n = len(lines)
while i < n:
    ln = lines[i]
    s = ln.strip()

    m = IMG_RE.match(s)
    if m:
        alt, rel = m.group(1), m.group(2)
        p = os.path.normpath(os.path.join(BASE, "manuscript", rel))
        if os.path.isfile(p):
            body.append('<figure><img src="%s" alt="">'
                        "<figcaption>%s</figcaption></figure>" % (rel, inline(alt)))
            stats["images"] += 1
        else:
            body.append("<p>[MISSING IMAGE: %s]</p>" % esc(rel))
        i += 1
        continue

    if s == "---":
        body.append("<hr>")
        i += 1
        continue
    if not s:
        i += 1
        continue

    mh = re.match(r"^(#{1,5})\s+(.*)$", s)
    if mh:
        lvl = len(mh.group(1))
        body.append("<h%d>%s</h%d>" % (lvl, inline(mh.group(2)), lvl))
        stats["headings"].append(mh.group(2))
        i += 1
        continue

    # caption immediately followed by a table (a blank line usually separates them),
    # then an optional note
    mt = TBL_RE.match(s)
    jt = i + 1
    while jt < n and not lines[jt].strip():
        jt += 1
    if mt and jt < n and lines[jt].strip().startswith("|"):
        caption = mt.group(1)
        i = jt
        rows = []
        while i < n and lines[i].strip().startswith("|"):
            if not SEP_RE.match(lines[i].strip()):
                rows.append([clean_cell(c) for c in
                             lines[i].strip().strip("|").split("|")])
            i += 1
        note = None
        j = i
        while j < n and not lines[j].strip():
            j += 1
        if j < n:
            mn = NOTE_RE.match(lines[j].strip())
            if mn:
                note = mn.group(1)
                i = j + 1
        body.append(table_html(rows, caption, note))
        stats["tables"] += 1
        stats["rows"].append(len(rows) - 1)
        continue

    # bare table with no "**Table N.**" caption line
    if s.startswith("|") and i + 1 < n and SEP_RE.match(lines[i + 1].strip()):
        rows = []
        while i < n and lines[i].strip().startswith("|"):
            if not SEP_RE.match(lines[i].strip()):
                rows.append([clean_cell(c) for c in
                             lines[i].strip().strip("|").split("|")])
            i += 1
        body.append(table_html(rows, None, None))
        stats["tables"] += 1
        stats["rows"].append(len(rows) - 1)
        continue

    if s.startswith("> "):
        buf = []
        while i < n and lines[i].strip().startswith(">"):
            buf.append(lines[i].strip().lstrip(">").strip())
            i += 1
        body.append("<blockquote>%s</blockquote>" % inline(" ".join(buf)))
        continue

    if s.startswith("- ") or s.startswith("* "):
        items = []
        while i < n and (lines[i].strip().startswith("- ") or lines[i].strip().startswith("* ")):
            items.append(lines[i].strip()[2:])
            i += 1
        body.append("<ul>%s</ul>" % "".join("<li>%s</li>" % inline(x) for x in items))
        stats["ul"] += 1
        continue

    mo = OL_RE.match(s)
    if mo:
        items = []
        start = int(mo.group(1))
        while i < n:
            mm = OL_RE.match(lines[i].strip())
            if not mm:
                break
            items.append(mm.group(2))
            i += 1
        attr = ' start="%d"' % start if start != 1 else ""
        body.append("<ol%s>%s</ol>" % (attr, "".join(
            "<li>%s</li>" % inline(x) for x in items)))
        stats["ol"] += 1
        continue

    buf = []
    while i < n and lines[i].strip() and not IMG_RE.match(lines[i].strip()) \
            and not lines[i].strip().startswith(("|", "#", ">")) \
            and lines[i].strip() != "---" \
            and not OL_RE.match(lines[i].strip()) \
            and not lines[i].strip().startswith(("- ", "* ")):
        buf.append(lines[i].strip())
        i += 1
    if buf:
        body.append("<p>%s</p>" % inline(" ".join(buf)))

html = ("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
        "<title>DTI manuscript v6</title>\n<style>%s</style>\n</head>\n<body>\n%s\n"
        "</body>\n</html>\n" % (CSS, "\n".join(body)))
open(OUT, "w", encoding="utf-8").write(html)

print("=" * 78)
print("HTML written: %s  (%.1f KB)" % (OUT, os.path.getsize(OUT) / 1024))
print("=" * 78)
print("tables %d %s | images %d | headings %d | <ol> %d | <ul> %d" % (
    stats["tables"], stats["rows"], stats["images"],
    len(stats["headings"]), stats["ol"], stats["ul"]))
dups = sorted({h for h in stats["headings"] if stats["headings"].count(h) > 1})
print("duplicate headings: %s" % (dups if dups else "none"))
