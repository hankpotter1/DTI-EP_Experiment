# -*- coding: utf-8 -*-
"""
DTI_manuscript_v6.md -> DTI_manuscript_v6.docx

自写解析器(不再依赖 markdown/htmldocx —— 旧管线正是"渲染与源文件不一致"的根因):
  * 标题 -> Word Heading 样式,一一对应,不做任何自动编号/自动列表
  * 有序/无序列表 -> **字面文本**段落("1. xxx" / "• xxx"),绝不使用 Word 自动编号
    (旧稿参考文献从 22 开始编号,正是因为 Markdown 有序列表被渲染器接着前面的列表继续编号)
  * 表格 -> python-docx 逐行逐格写入;固定列宽(tblLayout=fixed + tblGrid)、
    允许自动换行、禁用"允许跨页断行"(w:cantSplit)、首行重复(w:tblHeader)
  * 图片 -> 居中嵌入 + 图注(alt 文本)
字体:西文 Times New Roman;eastAsia Microsoft YaHei。
"""
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
SRC = os.path.join(BASE, "manuscript", "DTI_manuscript_v6.md")
OUT = os.path.join(BASE, "manuscript", "DTI_manuscript_v6.docx")
LATIN, EASTASIA = "Times New Roman", "Microsoft YaHei"
USABLE_IN = 6.65          # A4 21cm - 2x2.0cm
IMG_IN = 6.30
TBL_FONT_PT = 7.5

raw = open(SRC, encoding="utf-8").read()
lines = raw.split("\n")

# ------------------------------------------------------------------ 文档
doc = Document()
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
for attr in ("left_margin", "right_margin"):
    setattr(sec, attr, Cm(2.0))
sec.top_margin, sec.bottom_margin = Cm(2.0), Cm(2.0)

normal = doc.styles["Normal"]
normal.font.name = LATIN
normal.font.size = Pt(10.5)
normal.paragraph_format.space_after = Pt(6)
normal.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), EASTASIA)

for hname, hsize in (("Heading 1", 15), ("Heading 2", 12.5), ("Heading 3", 11),
                     ("Heading 4", 10.5), ("Heading 5", 10.5), ("Title", 17)):
    try:
        st = doc.styles[hname]
        rpr = st.element.get_or_add_rPr()
        rf = rpr.get_or_add_rFonts()
        rf.set(qn("w:ascii"), LATIN)
        rf.set(qn("w:hAnsi"), LATIN)
        rf.set(qn("w:eastAsia"), EASTASIA)
        st.font.size = Pt(hsize)
        st.font.bold = True
        st.font.color.rgb = RGBColor(0, 0, 0)
    except KeyError:
        pass

# ------------------------------------------------------------------ 行内格式
INLINE = re.compile(r"(\*\*.+?\*\*|\*[^*]+?\*|`[^`]+?`)")


def set_run(run, size=None, italic=False, bold=False, color=None):
    run.font.name = LATIN
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), EASTASIA)
    run.italic = italic
    run.bold = bold
    if size:
        run.font.size = Pt(size)
    if color:
        run.font.color.rgb = color


def add_inline(par, text, size=None, base_italic=False, base_bold=False):
    """把 **bold** / *italic* / `code` 拆成 run;不解释任何其它 Markdown。"""
    for tok in INLINE.split(text):
        if not tok:
            continue
        if tok.startswith("**") and tok.endswith("**") and len(tok) > 4:
            r = par.add_run(tok[2:-2]); set_run(r, size, base_italic, True)
        elif tok.startswith("`") and tok.endswith("`") and len(tok) > 2:
            r = par.add_run(tok[1:-1]); set_run(r, size, base_italic, base_bold)
            r.font.name = "Consolas"
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            r = par.add_run(tok[1:-1]); set_run(r, size, True, base_bold)
        else:
            r = par.add_run(tok); set_run(r, size, base_italic, base_bold)


def add_para(text, size=None, italic=False, bold=False, style=None,
             align=None, space_before=None, space_after=None):
    p = doc.add_paragraph(style=style) if style else doc.add_paragraph()
    if align is not None:
        p.alignment = align
    if space_before is not None:
        p.paragraph_format.space_before = Pt(space_before)
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    add_inline(p, text, size, italic, bold)
    return p


# ------------------------------------------------------------------ 表格
def set_table_layout(table, widths_in):
    tbl = table._tbl
    tblPr = tbl.tblPr
    for tag in ("w:tblLayout", "w:tblW"):
        for el in tblPr.findall(qn(tag)):
            tblPr.remove(el)
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)
    tw = OxmlElement("w:tblW")
    tw.set(qn("w:type"), "dxa")
    tw.set(qn("w:w"), str(int(sum(widths_in) * 1440)))
    tblPr.append(tw)
    old = tbl.find(qn("w:tblGrid"))
    if old is not None:
        tbl.remove(old)
    grid = OxmlElement("w:tblGrid")
    for w in widths_in:
        gc = OxmlElement("w:gridCol")
        gc.set(qn("w:w"), str(int(w * 1440)))
        grid.append(gc)
    tblPr.addnext(grid)
    table.autofit = False
    for row in table.rows:
        for i, cell in enumerate(row.cells):
            cell.width = Inches(widths_in[i])


def row_flags(row, header=False):
    trPr = row._tr.get_or_add_trPr()
    cs = OxmlElement("w:cantSplit")          # 禁止该行跨页断开
    trPr.append(cs)
    if header:
        th = OxmlElement("w:tblHeader")      # 表头跨页重复
        trPr.append(th)


def compute_widths(rows, ncol):
    """按各列内容长度(sqrt 压缩)比例分配列宽,最小 0.42in。"""
    weights = []
    for c in range(ncol):
        m = max((len(r[c]) for r in rows if c < len(r)), default=1)
        weights.append(max(2.0, m ** 0.5))
    total = sum(weights)
    widths = [max(0.42, USABLE_IN * w / total) for w in weights]
    k = USABLE_IN / sum(widths)
    return [w * k for w in widths]


def add_table(rows):
    ncol = max(len(r) for r in rows)
    rows = [r + [""] * (ncol - len(r)) for r in rows]
    table = doc.add_table(rows=len(rows), cols=ncol)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, cells in enumerate(rows):
        for j, txt in enumerate(cells):
            cell = table.cell(i, j)
            par = cell.paragraphs[0]
            par.paragraph_format.space_before = Pt(1)
            par.paragraph_format.space_after = Pt(1)
            add_inline(par, txt, size=TBL_FONT_PT, base_bold=(i == 0))
    row_flags(table.rows[0], header=True)
    for r in table.rows[1:]:
        row_flags(r)
    set_table_layout(table, compute_widths(rows, ncol))
    return table


# ------------------------------------------------------------------ 主循环
IMG_RE = re.compile(r"^!\[(.*?)\]\((.+?)\)\s*$")
OL_RE = re.compile(r"^(\d+)\.\s+(.*)$")
SEP_RE = re.compile(r"^\|[\s:\-|]+\|$")

stats = {"tables": 0, "table_rows": [], "images": 0, "headings": [], "literals": 0}
i = 0
while i < len(lines):
    ln = lines[i]
    s = ln.strip()

    # 图片
    m = IMG_RE.match(s)
    if m:
        alt, rel = m.group(1), m.group(2)
        p = os.path.normpath(os.path.join(BASE, "manuscript", rel))
        if os.path.isfile(p):
            doc.add_picture(p, width=Inches(IMG_IN))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap = doc.add_paragraph()
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap.paragraph_format.space_after = Pt(10)
            r = cap.add_run(alt)
            set_run(r, 8.5, italic=True, color=RGBColor(0x55, 0x55, 0x55))
            stats["images"] += 1
        else:
            add_para("[MISSING IMAGE: %s]" % rel)
        i += 1
        continue

    # 表格
    if s.startswith("|") and i + 1 < len(lines) and SEP_RE.match(lines[i + 1].strip()):
        block = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not SEP_RE.match(lines[i].strip()):
                block.append(cells)
            i += 1
        add_table(block)
        stats["tables"] += 1
        stats["table_rows"].append(len(block) - 1)
        doc.add_paragraph().paragraph_format.space_after = Pt(2)
        continue

    if s == "---" or s == "":
        i += 1
        continue

    # 标题
    m = re.match(r"^(#{1,5})\s+(.*)$", s)
    if m:
        lvl = len(m.group(1))
        p = doc.add_paragraph(style="Heading %d" % min(lvl + 0, 5) if lvl > 1 else "Heading 1")
        add_inline(p, m.group(2))
        for r in p.runs:
            r.font.name = LATIN
            r.bold = True
            r.font.color.rgb = RGBColor(0, 0, 0)
        stats["headings"].append(m.group(2))
        i += 1
        continue

    # 引用块
    if s.startswith("> "):
        bufq = []
        while i < len(lines) and lines[i].strip().startswith(">"):
            bufq.append(lines[i].strip().lstrip(">").strip())
            i += 1
        p = add_para(" ".join(bufq), size=9.5, italic=True)
        p.paragraph_format.left_indent = Cm(0.6)
        stats["literals"] += 1
        continue

    # 无序列表 -> 字面项目符号
    if s.startswith("- ") or s.startswith("* "):
        p = add_para("\u2022 " + s[2:])
        p.paragraph_format.left_indent = Cm(0.5)
        p.paragraph_format.space_after = Pt(4)
        stats["literals"] += 1
        i += 1
        continue

    # 有序列表 -> 字面编号(绝不用 Word 自动编号)
    m = OL_RE.match(s)
    if m:
        p = add_para("%s. %s" % (m.group(1), m.group(2)))
        p.paragraph_format.left_indent = Cm(0.5)
        p.paragraph_format.space_after = Pt(4)
        stats["literals"] += 1
        i += 1
        continue

    # 普通段落(连续非空行合并)
    buf = []
    while i < len(lines) and lines[i].strip() and not IMG_RE.match(lines[i].strip()) \
            and not lines[i].strip().startswith("|") and not lines[i].strip().startswith("#") \
            and lines[i].strip() != "---" and not OL_RE.match(lines[i].strip()) \
            and not lines[i].strip().startswith(("- ", "* ", "> ")):
        buf.append(lines[i].strip())
        i += 1
    add_para(" ".join(buf))

# --- v5 hardening: never leave a table caption or a figure stranded at a page foot ---
_n_cap = 0
_n_img = 0
for _p in doc.paragraphs:
    _t = _p.text.strip()
    if re.match(r"^Table \d+\.", _t):
        _p.paragraph_format.keep_with_next = True
        _n_cap += 1
for _p in doc.paragraphs:
    if _p._p.findall(qn("w:drawing")) or any(
            r._element.findall(qn("w:drawing")) for r in _p.runs):
        _p.paragraph_format.keep_with_next = True
        _n_img += 1
print("keep-with-next: %d table captions, %d figure paragraphs" % (_n_cap, _n_img))

doc.core_properties.title = ("Open-box drug-target interaction models do not reproduce "
                             "within-target affinity ranking on a 57-target benchmark")
doc.save(OUT)

# ================================================================== 报告
print("=" * 78)
print("生成 %s  (%.2f MB)" % (OUT, os.path.getsize(OUT) / 1024 / 1024))
print("=" * 78)
print("段落 %d | 表格 %d | 图片 %d | 标题 %d | 字面列表项 %d" % (
    len(doc.paragraphs), stats["tables"], stats["images"], len(stats["headings"]),
    stats["literals"]))
print()
print("表格行数(markdown 源 vs docx):")
d = Document(OUT)
src_rows = stats["table_rows"]
ok = True
for k, t in enumerate(d.tables):
    sr = src_rows[k] if k < len(src_rows) else -1
    dr = len(t.rows) - 1
    flag = "OK " if sr == dr else "BAD"
    if sr != dr:
        ok = False
    print("  Table %2d: 源 %2d 数据行 | docx %2d 数据行 (%d 行 x %d 列) %s" % (
        k + 1, sr, dr, len(t.rows), len(t.columns), flag))
print()
dups = sorted({h for h in stats["headings"] if stats["headings"].count(h) > 1})
print("重复标题: %s" % ("None" if not dups else dups))
print("表格行数一致: %s" % ("YES" if ok else "NO"))
