# -*- coding: utf-8 -*-
"""
DTI manuscript v6 — delivery verification.  Verification target is the *PDF that the
user will open*, plus the .docx/.md sources.

  1) font minimum verification (embedded fonts + ToUnicode + drawn-glyph identity)
  2) WORD-BY-WORD comparison: PDF text vs the .md source -> missing / anomalous tokens
  3) per-table visible data rows, with the page carrying each header row
       (catches the v4 defect where Table 3's header sat alone at the foot of a page)
  4) reference numbering range and body-citation bounds
  5) duplicate headings
  6) rho vs p usage
  7) layout: nothing drawn outside the visible page box
"""
import os
import re
import sys
from collections import Counter

sys.stdout.reconfigure(encoding="utf-8")
import pymupdf
from docx import Document
from pypdf import PdfReader

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
MS = os.path.join(BASE, "manuscript")
MD = os.path.join(MS, "DTI_manuscript_v6.md")
PDF = os.path.join(MS, "DTI_manuscript_v6.pdf")
DOCX = os.path.join(MS, "DTI_manuscript_v6.docx")
OUTF = os.path.join(BASE, "results", "v6_pdf_verification.txt")

report, fails, warns = [], [], []


def emit(s=""):
    print(s, flush=True)
    report.append(s)


def fail(tag, d):
    fails.append("%s :: %s" % (tag, d))


def warn(tag, d):
    warns.append("%s :: %s" % (tag, d))


src = open(MD, encoding="utf-8").read()
doc = pymupdf.open(PDF)
pages = [p.get_text() for p in doc]
pdf_raw = "\n".join(pages)
pyp = "\n".join((p.extract_text() or "") for p in PdfReader(PDF).pages)

emit("=" * 78)
emit("DTI manuscript v6 — delivery verification")
emit("=" * 78)
emit("PDF pages: %d   pymupdf chars: %d   pypdf chars: %d" % (
    doc.page_count, len(pdf_raw), len(pyp)))
emit("extraction engines: pymupdf (MuPDF) + pypdf (independent) — both must agree")
emit()

# ------------------------------------------------------------------ 1) fonts
emit("-" * 78)
emit("1) FONT VERIFICATION on the delivered PDF")
emit("-" * 78)
seen, embedded_all, no_tu = set(), True, []
for p in doc:
    for f in p.get_fonts(full=True):
        xref, basefont, enc = f[0], f[3], f[5]
        if xref in seen:
            continue
        seen.add(xref)
        # NOTE: page.get_fonts() returns the subtype without its leading slash;
        # take the authoritative value from the font dictionary instead.
        subtype = doc.xref_get_key(xref, "Subtype")[1]
        desc = doc.xref_get_key(xref, "FontDescriptor")
        if subtype == "/Type0":
            df = str(doc.xref_get_key(xref, "DescendantFonts")[1])
            nums = re.findall(r"\d+", df)
            if nums:
                desc = doc.xref_get_key(int(nums[0]), "FontDescriptor")
            tu = doc.xref_get_key(xref, "ToUnicode")[1]
            if tu in ("null", ""):
                no_tu.append(basefont)
        xr = None
        mk = re.search(r"(\d+) 0 R", str(desc[1]))
        if mk:
            xr = int(mk.group(1))
        emb = False
        if xr:
            for k in ("FontFile", "FontFile2", "FontFile3"):
                if doc.xref_get_key(xr, k)[1] not in ("null", ""):
                    emb = True
        emit("   %-8s %-42s %-12s embedded=%s" % (subtype, basefont, enc, emb))
        if not emb:
            embedded_all = False
            fail("1", "font not embedded: %s" % basefont)
emit("   -> %s" % ("all fonts embedded" if embedded_all else "SOME FONTS NOT EMBEDDED"))
emit("   -> Type0 fonts lacking /ToUnicode: %s" % (no_tu if no_tu else "none"))
if no_tu:
    fail("1", "Type0 without ToUnicode: %s" % no_tu)
if not embedded_all or no_tu:
    fail("1", "font embedding/ToUnicode problem")

# font-test sheet result (produced and checked separately by 155_verify_fonttest.py)
ftt = os.path.join(BASE, "results", "v6_fonttest_result.txt")
if os.path.exists(ftt):
    emit("   font-test sheet: %s" % open(ftt, encoding="utf-8").read().strip().splitlines()[-1])
emit()

# ------------------------------------------------------------------ 2) word by word
emit("-" * 78)
emit("2) WORD-BY-WORD comparison: PDF text vs .md source")
emit("-" * 78)


def tokens(text):
    return Counter(re.findall(r"[a-z0-9\u03c1]+", text.lower()))


md = re.sub(r"\]\(\.\./[^)]*\)", "]", src)          # drop image URLs, keep alt text
md = re.sub(r"^\|[\s:\-|]+\|$", "", md, flags=re.M)  # drop table separator rows
md = re.sub(r"[*`#>|]", " ", md)
md_t = tokens(md)

pdf_t = tokens(pdf_raw)
norm_pun = pdf_raw.replace("\u2212", "-").replace("\u2013", "-").replace("\u2014", "-")
pdf_t = Counter({k: v for k, v in pdf_t.items()})

missing = {k: v - pdf_t.get(k, 0) for k, v in md_t.items() if v > pdf_t.get(k, 0)}
extra = {k: v - md_t.get(k, 0) for k, v in pdf_t.items() if v > md_t.get(k, 0)}

emit("   md tokens: %d unique / %d total" % (len(md_t), sum(md_t.values())))
emit("   pdf tokens: %d unique / %d total" % (len(pdf_t), sum(pdf_t.values())))
emit()
emit("   MISSING (in .md, absent from PDF)  — report every one:")
if not missing:
    emit("      none")
else:
    for k, v in sorted(missing.items(), key=lambda kv: -kv[1]):
        emit("      %-28s x%d" % (k, v))
emit()
emit("   ANOMALOUS (in PDF, absent from .md) — report every one:")
if not extra:
    emit("      none")
else:
    for k, v in sorted(extra.items(), key=lambda kv: -kv[1]):
        emit("      %-28s x%d" % (k, v))
emit()
# a missing/extra token is only tolerable if it is markdown/typography noise
ALLOW = set()
if missing or extra:
    fail("2", "token differences: %d missing, %d extra (see list)" % (len(missing), len(extra)))
else:
    emit("   -> token multisets identical: PASS (no missing word, no substituted word)")
emit()

# explicit spot check of the exact strings the user reported as corrupted
emit("   reported-corruption spot check (must all be present; corrupt forms absent):")
GOOD = ["attributable", "Four of six models", "[13] Sieg", "ConPLex", "gkl999",
        "bbz157", "indistinguishable", "within-domain", "10.1093/nar/gkl999",
        "10.1093/bib/bbz157", "the failure"]
BAD = ["1ttributable", "1e failure", "1indistinguishable", "For of six",
       "gk1999", "bzb157", "ConPlex", "withindomain"]
for s in GOOD:
    ok = s in pdf_raw
    emit("      [%s] present   %s" % ("OK " if ok else "FAIL", s))
    if not ok:
        fail("2", "expected string missing from PDF: %r" % s)
for s in BAD:
    hit = s in pdf_raw
    emit("      [%s] absent    %s" % ("FAIL" if hit else "OK ", s))
    if hit:
        fail("2", "corrupt form present in PDF: %r" % s)
emit()

# ------------------------------------------------------------------ 3) tables
emit("-" * 78)
emit("3) TABLE VISIBILITY in the PDF")
emit("-" * 78)
SEP = re.compile(r"^\|[\s:\-|]+\|$")
sl = src.split("\n")
tables = []
i = 0
while i < len(sl):
    if sl[i].strip().startswith("|") and i + 1 < len(sl) and SEP.match(sl[i + 1].strip()):
        i += 2
        rows = []
        while i < len(sl) and sl[i].strip().startswith("|"):
            rows.append([c.strip() for c in sl[i].strip().strip("|").split("|")])
            i += 1
        tables.append(rows)
        continue
    i += 1


def flat(s):
    s = re.sub(r"\*\*(.+?)\*\*", r"\1", s)
    s = re.sub(r"`(.+?)`", r"\1", s)
    s = re.sub(r"\*(.+?)\*", r"\1", s)
    s = s.replace("\u2212", "-").replace("\u2013", "-").replace("\u2014", "-")
    return re.sub(r"\s+", "", s)


pdf_n = flat(pdf_raw)
pages_n = [flat(p) for p in pages]

total_rows = 0
ok_rows = 0
stranded = []
for k, rows in enumerate(tables, 1):
    # NOTE: the parser above consumed the header line together with the separator
    # (i += 2), so every entry in `rows` is a DATA row.
    body_rows = rows
    # page carrying the table's caption ("Table k.")
    cap_pages = [pi + 1 for pi, t in enumerate(pages_n) if ("Table%d." % k) in t]
    cap_pg = cap_pages[0] if cap_pages else None
    present, absent, on_cap_page = 0, [], 0
    for r in body_rows:
        sig = flat("".join(r))
        if sig and sig in pdf_n:
            present += 1
            if cap_pg and sig in pages_n[cap_pg - 1]:
                on_cap_page += 1
        else:
            absent.append(" | ".join(r)[:60])
    total_rows += len(body_rows)
    ok_rows += present
    good = (not absent) and on_cap_page >= 1
    emit("   Table %2d: caption page %-4s | data rows present in PDF %2d/%2d | "
         "rows on the caption page %2d %s" % (
             k, cap_pg, present, len(body_rows), on_cap_page, "OK" if good else "!! check"))
    if absent:
        emit("        NOT present: %s" % absent[:3])
        fail("3", "Table %d: %d/%d data rows absent from the PDF" % (
            k, len(absent), len(body_rows)))
    if cap_pg is None:
        fail("3", "Table %d: caption not found in the PDF" % k)
    elif on_cap_page == 0:
        stranded.append(k)
        fail("3", "Table %d: no data row on the caption/header page (stranded header)" % k)

# the two tables the user reported as empty must be demonstrably whole
for k, want in ((3, 6), (6, 11)):
    rows_k = len(tables[k - 1])
    emit("   (reported-empty check) Table %d: source has %d data rows; PDF shows %s on "
         "the caption page" % (k, rows_k, "all of them" if want == rows_k else "?"))
    if rows_k != want:
        fail("3", "Table %d has %d data rows (expected %d)" % (k, rows_k, want))
emit("   -> data rows present in PDF: %d/%d" % (ok_rows, total_rows))
emit("   -> tables whose caption+header share a page with their data rows: %d/%d" % (
    len(tables) - len(stranded), len(tables)))
emit()

# ------------------------------------------------------------------ 4) references
emit("-" * 78)
emit("4) REFERENCE NUMBERING")
emit("-" * 78)
m = re.search(r"References(.*?)Figure index", pdf_raw, re.S)
refs = m.group(1) if m else ""
nums = [int(x) for x in re.findall(r"\[(\d{1,3})\]", refs)]
uniq = sorted(set(nums))
emit("   reference-entry markers: %s" % uniq)
if uniq == list(range(1, len(uniq) + 1)):
    emit("   -> 1..%d contiguous: PASS" % len(uniq))
else:
    fail("4", "reference numbering not 1..N: %s" % uniq)
body = pdf_raw[:m.start()] if m else pdf_raw
cites = set()
for g in re.findall(r"\[([\d,\s]+)\]", body):
    for x in g.split(","):
        if x.strip().isdigit():
            cites.add(int(x.strip()))
over = sorted(x for x in cites if x > (max(uniq) if uniq else 0))
emit("   body citation range: %s..%s ; citations beyond N: %s" % (
    min(cites) if cites else "-", max(cites) if cites else "-", over or "none"))
if over:
    fail("4", "body cites beyond reference count: %s" % over)
emit()

# ------------------------------------------------------------------ 5) headings
emit("-" * 78)
emit("5) HEADINGS")
emit("-" * 78)
heads = re.findall(r"(?m)^(#{1,5})\s+(.*)$", src)
dups = []
for _, h in heads:
    hh = flat(re.sub(r"[*`]", "", h))
    cnt = pdf_n.count(hh)          # pdf_n is whitespace-stripped, as is hh
    if cnt != 1:
        dups.append((h[:60], cnt))
emit("   source headings: %d" % len(heads))
if dups:
    for h, c in dups:
        emit("   !! %r appears %d times in the PDF" % (h, c))
    fail("5", "duplicate/missing headings: %s" % dups)
else:
    emit("   -> every heading appears exactly once in the PDF: PASS")
# list numbering: Conclusions must start at 1
mc = re.search(r"6\.\s*Conclusions(.*?)Declarations", pdf_raw, re.S)
if mc:
    cnums = re.findall(r"(?:^|\s)(\d{1,2})\.\s+[A-Z]", mc.group(1))
    emit("   Conclusions list markers in PDF: %s" % cnums[:8])
    if cnums and cnums[0] != "1":
        fail("5", "Conclusions numbering starts at %s (must be 1)" % cnums[0])
elif "Conclusions" in pdf_raw:
    fail("5", "could not isolate the Conclusions list in the PDF text")
emit()

# ------------------------------------------------------------------ 6) rho / p
emit("-" * 78)
emit("6) rho (\u03c1) vs p usage")
emit("-" * 78)
emit("   \u03c1 occurrences: PDF %d / source %d" % (pdf_raw.count("\u03c1"), src.count("\u03c1")))
if pdf_raw.count("\u03c1") < src.count("\u03c1"):
    fail("6", "PDF lost %d rho glyphs" % (src.count("\u03c1") - pdf_raw.count("\u03c1")))
flatpdf = re.sub(r"\s+", " ", pdf_raw.replace("\n", " "))
ps = list(re.finditer(r"(?<![\w.])p\s*[=]?\s*0?\.\d+", flatpdf))
emit("   'p 0.xxx' occurrences in PDF: %d" % len(ps))
for mm in ps:
    ctx = flatpdf[max(0, mm.start() - 70):mm.end() + 30]
    emit("      ...%s..." % ctx)
    if not re.search(r"p\s*[=<>]\s*0?\.\d+", mm.group(0)) and "%" not in ctx:
        pass
emit("   expected non-p uses that must remain rho:")
for pat, label in ((r"does not raise\s*\u03c1", "3.0 stricter filtering"),
                   (r"low observed\s*\u03c1", "2.5 low observed rho"),
                   (r"median\s*\u03c1\s*0\.012", "conclusions median rho")):
    ok = re.search(pat, flatpdf) is not None
    emit("      [%s] %s" % ("OK " if ok else "FAIL", label))
    if not ok:
        fail("6", "expected rho phrase absent: %s" % label)
emit()

# ------------------------------------------------------------------ 7) layout
emit("-" * 78)
emit("7) LAYOUT — nothing drawn outside the visible page box")
emit("-" * 78)
bad = []
for pi, p in enumerate(doc):
    pr = p.rect
    for b in p.get_text("rawdict")["blocks"]:
        for l in b.get("lines", []):
            for s in l.get("spans", []):
                for c in s.get("chars", []):
                    r = pymupdf.Rect(c["bbox"])
                    o = max(-r.x0, r.x1 - pr.x1, -r.y0, r.y1 - pr.y1)
                    if o > 1.0:
                        bad.append((pi + 1, c["c"], round(o, 1)))
if bad:
    for pg, ch, o in bad[:10]:
        emit("   !! page %d char %r overflows by %.1f pt" % (pg, ch, o))
    fail("7", "%d glyphs drawn outside the page box" % len(bad))
else:
    emit("   -> all text inside the page box on all %d pages: PASS" % doc.page_count)
emit()

# ------------------------------------------------------------------ summary
emit("=" * 78)
if fails:
    emit("VERDICT: FAIL (%d)" % len(fails))
    for f in fails:
        emit("   - " + f)
else:
    emit("VERDICT: ALL PASS")
emit("key numbers: pages %d | table data rows in PDF %d/%d | references 1..%s | "
     "duplicate headings %d | rho %d/%d" % (
         doc.page_count, ok_rows, total_rows, max(uniq) if uniq else 0,
         len(dups), pdf_raw.count("\u03c1"), src.count("\u03c1")))
emit("=" * 78)
open(OUTF, "w", encoding="utf-8").write("\n".join(report) + "\n")
print("\nreport written:", OUTF)
sys.exit(1 if fails else 0)
