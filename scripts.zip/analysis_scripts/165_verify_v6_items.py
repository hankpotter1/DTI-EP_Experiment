# -*- coding: utf-8 -*-
"""
DTI manuscript v6 — item-level verification (the checks the task asked for beyond the
base delivery verification):

  3) Table 3 column names really are p values (not rho)
  6) full rho-vs-p semantic sweep: EVERY occurrence of rho and EVERY p-value token,
     with the semantic judgement printed for each
  7) landing confirmation for items A-D

Reads the delivered PDF body (the artefact the user opens) plus md/html/docx sources.
"""
import os
import re
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8")
import pymupdf

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
MS = os.path.join(BASE, "manuscript")
RHO = "\u03c1"
MD = os.path.join(MS, "DTI_manuscript_v6.md")
PDF = os.path.join(MS, "DTI_manuscript_v6.pdf")
HTML = os.path.join(MS, "DTI_manuscript_v6.html")
DOCX = os.path.join(MS, "DTI_manuscript_v6.docx")

md = open(MD, encoding="utf-8").read()
html = open(HTML, encoding="utf-8").read()
with zipfile.ZipFile(DOCX) as z:
    dxml = re.sub(r"<[^>]+>", "", z.read("word/document.xml").decode("utf-8"))
doc = pymupdf.open(PDF)
pdf = "\n".join(p.get_text() for p in doc)
flat = re.sub(r"\s+", " ", pdf)
SRC = {"MD": md, "HTML": html, "DOCX": dxml, "PDF": pdf}

report, fails = [], []


def emit(s=""):
    print(s, flush=True)
    report.append(s)


def chk(ok, tag, detail):
    emit("   [%s] %-56s %s" % ("OK " if ok else "FAIL", tag, detail))
    if not ok:
        fails.append("%s :: %s" % (tag, detail))


# =====================================================================  3) Table 3
emit("=" * 78)
emit("3) TABLE 3 COLUMN NAMES ARE p VALUES (not rho)")
emit("=" * 78)
hdr = [l for l in md.split("\n") if l.startswith("| Model | median " + RHO)][0]
cols = [c.strip() for c in hdr.strip().strip("|").split("|")]
emit("   header row : %s" % cols)
want = ["Model", "median " + RHO, "95% CI", "positive", "sign p", "BH p",
        "Bonferroni p", "Wilcoxon p"]
chk(cols == want, "Table 3 header equals the expected 8 columns", "%s" % (cols == want))
pcols = [c for c in cols[4:]]
chk(pcols == ["sign p", "BH p", "Bonferroni p", "Wilcoxon p"],
    "the four test columns end in 'p'", "-> %s" % pcols)
chk(not any(c.endswith(RHO) for c in cols[4:]),
    "no test column labelled with rho", "-> none")
# the four false forms must be absent from every artefact
for s in ("sign " + RHO, "BH " + RHO, "Bonferroni " + RHO, "Wilcoxon " + RHO):
    tot = sum(v.count(s) for v in SRC.values())
    chk(tot == 0, "false form absent from MD/HTML/DOCX/PDF: %r" % s, "count=%d" % tot)
chk("`sign p` is a two-sided sign test against " + RHO + " = 0; `Wilcoxon p` is the "
    "signed-rank test on the same per-target " + RHO + " values." in md,
    "Table 3 note defines sign p / Wilcoxon p correctly", "")
emit()

# =====================================================================  6) rho / p sweep
emit("=" * 78)
emit("6) FULL rho-vs-p SEMANTIC SWEEP  (every occurrence, with its judgement)")
emit("=" * 78)
emit("   --- every %s character in the delivered PDF: %d occurrences ---"
     % (RHO, pdf.count(RHO)))
bad_rho = 0
for i, m in enumerate(re.finditer(re.escape(RHO), flat), 1):
    ctx = flat[max(0, m.start() - 62):m.end() + 40]
    # semantic rule: rho == Spearman rank correlation (a coefficient), never a p value.
    sem = "correlation coefficient (correct)"
    if re.search(re.escape(RHO) + r"\s*[=<]\s*0?\.\d", ctx) and \
       not re.search(r"(test against|reference line|exceed|reporting|threshold|draws|role for)", ctx):
        sem = "*** REVIEW: looks like a p value ***"
        bad_rho += 1
    emit("   %2d. %s" % (i, ctx))
    emit("       -> %s" % sem)
chk(bad_rho == 0, "no rho used with p-value semantics", "%d suspicious" % bad_rho)
emit()
emit("   --- every p-value token in the delivered PDF ---")
ptok = list(re.finditer(r"(?<![A-Za-z.])p\s*[=<]?\s*0?\.\d+", flat))
for i, m in enumerate(ptok, 1):
    ctx = flat[max(0, m.start() - 62):m.end() + 20]
    emit("   %2d. %s" % (i, ctx))
    emit("       -> statistical p value (correct)")
chk(len(ptok) > 0, "p-value tokens present and all statistical", "%d found" % len(ptok))
emit()
emit("   --- rho/p counts on both sides (source vs delivered PDF) ---")
chk(pdf.count(RHO) == md.count(RHO), "rho glyphs preserved MD -> PDF",
    "MD=%d PDF=%d" % (md.count(RHO), pdf.count(RHO)))
for lbl, pat in (("sign p", r"sign p"), ("BH p", r"BH p"),
                 ("Bonferroni p", r"Bonferroni p"), ("Wilcoxon p", r"Wilcoxon p")):
    chk(len(re.findall(pat, md)) == len(re.findall(pat, pdf)),
        "p-column label count matches: %s" % lbl,
        "MD=%d PDF=%d" % (len(re.findall(pat, md)), len(re.findall(pat, pdf))))
emit()

# =====================================================================  7) A-D landing
emit("=" * 78)
emit("7) LANDING CONFIRMATION, ITEMS A-D")
emit("=" * 78)


def present(s, where="MD"):
    return s in SRC[where]


def absent(s):
    return all(v.count(s) == 0 for v in SRC.values())


emit("A. rho-for-p 'over-correction' to roll back")
chk(not any("sign " + RHO in v or "BH " + RHO in v or "Bonferroni " + RHO in v
            or "Wilcoxon " + RHO in v for v in SRC.values()),
    "A  no 'sign/BH/Bonferroni/Wilcoxon rho' in any artefact",
    "-> NOT REPRODUCIBLE IN SOURCE (already 'p'); nothing was changed")
chk(present("sign p") and present("BH p") and present("Bonferroni p")
    and present("Wilcoxon p"), "A  the four columns are 'p'", "")
chk("sign p` is a two-sided sign test against " + RHO + " = 0" in md,
    "A  Table 3 note unchanged and correct", "")
chk(bad_rho == 0, "A  full-text recheck: 0 rho used with p-value semantics", "")

emit()
emit("B1. Table 4 note vs " + "\u00a7" + "2.2 checkpoint provenance")
chk(present("the epoch-43 checkpoint is from the validation-best epoch (reproduced "
            "across two runs with SEED=42), and the epoch-30 checkpoint is an earlier "
            "point from the same run, included as a sensitivity check."),
    "B1 new Table 4 note present (MD/HTML/DOCX)",
    "PDF(flat)=%d" % flat.count("the epoch-43 checkpoint is from the validation-best epoch"))
chk(absent("the two checkpoints are from the two training runs"),
    "B1 old contradictory wording gone from all artefacts", "")

emit()
emit("B2. Figure 12 = mean rho vs Table 3 = median rho")
chk(present("Figure 12 shows **mean** " + RHO + " for the three metric families; "
            "Table 3 reports **median** " + RHO + " as the primary endpoint."),
    "B2 " + "\u00a7" + "3.11 sentence present", "")
chk("Tier 3 is **mean** " + RHO + ", whereas Table 3 reports **median** " + RHO
    + " as the primary endpoint" in md,
    "B2 Figure 12 caption + figure index carry the mean/median note",
    "occurrences in MD = %d" % md.count("Tier 3 is **mean**"))
f12 = "\n".join(pg.get_text() for pg in pymupdf.open(
    os.path.join(BASE, "figures", "fig_bench_tiers.pdf")))
chk("Tier 3: within-target ranking " + RHO + " (mean)" in f12,
    "B2 Figure 12 legend itself labels Tier 3 as mean rho", "")

emit()
emit("B3. DrugBAN epoch-30 median rho (recorded value 0.1885 -> 0.189)")
chk(md.count("0.165" + "\u2013" + "0.189") == 5, "B3 five prose/caption ranges now 0.165-0.189",
    "count=%d" % md.count("0.165" + "\u2013" + "0.189"))
chk("0.165 (epoch 43) / 0.189 (epoch 30)" in md, "B3 " + "\u00a7" + "3.6 per-checkpoint values",
    "")
chk(absent("0.165" + "\u2013" + "0.188"), "B3 stale range gone from all artefacts", "")
chk("Median " + RHO + " values are given to three decimals from the recorded values "
    "(`results/drugban_eval_per_ckpt.json`: epoch 43 0.1646, epoch 30 0.1885)." in md,
    "B3 Table 6 note records the exact values + precision", "")
f6 = "\n".join(pg.get_text() for pg in pymupdf.open(
    os.path.join(BASE, "figures", "fig_report_F6_drugban_gap.pdf")))
chk(RHO + " 0.165\u20130.189" in f6, "B3 regenerated Figure 6 title reads 0.165-0.189", "")
chk("0.165" in f6 and "0.189" in f6, "B3 Figure 6 bar labels 0.165 / 0.189 (data-driven)", "")

emit()
emit("B4. " + "\u00a7" + "3.1 table number")
chk(md.count("(Table 1)") == 0, "B4 no '(Table 1)' cross-reference remains",
    "-> the Table 1 caption itself is 'Table 1. Evaluation sets.'")
chk("dropped to 0.21" + "\u2013" + "0.29 (Table 2)." in md,
    "B4 " + "\u00a7" + "3.1 temporal validation now cites Table 2", "")

emit()
emit("C5-C7, C8-C11. formatting items reported by the reviewer")
chk(absent("5. Limitations- Model coverage"), "C5 no duplicated '5. Limitations- Model coverage'",
    "-> NOT REPRODUCIBLE IN SOURCE")
chk(absent("all \\(1\\geq 15 / \\geq 20\\)"),
    "C5 escaped '\\geq' form absent", "-> NOT REPRODUCIBLE IN SOURCE")
chk(present("Stratified re-analysis (all / \u226515 / \u226520 ligands per target)"),
    "C5 source already reads 'all / >=15 / >=20'", "")
chk(absent("Mann-Whitney " + RHO + " = 0.569"), "C5 'Mann-Whitney rho = 0.569' absent",
    "-> NOT REPRODUCIBLE IN SOURCE")
chk(present("Mann-Whitney p = 0.569"), "C5 source already reads 'Mann-Whitney p = 0.569'", "")
lim = md.split("## 5. Limitations")[1].split("## 6. Conclusions")[0]
n_bul = len([l for l in lim.split("\n") if l.strip().startswith("- ")])
chk(n_bul == 11, "C5 " + "\u00a7" + "5 is a bullet list", "%d bullets" % n_bul)
con = md.split("## 6. Conclusions")[1].split("## Declarations")[0]
n_num = len([l for l in con.split("\n") if re.match(r"^\d+\.\s", l.strip())])
chk(n_num == 6, "C6 " + "\u00a7" + "6 is a numbered list", "%d items" % n_num)
chk(md.count("## 6. Conclusions") == 1, "C6 exactly one Conclusions heading", "")
rec = md.split("### 4.4 Practical recommendations")[1].split("### 4.5")[0]
n_rec = len([l for l in rec.split("\n") if re.match(r"^\d+\.\s", l.strip())])
chk(n_rec == 4, "C7 " + "\u00a7" + "4.4 has 4 separately-numbered lines", "%d" % n_rec)
chk(absent("11) Davis"), "C8 '11) Davis' (missing bracket) absent", "-> NOT REPRODUCIBLE")
chk(present("[11] Davis MI"), "C8 source already has '[11] Davis MI'", "")
chk(absent("fig bench titers"), "C9 'fig bench titers' absent", "-> NOT REPRODUCIBLE")
chk(present("fig_bench_tiers"), "C9 source already has 'fig_bench_tiers'", "")
chk(absent("Filter strictness sampling"), "C9 'Filter strictness sampling' absent",
    "-> NOT REPRODUCIBLE")
chk(present("Filter strictness \u00d7 sampling"), "C9 source already has the '\u00d7' form", "")
chk(absent("H-bond donors/acceptors"),
    "C10 'H-bond donors/acceptors' expanded (was in 2.5 and 4.5, not in the 3.10 note)",
    "count now=%d" % md.count("H-bond donors/acceptors"))
chk(md.count("H-bond donor count / H-bond acceptor count") == 2,
    "C10 expanded form present twice", "")
chk(absent("Fundings"), "C11 'Fundings' absent", "-> NOT REPRODUCIBLE")
chk(present("**Funding.**"), "C11 source already reads 'Funding.'", "")

emit()
emit("D12. reference [6] publication status")
ref6 = [l for l in md.split("\n") if l.startswith("[6]")][0]
chk(ref6.endswith("PMID: 42623034.") and "2026;42:btag608" in ref6,
    "D12 [6] citation present as verified", ref6[:96] + "...")
chk("preprint" not in ref6.lower(),
    "D12 no preprint annotation needed: Crossref type=journal-article (OUP), "
    "Europe PMC publicationStatus=ppublish, PMC13520922", "")

emit()
emit("D13. Figures 10/11 are the pilot, not the main benchmark")
chk(present("Figure 2 shows the main 57-target result; Figures 10 and 11 show the "
            "20-target pilot benchmark for comparison."), "D13 " + "\u00a7" + "3.2 sentence", "")
chk(md.count("pilot benchmark, not the main 57-target benchmark") == 4,
    "D13 both pilot figures flagged in the caption AND the figure index",
    "count=%d" % md.count("pilot benchmark, not the main 57-target benchmark"))

emit()
emit("D14. Table 6 title")
chk("**Table 6. Tier-1 retrieval and trivial-baseline comparison across all eight "
    "evaluation objects, with reference baselines.**" in md,
    "D14 Table 6 title now names the reference-baseline rows", "")
chk(r"Table 6. Tier-1 retrieval and trivial-baseline comparison across all eight "
    r"evaluation objects, with reference baselines." in flat,
    "D14 confirmed in the delivered PDF", "")

emit()
emit("=" * 78)
emit("VERDICT: %s" % ("ALL ITEM CHECKS PASS" if not fails else "FAIL (%d)" % len(fails)))
for f in fails:
    emit("   - " + f)
emit("=" * 78)

out = os.path.join(BASE, "results", "v6_item_verification.txt")
open(out, "w", encoding="utf-8").write("\n".join(report) + "\n")
print("\nreport written:", out)
sys.exit(1 if fails else 0)
