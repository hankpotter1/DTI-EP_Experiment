# -*- coding: utf-8 -*-
"""
Decisive rendering check for item A on the DELIVERED v6 PDF.

Question: does the statistic column of Table 3 draw a 'p'-shaped glyph, or a 'ρ'-shaped
one?  A correlation between bitmaps is only meaningful BETWEEN GLYPHS AT THE SAME FONT AND
SIZE, so this check compares only characters drawn inside ONE table header line (same span
font, same size):

  * p vs p   (different instances of the same letter)  -> must be ~1.000
  * rho vs rho (different instances)                   -> must be ~1.000
  * p vs rho                                           -> must be clearly lower
"""
import io
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
import pymupdf
from PIL import Image

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
PDF = os.path.join(BASE, "manuscript", "DTI_manuscript_v6.pdf")
RHO = "\u03c1"
doc = pymupdf.open(PDF)

# Group characters by their y-band: table header cells can be emitted as separate
# "lines" by the extractor, so a whole header row must be reassembled by y position.
LINES = []
for pi, page in enumerate(doc):
    cs = [{"c": c["c"], "bbox": c["bbox"], "font": s["font"],
           "size": round(s["size"], 2)}
          for b in page.get_text("rawdict")["blocks"]
          for l in b.get("lines", []) for s in l.get("spans", [])
          for c in s.get("chars", [])]
    bands = {}
    for c in cs:
        bands.setdefault(round(c["bbox"][1], 0), []).append(c)
    for y, band in bands.items():
        txt = "".join(c["c"] for c in band)
        if "Bonferroni" in txt and "median " + RHO in txt:
            fonts = sorted({c["font"] for c in band})
            sizes = sorted({c["size"] for c in band})
            LINES.append((pi + 1, txt, band, "|".join(fonts),
                          "|".join(str(s) for s in sizes)))
    if LINES:
        break

if not LINES:
    print("Table 3 header row not found")
    sys.exit(2)


def render(page, info, dpi=1200):
    r = pymupdf.Rect(info["bbox"])
    clip = pymupdf.Rect(r.x0 - 0.5, r.y0 - 0.5, r.x1 + 0.5, r.y1 + 0.5)
    pix = page.get_pixmap(clip=clip, dpi=dpi)
    return Image.open(io.BytesIO(pix.tobytes("png"))).convert("L")


def norm(img, size=(80, 80)):
    px, xs, ys = img.load(), [], []
    for y in range(img.size[1]):
        for x in range(img.size[0]):
            if px[x, y] < 160:
                xs.append(x)
                ys.append(y)
    if not xs:
        return None
    return img.crop((min(xs), min(ys), max(xs) + 1, max(ys) + 1)).resize(size, Image.LANCZOS)


def corr(a, b):
    n = a.size[0] * a.size[1]
    pa, pb = a.load(), b.load()
    va = [(255 - pa[x, y]) / 255.0 for y in range(a.size[1]) for x in range(a.size[0])]
    vb = [(255 - pb[x, y]) / 255.0 for y in range(b.size[1]) for x in range(b.size[0])]
    ma, mb = sum(va) / n, sum(vb) / n
    num = sum((va[i] - ma) * (vb[i] - mb) for i in range(n))
    da = sum((v - ma) ** 2 for v in va) ** 0.5
    db = sum((v - mb) ** 2 for v in vb) ** 0.5
    return num / (da * db) if da and db else 0.0


verdicts = []
for pg, txt, cs, font, size in LINES:
    page = doc[pg - 1]
    ps = [c for c in cs if c["c"] == "p" and c["font"] == font]
    rs = [c for c in cs if c["c"] == RHO and c["font"] == font]
    if len(ps) < 2 or not rs:
        ps = [c for c in cs if c["c"] == "p"]
        rs = [c for c in cs if c["c"] == RHO]
    if len(ps) < 2 or len(rs) < 1:
        continue
    G = {("p", i): norm(render(page, c)) for i, c in enumerate(ps)}
    G.update({(RHO, i): norm(render(page, c)) for i, c in enumerate(rs)})
    pp = corr(G[("p", 0)], G[("p", 1)])
    rr = corr(G[(RHO, 0)], G[(RHO, 1)]) if len(rs) > 1 else None
    pr = corr(G[("p", 0)], G[(RHO, 0)])
    print("page %d | fonts %s | sizes %s pt" % (pg, font, size))
    print("   header text: %s" % txt.strip()[:96])
    print("   p instances: %d   rho instances: %d" % (len(ps), len(rs)))
    print("   corr( p , p )     = %.3f   <- same letter must match" % pp)
    if rr is not None:
        print("   corr( rho , rho ) = %.3f   <- same letter must match" % rr)
    print("   corr( p , rho )   = %.3f   <- must be clearly lower" % pr)
    # criterion: same-letter instances track each other closely, while p vs rho are
    # completely different letterforms (measured separation is ~0.95 vs ~0.09).
    ok = pp > 0.90 and pr < 0.50 and (rr is None or rr > 0.90)
    print("   -> %s" % ("PASS: the drawn statistic glyphs are 'p', distinct from %s" % RHO
                        if ok else "INCONCLUSIVE"))
    print("      (same-letter corr %.3f vs cross-letter corr %.3f)" % (pp, pr))
    verdicts.append(ok)
    print()

print("rho glyphs in the whole delivered PDF text layer: %d"
      % sum(p.get_text().count(RHO) for p in doc))
print("OVERALL: %s" % ("PASS - no rho/p glyph substitution in the statistic columns"
                       if all(verdicts) else "REVIEW"))
sys.exit(0 if all(verdicts) else 1)
