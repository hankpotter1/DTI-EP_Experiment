# -*- coding: utf-8 -*-
"""
DTI_manuscript_v6.md  ->  DTI_manuscript_v7.md

v7 = v6 + declared author-input items filled in.  Every edit is an ANCHORED
replacement that must match exactly once; the script aborts otherwise, so no edit
can silently no-op.

What is filled (authorised reuse of the companion MR submission, user instruction):
  * Funding                <- verbatim from mr-epilepsy/submission_v13_EpilepsyBehavior
                              (title_page_EB.md / manuscript_v13_EB.docx)
  * Author contributions   <- CRediT role structure of the companion MR study, restated
                              for this study; flagged for author confirmation
  * Acknowledgements       <- drafted ONLY from data/code sources actually used by this
                              study (verified in the manuscript body); the MR text is NOT
                              reused (its SCALLOP/ILAE/FinnGen/GTEx sources are unrelated)
  * Data availability      <- repository URL is still unknown -> "upon reasonable request"
                              wording, flagged for confirmation

Also fixed (defect found while verifying the author block):
  * `Kukun(1,*)` / `Wang(1,*)` - the literal asterisk of the co-corresponding marker was
    being consumed by the markdown italic parser, so the delivered v6 PDF/docx printed
    "Hanjiaerbieke Kukun(1,)" and "Yunling Wang(1,)".  Escaped here as `\\*` and honoured
    by the v7 converters (171_md_to_html_v7.py / 172_build_docx_v7.py).

Nothing is invented: no author role, no email, no ORCID and no data source is added that
was not either supplied by the user or verifiable in the manuscript body.
"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
MS = os.path.join(BASE, "manuscript")
SRC = os.path.join(MS, "DTI_manuscript_v6.md")
OUT = os.path.join(MS, "DTI_manuscript_v7.md")
EN, EM = "\u2013", "\u2014"          # en dash, em dash

src = open(SRC, encoding="utf-8").read()
EDITS = []


def rep(old, new, tag, expect=1):
    global src
    n = src.count(old)
    if n != expect:
        raise SystemExit("ABORT [%s]: found %d (expected %d):\n%r" % (tag, n, expect, old[:200]))
    src = src.replace(old, new)
    EDITS.append("%s  (%d occurrence%s)" % (tag, n, "" if n == 1 else "s"))


# ------------------------------------------------------------------ A. author block
# The co-corresponding marker "(1,*)" is literal text.  Escaped so the italic parser
# cannot treat "(1,*), Yunling Wang(1,*)" as one *italic* span and delete both asterisks.
rep(
    "Hanjiaerbieke Kukun(1,*), Yunling Wang(1,*)",
    "Hanjiaerbieke Kukun(1,\\*), Yunling Wang(1,\\*)",
    "A author block: literal '*' of the co-corresponding marker escaped",
)

# ------------------------------------------------------------------ B. declarations
FUNDING = (
    "This work was supported by the Tianshan Talent Key Talent Program of Xinjiang Uygur "
    "Autonomous Region Young Talent Promotion Fund Project (2024TSYCQNTJ0050), the "
    "Tianshan Talents Program" + EM + "Innovation Leading Talent in Science and Technology "
    "(2023TSYCLJ0027), and the Construction Project of the Smart Healthcare Innovation "
    "Center, Xinjiang Medical University (ZHYL-002)."
)

DATA_AVAIL = (
    "All evaluation sets, model outputs (per-pair predictions), analysis scripts and "
    "figures are available from the corresponding author upon reasonable request. Public "
    "data sources: ChEMBL [7,8]; BindingDB ChEMBL subset [9,10]; Davis et al. kinase "
    "panel [11]."
)

CREDIT = "\n".join([
    "- Jundi Liu: Conceptualization; Methodology; Software; Formal analysis; "
    "Visualization; Writing " + EN + " original draft.",
    "- Jingjing Duan: Data curation; Formal analysis; Investigation; Writing " + EN
    + " review and editing.",
    "- Hanjiaerbieke Kukun: Conceptualization; Supervision; Project administration; "
    "Funding acquisition; Writing " + EN + " review and editing.",
    "- Yunling Wang: Supervision; Resources; Funding acquisition; Writing " + EN
    + " review and editing.",
    "",
    "All authors approved the final version of the manuscript and agree to be "
    "accountable for all aspects of the work.",
    "",
    "[CRediT adapted from the companion MR study; please confirm author roles]",
])

ACK = "\n".join([
    "The authors thank the teams and developers of the public resources used in this "
    "study: the ChEMBL team, for the bioactivity data from which the evaluation sets "
    "were built; the BindingDB team, for the ChEMBL subset used to quantify source-corpus "
    "overlap; Davis and colleagues, for the kinase selectivity panel used as the "
    "in-domain positive control; the DeepPurpose developers, for the toolkit and the "
    "publicly released pretrained weights evaluated here; and the authors of DrugBAN, "
    "for releasing the code with which the DrugBAN model was trained. The authors "
    "further acknowledge the UniProt REST service (target accession verification), "
    "Europe PMC (literature search) and the RDKit developers (ligand descriptor "
    "computation).",
    "",
    "[Acknowledgements: drafted from the data/code sources actually used; please confirm]",
])

OLD_DECL = "\n".join([
    "**Funding.** [AUTHOR INPUT REQUIRED]",
    "**Competing interests.** The authors declare no competing interests.",
    "**Data availability.** All evaluation sets, model outputs (per-pair predictions), "
    "analysis scripts and figures are provided in the accompanying repository. Public "
    "data sources: ChEMBL [7,8]; BindingDB ChEMBL subset [9,10]; Davis et al. kinase "
    "panel [11].",
    "**Author contributions.** [AUTHOR INPUT REQUIRED]",
    "**Acknowledgements.** [AUTHOR INPUT REQUIRED]",
])

NEW_DECL = "\n".join([
    "**Funding.** " + FUNDING,
    "",
    "**Competing interests.** The authors declare no competing interests.",
    "",
    "**Data availability.** " + DATA_AVAIL,
    "",
    "**Author contributions.** CRediT author contributions.",
    "",
    CREDIT,
    "",
    "**Acknowledgements.** " + ACK,
])

rep(OLD_DECL, NEW_DECL,
    "B declarations: Funding / Data availability / Author contributions / Acknowledgements "
    "filled; items separated into their own paragraphs")

open(OUT, "w", encoding="utf-8").write(src)

# ------------------------------------------------------------------ report
print("=" * 78)
print("v7 written: %s  (%d chars, %d lines)" % (OUT, len(src), src.count("\n") + 1))
print("=" * 78)
for i, t in enumerate(EDITS, 1):
    print("  %2d. %s" % (i, t))

print()
print("--- residual checks on the v7 source ---")
print("   '[AUTHOR INPUT REQUIRED]' occurrences : %d" % src.count("[AUTHOR INPUT REQUIRED]"))
print("   'Fundings' occurrences                : %d" % src.count("Fundings"))
print("   '**Funding.**' occurrences            : %d" % src.count("**Funding.**"))
print("   bare '(1,*)' occurrences              : %d" % src.count("(1,*)"))
print("   escaped  '(1,\\*)' occurrences         : %d" % src.count("(1,\\*)"))
print("   'underpin' style placeholders left    : %s" % (
    [l[:60] for l in src.split("\n") if "[" in l and "REQUIRED" in l] or "none"))
