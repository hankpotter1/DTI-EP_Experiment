# -*- coding: utf-8 -*-
"""ORCID 校验位验证:判定哪个 ORCID 是有效的。

ORCID 校验算法:前 15 位数字,权重 2..8,2..8 循环,加权和 mod 11,
余数 -> (12 - rem) mod 11,10 记为 'X'。
"""
import sys

sys.stdout.reconfigure(encoding="utf-8")


def check(prefix15: str) -> str:
    digits = [int(c) for c in prefix15 if c.isdigit()]
    assert len(digits) == 15, "need 15 digits"
    total = 0
    for i, d in enumerate(digits):
        total += d * (2 + (i % 8))
    rem = total % 11
    cd = (12 - rem) % 11
    return "X" if cd == 10 else str(cd)


cands = [
    "0000-0001-7052-9710",  # DTI 稿(用户最近给的)
    "0000-0001-7052-9290",  # MR 投稿版
    "0000-0003-3333-7710",  # Wang
    "0009-0006-0663-6239",  # Liu
]
print("ORCID 校验位验证")
print("-" * 46)
for o in cands:
    body = o.replace("-", "")
    prefix, given_cd = body[:15], body[15]
    calc = check(prefix)
    ok = "✅ 有效" if calc == given_cd else "❌ 无效(校验位应为 %s)" % calc
    print("  %s  -> %s" % (o, ok))
