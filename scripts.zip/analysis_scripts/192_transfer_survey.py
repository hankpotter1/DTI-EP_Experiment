# -*- coding: utf-8 -*-
"""转投选刊核查(精简版):PLOS ONE 与替代刊是否真发过同类稿。全部来自 Europe PMC 实检。"""
import json
import sys
import time
import urllib.parse
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")
API = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
UA = {"User-Agent": "netpharm-transfer-survey"}

Q = {
    "PLOSONE_netpharm": '(JOURNAL:"PLoS One") AND (TITLE_ABS:"network pharmacology")',
    "PLOSONE_tcm": '(JOURNAL:"PLoS One") AND (TITLE_ABS:"traditional Chinese medicine")',
    "PLOSONE_herbpair": '(JOURNAL:"PLoS One") AND (TITLE_ABS:"herb pair" OR TITLE_ABS:"herbal pair" OR TITLE_ABS:"herb-pair")',
    "PLOSONE_negative": '(JOURNAL:"PLoS One") AND (TITLE_ABS:"negative results" OR TITLE_ABS:"null results")',
    "JEP_netpharm": '(JOURNAL:"Journal of Ethnopharmacology") AND (TITLE_ABS:"network pharmacology")',
    "netpharm_critique": '(TITLE_ABS:"network pharmacology") AND (TITLE_ABS:"limitations" OR TITLE_ABS:"pitfalls" OR TITLE_ABS:"challenges" OR TITLE_ABS:"reproducibility")',
    "netpharm_synergy": '(TITLE_ABS:"network pharmacology") AND (TITLE_ABS:"synergy" OR TITLE_ABS:"synergistic")',
}

out = {}
for k, q in Q.items():
    url = API + "?" + urllib.parse.urlencode(
        {"query": q, "format": "json", "pageSize": "6", "resultType": "core"})
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r:
            d = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        print("[%s] 失败: %s" % (k, str(e)[:70]), flush=True)
        continue
    n = d.get("hitCount")
    items = [{"title": x.get("title"), "journal": x.get("journalTitle"),
              "year": x.get("pubYear"), "doi": x.get("doi"), "pmid": x.get("pmid")}
             for x in d.get("resultList", {}).get("result", [])]
    out[k] = {"query": q, "hitCount": n, "items": items}
    print("\n=== %s | 命中 %s ===" % (k, n), flush=True)
    for it in items[:4]:
        print("  · [%s] %s | doi:%s" % (it["year"], (it["title"] or "")[:88], it["doi"]), flush=True)
    time.sleep(0.4)

json.dump(out, open(r"G:\HHH\openclaw-workspace\netpharm-toolkit\results\transfer_survey_journal.json",
                    "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("\n落盘: results/transfer_survey_journal.json", flush=True)
