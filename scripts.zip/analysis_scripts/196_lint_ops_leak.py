# -*- coding: utf-8 -*-
"""
稿件"运维/环境表述"闸门(lint)。
把"我们怎么做的"泄漏进正文的措辞一律拦下 —— 不依赖人眼复读。

用法: python 196_lint_ops_leak.py <稿件.md> [...]
退出码: 0 = 干净;1 = 命中(构包流程应据此失败)
"""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

# 违规词组:环境/运维/本地条件 —— 这些属于代码仓,不属于论文
BANNED = [
    r"in our (environment|setup|workflow|network|pipeline|hands)",
    r"(not|un)reliably reachable",
    r"reachable in our",
    r"engineering record",
    r"not in this manuscript",
    r"we could not obtain",
    r"we were unable to (download|obtain|access)",
    r"failed to (download|connect)",
    r"proxy",
    r"hf-mirror",
    r"huggingface\.co",
    r"ghproxy",
    r"mirror (site|source)s?",
    r"(本地|我们的)(代理|网络|环境)",
    r"网络(不通|不可达|限制)",
    r"墙",
    r"CDN",
]
# 白名单:软硬件规格属方法学(复现性),允许
ALLOW = [
    r"Windows 1[01]", r"RTX \d+", r"torch \d", r"CUDA ?\d", r"Python 3\.\d",
    r"numpy \d", r"dgl \d", r"DeepPurpose \d",
]

bad_total = 0
for path in sys.argv[1:]:
    try:
        txt = open(path, encoding="utf-8").read()
    except OSError as e:
        print("跳过(读不到): %s | %s" % (path, e), flush=True)
        continue
    hits = []
    for pat in BANNED:
        for m in re.finditer(pat, txt, re.I):
            line = txt[: m.start()].count("\n") + 1
            snippet = txt[max(0, m.start() - 60): m.end() + 60].replace("\n", " ")
            # 白名单豁免
            if any(re.search(a, snippet, re.I) for a in ALLOW):
                continue
            hits.append((line, pat, snippet.strip()))
    print("=== %s: %d 处违规 ===" % (path.split("\\")[-1], len(hits)), flush=True)
    for line, pat, sn in hits:
        print("  L%-5d [%s]  …%s…" % (line, pat, sn), flush=True)
    bad_total += len(hits)

print("\n合计违规: %d" % bad_total, flush=True)
sys.exit(1 if bad_total else 0)
