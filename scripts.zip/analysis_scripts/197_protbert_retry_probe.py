# -*- coding: utf-8 -*-
"""ProtBert 获取多路径探测:一次性试遍候选镜像/代理/来源,报告真实可达性。

判据:必须能取到**文件字节**(200 + content-length + 非 HTML),重定向到 huggingface.co 视为失败。
"""
import sys

sys.stdout.reconfigure(encoding="utf-8")
import requests

TIMEOUT = 25
PROXIES = {"http": "http://127.0.0.1:7897", "https": "http://127.0.0.1:7897"}

CANDS = [
    ("HF 直连", "https://huggingface.co/Rostlab/prot_bert/resolve/main/config.json", None),
    ("HF 直连(经代理)", "https://huggingface.co/Rostlab/prot_bert/resolve/main/config.json", PROXIES),
    ("hf-mirror.com", "https://hf-mirror.com/Rostlab/prot_bert/resolve/main/config.json", None),
    ("hf-mirror.com(经代理)", "https://hf-mirror.com/Rostlab/prot_bert/resolve/main/config.json", PROXIES),
    ("hf-mirror.com API", "https://hf-mirror.com/api/models/Rostlab/prot_bert", None),
    ("HF API(经代理)", "https://huggingface.co/api/models/Rostlab/prot_bert", PROXIES),
    ("ModelScope 文件API", "https://www.modelscope.cn/api/v1/models/Rostlab/prot_bert/repo/files?Revision=master", None),
    ("ModelScope 搜索", "https://www.modelscope.cn/api/v1/dolphin/models?PageSize=10&Query=prot_bert", None),
    ("aliendao.cn", "https://aliendao.cn/models/Rostlab/prot_bert", None),
    ("aifasthub.com", "https://aifasthub.com/Rostlab/prot_bert/resolve/main/config.json", None),
    ("gh-proxy(raw)", "https://gh-proxy.com/https://raw.githubusercontent.com/Rostlab/prot_bert/main/config.json", PROXIES),
    ("jsdelivr(gh)", "https://cdn.jsdelivr.net/gh/Rostlab/prot_bert@main/config.json", None),
    ("gitclone", "https://gitclone.com/github.com/Rostlab/prot_bert", None),
    ("SJTU mirror", "https://mirror.sjtu.edu.cn/hugging-face-models/Rostlab/prot_bert/resolve/main/config.json", None),
]

for name, url, prox in CANDS:
    try:
        r = requests.get(url, timeout=TIMEOUT, allow_redirects=True,
                         stream=True, proxies=prox, headers={"User-Agent": "Mozilla/5.0"})
        cl = r.headers.get("content-length", "?")
        ct = (r.headers.get("content-type") or "")[:32]
        final = r.url
        bounced = "huggingface.co" in final and "hf-mirror" in url
        # 读一小段判断是否为真实文件
        chunk = next(r.iter_content(256), b"")
        head = chunk[:60].decode("utf-8", "ignore").replace("\n", " ")
        r.close()
        tag = "⚠️重定向到HF" if bounced else ("✅疑似真实文件" if r.status_code == 200 and ct and "html" not in ct else "")
        print("%-22s [%s] len=%-10s %-20s %s" % (name, r.status_code, cl, ct, tag))
        if tag.startswith("✅"):
            print("      ↳ 首 60 字节: %s" % head)
    except Exception as e:
        print("%-22s ❌ %s" % (name, str(e)[:70]))
