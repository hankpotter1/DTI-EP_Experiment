# -*- coding: utf-8 -*-
"""ProtBert 下载(走 hf-mirror,禁用代理 —— 探测显示代理会掐断该路径)。"""
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")
import requests

DEST = r"G:\HHH\openclaw-workspace\netpharm-toolkit\thirdparty\conplex\prot_bert_local"
BASES = [
    "https://hf-mirror.com/Rostlab/prot_bert/resolve/main",
    "https://aifasthub.com/Rostlab/prot_bert/resolve/main",
]
FILES = ["config.json", "vocab.txt", "tokenizer_config.json", "special_tokens_map.json",
         "pytorch_model.bin"]

os.makedirs(DEST, exist_ok=True)
# 关键:显式禁用代理(环境变量与 requests 会话双保险)
for k in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY", "all_proxy"):
    os.environ.pop(k, None)
S = requests.Session()
S.trust_env = False
S.proxies = {}

for fn in FILES:
    dst = os.path.join(DEST, fn)
    if os.path.isfile(dst) and os.path.getsize(dst) > 0:
        print("跳过(已存在) %-26s %.1f MB" % (fn, os.path.getsize(dst) / 1048576), flush=True)
        continue
    done = False
    for base in BASES:
        if done:
            break
        url = "%s/%s" % (base, fn)
        for attempt in range(3):
            try:
                t0 = time.time()
                with S.get(url, stream=True, timeout=600, allow_redirects=True) as r:
                    if r.status_code != 200:
                        raise RuntimeError("HTTP %s" % r.status_code)
                    total = int(r.headers.get("content-length") or 0)
                    tmp = dst + ".part"
                    got = 0
                    with open(tmp, "wb") as f:
                        for ch in r.iter_content(1024 * 1024):
                            if ch:
                                f.write(ch)
                                got += len(ch)
                                if total and got % (50 * 1048576) < (1024 * 1024):
                                    print("   … %s %.0f/%.0f MB" % (fn, got / 1048576, total / 1048576),
                                          flush=True)
                    os.replace(tmp, dst)
                print("✅ %-26s %.1f MB  (%.0fs, 源=%s)" % (fn, got / 1048576, time.time() - t0,
                                                          base.split("/")[2]), flush=True)
                done = True
                break
            except Exception as e:
                print("⚠️ %s @%s 第%d次: %s" % (fn, base.split("/")[2], attempt + 1, str(e)[:80]),
                      flush=True)
                time.sleep(3 * (attempt + 1))
    if not done:
        print("❌ %s 全部源失败" % fn, flush=True)

print("\n=== 结果 ===", flush=True)
for fn in FILES:
    p = os.path.join(DEST, fn)
    print("  %-28s %s" % (fn, ("%.1f MB" % (os.path.getsize(p) / 1048576)) if os.path.isfile(p) else "缺失"),
          flush=True)
