# -*- coding: utf-8 -*-
"""
A 路线 · 第 1 步:构建 ChEMBL 配体-靶点参考集(供配体相似性靶点预测使用)

原理(等价 SwissTargetPrediction / SEA):
  若查询化合物与某个已知配体高度相似,则继承该配体的靶点。
参考集质量决定预测质量,故:
  · 只用实测活性(pchembl_value >= 6)且靶点为人类单蛋白
  · 每个靶点最多保留 N_REF_PER_TARGET 个配体,避免热门靶点霸榜
  · 落盘为 CSV(分子/ SMILES / 靶点 / pChEMBL),便于复现
"""
import os
import time
import json
import urllib.parse
import urllib.request
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CACHE = os.path.join(ROOT, "cache", "searef")
OUT = os.path.join(ROOT, "results")
os.makedirs(CACHE, exist_ok=True)
os.makedirs(OUT, exist_ok=True)

CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
UA = {"User-Agent": "netpharm-searef"}

MAX_PAGES = int(os.environ.get("MAX_PAGES", "40"))      # 每页 1000 条
N_REF_PER_TARGET = 60
MIN_PCHEMBL = 6.0


def fetch(url, name, timeout=120, attempts=5):
    """带重试 + 指数退避;缓存原子写入(避免读到半截 JSON)。"""
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        try:
            with open(cf, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            try:
                os.remove(cf)      # 缓存损坏(可能是半截写入)-> 重抓
            except Exception:
                pass
    last = None
    for k in range(attempts):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode("utf-8"))
            tmp = cf + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp, cf)    # 原子替换
            time.sleep(0.4)
            return data
        except Exception as e:
            last = e
            time.sleep(1.5 * (k + 1))
    raise last


print("[1] 抓 ChEMBL 实测活性(pchembl>=%s, 人类靶点, 最多 %d 页)" % (MIN_PCHEMBL, MAX_PAGES), flush=True)
pairs = defaultdict(dict)      # (mol, target) -> pchembl
n_rec, off = 0, 0
for page in range(MAX_PAGES):
    url = (CHEMBL + "/activity.json?pchembl_value__gte=" + str(MIN_PCHEMBL)
           + "&target_organism=Homo%20sapiens&standard_relation=%3D&limit=1000&offset=" + str(off))
    try:
        d = fetch(url, "act_%04d.json" % page)
    except Exception as e:
        print("   [warn] page %d: %s" % (page, str(e)[:70]), flush=True)
        break
    acts = d.get("activities", [])
    if not acts:
        break
    for a in acts:
        mid, tid, pv = a.get("molecule_chembl_id"), a.get("target_chembl_id"), a.get("pchembl_value")
        if not mid or not tid or pv is None:
            continue
        try:
            pv = float(pv)
        except Exception:
            continue
        if pv < MIN_PCHEMBL:
            continue
        key = (mid, tid)
        if key not in pairs or pv > pairs[key]:
            pairs[key] = pv
    n_rec += len(acts)
    off += 1000
    if page % 5 == 0:
        print("   已抓 %d 条,累计配对 %d" % (n_rec, len(pairs)), flush=True)
    if len(acts) < 1000:
        break

print("   总计读取 %d 条活性,去重后配对 %d" % (n_rec, len(pairs)), flush=True)

# ---- 每靶点限量 ----
by_target = defaultdict(list)
for (mid, tid), pv in pairs.items():
    by_target[tid].append((mid, pv))
sel = {}
for tid, lst in by_target.items():
    lst.sort(key=lambda kv: -kv[1])
    for mid, pv in lst[:N_REF_PER_TARGET]:
        sel[(mid, tid)] = pv
mols = sorted({m for m, _ in sel})
print("   限量后:靶点 %d 个,配对 %d,唯一分子 %d" % (len(by_target), len(sel), len(mols)), flush=True)

# ---- 批量取 SMILES ----
print("[2] 批量取 SMILES ...", flush=True)
smiles = {}
BATCH = 20
for i in range(0, len(mols), BATCH):
    batch = mols[i:i + BATCH]
    url = "%s/molecule.json?molecule_chembl_id__in=%s&limit=100" % (CHEMBL, ",".join(batch))
    try:
        d = fetch(url, "mols_%05d.json" % i)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st:
                smiles[mid] = st
    except Exception as e:
        print("   [warn] batch %d: %s" % (i, str(e)[:60]), flush=True)
    if i % 200 == 0:
        print("   ... %d/%d,已得 %d" % (i, len(mols), len(smiles)), flush=True)
print("   得到 SMILES: %d / %d" % (len(smiles), len(mols)), flush=True)

# ---- 靶点名称 ----
print("[3] 取靶点名称 ...", flush=True)
tids = sorted({t for _, t in sel})
tmeta = {}
for i in range(0, len(tids), BATCH):
    batch = tids[i:i + BATCH]
    url = "%s/target.json?target_chembl_id__in=%s&limit=100" % (CHEMBL, ",".join(batch))
    try:
        d = fetch(url, "tgts_%05d.json" % i)
        for t in d.get("targets", []):
            tid = t.get("target_chembl_id")
            comps = t.get("target_components") or [{}]
            acc = (comps[0].get("accession") if comps else None) or ""
            prefs = t.get("pref_name") or ""
            tmeta[tid] = {"pref_name": prefs, "accession": acc,
                          "type": t.get("target_type") or ""}
    except Exception as e:
        print("   [warn] targets %d: %s" % (i, str(e)[:60]), flush=True)
print("   靶点元数据: %d" % len(tmeta), flush=True)

# ---- 落盘 ----
out_csv = os.path.join(OUT, "cheml_ligand_target_reference.csv")
with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
    import csv as _csv
    w = _csv.writer(f)
    w.writerow(["molecule_chembl_id", "smiles", "target_chembl_id", "pchembl_value",
                "target_name", "uniprot", "target_type"])
    for (mid, tid), pv in sorted(sel.items()):
        if mid not in smiles:
            continue
        tm = tmeta.get(tid, {})
        w.writerow([mid, smiles[mid], tid, pv, tm.get("pref_name", ""), tm.get("accession", ""),
                    tm.get("type", "")])
print("\n落盘:", out_csv)
print("参考集规模: 记录 %d" % sum(1 for k in sel if k[0] in smiles))
print("唯一靶点 %d,唯一分子 %d" % (len({t for _, t in sel}), len(smiles)))
