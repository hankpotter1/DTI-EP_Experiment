# -*- coding: utf-8 -*-
"""
A-2 第 1 步:从 COCONUT 全库(667 MB)抽取「定痫丸各味药」的成分。

原理:COCONUT 第 39 列 `organisms` 记录该化合物的产生物种(含植物学名)。
     按各药材的**植物学名**做匹配即可拿到成分 + SMILES + 类药性字段。

口径(Hank 已定 (a)):COCONUT 无 TCMSP 的 OB/DL,改用 RDKit 类药性规则替代,
     并在方法中如实写明差异。本步只做抽取;过滤在下一步。
"""
import csv
import os
import re
import sys
import io

csv.field_size_limit(10 ** 9)
sys.stdout.reconfigure(encoding="utf-8")

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
SRC = r"G:\HHH\openclaw-workspace\downloads\coconut_full\coconut_csv-09-2026.csv"
OUT = os.path.join(BASE, "results", "dingxian_compounds_raw.csv")

# 药材 -> (中文名, 匹配用的学名正则片段)
# 注:朱砂(HgS)、琥珀 为矿物药,按既定方案剔除
HERBS = [
    ("天麻",     r"Gastrodia\s+elata"),
    ("川贝母",   r"Fritillaria\s+(cirrhosa|unibracteata|przewalskii|delavayi)"),
    ("胆南星",   r"Arisaema\s+(erubescens|heterophyllum|amurense)"),
    ("半夏",     r"Pinellia\s+ternata"),
    ("陈皮",     r"Citrus\s+reticulata"),
    ("茯苓",     r"(Poria|Wolfiporia)\s+cocos"),
    ("丹参",     r"Salvia\s+miltiorrhiza"),
    ("麦冬",     r"Ophiopogon\s+japonicus"),
    ("石菖蒲",   r"Acorus\s+(tatarinowii|gramineus)"),
    ("远志",     r"Polygala\s+tenuifolia"),
    ("全蝎",     r"(Mesobuthus|Buthus)\s+martensii"),
    ("僵蚕",     r"Bombyx\s+mori"),
    ("甘草",     r"Glycyrrhiza\s+uralensis"),
    ("灯心草",   r"Juncus\s+effusus"),
    ("钩藤",     r"Uncaria\s+rhynchophylla"),      # 定痫丸加减方常含,一并抽取备用
]

KEEP = ["identifier", "canonical_smiles", "name", "molecular_weight", "alogp",
        "topological_polar_surface_area", "rotatable_bond_count",
        "hydrogen_bond_acceptors_lipinski", "hydrogen_bond_donors_lipinski",
        "lipinski_rule_of_five_violations", "qed_drug_likeliness", "np_likeness",
        "contains_sugar", "organisms"]

pat = [(zh, re.compile(rx, re.I)) for zh, rx in HERBS]
hits = []
n = 0
with open(SRC, encoding="utf-8", newline="") as f:
    rdr = csv.DictReader(f)
    for row in rdr:
        n += 1
        if n % 100000 == 0:
            print("  ... 已扫 %d 行,命中 %d" % (n, len(hits)), flush=True)
        org = row.get("organisms") or ""
        if not org:
            continue
        for zh, rx in pat:
            if rx.search(org):
                rec = {"herb": zh}
                for k in KEEP:
                    rec[k] = row.get(k, "")
                hits.append(rec)

print("总行数 %d,命中 %d" % (n, len(hits)), flush=True)

with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["herb"] + KEEP)
    w.writeheader()
    w.writerows(hits)
print("落盘:", OUT, flush=True)

# 汇总
from collections import Counter
c = Counter(h["herb"] for h in hits)
print("\n=== 各药材命中成分数 ===", flush=True)
for zh, _ in HERBS:
    print("  %-8s %d" % (zh, c.get(zh, 0)), flush=True)
