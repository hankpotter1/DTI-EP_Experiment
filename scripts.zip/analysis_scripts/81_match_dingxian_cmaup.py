# -*- coding: utf-8 -*-
"""在 CMAUP Plants 表中定位定痫丸各味药(按学名/属名匹配)。"""
import csv
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")
D = r"G:\HHH\openclaw-workspace\downloads\cmaup"
PLANTS = os.path.join(D, "CMAUPv2.0_download_Plants.txt")

# 药材 -> 匹配用的学名/属名片段(小写比较)
HERBS = [
    ("天麻",     ["gastrodia elata"]),
    ("川贝母",   ["fritillaria cirrhosa", "fritillaria unibracteata", "fritillaria przewalskii",
                  "fritillaria delavayi", "fritillaria thunbergii"]),
    ("胆南星",   ["arisaema erubescens", "arisaema heterophyllum", "arisaema amurense",
                  "arisaema consanguineum"]),
    ("半夏",     ["pinellia ternata", "pinellia pedatisecta"]),
    ("陈皮",     ["citrus reticulata", "citrus chachi", "citrus tangerina"]),
    ("茯苓",     ["poria cocos", "wolfiporia cocos", "pachyma cocos"]),
    ("丹参",     ["salvia miltiorrhiza"]),
    ("麦冬",     ["ophiopogon japonicus"]),
    ("石菖蒲",   ["acorus tatarinowii", "acorus gramineus", "acorus calamus"]),
    ("远志",     ["polygala tenuifolia", "polygala sibirica"]),
    ("全蝎",     ["mesobuthus martensii", "buthus martensii", "scorpio"]),
    ("僵蚕",     ["bombyx mori"]),
    ("甘草",     ["glycyrrhiza uralensis", "glycyrrhiza glabra", "glycyrrhiza inflata"]),
    ("灯心草",   ["juncus effusus", "juncus setchuensis"]),
    ("钩藤",     ["uncaria rhynchophylla", "uncaria tomentosa", "uncaria sinensis"]),
]

rows = []
with open(PLANTS, encoding="utf-8", newline="") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        rows.append(r)
print("CMAUP Plants 表: %d 条\n" % len(rows), flush=True)

print("%-8s %-8s %s" % ("药材", "命中", "匹配到的物种(Plant_ID)"))
print("-" * 100)
found = {}
for zh, pats in HERBS:
    hits = []
    for r in rows:
        hay = " ".join(str(r.get(k) or "") for k in ("Plant_Name", "Species_Name", "Genus_Name")).lower()
        for p in pats:
            if p in hay:
                hits.append((r.get("Plant_ID"), r.get("Plant_Name"), r.get("Species_Name")))
                break
    found[zh] = hits
    show = "; ".join("%s(%s)" % (h[1][:26], h[0]) for h in hits[:4])
    print("%-8s %-8d %s" % (zh, len(hits), show[:110]), flush=True)

total = sum(len(v) for v in found.values())
print("\n合计匹配物种条目: %d" % total, flush=True)
with open(r"G:\HHH\openclaw-workspace\netpharm-toolkit\results\dingxian_cmaup_plants.csv",
          "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["herb", "plant_id", "plant_name", "species_name"])
    for zh, hits in found.items():
        for pid, pn, sn in hits:
            w.writerow([zh, pid, pn, sn])
print("落盘: results/dingxian_cmaup_plants.csv", flush=True)
