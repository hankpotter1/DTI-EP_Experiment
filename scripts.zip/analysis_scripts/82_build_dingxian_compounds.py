# -*- coding: utf-8 -*-
"""
A-2 第 2 步:构建定痫丸成分表(植物药部分,CMAUP)
链路:Plants(药材→Plant_ID) → Plant_Ingredient(→Ingredient_ID)
      → Ingredients_All(名称/SMILES) → Human_Oral_Bioavailability(Hob 等)
过滤:Hob(人体口服生物利用度)预测为阳性 —— 对应 TCMSP 的 OB 口径意图
"""
import csv
import os
import sys
from collections import defaultdict

sys.stdout.reconfigure(encoding="utf-8")
csv.field_size_limit(10 ** 9)

D = r"G:\HHH\openclaw-workspace\downloads\cmaup"
OUT = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"


def load(name, delim="\t"):
    p = os.path.join(D, name)
    with open(p, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter=delim))


# ---- 药材 -> Plant_ID ----
plants = load("CMAUPv2.0_download_Plants.txt")
HERB_PAT = {
    "天麻": ["Gastrodia Elata"],
    "川贝母": ["Fritillaria Unibracteata", "Fritillaria Przewalskii", "Fritillaria Cirrhosa",
               "Fritillaria Delavayi", "Fritillaria Thunbergii"],
    "胆南星": ["Arisaema Amurense", "Arisaema Heterophyllum", "Arisaema Erubescens",
               "Arisaema Consanguineum"],
    "半夏": ["Pinellia Ternata", "Pinellia Pedatisecta"],
    "陈皮": ["Citrus Reticulata", "Citrus Chachiensis", "Citrus Tangerina"],
    "丹参": ["Salvia Miltiorrhiza"],
    "麦冬": ["Ophiopogon Japonicus"],
    "石菖蒲": ["Acorus Tatarinowii", "Acorus Gramineus", "Acorus Calamus"],
    "远志": ["Polygala Tenuifolia", "Polygala Sibirica"],
    "甘草": ["Glycyrrhiza Uralensis", "Glycyrrhiza Glabra", "Glycyrrhiza Inflata"],
    "灯心草": ["Juncus Effusus"],
    "钩藤": ["Uncaria Rhynchophylla", "Uncaria Sinensis", "Uncaria Tomentosa"],
}
herb2pid = defaultdict(list)
for r in plants:
    pn = (r.get("Plant_Name") or "")
    for zh, names in HERB_PAT.items():
        if any(pn.startswith(n) for n in names):
            herb2pid[zh].append(str(r.get("Plant_ID")).strip())
print("=== 药材 → Plant_ID ===")
for zh in HERB_PAT:
    print("  %-8s %s" % (zh, ",".join(herb2pid.get(zh, [])) or "(无)"), flush=True)

# ---- Plant_ID -> Ingredient_ID ----
pi = load("CMAUPv2.0_download_Plant_Ingredient_Associations_allIngredients.txt")
pid2ing = defaultdict(set)
for r in pi:
    vals = list(r.values())
    pid, ing = str(vals[0]).strip(), str(vals[1]).strip()
    pid2ing[pid].add(ing)
print("\nPlant_Ingredient 关联: %d 条" % len(pi), flush=True)

# ---- Ingredient 元数据 ----
ings = load("CMAUPv2.0_download_Ingredients_All.txt")
print("Ingredients_All 列:", list(ings[0].keys()) if ings else "(空)", flush=True)
ing_meta = {}
for r in ings:
    k = str(r.get("Ingredient_ID") or r.get("NPC_ID") or "").strip()
    if k:
        ing_meta[k] = r

# ---- Hob(口服生物利用度)----
hob = load("CMAUPv2.0_download_Human_Oral_Bioavailability_information_of_Ingredients_All.txt")
print("Hob 列:", list(hob[0].keys()) if hob else "(空)", flush=True)
ing_hob = {}
for r in hob:
    k = str(r.get("Ingredient_ID") or "").strip()
    if k:
        ing_hob[k] = r

# ---- 组装 ----
rows = []
for zh, pids in herb2pid.items():
    seen = set()
    for pid in pids:
        for ing in pid2ing.get(pid, ()):
            if ing in seen:
                continue
            seen.add(ing)
            m = ing_meta.get(ing, {})
            h = ing_hob.get(ing, {})
            rows.append({
                "herb": zh, "plant_id": pid, "ingredient_id": ing,
                "name": m.get("Ingredient_Name") or m.get("Name") or "",
                "smiles": h.get("SMILES") or m.get("SMILES") or "",
                "MW": h.get("MW") or m.get("MW") or "",
                "XLOGP3": h.get("XLOGP3") or "",
                "TPSA": h.get("TPSA") or "",
                "ESOL": h.get("ESOL") or "",
                "Pred_Hob": h.get("Prediction_Hob") or "",
                "Pred_Swissadme": h.get("Prediction_Swissadme") or "",
                "Pred_Both": h.get("Prediction_Hob&Swissadme") or "",
            })

out_csv = os.path.join(OUT, "dingxian_compounds_cmaup_raw.csv")
cols = ["herb", "plant_id", "ingredient_id", "name", "smiles", "MW", "XLOGP3", "TPSA", "ESOL",
        "Pred_Hob", "Pred_Swissadme", "Pred_Both"]
with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(rows)

print("\n=== 各药材成分数(去重) ===", flush=True)
from collections import Counter
c = Counter(r["herb"] for r in rows)
for zh in HERB_PAT:
    print("  %-8s %d" % (zh, c.get(zh, 0)), flush=True)

with_smiles = sum(1 for r in rows if r["smiles"])
with_hob = sum(1 for r in rows if str(r["Pred_Hob"]).strip() == "1")
with_both = sum(1 for r in rows if str(r["Pred_Both"]).strip() == "1")
print("\n总成分记录 %d | 有 SMILES %d | Hob 阳性 %d | Hob&SwissADME 双阳性 %d" % (
    len(rows), with_smiles, with_hob, with_both), flush=True)
print("落盘:", out_csv, flush=True)
