# -*- coding: utf-8 -*-
"""
A-2 第 3 步:补三味「非植物药」(CMAUP 只收植物)
  茯苓  = Poria cocos / Wolfiporia cocos   (真菌)
  全蝎  = Mesobuthus martensii             (节肢动物)
  僵蚕  = Bombyx mori                      (昆虫,白僵菌感染)
来源:COCONUT(organisms 字段),并加**特异度过滤**(物种数 <= 10)以压制假阳性
     —— 该字段是"化合物出现过的物种并集",不过滤会混入大量初级代谢物。
"""
import csv
import os
import re
import sys
from collections import Counter

sys.stdout.reconfigure(encoding="utf-8")
csv.field_size_limit(10 ** 9)

SRC = r"G:\HHH\openclaw-workspace\downloads\coconut_full\coconut_csv-09-2026.csv"
OUT = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"

NONPLANT = [
    ("茯苓",  re.compile(r"(Poria|Wolfiporia)\s+cocos", re.I)),
    ("全蝎",  re.compile(r"(Mesobuthus|Buthus)\s+martensii", re.I)),
    ("僵蚕",  re.compile(r"Bombyx\s+mori", re.I)),
]
MAX_SP = 10          # 特异度阈值

KEEP = ["identifier", "canonical_smiles", "name", "molecular_weight", "alogp",
        "topological_polar_surface_area", "rotatable_bond_count",
        "hydrogen_bond_acceptors_lipinski", "hydrogen_bond_donors_lipinski",
        "lipinski_rule_of_five_violations", "qed_drug_likeliness", "np_likeness"]

rows, allc, spec = [], Counter(), Counter()
n = 0
with open(SRC, encoding="utf-8", newline="") as f:
    for row in csv.DictReader(f):
        n += 1
        org = row.get("organisms") or ""
        if not org:
            continue
        parts = [p.strip() for p in org.split("|") if p.strip()]
        nsp = len(parts)
        for zh, rx in NONPLANT:
            if not any(rx.search(p) for p in parts):
                continue
            allc[zh] += 1
            if nsp <= MAX_SP:
                spec[zh] += 1
                rec = {"herb": zh, "n_organisms": nsp}
                for k in KEEP:
                    rec[k] = row.get(k, "")
                rows.append(rec)

with open(os.path.join(OUT, "dingxian_compounds_nonplant.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["herb", "n_organisms"] + KEEP)
    w.writeheader()
    w.writerows(rows)

print("COCONUT 扫描 %d 行" % n, flush=True)
print("\n=== 三味非植物药 ===\n  %-6s %8s %12s" % ("药材", "全部命中", "特异度<=10"), flush=True)
for zh, _ in NONPLANT:
    print("  %-6s %8d %12d" % (zh, allc[zh], spec[zh]), flush=True)
print("\n保留记录 %d 条(落盘: results/dingxian_compounds_nonplant.csv)" % len(rows), flush=True)
if rows:
    c = Counter(r["herb"] for r in rows)
    for zh, _ in NONPLANT:
        print("  %-6s %d" % (zh, c.get(zh, 0)), flush=True)
    print("\n样例:", flush=True)
    for r in rows[:5]:
        print("   %-6s %-40s MW=%s Lipinski=%s" % (
            r["herb"], (r["name"] or "")[:40], r["molecular_weight"], r["lipinski_rule_of_five_violations"]), flush=True)
