# -*- coding: utf-8 -*-
"""
A-2 第 4 步:合并 + 过滤,定稿定痫丸成分表。
  · 植物药(CMAUP):以 Hob & SwissADME 双阳性为「口服生物利用度」等价门槛
  · 非植物药(COCONUT):以 Lipinski 违规 <= 2 为门槛
  · 统一输出:herb / name / smiles / MW / logP / TPSA + 来源列
口径说明(Hank 已定方案 a):CMAUP 的 Hob 为二分类预测,与 TCMSP 的 OB% 不完全等价,
  方法中如实写明"以双模型口服生物利用度预测替代 OB≥30%"。
"""
import csv
import os
import sys
from collections import Counter

sys.stdout.reconfigure(encoding="utf-8")
csv.field_size_limit(10 ** 9)

RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
cmaup = list(csv.DictReader(open(os.path.join(RES, "dingxian_compounds_cmaup_raw.csv"), encoding="utf-8-sig")))
nonp = list(csv.DictReader(open(os.path.join(RES, "dingxian_compounds_nonplant.csv"), encoding="utf-8-sig")))

rows = []

# --- 植物药:双阳性优先;若某药材双阳性为空,回退到 Hob 单阳性(并标注级别)---
by_herb = {}
for r in cmaup:
    by_herb.setdefault(r["herb"], []).append(r)

for zh, rs in by_herb.items():
    dbl = [r for r in rs if str(r.get("Pred_Both", "")).strip() == "1" and (r.get("smiles") or "").strip()]
    if dbl:
        picked, lvl = dbl, "Hob&SwissADME+"
    else:
        picked = [r for r in rs if str(r.get("Pred_Hob", "")).strip() == "1" and (r.get("smiles") or "").strip()]
        lvl = "Hob+"
        if not picked:                      # 连 Hob 都为空,则收全部有 SMILES 的
            picked = [r for r in rs if (r.get("smiles") or "").strip()]
            lvl = "all(no-Hob)"
    if lvl != "Hob&SwissADME+":
        print("[回退] %s -> %s (%d 个)" % (zh, lvl, len(picked)), flush=True)
    for r in picked:
        rows.append({
            "herb": zh, "source": "CMAUP", "ingredient_id": r["ingredient_id"],
            "name": (r.get("name") or "").strip(), "smiles": r["smiles"].strip(),
            "MW": r.get("MW", ""), "logP": r.get("XLOGP3", ""), "TPSA": r.get("TPSA", ""),
            "filter": lvl,
        })

# --- 非植物药:Lipinski 过滤 ---
def safe_float(x):
    try:
        return float(x)
    except Exception:
        return None

for r in nonp:
    viol = safe_float(r.get("lipinski_rule_of_five_violations"))
    if viol is None or viol > 2:
        continue
    if not (r.get("canonical_smiles") or "").strip():
        continue
    rows.append({
        "herb": r["herb"], "source": "COCONUT", "ingredient_id": r["identifier"],
        "name": (r.get("name") or "").strip(), "smiles": r["canonical_smiles"].strip(),
        "MW": r.get("molecular_weight", ""), "logP": r.get("alogp", ""),
        "TPSA": r.get("topological_polar_surface_area", ""),
        "filter": "Lipinski<=2",
    })

# 去重(同 herb + 同 smiles)
seen, dedup = set(), []
for r in rows:
    k = (r["herb"], r["smiles"])
    if k in seen:
        continue
    seen.add(k)
    dedup.append(r)

out = os.path.join(RES, "dingxian_compound_table.csv")
cols = ["herb", "source", "ingredient_id", "name", "smiles", "MW", "logP", "TPSA", "filter"]
with open(out, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(dedup)

print("=== 定痫丸成分表(定稿)===", flush=True)
print("成分记录: %d(去重后)" % len(dedup), flush=True)
c = Counter(r["herb"] for r in dedup)
print("\n  %-8s %6s  %s" % ("药材", "成分数", "来源"), flush=True)
for zh in ["天麻", "川贝母", "胆南星", "半夏", "陈皮", "茯苓", "丹参", "麦冬", "石菖蒲",
           "远志", "全蝎", "僵蚕", "甘草", "灯心草", "钩藤"]:
    srcs = sorted({r["source"] for r in dedup if r["herb"] == zh})
    print("  %-8s %6d  %s" % (zh, c.get(zh, 0), ",".join(srcs)), flush=True)
print("\n合计药材数: %d / 15(朱砂、琥珀为矿物药,按方案剔除)" % len(c), flush=True)
print("落盘:", out, flush=True)
