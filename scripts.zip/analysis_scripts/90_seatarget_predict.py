# -*- coding: utf-8 -*-
"""
A-3 留一法相似性靶点预测(SEA / SwissTargetPrediction 原理)

参考集:ChEMBL 实测活性 -> 配体-靶点对(单一蛋白,带 UniProt)
查询集:定痫丸 819 个成分
方法  :ECFP4(Morgan r=2, 2048 bit)+ Tanimoto 相似性 -> 靶点迁移
留一法:若查询分子与参考集中的某分子 SMILES 完全相同,预测时**先剔除该分子**,
        避免"自己预测自己"的循环论证。

输出:compound -> 预测靶点(带最大相似度、支持邻居数、打分)
"""
import csv
import os
import sys
from collections import defaultdict

sys.stdout.reconfigure(encoding="utf-8")
csv.field_size_limit(10 ** 9)

RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
REF = os.path.join(RES, "cheml_ligand_target_reference.csv")
QRY = os.path.join(RES, "dingxian_compound_table.csv")
OUT = os.path.join(RES, "dingxian_predicted_targets.csv")

SIM_CUT = 0.40          # SEA 风格阈值:相似度 >= 0.40 才迁移
TOP_N = 8               # 每个化合物最多保留的靶点数

from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, DataStructs

RDLogger.DisableLog("rdApp.*")


def fp_of(smi):
    m = Chem.MolFromSmiles(smi)
    if m is None:
        return None
    return AllChem.GetMorganFingerprintAsBitVect(m, 2, nBits=2048)


# ---------- 1. 参考集 ----------
ref_tgt, ref_fps, ref_smiles = [], [], []
with open(REF, encoding="utf-8-sig", newline="") as f:
    for r in csv.DictReader(f):
        if (r.get("target_type") or "").strip() != "SINGLE PROTEIN":
            continue
        if not (r.get("uniprot") or "").strip():
            continue
        smi = (r.get("smiles") or "").strip()
        if not smi:
            continue
        fp = fp_of(smi)
        if fp is None:
            continue
        ref_tgt.append((r["target_chembl_id"], r.get("target_name", ""), r["uniprot"],
                        float(r.get("pchembl_value") or 0), r["molecule_chembl_id"]))
        ref_fps.append(fp)
        ref_smiles.append(smi)
print("参考集: %d 个配体-靶点对, %d 条指纹" % (len(ref_tgt), len(ref_fps)), flush=True)

# ---------- 2. 查询集 ----------
queries = []
with open(QRY, encoding="utf-8-sig", newline="") as f:
    for r in csv.DictReader(f):
        if (r.get("smiles") or "").strip():
            queries.append(r)
print("查询成分: %d" % len(queries), flush=True)

# ---------- 3. 逐个查询做相似性迁移 ----------
from rdkit.Chem import rdMolDescriptors

out_rows = []
lo_count = 0
n_tgt_total = 0
for i, q in enumerate(queries):
    fp = fp_of(q["smiles"])
    if fp is None:
        continue
    sims = DataStructs.BulkTanimotoSimilarity(fp, ref_fps)
    # 留一法:剔除与查询 SMILES 完全相同的参考分子
    q_can = Chem.MolToSmiles(Chem.MolFromSmiles(q["smiles"]))
    tgt_score = defaultdict(lambda: [0.0, 0, None, ""])
    excluded = 0
    for j, s in enumerate(sims):
        if s < SIM_CUT:
            continue
        try:
            r_can = Chem.MolToSmiles(Chem.MolFromSmiles(ref_smiles[j]))
        except Exception:
            r_can = ref_smiles[j]
        if r_can == q_can:
            excluded += 1
            continue                       # 留一
        tid, tname, up, pch, mid = ref_tgt[j]
        cur = tgt_score[tid]
        cur[0] = max(cur[0], s)            # 最大相似度
        cur[1] += 1                        # 邻居计数
        cur[2] = up
        cur[3] = tname
    if excluded:
        lo_count += 1
    ranked = sorted(tgt_score.items(), key=lambda kv: (-kv[1][0], -kv[1][1]))[:TOP_N]
    n_tgt_total += len(ranked)
    for tid, (mx, cnt, up, tname) in ranked:
        out_rows.append({
            "herb": q["herb"], "compound": q.get("name") or "", "ingredient_id": q["ingredient_id"],
            "smiles": q["smiles"], "target_chembl_id": tid, "target_name": tname, "uniprot": up,
            "max_similarity": round(mx, 3), "n_neighbors": cnt,
        })
    if (i + 1) % 100 == 0:
        print("  ... %d/%d 个查询完成" % (i + 1, len(queries)), flush=True)

with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["herb", "compound", "ingredient_id", "smiles",
                                      "target_chembl_id", "target_name", "uniprot",
                                      "max_similarity", "n_neighbors"])
    w.writeheader()
    w.writerows(out_rows)

print("\n=== 预测结果 ===", flush=True)
print("化合物-靶点对: %d" % len(out_rows), flush=True)
print("命中(有预测靶点)的化合物数: %d / %d" % (len({r["ingredient_id"] for r in out_rows}), len(queries)), flush=True)
print("涉及唯一靶点: %d" % len({r["target_chembl_id"] for r in out_rows}), flush=True)
print("触发留一剔除的化合物数: %d" % lo_count, flush=True)
print("落盘:", OUT, flush=True)

from collections import Counter
print("\n=== 被预测最多的靶点(Top 15)===", flush=True)
for (tid, tn), c in Counter((r["target_chembl_id"], r["target_name"]) for r in out_rows).most_common(15):
    print("  %-12s %-38s %d 个成分" % (tid, tn[:38], c), flush=True)
