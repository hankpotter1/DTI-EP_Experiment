# -*- coding: utf-8 -*-
"""
M7 + M8:实测型靶点层(CMAUP)+ 与预测型靶点层的对照

M7:CMAUP Ingredient_Target 关联(带 Ki/IC50 活性值)→ 定痫丸成分的实测靶点
M8:预测层(ChEMBL 相似性) vs 实测层,统一用 UniProt 对齐,统计重叠
     —— 注意方向性:两层分别反映"结构相似性外推"与"文献实测富集",不一致是**信息**而非错误
"""
import csv
import os
import sys
from collections import defaultdict, Counter

sys.stdout.reconfigure(encoding="utf-8")
csv.field_size_limit(10 ** 9)

D = r"G:\HHH\openclaw-workspace\downloads\cmaup"
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"


def load(path, delim="\t"):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter=delim))


# ---------- 靶点元数据(NPT -> UniProt/ChEMBL/Gene) ----------
tgt_meta = {}
for r in load(os.path.join(D, "CMAUPv2.0_download_Targets.txt")):
    tid = (r.get("Target_ID") or "").strip()
    if tid:
        tgt_meta[tid] = {
            "gene": (r.get("Gene_Symbol") or "").strip(),
            "protein": (r.get("Protein_Name") or "").strip(),
            "uniprot": (r.get("Uniprot_ID") or "").strip(),
            "chembl": (r.get("ChEMBL_ID") or "").strip(),
            "cls": (r.get("Target_Class_Level1") or "").strip(),
        }
print("CMAUP 靶点元数据: %d" % len(tgt_meta), flush=True)

# ---------- 成分 -> 实测靶点 ----------
cmaup_ing = set()
compounds = list(csv.DictReader(open(os.path.join(RES, "dingxian_compound_table.csv"), encoding="utf-8-sig")))
for c in compounds:
    if c["source"] == "CMAUP":
        cmaup_ing.add(c["ingredient_id"])
print("定痫丸成分中来自 CMAUP 的: %d" % len(cmaup_ing), flush=True)

meas = defaultdict(list)      # ingredient_id -> [(ntp, activity_type, value, unit)]
for r in load(os.path.join(D, "CMAUPv2.0_download_Ingredient_Target_Associations_ActivityValues_References.txt")):
    iid = (r.get("Ingredient_ID") or "").strip()
    if iid in cmaup_ing:
        meas[iid].append((r.get("Target_ID", "").strip(), r.get("Activity_Type", ""),
                          r.get("Activity_Value", ""), r.get("Activity_Unit", "")))

rows_meas = []
for c in compounds:
    if c["source"] != "CMAUP":
        continue
    for tid, at, av, au in meas.get(c["ingredient_id"], []):
        m = tgt_meta.get(tid, {})
        rows_meas.append({
            "herb": c["herb"], "compound": c["name"], "ingredient_id": c["ingredient_id"],
            "target_id": tid, "gene": m.get("gene", ""), "protein": m.get("protein", ""),
            "uniprot": m.get("uniprot", ""), "chembl": m.get("chembl", ""), "cls": m.get("cls", ""),
            "activity_type": at, "activity_value": av, "activity_unit": au,
        })

out_meas = os.path.join(RES, "dingxian_measured_targets.csv")
with open(out_meas, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows_meas[0].keys()) if rows_meas else
                       ["herb", "compound", "ingredient_id", "target_id", "gene", "protein",
                        "uniprot", "chembl", "cls", "activity_type", "activity_value", "activity_unit"])
    w.writeheader()
    w.writerows(rows_meas)

print("\n=== M7 实测层 ===", flush=True)
print("  成分-靶点记录: %d" % len(rows_meas), flush=True)
print("  有实测靶点的成分: %d / %d(CMAUP 来源)" % (
    len({r['ingredient_id'] for r in rows_meas}), len(cmaup_ing)), flush=True)
print("  唯一靶点(UniProt): %d" % len({r["uniprot"] for r in rows_meas if r["uniprot"]}), flush=True)
print("  落盘:", out_meas, flush=True)

# ---------- M8 对照 ----------
pred = list(csv.DictReader(open(os.path.join(RES, "dingxian_predicted_targets.csv"), encoding="utf-8-sig")))
pred_up = {r["uniprot"] for r in pred if r["uniprot"]}
meas_up = {r["uniprot"] for r in rows_meas if r["uniprot"]}
inter = pred_up & meas_up

print("\n=== M8 双路对照(UniProt 层面)===", flush=True)
print("  预测层靶点: %d" % len(pred_up), flush=True)
print("  实测层靶点: %d" % len(meas_up), flush=True)
print("  交集: %d" % len(inter), flush=True)
if pred_up:
    print("  预测层中同时被实测支持的比例: %.1f%%" % (len(inter) / len(pred_up) * 100), flush=True)

print("\n  --- 交集靶点 ---", flush=True)
gmap = {}
for r in rows_meas:
    if r["uniprot"]:
        gmap[r["uniprot"]] = r.get("gene") or r.get("protein", "")
for u in sorted(inter):
    print("    %-12s %s" % (u, gmap.get(u, "")[:50]), flush=True)

print("\n  --- 预测最多但无实测支持的靶点 ---", flush=True)
pc = Counter((r["uniprot"], r["target_name"]) for r in pred if r["uniprot"])
for (u, tn), k in pc.most_common(8):
    if u not in meas_up:
        print("    %-12s %-40s %d 成分" % (u, tn[:40], k), flush=True)

print("\n  --- 实测靶点最集中的 Top 12 ---", flush=True)
mc = Counter((r["uniprot"], r.get("gene") or r.get("protein")) for r in rows_meas if r["uniprot"])
for (u, g), k in mc.most_common(12):
    print("    %-12s %-40s %d 条活性记录" % (u, (g or "")[:40], k), flush=True)

with open(os.path.join(RES, "m8_layer_comparison.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["layer", "uniprot", "label"])
    for r in pred:
        if r["uniprot"]:
            w.writerow(["predicted", r["uniprot"], r["target_name"]])
    for r in rows_meas:
        if r["uniprot"]:
            w.writerow(["measured", r["uniprot"], r.get("gene") or r.get("protein")])
print("\n落盘: results/m8_layer_comparison.csv", flush=True)
