# -*- coding: utf-8 -*-
"""
收尾 ①:出图
  fig_m8_venn            预测层 vs 实测层(靶点集合对照)
  fig_target_class       靶点类别构成对比
  fig_herb_contribution  各药材贡献(成分数 / 实测靶点数)
同时输出可引用的图注文本。
"""
import csv
import os
import sys
from collections import Counter, defaultdict

sys.stdout.reconfigure(encoding="utf-8")
csv.field_size_limit(10 ** 9)

D = r"G:\HHH\openclaw-workspace\downloads\cmaup"
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = os.path.join(os.path.dirname(RES), "figures")
os.makedirs(FIG, exist_ok=True)

import plotly.graph_objects as go

DARK, RED, GREY, BLUE, GREEN = "#2C3E50", "#E74C3C", "#7F8C8D", "#2471A3", "#1E8449"

pred = list(csv.DictReader(open(os.path.join(RES, "dingxian_predicted_targets.csv"), encoding="utf-8-sig")))
meas = list(csv.DictReader(open(os.path.join(RES, "dingxian_measured_targets.csv"), encoding="utf-8-sig")))
comps = list(csv.DictReader(open(os.path.join(RES, "dingxian_compound_table.csv"), encoding="utf-8-sig")))

pred_up = {r["uniprot"] for r in pred if r["uniprot"]}
meas_up = {r["uniprot"] for r in meas if r["uniprot"]}
inter = pred_up & meas_up
only_p, only_m = pred_up - meas_up, meas_up - pred_up
print("预测 %d | 实测 %d | 交集 %d | 仅预测 %d | 仅实测 %d" % (
    len(pred_up), len(meas_up), len(inter), len(only_p), len(only_m)), flush=True)

# ---------- Fig 1: 两圆 Venn ----------
fig = go.Figure()
fig.add_shape(type="circle", x0=28, x1=72, y0=30, y1=74, fillcolor=RED, opacity=0.32, line=dict(color=RED, width=2))
fig.add_shape(type="circle", x0=46, x1=90, y0=30, y1=74, fillcolor=BLUE, opacity=0.32, line=dict(color=BLUE, width=2))
fig.add_annotation(x=39, y=52, text="<b>%d</b><br>predicted only" % len(only_p), showarrow=False,
                   font=dict(size=13, color=DARK))
fig.add_annotation(x=59, y=52, text="<b>%d</b><br>shared" % len(inter), showarrow=False,
                   font=dict(size=13, color=DARK))
fig.add_annotation(x=79, y=52, text="<b>%d</b><br>measured only" % len(only_m), showarrow=False,
                   font=dict(size=13, color=DARK))
fig.add_annotation(x=28, y=78, text="<b>Predicted layer</b><br>(ligand-similarity, n=%d)" % len(pred_up),
                   showarrow=False, font=dict(size=11, color=RED), xanchor="center")
fig.add_annotation(x=90, y=78, text="<b>Measured layer</b><br>(CMAUP activity, n=%d)" % len(meas_up),
                   showarrow=False, font=dict(size=11, color=BLUE), xanchor="center")
fig.add_annotation(x=59, y=20, text="Overlap = %.1f%% of predicted targets" % (len(inter) / len(pred_up) * 100),
                   showarrow=False, font=dict(size=12, color=GREY))
fig.update_xaxes(range=[10, 108], visible=False)
fig.update_yaxes(range=[10, 90], visible=False)
fig.update_layout(width=900, height=520, template="simple_white",
                  margin=dict(l=10, r=10, t=40, b=10),
                  title="Dingxian Pill: predicted vs measured target layers")
fig.write_image(os.path.join(FIG, "fig_m8_venn.png"), scale=3, width=900, height=520)
fig.write_image(os.path.join(FIG, "fig_m8_venn.pdf"), width=900, height=520)
print("saved fig_m8_venn", flush=True)

# ---------- Fig 2: 靶点类别构成 ----------
up2cls = {}
for r in csv.DictReader(open(os.path.join(D, "CMAUPv2.0_download_Targets.txt"), encoding="utf-8"),
                        delimiter="\t"):
    u = (r.get("Uniprot_ID") or "").strip()
    if u:
        up2cls[u] = (r.get("Target_Class_Level1") or "Unknown").strip()

pcls = Counter(up2cls.get(u, "Not annotated") for u in pred_up)
mcls = Counter(up2cls.get(u, "Not annotated") for u in meas_up)
cats = sorted(set(pcls) | set(mcls), key=lambda c: -(pcls.get(c, 0) + mcls.get(c, 0)))[:10]

fig2 = go.Figure()
fig2.add_trace(go.Bar(name="Predicted", x=[pcls.get(c, 0) for c in cats], y=cats,
                      orientation="h", marker_color=RED))
fig2.add_trace(go.Bar(name="Measured", x=[mcls.get(c, 0) for c in cats], y=cats,
                      orientation="h", marker_color=BLUE))
fig2.update_layout(barmode="group", template="simple_white", width=900, height=520,
                   title="Target-class composition of the two layers",
                   xaxis_title="Number of targets", margin=dict(l=200, r=30, t=60, b=50))
fig2.write_image(os.path.join(FIG, "fig_target_class.png"), scale=3, width=900, height=520)
fig2.write_image(os.path.join(FIG, "fig_target_class.pdf"), width=900, height=520)
print("saved fig_target_class", flush=True)

# ---------- Fig 3: 各药材贡献 ----------
comp_by_herb = Counter(c["herb"] for c in comps)
ing2herb = {c["ingredient_id"]: c["herb"] for c in comps if c["source"] == "CMAUP"}
meas_by_herb = Counter(ing2herb.get(r["ingredient_id"], "") for r in meas)
herbs = [h for h, _ in comp_by_herb.most_common()]

fig3 = go.Figure()
fig3.add_trace(go.Bar(name="Compounds", x=herbs, y=[comp_by_herb[h] for h in herbs], marker_color=GREY))
fig3.add_trace(go.Bar(name="Measured target records", x=herbs,
                      y=[meas_by_herb.get(h, 0) for h in herbs], marker_color=BLUE))
fig3.update_layout(barmode="group", template="simple_white", width=1000, height=520,
                   title="Per-herb contribution to the Dingxian Pill compound and target layers",
                   yaxis_title="Count", margin=dict(l=60, r=30, t=60, b=110))
fig3.update_xaxes(tickangle=-45)
fig3.write_image(os.path.join(FIG, "fig_herb_contribution.png"), scale=3, width=1000, height=520)
fig3.write_image(os.path.join(FIG, "fig_herb_contribution.pdf"), width=1000, height=520)
print("saved fig_herb_contribution", flush=True)

# ---------- 图注 ----------
CAP = """# 图注(可直接用于稿件)

**Figure X. Predicted versus measured target layers for Dingxian Pill.**
Two target-inference routes were applied to the same 819-compound formula.
The *predicted* layer (red) transfers targets from ChEMBL reference ligands by ligand
similarity (ECFP4/Tanimoto >= 0.40) under a leave-one-out protocol; the *measured* layer
(blue) comprises curated ingredient-target associations with reported activity values
(Ki/IC50) from CMAUP. Targets are compared at the UniProt level. The two routes converged
on only %d of %d predicted targets (%.1f%%), with %d targets unique to the predicted layer
and %d unique to the measured layer.

**Figure Y. Target-class composition of the two layers.**
Class assignment follows CMAUP Target_Class_Level1. The predicted layer is enriched for
ion channels and G-protein-coupled receptors, whereas the measured layer is dominated by
enzymes and transporters - reflecting the fact that natural-product bioactivity screening
has historically concentrated on a small set of assay families rather than on the full
druggable proteome.

**Figure Z. Per-herb contribution.**
Number of compounds retained per herb (grey) and number of curated ingredient-target
activity records per herb (blue).
""" % (len(inter), len(pred_up), len(inter) / len(pred_up) * 100, len(only_p), len(only_m))

open(os.path.join(RES, "figure_legends_m8.md"), "w", encoding="utf-8").write(CAP)
print("saved figure_legends_m8.md", flush=True)
print("\n产物:", flush=True)
for f in ("fig_m8_venn.png/pdf", "fig_target_class.png/pdf", "fig_herb_contribution.png/pdf"):
    print("  ", f, flush=True)
