# -*- coding: utf-8 -*-
"""
大白话版解释图(中文)—— 面向临床读者,不用专业术语。
  1) 研究总览:一个古方 → 成分 → 两条路找靶点 → 对账
  2) 那 4.58 亿参数的模型为什么"废了"
  3) 两条路的靶点对账(维恩)
  4) 两条路的靶点类别差异
"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"
os.makedirs(FIG, exist_ok=True)

import plotly.graph_objects as go

FONT = "Microsoft YaHei"
DARK, RED, BLUE, GREY, GREEN = "#2C3E50", "#E74C3C", "#2471A3", "#7F8C8D", "#1E8449"

# ============ 图 1:研究总览 ============
fig = go.Figure()
fig.update_xaxes(range=[0, 100], visible=False)
fig.update_yaxes(range=[0, 100], visible=False)


def box(x0, x1, y0, y1, title, body, fill, tcol="white", fs=15, bfs=11):
    fig.add_shape(type="rect", x0=x0, x1=x1, y0=y0, y1=y1, fillcolor=fill,
                  line=dict(color=fill, width=1.5), layer="below")
    fig.add_annotation(x=(x0 + x1) / 2, y=y1 - 4, text="<b>%s</b>" % title, showarrow=False,
                       font=dict(size=fs, color=tcol, family=FONT), xanchor="center", yanchor="top")
    fig.add_annotation(x=(x0 + x1) / 2, y=y1 - 13, text=body, showarrow=False,
                       font=dict(size=bfs, color=tcol, family=FONT), xanchor="center",
                       yanchor="top", align="center")


def arrow(x0, y0, x1, y1):
    fig.add_annotation(x=x1, y=y1, ax=x0, ay=y0, xref="x", yref="y", axref="x", ayref="y",
                       showarrow=True, arrowhead=2, arrowsize=1.5, arrowwidth=2.4, arrowcolor=DARK, text="")


fig.add_annotation(x=50, y=97, text="<b>这次研究到底做了什么</b>", showarrow=False,
                   font=dict(size=22, color=DARK, family=FONT), xanchor="center", yanchor="top")

box(1, 20, 40, 82, "一个古方",
    "定痫丸<br>15 味中药<br>中医治癫痫的经典方", DARK)

box(24, 44, 40, 82, "拆成化学成分",
    "把 15 味药里已知的<br>化学成分全部列出来<br><br><b>819 个成分</b>", GREY)

arrow(20.5, 61, 23.5, 61)

# 两条路
box(48, 71, 62, 92, "路① 看化学长相",
    "拿每个成分去和<br>「已知药物的化学结构」比相似度<br>长得像谁,就猜它作用在谁的靶点上<br><br>"
    "<b>结果:35 个靶点</b>", RED, bfs=10.5)
box(48, 71, 26, 58, "路② 查实验档案",
    "去文献数据库查:<br>这个成分有没有人做过<br>「和某个靶点结合」的实验<br><br>"
    "<b>结果:93 个靶点</b>", BLUE, bfs=10.5)
arrow(44.5, 77, 47.5, 77)
arrow(44.5, 42, 47.5, 42)

box(75, 99, 40, 82, "两边对账",
    "两条路各自找到的靶点<br>只有 <b>9 个</b>是一样的<br><br>"
    "重合率 <b>25.7%</b><br><br>剩下 3/4 各说各话", GREEN, bfs=11)
arrow(71.5, 77, 74.5, 61)
arrow(71.5, 42, 74.5, 55)

fig.add_annotation(x=50, y=14,
                   text="<b>一句话:</b>同一个方子,换一种「找靶点」的方法,结果就换一大批 —— 而后续的机制分析全建立在这一层上",
                   showarrow=False, font=dict(size=13, color=DARK, family=FONT),
                   xanchor="center", yanchor="top")
fig.add_annotation(x=50, y=5, text="(朱砂、琥珀按矿物药剔除;茯苓、全蝎、僵蚕三味动物/真菌药由另一数据库补齐)",
                   showarrow=False, font=dict(size=10, color=GREY, family=FONT), xanchor="center")

fig.update_layout(width=1200, height=620, template="simple_white",
                  margin=dict(l=8, r=8, t=8, b=8), showlegend=False)
fig.write_image(os.path.join(FIG, "explainer_1_overview.png"), scale=2, width=1200, height=620)
fig.write_image(os.path.join(FIG, "explainer_1_overview.pdf"), width=1200, height=620)
print("saved explainer_1_overview", flush=True)

# ============ 图 2:模型为什么废了 ============
# 数据来自 results/m4b_affinity_correlation.json 对应的逐对预测
DATA = {
    "CA2(碳酸酐酶2)": [(10.00, 6.17), (9.00, 6.18), (8.68, 6.10), (8.48, 6.17), (8.22, 6.14),
                    (8.05, 6.10), (7.89, 6.09), (7.70, 6.30), (7.50, 6.06), (7.29, 6.20),
                    (7.02, 6.13), (6.75, 6.18), (6.43, 6.55), (5.00, 6.11)],
    "ABL1(一种激酶)": [(10.70, 6.84), (8.46, 7.10), (7.92, 7.05), (7.57, 6.87), (7.25, 6.98),
                    (7.00, 6.82), (6.70, 6.96), (6.52, 7.01), (6.35, 7.03), (6.12, 6.96),
                    (5.89, 6.95), (5.70, 7.10), (5.37, 6.81), (5.00, 7.10)],
    "PTGS2(环氧合酶2)": [(10.10, 5.77), (8.30, 5.79), (7.92, 5.81), (7.66, 5.74), (7.40, 5.78),
                      (7.16, 5.77), (6.92, 5.74), (6.66, 5.74), (6.46, 5.82), (6.21, 5.77),
                      (6.00, 5.75), (5.75, 5.76), (5.38, 5.77), (5.00, 5.78)],
}
COLS = [RED, BLUE, GREEN]
fig2 = go.Figure()
for (name, pts), c in zip(DATA.items(), COLS):
    fig2.add_trace(go.Scatter(x=[p[0] for p in pts], y=[p[1] for p in pts], mode="markers",
                              name=name, marker=dict(size=10, color=c, opacity=0.85)))
fig2.add_annotation(x=7.8, y=6.55, text="实测亲和力差了 <b>10 万倍</b>(横轴 5→10.7)<br>"
                                        "模型预测几乎 <b>不跟着动</b>(纵轴只挪 0.03–0.5)",
                   showarrow=True, arrowhead=2, ax=-160, ay=-60,
                   font=dict(size=14, color=DARK, family=FONT),
                   bgcolor="rgba(255,255,255,0.9)", bordercolor=GREY)
fig2.add_annotation(x=5.2, y=7.15, text="横着一条线<br>= 模型没学会区分配体",
                   showarrow=False, font=dict(size=12, color=GREY, family=FONT), xanchor="left")
fig2.update_layout(template="simple_white", width=1100, height=600,
                   title=dict(text="<b>那个 4.58 亿参数的 AI 模型,为什么不能用</b>",
                              font=dict(size=20, family=FONT)),
                   xaxis_title="实测亲和力 pChEMBL(越大=结合越强)",
                   yaxis_title="模型预测 pKd(越大=预测越强)",
                   font=dict(family=FONT, size=13),
                   margin=dict(l=80, r=40, t=90, b=70))
fig2.write_image(os.path.join(FIG, "explainer_2_model_failure.png"), scale=2, width=1100, height=600)
fig2.write_image(os.path.join(FIG, "explainer_2_model_failure.pdf"), width=1100, height=600)
print("saved explainer_2_model_failure", flush=True)

# ============ 图 3:维恩(中文) ============
fig3 = go.Figure()
fig3.add_shape(type="circle", x0=26, x1=70, y0=28, y1=72, fillcolor=RED, opacity=0.33,
               line=dict(color=RED, width=2))
fig3.add_shape(type="circle", x0=46, x1=90, y0=28, y1=72, fillcolor=BLUE, opacity=0.33,
               line=dict(color=BLUE, width=2))
fig3.add_annotation(x=37, y=50, text="<b>26</b><br>只有路①找到", showarrow=False,
                    font=dict(size=15, color=DARK, family=FONT))
fig3.add_annotation(x=58, y=50, text="<b>9</b><br>两条路都找到", showarrow=False,
                    font=dict(size=15, color=DARK, family=FONT))
fig3.add_annotation(x=80, y=50, text="<b>84</b><br>只有路②找到", showarrow=False,
                    font=dict(size=15, color=DARK, family=FONT))
fig3.add_annotation(x=27, y=78, text="<b>路① 看化学长相</b><br>共 35 个靶点", showarrow=False,
                    font=dict(size=13, color=RED, family=FONT), xanchor="center")
fig3.add_annotation(x=89, y=78, text="<b>路② 查实验档案</b><br>共 93 个靶点", showarrow=False,
                    font=dict(size=13, color=BLUE, family=FONT), xanchor="center")
fig3.add_annotation(x=58, y=17, text="两条路的重合率只有 <b>25.7%</b>", showarrow=False,
                    font=dict(size=15, color=DARK, family=FONT))
fig3.update_xaxes(range=[8, 108], visible=False)
fig3.update_yaxes(range=[8, 92], visible=False)
fig3.update_layout(width=1000, height=560, template="simple_white",
                   title=dict(text="<b>同一个方子,两条路找出的靶点几乎不一样</b>",
                              font=dict(size=20, family=FONT)),
                   margin=dict(l=20, r=20, t=80, b=20), font=dict(family=FONT))
fig3.write_image(os.path.join(FIG, "explainer_3_venn_zh.png"), scale=2, width=1000, height=560)
fig3.write_image(os.path.join(FIG, "explainer_3_venn_zh.pdf"), width=1000, height=560)
print("saved explainer_3_venn_zh", flush=True)

# ============ 图 4:靶点类别差异(中文) ============
cats = ["酶", "转运蛋白", "离子通道", "G蛋白偶联受体", "核受体", "其他/未注释"]
pred = [9, 3, 4, 11, 2, 6]
meas = [42, 12, 4, 18, 3, 14]
fig4 = go.Figure()
fig4.add_trace(go.Bar(name="路① 看化学长相", y=cats, x=pred, orientation="h", marker_color=RED))
fig4.add_trace(go.Bar(name="路② 查实验档案", y=cats, x=meas, orientation="h", marker_color=BLUE))
fig4.update_layout(barmode="group", template="simple_white", width=1050, height=560,
                   title=dict(text="<b>路②为什么「酶」和「转运蛋白」特别多?</b>", font=dict(size=20, family=FONT)),
                   xaxis_title="靶点个数", font=dict(family=FONT, size=13),
                   margin=dict(l=180, r=40, t=80, b=60))
fig4.add_annotation(x=34, y=5.35, text="不是这些靶点更重要,而是<b>实验最常做这几类</b>",
                    showarrow=False, font=dict(size=13, color=DARK, family=FONT), xanchor="center")
fig4.write_image(os.path.join(FIG, "explainer_4_classes_zh.png"), scale=2, width=1050, height=560)
fig4.write_image(os.path.join(FIG, "explainer_4_classes_zh.pdf"), width=1050, height=560)
print("saved explainer_4_classes_zh", flush=True)
