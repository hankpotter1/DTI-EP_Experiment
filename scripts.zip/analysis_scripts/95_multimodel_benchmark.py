# -*- coding: utf-8 -*-
"""
扩展 ①:多模型基准评测台架(统一三层判据)

评测集与 TED 那次(M4-b)严格一致:
  · 3 个靶点(CA2 / ABL1 / PTGS2),各 14 个配体,实测 pChEMBL 跨约 5 个数量级
  · 数据来源:cache/m4b 的 ChEMBL 活性 + 分子 SMILES + UniProt 序列

三层判据(对每个模型都算):
  Tier1 跨靶点判别 AUC:正样本=该靶点自己的强配体;负样本=其他靶点的强配体
  Tier2 同靶点判别 AUC:按实测中位数分强/弱两半
  Tier3 亲和力排序 Spearman:预测值 vs 实测 pChEMBL(逐靶点)

对比对象:TED-DTI(我此前测得 平均 ρ = -0.029)
"""
import csv
import json
import os
import sys
import traceback

sys.stdout.reconfigure(encoding="utf-8")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

BASE = r"G:\HHH\openclaw-workspace\netpharm-toolkit"
CACHE = os.path.join(BASE, "cache", "m4b")
OUT = os.path.join(BASE, "results")
os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(BASE, "scripts"))

TARGETS = [("CA2", "CHEMBL205", "P00918"), ("ABL1", "CHEMBL1862", "P00519"),
           ("PTGS2", "CHEMBL230", "P35354")]
N_PER = 14

# ---------- 1. 重建评测集 ----------
def jload(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


pairs = {}       # target -> [(mol_id, pchembl)]
for name, cid, acc in TARGETS:
    acts = jload(os.path.join(CACHE, "act_%s.json" % cid)).get("activities", [])
    best = {}
    for a in acts:
        mid, pv = a.get("molecule_chembl_id"), a.get("pchembl_value")
        if not mid or pv is None:
            continue
        try:
            pv = float(pv)
        except Exception:
            continue
        if mid not in best or pv > best[mid]:
            best[mid] = pv
    ordered = sorted(best.items(), key=lambda kv: -kv[1])
    idx = [round(i * (len(ordered) - 1) / (N_PER - 1)) for i in range(N_PER)]
    pairs[name] = [ordered[i] for i in sorted(set(idx))]

# SMILES(从缓存的两个批次里取)
smiles = {}
for fn in sorted(os.listdir(CACHE)):
    if fn.startswith("mol_") and fn.endswith(".json"):
        for m in jload(os.path.join(CACHE, fn)).get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st:
                smiles[mid] = st

# 序列
seqs = {}
for name, cid, acc in TARGETS:
    p = os.path.join(CACHE, "seq_%s.json" % acc)
    if os.path.isfile(p):
        seqs[name] = jload(p)["results"][0]["sequence"]["value"]

print("评测集:", flush=True)
for name, _, _ in TARGETS:
    got = [m for m, _ in pairs[name] if m in smiles]
    print("  %-6s 配体 %d/%d 有 SMILES, 序列 %d aa, pChEMBL %.2f-%.2f" % (
        name, len(got), len(pairs[name]), len(seqs.get(name, "")),
        pairs[name][-1][1], pairs[name][0][1]), flush=True)

# ---------- 2. 逐模型评测 ----------
from DeepPurpose import DTI, utils
from DeepPurpose.utils import generate_config, download_pretrained_model
from sklearn.metrics import roc_auc_score
from scipy.stats import spearmanr

MODELS = [
    ("mpnn_cnn_bindingdb", "MPNN", "CNN"),
    ("cnn_cnn_bindingdb", "CNN", "CNN"),
    ("morgan_cnn_bindingdb", "Morgan", "CNN"),
    ("transformer_cnn_bindingdb", "Transformer", "CNN"),
    ("morgan_aac_bindingdb", "Morgan", "AAC"),
    ("daylight_aac_bindingdb", "Daylight", "AAC"),
]

# 展开成显式配对的打分表
score_rows = []      # (target, mol, pchembl, smiles)
for name, _, _ in TARGETS:
    for mid, pv in pairs[name]:
        if mid in smiles:
            score_rows.append((name, mid, pv, smiles[mid]))

results = []
per_model_pred = {}
for model_name, drug_enc, tgt_enc in MODELS:
    print("\n=== %s (%s / %s) ===" % (model_name, drug_enc, tgt_enc), flush=True)
    try:
        path = download_pretrained_model(model_name)
        model = DTI.model_pretrained(path)
        # 以模型自带 config 为准(比硬编码更可靠),取不到再回退
        cfg = getattr(model, "config", {}) or {}
        drug_enc = cfg.get("drug_encoding", drug_enc)
        tgt_enc = cfg.get("target_encoding", tgt_enc)
        print("  实际编码: %s / %s" % (drug_enc, tgt_enc), flush=True)
    except Exception as e:
        print("  加载失败:", str(e)[:150], flush=True)
        traceback.print_exc(limit=2)
        continue

    # 构造全部 (配体 x 靶点) 组合
    X_d, X_t, meta = [], [], []
    for tname, _, _ in TARGETS:
        seq = seqs[tname]
        for name, mid, pv, smi in score_rows:
            X_d.append(smi)
            X_t.append(seq)
            meta.append((tname, mid, pv, name))   # (被预测靶点, 分子, 实测效价, 该分子原生靶点)
    try:
        df = utils.data_process(X_drug=X_d, X_target=X_t, y=[1.0] * len(X_d),
                                drug_encoding=drug_enc, target_encoding=tgt_enc,
                                split_method="no_split")
        preds = model.predict(df)
    except Exception as e:
        print("  推理失败:", str(e)[:150], flush=True)
        traceback.print_exc(limit=2)
        continue
    print("  完成 %d 个配对的打分" % len(preds), flush=True)

    pred = {}
    for (tname, mid, pv, native), p in zip(meta, preds):
        pred[(tname, mid)] = float(p)
    per_model_pred[model_name] = {("%s|%s" % k): v for k, v in pred.items()}

    # Tier3 逐靶点 Spearman
    rhos = []
    for tname, _, _ in TARGETS:
        xs = [pred[(tname, mid)] for tn, mid, pv, nt in meta if tn == tname]
        ys = [pv for tn, mid, pv, nt in meta if tn == tname]
        if len(xs) >= 5:
            rho, _ = spearmanr(xs, ys)
            rhos.append(rho)
    # Tier2 同靶点 AUC(实测中位数分半)
    aucs2 = []
    for tname, _, _ in TARGETS:
        sub = [(pred[(tname, mid)], pv) for tn, mid, pv, nt in meta if tn == tname]
        med = sorted(pv for _, pv in sub)[len(sub) // 2]
        y = [1 if pv >= med else 0 for _, pv in sub]
        if len(set(y)) == 2:
            aucs2.append(roc_auc_score(y, [s for s, _ in sub]))
    # Tier1 跨靶点 AUC
    y1, s1 = [], []
    for tname, _, _ in TARGETS:
        for tn, mid, pv, native in meta:
            if tn != tname:
                continue
            y1.append(1 if native == tname else 0)
            s1.append(pred[(tname, mid)])
    auc1 = roc_auc_score(y1, s1) if len(set(y1)) == 2 else float("nan")

    r = {"model": model_name, "enc": "%s/%s" % (drug_enc, tgt_enc),
         "tier1_cross_auc": round(float(auc1), 3),
         "tier2_within_auc_mean": round(float(sum(aucs2) / len(aucs2)), 3) if aucs2 else None,
         "tier3_spearman_mean": round(float(sum(rhos) / len(rhos)), 3) if rhos else None,
         "tier3_spearman_each": [round(float(x), 3) for x in rhos]}
    results.append(r)
    print("  Tier1 跨靶点 AUC = %.3f" % auc1, flush=True)
    print("  Tier2 同靶点 AUC = %s" % r["tier2_within_auc_mean"], flush=True)
    print("  Tier3 Spearman  = %s %s" % (r["tier3_spearman_mean"], r["tier3_spearman_each"]), flush=True)

with open(os.path.join(OUT, "multimodel_benchmark.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print("\n落盘: results/multimodel_benchmark.json", flush=True)

print("\n==== 汇总 ====", flush=True)
print("%-30s %8s %10s %10s" % ("模型", "T1跨靶", "T2同靶", "T3排序"), flush=True)
for r in results:
    print("%-30s %8.3f %10s %10s" % (r["model"], r["tier1_cross_auc"],
                                     r["tier2_within_auc_mean"], r["tier3_spearman_mean"]), flush=True)
print("\n对照 TED-DTI: T1=0.562  T2=0.563  T3=-0.029", flush=True)
