# -*- coding: utf-8 -*-
"""
扩展 ②:构建大规模评测集(20 靶点 x 25 配体,跨靶点类别)
  · 靶点元数据/UniProt 从 ChEMBL 取(不硬编码,避免记忆错误)
  · 活性:pchembl >= 5,标准关系 "=",按分子取最大 pChEMBL,按效价排序后等距取样
  · SMILES:批量取(带重试,ChEMBL 大批量请求易 SSL EOF)
缓存于 cache/bench/,可断点续跑。
"""
import csv
import json
import os
import re
import time
import urllib.request

CACHE = r"G:\HHH\openclaw-workspace\netpharm-toolkit\cache\bench"
OUT = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
os.makedirs(CACHE, exist_ok=True)
os.makedirs(OUT, exist_ok=True)

UA = {"User-Agent": "netpharm-bench"}
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
N_PER = 25
MIN_PCH = 5.0

# 20 个靶点,跨 6 个类别
TARGETS = [
    ("CA2",     "CHEMBL205",   "酶-碳酸酐酶"),
    ("PTGS2",   "CHEMBL230",   "酶-环氧合酶"),
    ("ACHE",    "CHEMBL220",   "酶-乙酰胆碱酯酶"),
    ("DPP4",    "CHEMBL284",   "酶-二肽基肽酶"),
    ("ACE",     "CHEMBL1808",  "酶-血管紧张素转换酶"),
    ("BACE1",   "CHEMBL4822",  "酶-β分泌酶"),
    ("ABL1",    "CHEMBL1862",  "激酶-ABL"),
    ("EGFR",    "CHEMBL203",   "激酶-EGFR"),
    ("CDK2",    "CHEMBL301",   "激酶-CDK2"),
    ("KDR",     "CHEMBL279",   "激酶-VEGFR2"),
    ("SRC",     "CHEMBL267",   "激酶-SRC"),
    ("ADRB2",   "CHEMBL210",   "GPCR-β2肾上腺素"),
    ("DRD2",    "CHEMBL217",   "GPCR-多巴胺D2"),
    ("ADORA2A", "CHEMBL251",   "GPCR-腺苷A2A"),
    ("OPRM1",   "CHEMBL233",   "GPCR-μ阿片"),
    ("HTR1A",   "CHEMBL214",   "GPCR-5HT1A"),
    ("KCNH2",   "CHEMBL240",   "离子通道-hERG"),
    ("SLC6A4",  "CHEMBL228",   "转运体-5HT"),
    ("ESR1",    "CHEMBL206",   "核受体-雌激素α"),
    ("AR",      "CHEMBL1871",  "核受体-雄激素"),
]


def fetch(url, name, attempts=5, timeout=90):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        try:
            with open(cf, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            os.remove(cf)
    last = None
    for k in range(attempts):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8"))
            tmp = cf + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f)
            os.replace(tmp, cf)
            time.sleep(0.35)
            return d
        except Exception as e:
            last = e
            time.sleep(1.5 * (k + 1))
    raise last


print("=== 1) 靶点元数据(含 UniProt)===", flush=True)
tmeta = {}
for short, cid, cls in TARGETS:
    try:
        d = fetch(CHEMBL + "/target/%s.json" % cid, "tgt_%s.json" % cid)
        comps = d.get("target_components") or [{}]
        acc = (comps[0].get("accession") if comps else "") or ""
        tmeta[short] = {"chembl": cid, "uniprot": acc, "name": d.get("pref_name") or "", "cls": cls}
        print("  %-8s %-14s %-11s %s" % (short, cid, acc, (d.get("pref_name") or "")[:40]), flush=True)
    except Exception as e:
        print("  %-8s 元数据失败: %s" % (short, str(e)[:60]), flush=True)

print("\n=== 2) 配体取样(pchembl>=%s, 每靶点 %d 个)===" % (MIN_PCH, N_PER), flush=True)
ligands = {}
for short, cid, cls in TARGETS:
    try:
        d = fetch(CHEMBL + "/activity.json?target_chembl_id=%s&pchembl_value__gte=%s&standard_relation=%%3D&limit=1000"
                  % (cid, MIN_PCH), "act_%s.json" % cid)
        acts = d.get("activities", [])
    except Exception as e:
        print("  %-8s 活性失败: %s" % (short, str(e)[:60]), flush=True)
        continue
    best = {}
    for a in acts:
        mid, pv = a.get("molecule_chembl_id"), a.get("pchembl_value")
        if not mid or pv is None:
            continue
        try:
            pv = float(pv)
        except Exception:
            continue
        if mid not in best or pv > best[mid]:
            best[mid] = pv
    ordered = sorted(best.items(), key=lambda kv: -kv[1])
    if len(ordered) >= N_PER:
        idx = [round(i * (len(ordered) - 1) / (N_PER - 1)) for i in range(N_PER)]
        sel = [ordered[i] for i in sorted(set(idx))]
    else:
        sel = ordered
    ligands[short] = sel
    if sel:
        print("  %-8s 可用 %4d -> 取样 %2d (pChEMBL %.2f-%.2f)" % (
            short, len(best), len(sel), sel[-1][1], sel[0][1]), flush=True)

# ---- SMILES ----
print("\n=== 3) 批量取 SMILES ===", flush=True)
mids = sorted({m for v in ligands.values() for m, _ in v})
smiles = {}
B = 20
for i in range(0, len(mids), B):
    batch = mids[i:i + B]
    try:
        d = fetch(CHEMBL + "/molecule.json?molecule_chembl_id__in=%s&limit=100" % ",".join(batch),
                  "mol_%05d.json" % i)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st:
                smiles[mid] = st
    except Exception as e:
        print("   [warn] 批 %d: %s" % (i, str(e)[:60]), flush=True)
    if i % 200 == 0:
        print("   ... %d/%d,已得 %d" % (i, len(mids), len(smiles)), flush=True)
print("   SMILES: %d / %d" % (len(smiles), len(mids)), flush=True)

# ---- 序列 ----
print("\n=== 4) 靶点序列(UniProt)===", flush=True)
seqs = {}
for short in tmeta:
    acc = tmeta[short]["uniprot"]
    if not acc:
        continue
    try:
        d = fetch("https://rest.uniprot.org/uniprotkb/search?format=json&size=1&fields=sequence&query=accession:%s" % acc,
                  "seq_%s.json" % acc)
        seqs[short] = d["results"][0]["sequence"]["value"]
    except Exception as e:
        print("  %-8s 序列失败: %s" % (short, str(e)[:50]), flush=True)
print("   取得序列: %d / %d" % (len(seqs), len(tmeta)), flush=True)

# ---- 落盘 ----
rows = []
for short, sel in ligands.items():
    if short not in seqs:
        continue
    for mid, pv in sel:
        if mid in smiles:
            rows.append({"target": short, "chembl_target": tmeta[short]["chembl"],
                         "uniprot": tmeta[short]["uniprot"], "cls": tmeta[short]["cls"],
                         "sequence": seqs[short], "molecule_chembl_id": mid,
                         "pchembl": pv, "smiles": smiles[mid]})
out = os.path.join(OUT, "bench_eval_set.csv")
with open(out, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["target", "chembl_target", "uniprot", "cls", "sequence",
                                      "molecule_chembl_id", "pchembl", "smiles"])
    w.writeheader()
    w.writerows(rows)

print("\n=== 汇总 ===", flush=True)
from collections import Counter
c = Counter(r["target"] for r in rows)
print("  靶点 %d 个,配体记录 %d 条" % (len(c), len(rows)), flush=True)
for short, cid, cls in TARGETS:
    if c.get(short):
        print("    %-8s %-26s %d" % (short, cls, c[short]), flush=True)
print("  落盘:", out, flush=True)
