# -*- coding: utf-8 -*-
"""
扩展 ④:出版级图表
  fig_bench_flip        3 靶点 vs 20 靶点的结论翻转(最有说服力)
  fig_bench_models      20 靶点上各模型排序能力
  fig_bench_per_target  逐靶点 ρ 分布(展示噪声本质)
  fig_bench_tiers       三层判据总览
"""
import csv
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
RES = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
FIG = r"G:\HHH\openclaw-workspace\netpharm-toolkit\figures"
os.makedirs(FIG, exist_ok=True)

import plotly.graph_objects as go

DARK, RED, BLUE, GREY, GREEN, ORANGE = "#2C3E50", "#E74C3C", "#2471A3", "#7F8C8D", "#1E8449", "#E67E22"
FONT = "Arial"

j3 = json.load(open(os.path.join(RES, "multimodel_benchmark.json"), encoding="utf-8"))
j20 = json.load(open(os.path.join(RES, "multimodel_benchmark_20t.json"), encoding="utf-8"))

byname3 = {r["model"]: r for r in j3}
byname20 = {r["model"]: r for r in j20}
ORDER = [r["model"] for r in j20]

# ---------- Fig 1: 结论翻转 ----------
r3 = [byname3[m]["tier3_spearman_mean"] for m in ORDER]
r20 = [byname20[m]["tier3_spearman_mean"] for m in ORDER]
fig = go.Figure()
fig.add_trace(go.Bar(name="3 targets x 14 ligands", x=ORDER, y=r3, marker_color=GREY))
fig.add_trace(go.Bar(name="20 targets x 25 ligands", x=ORDER, y=r20, marker_color=RED))
fig.add_hline(y=0, line=dict(color=DARK, width=1))
fig.add_hline(y=0.4, line=dict(color=GREEN, width=1.4, dash="dash"),
              annotation_text="usable ranking (rho >= 0.4)", annotation_position="top left")
fig.add_annotation(x="morgan_cnn_bindingdb", y=0.598, text="0.60 -> 0.17", showarrow=True,
                   arrowhead=2, ax=0, ay=-45, font=dict(size=12, color=DARK), bgcolor="white")
fig.update_layout(template="simple_white", width=1050, height=560, barmode="group",
                  title=dict(text="<b>The conclusion flips when the evaluation set grows</b>",
                             font=dict(size=19, family=FONT)),
                  yaxis_title="Mean Spearman rho (predicted vs measured affinity)",
                  xaxis_tickangle=-18, font=dict(family=FONT, size=12),
                  margin=dict(l=80, r=40, t=80, b=130), legend=dict(x=0.02, y=0.98))
fig.update_xaxes(tickfont=dict(size=10))
fig.write_image(os.path.join(FIG, "fig_bench_flip.png"), scale=3, width=1050, height=560)
fig.write_image(os.path.join(FIG, "fig_bench_flip.pdf"), width=1050, height=560)
print("saved fig_bench_flip", flush=True)

# ---------- Fig 2: 20 靶点上各模型 ----------
fig2 = go.Figure()
fig2.add_trace(go.Bar(x=ORDER, y=r20, marker_color=RED))
fig2.add_hline(y=0.4, line=dict(color=GREEN, width=1.4, dash="dash"),
               annotation_text="rho = 0.4 (weak-but-usable)", annotation_position="top left")
fig2.add_hline(y=0.0, line=dict(color=DARK, width=1))
fig2.add_annotation(x=0.5, y=0.22, xref="paper", yref="y",
                    text="all models far below any usable threshold",
                    showarrow=False, font=dict(size=12, color=GREY, family=FONT))
fig2.update_layout(template="simple_white", width=1050, height=540,
                   title=dict(text="<b>Affinity-ranking performance, 6 public DTI models (20 targets, 500 ligands)</b>",
                              font=dict(size=17, family=FONT)),
                   yaxis_title="Mean Spearman rho", yaxis_range=[-0.1, 0.5],
                   xaxis_tickangle=-18, font=dict(family=FONT, size=12),
                   margin=dict(l=80, r=40, t=80, b=130), showlegend=False)
fig2.update_xaxes(tickfont=dict(size=10))
fig2.write_image(os.path.join(FIG, "fig_bench_models.png"), scale=3, width=1050, height=540)
fig2.write_image(os.path.join(FIG, "fig_bench_models.pdf"), width=1050, height=540)
print("saved fig_bench_models", flush=True)

# ---------- Fig 3: 逐靶点 ρ 分布 ----------
fig3 = go.Figure()
for i, m in enumerate(ORDER):
    vals = [r["tier3_spearman_mean"] for r in j20 if r["model"] == m]
    # 用 by_class 的逐靶点值
    bd = byname20[m].get("tier3_by_class", {})
    ys = sorted(bd.values(), reverse=True)
    fig3.add_trace(go.Box(y=ys, name=m.replace("_bindingdb", ""), boxpoints="all",
                          jitter=0.5, pointpos=0, marker_color=[RED, BLUE, GREEN, ORANGE, GREY, DARK][i]))
fig3.add_hline(y=0, line=dict(color=DARK, width=1))
fig3.add_hline(y=0.4, line=dict(color=GREEN, width=1.4, dash="dash"))
fig3.update_layout(template="simple_white", width=1100, height=560,
                   title=dict(text="<b>Per-target rho spread: wide and sign-inconsistent = noise, not signal</b>",
                              font=dict(size=17, family=FONT)),
                   yaxis_title="Spearman rho (per target)", font=dict(family=FONT, size=12),
                   margin=dict(l=80, r=40, t=80, b=110), showlegend=False)
fig3.update_xaxes(tickangle=-18, tickfont=dict(size=10))
fig3.write_image(os.path.join(FIG, "fig_bench_per_target.png"), scale=3, width=1100, height=560)
fig3.write_image(os.path.join(FIG, "fig_bench_per_target.pdf"), width=1100, height=560)
print("saved fig_bench_per_target", flush=True)

# ---------- Fig 4: 三层判据 ----------
t1 = [byname20[m]["tier1_cross_auc_mean"] for m in ORDER]
t2 = [byname20[m]["tier2_within_auc_mean"] for m in ORDER]
fig4 = go.Figure()
fig4.add_trace(go.Bar(name="Tier 1: cross-target AUC", x=ORDER, y=t1, marker_color=BLUE))
fig4.add_trace(go.Bar(name="Tier 2: within-target AUC", x=ORDER, y=t2, marker_color=ORANGE))
fig4.add_trace(go.Bar(name="Tier 3: ranking rho", x=ORDER, y=r20, marker_color=RED))
fig4.add_hline(y=0.5, line=dict(color=DARK, width=1.2, dash="dot"),
               annotation_text="chance (AUC = 0.5)", annotation_position="bottom left")
fig4.update_layout(template="simple_white", width=1100, height=560, barmode="group",
                   title=dict(text="<b>Three-tier check: no model clears any tier</b>",
                              font=dict(size=17, family=FONT)),
                   yaxis_title="Score (AUC or rho)", yaxis_range=[0, 0.75],
                   xaxis_tickangle=-18, font=dict(family=FONT, size=12),
                   margin=dict(l=80, r=40, t=80, b=130), legend=dict(x=0.02, y=0.98))
fig4.update_xaxes(tickfont=dict(size=10))
fig4.write_image(os.path.join(FIG, "fig_bench_tiers.png"), scale=3, width=1100, height=560)
fig4.write_image(os.path.join(FIG, "fig_bench_tiers.pdf"), width=1100, height=560)
print("saved fig_bench_tiers", flush=True)

# ---------- 图注 ----------
LEG = """# Figure legends — multi-model DTI benchmark

**Figure A. The conclusion flips when the evaluation set grows.**
Mean Spearman correlation between predicted and measured binding affinity for six publicly
available drug-target interaction models. Grey bars: three targets x 14 ligands (42 pairs),
a commonly seen evaluation size in the network-pharmacology literature. Red bars: twenty
targets x 25 ligands (500 ligands) spanning six target classes. The Morgan-fingerprint model
that appeared to rank affinity well on the small set (rho = 0.60) falls to rho = 0.17 on the
larger set. Small evaluation sets therefore produce apparently positive results that do not
survive scale-up.

**Figure B. Affinity-ranking performance of six public DTI models (20 targets, 500 ligands).**
No model approaches a usable threshold (rho >= 0.4); best mean rho = 0.17.

**Figure C. Per-target rho spread.**
Distribution of per-target Spearman rho for each model across the 20 targets. Values span
roughly -0.4 to +0.5 with both signs, the signature of noise rather than of a weak but real
signal.

**Figure D. Three-tier check.**
Tier 1, cross-target discrimination (can the model tell which target a ligand belongs to);
Tier 2, within-target discrimination between stronger and weaker binders (median split);
Tier 3, affinity ranking (Spearman). Chance levels are AUC = 0.50 and rho = 0.
"""
open(os.path.join(RES, "figure_legends_benchmark.md"), "w", encoding="utf-8").write(LEG)
print("saved figure_legends_benchmark.md", flush=True)
