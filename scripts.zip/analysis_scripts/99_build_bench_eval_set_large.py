# -*- coding: utf-8 -*-
"""
扩展 ⑤:大规模评测集(目标 45+ 靶点 x 25 配体)

稳健做法:候选靶点用 **UniProt 号**指定(比 ChEMBL 内部 ID 可靠),
         脚本自行向 ChEMBL 解析 target_chembl_id;解析失败/配体不足者自动淘汰。
输出:results/bench_eval_set_large.csv
"""
import csv
import json
import os
import time
import urllib.parse
import urllib.request

CACHE = r"G:\HHH\openclaw-workspace\netpharm-toolkit\cache\bench2"
OUT = r"G:\HHH\openclaw-workspace\netpharm-toolkit\results"
os.makedirs(CACHE, exist_ok=True)
UA = {"User-Agent": "netpharm-bench2"}
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
N_PER = 25
MIN_PCH = 5.0

# (基因, UniProt, 类别)—— 约 50 个候选,预期 ~45 可用
CAND = [
    # ---- 酶 ----
    ("CA2", "P00918", "酶"), ("CA1", "P00915", "酶"), ("PTGS2", "P35354", "酶"),
    ("PTGS1", "P23219", "酶"), ("ACHE", "P22303", "酶"), ("DPP4", "P27487", "酶"),
    ("ACE", "P12821", "酶"), ("BACE1", "P56817", "酶"), ("MMP9", "P14780", "酶"),
    ("F10", "P00742", "酶"), ("F2", "P00734", "酶"), ("REN", "P00797", "酶"),
    ("PTPN1", "P18031", "酶"), ("ALOX5", "P09917", "酶"), ("PDE5A", "O76074", "酶"),
    ("MAOB", "P27338", "酶"), ("MAOA", "P21397", "酶"),
    # ---- 激酶 ----
    ("ABL1", "P00519", "激酶"), ("EGFR", "P00533", "激酶"), ("CDK2", "P24941", "激酶"),
    ("KDR", "P35968", "激酶"), ("SRC", "P12931", "激酶"), ("GSK3B", "P49841", "激酶"),
    ("JAK2", "O60674", "激酶"), ("BRAF", "P15056", "激酶"), ("MAPK14", "Q16539", "激酶"),
    ("LCK", "P06239", "激酶"), ("IGF1R", "P08069", "激酶"), ("MET", "P08581", "激酶"),
    ("AKT1", "P31749", "激酶"),
    # ---- GPCR ----
    ("ADRB2", "P07550", "GPCR"), ("ADRB1", "P08588", "GPCR"), ("DRD2", "P14416", "GPCR"),
    ("DRD3", "P35462", "GPCR"), ("ADORA2A", "P29274", "GPCR"), ("ADORA1", "P30542", "GPCR"),
    ("OPRM1", "P35372", "GPCR"), ("OPRD1", "P41143", "GPCR"), ("HTR1A", "P08908", "GPCR"),
    ("HTR2A", "P28223", "GPCR"), ("CNR1", "P21554", "GPCR"), ("HRH1", "P35367", "GPCR"),
    ("CCR5", "P51681", "GPCR"),
    # ---- 离子通道 ----
    ("KCNH2", "Q12809", "离子通道"), ("GABRA1", "P14867", "离子通道"), ("SCN5A", "Q14524", "离子通道"),
    # ---- 转运体 ----
    ("SLC6A4", "P31645", "转运体"), ("SLC6A2", "P23975", "转运体"), ("SLC6A3", "Q01959", "转运体"),
    # ---- 核受体 ----
    ("ESR1", "P03372", "核受体"), ("ESR2", "Q92731", "核受体"), ("AR", "P10275", "核受体"),
    ("NR3C1", "P04150", "核受体"), ("PPARG", "P37231", "核受体"), ("PGR", "P06401", "核受体"),
    ("VDR", "P11473", "核受体"),
    # ---- 其他 ----
    ("CASP3", "P42574", "蛋白酶"),
]


def fetch(url, name, attempts=4, timeout=90):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        try:
            with open(cf, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            os.remove(cf)
    last = None
    for k in range(attempts):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8"))
            tmp = cf + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f)
            os.replace(tmp, cf)
            time.sleep(0.3)
            return d
        except Exception as e:
            last = e
            time.sleep(1.2 * (k + 1))
    raise last


# ---------- 1) 解析 ChEMBL 靶点 ----------
print("=== 1) 用 UniProt 解析 ChEMBL 靶点 ===", flush=True)
resolved = {}
for gene, acc, cls in CAND:
    try:
        d = fetch(CHEMBL + "/target.json?target_components__accession=%s&limit=20" % acc,
                  "map_%s.json" % acc)
        cands = [t for t in d.get("targets", []) if t.get("target_type") == "SINGLE PROTEIN"]
        if not cands:
            print("  %-8s %-11s 未解析到单一蛋白" % (gene, acc), flush=True)
            continue
        # 优先带 pref_name 的人类靶点
        best = cands[0]
        resolved[gene] = {"chembl": best["target_chembl_id"], "uniprot": acc, "cls": cls}
    except Exception as e:
        print("  %-8s %-11s 解析失败 %s" % (gene, acc, str(e)[:45]), flush=True)
print("  解析成功: %d / %d" % (len(resolved), len(CAND)), flush=True)

# ---------- 2) 活性 + 取样 ----------
print("\n=== 2) 抓活性并取样 ===", flush=True)
ligands = {}
for gene, info in resolved.items():
    cid = info["chembl"]
    try:
        d = fetch(CHEMBL + "/activity.json?target_chembl_id=%s&pchembl_value__gte=%s&standard_relation=%%3D&limit=1000"
                  % (cid, MIN_PCH), "act_%s.json" % gene)
    except Exception as e:
        print("  %-8s 活性失败 %s" % (gene, str(e)[:40]), flush=True)
        continue
    best = {}
    for a in d.get("activities", []):
        mid, pv = a.get("molecule_chembl_id"), a.get("pchembl_value")
        if not mid or pv is None:
            continue
        try:
            pv = float(pv)
        except Exception:
            continue
        if mid not in best or pv > best[mid]:
            best[mid] = pv
    ordered = sorted(best.items(), key=lambda kv: -kv[1])
    if len(ordered) < 15:
        print("  %-8s 配体不足(%d)" % (gene, len(ordered)), flush=True)
        continue
    if len(ordered) >= N_PER:
        idx = [round(i * (len(ordered) - 1) / (N_PER - 1)) for i in range(N_PER)]
        sel = [ordered[i] for i in sorted(set(idx))]
    else:
        sel = ordered
    ligands[gene] = sel
    print("  %-8s 可用 %4d -> %2d (pChEMBL %.2f-%.2f)" % (gene, len(best), len(sel), sel[-1][1], sel[0][1]), flush=True)

# ---------- 3) SMILES ----------
print("\n=== 3) 批量取 SMILES ===", flush=True)
mids = sorted({m for v in ligands.values() for m, _ in v})
smiles = {}
for i in range(0, len(mids), 20):
    try:
        d = fetch(CHEMBL + "/molecule.json?molecule_chembl_id__in=%s&limit=100" % ",".join(mids[i:i + 20]),
                  "mol_%05d.json" % i)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st:
                smiles[mid] = st
    except Exception as e:
        print("   [warn] 批 %d: %s" % (i, str(e)[:50]), flush=True)
    if i % 300 == 0:
        print("   ... %d/%d,已得 %d" % (i, len(mids), len(smiles)), flush=True)
print("   SMILES %d / %d" % (len(smiles), len(mids)), flush=True)

# ---------- 4) 序列 ----------
print("\n=== 4) 取序列 ===", flush=True)
seqs = {}
for gene, info in resolved.items():
    acc = info["uniprot"]
    try:
        d = fetch("https://rest.uniprot.org/uniprotkb/search?format=json&size=1&fields=sequence&query=accession:%s" % acc,
                  "seq_%s.json" % acc)
        seqs[gene] = d["results"][0]["sequence"]["value"]
    except Exception:
        pass
print("   序列 %d" % len(seqs), flush=True)

# ---------- 5) 落盘 ----------
rows = []
for gene, sel in ligands.items():
    if gene not in seqs:
        continue
    for mid, pv in sel:
        if mid in smiles:
            rows.append({"target": gene, "chembl_target": resolved[gene]["chembl"],
                         "uniprot": resolved[gene]["uniprot"], "cls": resolved[gene]["cls"],
                         "sequence": seqs[gene], "molecule_chembl_id": mid,
                         "pchembl": pv, "smiles": smiles[mid]})
out = os.path.join(OUT, "bench_eval_set_large.csv")
with open(out, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["target", "chembl_target", "uniprot", "cls", "sequence",
                                      "molecule_chembl_id", "pchembl", "smiles"])
    w.writeheader()
    w.writerows(rows)

from collections import Counter
c = Counter(r["target"] for r in rows)
cc = Counter()
for r in rows:
    cc[r["cls"]] += 0
tcls = {g: i["cls"] for g, i in resolved.items()}
bycls = Counter(tcls[g] for g in c)
print("\n=== 汇总 ===", flush=True)
print("  靶点 %d 个,配体记录 %d 条" % (len(c), len(rows)), flush=True)
print("  类别:", dict(bycls), flush=True)
print("  落盘:", out, flush=True)
