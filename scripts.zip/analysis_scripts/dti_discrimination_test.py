# -*- coding: utf-8 -*-
"""
M4-v2 — 决定性判别力测试(替代 M4 的跨靶点打乱设计)

M4 的缺陷:用「同药换靶」当负样本,但所选药物多为广谱结合剂(dasatinib 多激酶、
caffeine 作用于 ADORA1/2A/2B、acetazolamide 多碳酸酐酶),导致部分"负样本"实为真结合,
AUC 被压低(0.562),无法区分「模型无判别力」与「对照设计有缺陷」。

本版改为 **同靶点内 已知结合剂 vs 已知非结合剂**:
  对每个靶点,只比较"已知有药理作用(正)"与"药理学无关(负)"的分子 —— 标签干净。
  指标:全局 AUC + 每靶点的 正-负 均值差。

同时修正:M4 里模型落在 cpu,这里显式 .to("cuda")。
"""
import os
import json
import time
import urllib.parse
import urllib.request

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "results")
CACHE = os.path.join(ROOT, "cache", "m4")
os.makedirs(OUT, exist_ok=True)
os.makedirs(CACHE, exist_ok=True)

LOCAL_MODEL = r"G:\HHH\openclaw-workspace\downloads\dti_models\ibm-ted-dti"
TOKENIZER_DIR = os.path.join(LOCAL_MODEL, "tokenizer")

import torch
from fuse.data.tokenizers.modular_tokenizer.op import ModularTokenizerOp
from mammal.model import Mammal
from dti_mammal import data_preprocessing, process_model_output, NORM_Y_MEAN, NORM_Y_STD


def fetch(url, name, timeout=60):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        with open(cf, "r", encoding="utf-8") as f:
            return json.load(f)
    req = urllib.request.Request(url, headers={"User-Agent": "netpharm-m4v2"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    with open(cf, "w", encoding="utf-8") as f:
        json.dump(data, f)
    time.sleep(0.3)
    return data


def uniprot_seq(acc):
    url = ("https://rest.uniprot.org/uniprotkb/search?format=json&size=1&fields=sequence&query="
           + urllib.parse.quote("accession:" + acc))
    return fetch(url, "seq_%s.json" % acc)["results"][0]["sequence"]["value"]


def pubchem_smiles(name):
    props = "IsomericSMILES,CanonicalSMILES,ConnectivitySMILES"
    url = ("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/%s/property/%s/JSON"
           % (urllib.parse.quote(name), props))
    row = fetch(url, "smiles_%s.json" % name.replace(" ", "_"))["PropertyTable"]["Properties"][0]
    for k in ("IsomericSMILES", "CanonicalSMILES", "ConnectivitySMILES", "SMILES"):
        if k in row:
            return row[k]
    raise KeyError("no SMILES for %s: %s" % (name, list(row.keys())))


TARGETS = {
    "P00519": "ABL1", "P00533": "EGFR", "P35354": "PTGS2/COX2",
    "P00918": "CA2", "P29274": "ADORA2A", "P14867": "GABRA1",
}

# (药物, 靶点, 标签)  标签 1 = 已知药理结合; 0 = 药理学无关(干净负样本)
LABELS = [
    # ABL1
    ("imatinib", "P00519", 1), ("dasatinib", "P00519", 1), ("nilotinib", "P00519", 1),
    ("caffeine", "P00519", 0), ("acetazolamide", "P00519", 0), ("methotrexate", "P00519", 0),
    # EGFR
    ("erlotinib", "P00533", 1), ("gefitinib", "P00533", 1),
    ("caffeine", "P00533", 0), ("acetazolamide", "P00533", 0), ("methotrexate", "P00533", 0),
    # PTGS2
    ("celecoxib", "P35354", 1), ("ibuprofen", "P35354", 1),
    ("caffeine", "P35354", 0), ("methotrexate", "P35354", 0),
    # CA2
    ("acetazolamide", "P00918", 1),
    ("caffeine", "P00918", 0), ("diazepam", "P00918", 0), ("imatinib", "P00918", 0),
    # ADORA2A(caffeine 是拮抗剂)
    ("caffeine", "P29274", 1),
    ("acetazolamide", "P29274", 0), ("methotrexate", "P29274", 0),
    # GABRA1
    ("diazepam", "P14867", 1),
    ("caffeine", "P14867", 0), ("imatinib", "P14867", 0),
]

drugs = sorted({d for d, _, _ in LABELS})
accs = sorted({a for _, a, _ in LABELS})

print("[1] fetch %d drugs + %d targets ..." % (len(drugs), len(accs)), flush=True)
seqs, smis = {}, {}
for a in accs:
    seqs[a] = uniprot_seq(a)
    print("    target %-10s len=%d" % (TARGETS[a], len(seqs[a])), flush=True)
for d in drugs:
    smis[d] = pubchem_smiles(d)
    print("    drug   %-14s %s" % (d, smis[d][:40]), flush=True)

print("\n[2] load model + move to cuda ...", flush=True)
tokenizer_op = ModularTokenizerOp.from_pretrained(TOKENIZER_DIR)
model = Mammal.from_pretrained(LOCAL_MODEL)
model.eval()
if torch.cuda.is_available():
    model = model.to("cuda")
dev = model.device
print("    device:", dev, flush=True)


def predict(drug, acc):
    s = {"target_seq": seqs[acc], "drug_seq": smis[drug]}
    s = data_preprocessing(sample_dict=s, tokenizer_op=tokenizer_op,
                           target_sequence_key="target_seq", drug_sequence_key="drug_seq",
                           norm_y_mean=None, norm_y_std=None, device=dev)
    with torch.no_grad():
        b = model.forward_encoder_only([s])
    b = process_model_output(b, scalars_preds_processed_key="model.out.dti_bindingdb_kd",
                             norm_y_mean=NORM_Y_MEAN, norm_y_std=NORM_Y_STD)
    return float(b["model.out.dti_bindingdb_kd"][0])


print("\n[3] predict %d labelled pairs ..." % len(LABELS), flush=True)
t0 = time.time()
rows = []
for drug, acc, lab in LABELS:
    v = predict(drug, acc)
    rows.append({"drug": drug, "target": TARGETS[acc], "acc": acc, "label": lab, "pkd": round(v, 3)})
    print("    %-14s + %-10s  y=%d  pKd=%.3f" % (drug, TARGETS[acc], lab, v), flush=True)
print("    (%.1fs)" % (time.time() - t0), flush=True)

y = [r["label"] for r in rows]
s = [r["pkd"] for r in rows]
try:
    from sklearn.metrics import roc_auc_score
    auc = float(roc_auc_score(y, s))
except Exception as e:
    # 手算 AUC
    pos = [v for v, l in zip(s, y) if l == 1]
    neg = [v for v, l in zip(s, y) if l == 0]
    wins = sum(1 for a in pos for b in neg if a > b) + 0.5 * sum(1 for a in pos for b in neg if a == b)
    auc = wins / (len(pos) * len(neg))
    print("    (sklearn 不可用,已手算 AUC:", e, ")", flush=True)

pos = [v for v, l in zip(s, y) if l == 1]
neg = [v for v, l in zip(s, y) if l == 0]
per_target = {}
for a in accs:
    p = [r["pkd"] for r in rows if r["acc"] == a and r["label"] == 1]
    n = [r["pkd"] for r in rows if r["acc"] == a and r["label"] == 0]
    if p and n:
        per_target[TARGETS[a]] = {
            "n_pos": len(p), "n_neg": len(n),
            "mean_pos": round(sum(p) / len(p), 3), "mean_neg": round(sum(n) / len(n), 3),
            "delta": round(sum(p) / len(p) - sum(n) / len(n), 3),
        }

summary = {
    "n_pairs": len(rows), "n_pos": len(pos), "n_neg": len(neg),
    "mean_pos": round(sum(pos) / len(pos), 3), "mean_neg": round(sum(neg) / len(neg), 3),
    "delta": round(sum(pos) / len(pos) - sum(neg) / len(neg), 3),
    "auc": round(auc, 3), "per_target": per_target,
}
print("\n==== M4-v2 SUMMARY ====", flush=True)
print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
with open(os.path.join(OUT, "m4v2_discrimination.json"), "w", encoding="utf-8") as f:
    json.dump({"summary": summary, "rows": rows}, f, ensure_ascii=False, indent=2)

verdict = "PASS" if auc >= 0.7 else ("WEAK" if auc >= 0.6 else "FAIL")
print("\nM4-v2 %s  (AUC=%.3f, delta=%+.3f)" % (verdict, auc, summary["delta"]), flush=True)
