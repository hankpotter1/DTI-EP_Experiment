# -*- coding: utf-8 -*-
"""
M3 — DTI 模型加载 + 单次前向推理验证

来源:IBM `ibm/biomed.omics.bl.sm.ma-ted-458m.dti_bindingdb_pkd`(MAMMAL / TED,458M)
权重已离线下载至 downloads/dti_models/ibm-ted-dti —— 所以 from_pretrained 走本地路径,
并强制离线模式,避免去 huggingface.co(hf.co 在本机被墙)。

通过标准:能加载模型 + 打印出一个有限的 pKd 数值。
"""
import os
import time

# 强制离线,避免联网(hf.co 被墙)
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"] = "1"

LOCAL_MODEL = r"G:\HHH\openclaw-workspace\downloads\dti_models\ibm-ted-dti"

import torch
print("torch:", torch.__version__, "| cuda_build:", torch.version.cuda,
      "| available:", torch.cuda.is_available(), flush=True)
if torch.cuda.is_available():
    print("device:", torch.cuda.get_device_name(0), flush=True)

t0 = time.time()
print("\n[1] import mammal/fuse ...", flush=True)
from fuse.data.tokenizers.modular_tokenizer.op import ModularTokenizerOp
from mammal.model import Mammal
# 用本地适配层替代 mammal.examples.dti_bindingdb_kd.task
# —— 该模块的导入链会拉到 pyTDC，而 pyTDC 依赖 tiledbsoma 在 Windows 上编译失败
from dti_mammal import data_preprocessing, process_model_output, NORM_Y_MEAN, NORM_Y_STD
print("    imports OK  (%.1fs)" % (time.time() - t0), flush=True)

print("\n[2] load tokenizer from local path ...", flush=True)
t1 = time.time()
# 注意：ModularTokenizerOp.from_pretrained 若收到「目录」，会直接把它当 tokenizer_path，
# 并要求 config.yaml 就在该目录下。而 HF 仓库里 config.yaml 在 tokenizer/ 子目录 → 必须指到该子目录。
TOKENIZER_DIR = os.path.join(LOCAL_MODEL, "tokenizer")
tokenizer_op = ModularTokenizerOp.from_pretrained(TOKENIZER_DIR)
print("    tokenizer OK  (%.1fs)" % (time.time() - t1), flush=True)

print("\n[3] load model from local path ...", flush=True)
t2 = time.time()
model = Mammal.from_pretrained(LOCAL_MODEL)
model.eval()
print("    model OK  (%.1fs)" % (time.time() - t2), flush=True)
try:
    n_par = sum(p.numel() for p in model.parameters())
    print("    params: %.1fM" % (n_par / 1e6), flush=True)
except Exception as e:
    print("    (param count skipped:", e, ")", flush=True)

# README 自带示例对
target_seq = "NLMKRCTRGFRKLGKCTTLEEEKCKTLYPRGQCTCSDSKMNTHSCDCKSC"
drug_seq = "CC(=O)NCCC1=CNc2c1cc(OC)cc2"

print("\n[4] data_preprocessing + forward_encoder_only ...", flush=True)
t3 = time.time()
sample_dict = {"target_seq": target_seq, "drug_seq": drug_seq}
sample_dict = data_preprocessing(
    sample_dict=sample_dict,
    tokenizer_op=tokenizer_op,
    target_sequence_key="target_seq",
    drug_sequence_key="drug_seq",
    norm_y_mean=None,
    norm_y_std=None,
    device=model.device,
)
with torch.no_grad():
    batch_dict = model.forward_encoder_only([sample_dict])
batch_dict = process_model_output(
    batch_dict,
    scalars_preds_processed_key="model.out.dti_bindingdb_kd",
    norm_y_mean=NORM_Y_MEAN,
    norm_y_std=NORM_Y_STD,
)
ans = {"model.out.dti_bindingdb_kd": float(batch_dict["model.out.dti_bindingdb_kd"][0])}
print("    forward OK  (%.1fs)" % (time.time() - t3), flush=True)

print("\n==== RESULT ====", flush=True)
print("pKd prediction:", ans["model.out.dti_bindingdb_kd"], flush=True)
print("total elapsed: %.1fs" % (time.time() - t0), flush=True)
print("M3 PASS" if ans["model.out.dti_bindingdb_kd"] == ans["model.out.dti_bindingdb_kd"] else "M3 FAIL",
      flush=True)
