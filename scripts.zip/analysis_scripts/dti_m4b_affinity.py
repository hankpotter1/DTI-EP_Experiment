# -*- coding: utf-8 -*-
"""
M4-b — 严格判别力复核:同靶点内「预测 pKd vs 实测 pChEMBL」的 Spearman 相关

为什么需要:
  M4-v2 用"药理学无关分子"当负样本,但 caffeine 等本身就是弱结合剂(嘌呤类/ATP 竞争性),
  负样本不干净 → 无法据此断定模型无判别力。
本设计:
  对若干靶点,取同一靶点下**实测亲和力跨越多个量级**的配体系列,
  看模型预测的 pKd 能否复现实测 pChEMBL 的排序。
  若 Spearman ≈ 0 → 模型在亲和力排序上无信息量(结论钉死);
  若相关显著 → 说明 M4/M4-v2 的 AUC 是被脏负样本压低的。

数据源:ChEMBL(实测活性)+ UniProt(序列)。模型:MAMMAL TED-DTI(本地权重)。
"""
import os
import json
import time
import urllib.parse
import urllib.request

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CACHE = os.path.join(ROOT, "cache", "m4b")
OUT = os.path.join(ROOT, "results")
os.makedirs(CACHE, exist_ok=True)
os.makedirs(OUT, exist_ok=True)

LOCAL_MODEL = r"G:\HHH\openclaw-workspace\downloads\dti_models\ibm-ted-dti"
TOKENIZER_DIR = os.path.join(LOCAL_MODEL, "tokenizer")

CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
UA = {"User-Agent": "netpharm-m4b"}

# 靶点:ChEMBL ID / UniProt / 名称
TARGETS = [
    ("CHEMBL205",  "P00918", "CA2"),
    ("CHEMBL1862", "P00519", "ABL1"),
    ("CHEMBL230",  "P35354", "PTGS2"),
]
N_PER_TARGET = 14


def fetch_url(url, cache_name, timeout=90):
    cf = os.path.join(CACHE, cache_name)
    if os.path.isfile(cf):
        with open(cf, "r", encoding="utf-8") as f:
            return json.load(f)
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    with open(cf, "w", encoding="utf-8") as f:
        json.dump(data, f)
    time.sleep(0.3)
    return data


def uniprot_seq(acc):
    url = ("https://rest.uniprot.org/uniprotkb/search?format=json&size=1&fields=sequence&query="
           + urllib.parse.quote("accession:" + acc))
    return fetch_url(url, "seq_%s.json" % acc)["results"][0]["sequence"]["value"]


print("[1] 抓 ChEMBL 实测活性(同一靶点、亲和力跨度大) ...", flush=True)
pairs = {}   # target_name -> list of (molecule_chembl_id, pchembl)
for cid, acc, name in TARGETS:
    url = ("%s/activity.json?target_chembl_id=%s&pchembl_value__gte=5&standard_relation=%%3D"
           "&limit=1000" % (CHEMBL, cid))
    try:
        d = fetch_url(url, "act_%s.json" % cid)
        acts = d.get("activities", [])
    except Exception as e:
        print("   [warn] %s 活性抓取失败: %s" % (name, str(e)[:60]))
        continue
    best = {}
    for a in acts:
        mid = a.get("molecule_chembl_id")
        pv = a.get("pchembl_value")
        if not mid or pv is None:
            continue
        try:
            pv = float(pv)
        except Exception:
            continue
        if mid not in best or pv > best[mid]:
            best[mid] = pv
    # 按亲和力排序后均匀取样,保证跨量级
    ordered = sorted(best.items(), key=lambda kv: -kv[1])
    if len(ordered) > N_PER_TARGET:
        idx = [round(i * (len(ordered) - 1) / (N_PER_TARGET - 1)) for i in range(N_PER_TARGET)]
        ordered = [ordered[i] for i in sorted(set(idx))]
    pairs[name] = ordered
    print("   %-6s 可用分子 %d,取样 %d,实测 pChEMBL 范围 %.2f-%.2f" % (
        name, len(best), len(ordered), ordered[-1][1], ordered[0][1]), flush=True)

# ---- 批量取 SMILES ----
print("\n[2] 批量取 SMILES ...", flush=True)
all_mids = sorted({m for v in pairs.values() for m, _ in v})
smiles = {}
for i in range(0, len(all_mids), 40):
    batch = all_mids[i:i + 40]
    url = ("%s/molecule.json?molecule_chembl_id__in=%s&limit=100"
           % (CHEMBL, ",".join(batch)))
    try:
        d = fetch_url(url, "mol_%d.json" % i)
        for m in d.get("molecules", []):
            mid = m.get("molecule_chembl_id")
            st = (m.get("molecule_structures") or {}).get("canonical_smiles")
            if mid and st:
                smiles[mid] = st
    except Exception as e:
        print("   [warn] 批次 %d: %s" % (i, str(e)[:60]))
print("   拿到 SMILES 的分子数:", len(smiles), "/", len(all_mids), flush=True)

# ---- 模型推理 ----
import torch
from fuse.data.tokenizers.modular_tokenizer.op import ModularTokenizerOp
from mammal.model import Mammal
from dti_mammal import data_preprocessing, process_model_output, NORM_Y_MEAN, NORM_Y_STD

print("\n[3] 加载模型 ...", flush=True)
tokenizer_op = ModularTokenizerOp.from_pretrained(TOKENIZER_DIR)
model = Mammal.from_pretrained(LOCAL_MODEL)
model.eval()
if torch.cuda.is_available():
    model = model.to("cuda")
print("   device:", model.device, flush=True)

seqs = {name: uniprot_seq(acc) for _, acc, name in TARGETS}
print("   序列长度:", {k: len(v) for k, v in seqs.items()}, flush=True)


def predict(sm, seq):
    s = {"target_seq": seq, "drug_seq": sm}
    s = data_preprocessing(sample_dict=s, tokenizer_op=tokenizer_op,
                           target_sequence_key="target_seq", drug_sequence_key="drug_seq",
                           norm_y_mean=None, norm_y_std=None, device=model.device)
    with torch.no_grad():
        b = model.forward_encoder_only([s])
    b = process_model_output(b, scalars_preds_processed_key="model.out.dti_bindingdb_kd",
                             norm_y_mean=NORM_Y_MEAN, norm_y_std=NORM_Y_STD)
    return float(b["model.out.dti_bindingdb_kd"][0])


print("\n[4] 逐靶点:预测 vs 实测", flush=True)
from scipy.stats import spearmanr

summary = {}
for name, lst in pairs.items():
    if name not in seqs:
        continue
    meas, pred = [], []
    print("\n   ---- %s (序列 %d aa) ----" % (name, len(seqs[name])), flush=True)
    for mid, pv in lst:
        sm = smiles.get(mid)
        if not sm:
            continue
        p = predict(sm, seqs[name])
        meas.append(pv); pred.append(p)
        print("      %-14s 实测 %.2f  预测 %.2f" % (mid, pv, p), flush=True)
    if len(meas) >= 5:
        rho, pval = spearmanr(meas, pred)
        summary[name] = {"n": len(meas), "spearman": round(float(rho), 3),
                         "p": round(float(pval), 4),
                         "measured_range": [round(min(meas), 2), round(max(meas), 2)],
                         "predicted_range": [round(min(pred), 2), round(max(pred), 2)],
                         "predicted_sd": round(float(torch.tensor(pred).std()), 3)}
        print("      -> Spearman rho=%.3f  p=%.4f  (n=%d)" % (rho, pval, len(meas)), flush=True)

print("\n==== M4-b SUMMARY ====", flush=True)
print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
with open(os.path.join(OUT, "m4b_affinity_correlation.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

if summary:
    allrho = [v["spearman"] for v in summary.values()]
    mean_rho = sum(allrho) / len(allrho)
    verdict = ("模型具备亲和力排序能力" if mean_rho >= 0.4 else
               ("信号微弱、不足以做靶点预测" if mean_rho >= 0.15 else
                "模型无亲和力排序能力(结论钉死)"))
    print("\n平均 Spearman rho = %.3f -> %s" % (mean_rho, verdict), flush=True)
    print("预测值标准差(各靶点):", {k: v["predicted_sd"] for k, v in summary.items()}, flush=True)
