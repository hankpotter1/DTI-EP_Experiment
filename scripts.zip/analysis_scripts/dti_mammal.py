# -*- coding: utf-8 -*-
"""
dti_mammal.py — MAMMAL DTI 任务的「无 tdc」适配层

背景:官方用法要 `from mammal.examples.dti_bindingdb_kd.task import DtiBindingdbKdTask`,
但 task -> pl_data_module -> `from tdc.multi_pred.dti import DTI`,
而 pyTDC 的依赖 `tiledbsoma` 在 Windows 上编译失败(WinError 2,找不到 tiledbsoma.dll)。

我们实际只用到 task 里两个 @staticmethod,它们只依赖 fuse + torch + mammal.keys。
故原样抄出(逐行照搬上游实现,未改动逻辑),从关键路径上彻底摘掉 tdc。

来源文件: mammal/examples/dti_bindingdb_kd/task.py (line 103-247)
"""
from typing import Any

import torch
from fuse.data.tokenizers.modular_tokenizer.op import ModularTokenizerOp
from mammal.keys import *  # noqa: F401,F403  上游同样用法


def data_preprocessing(
    sample_dict: dict,
    *,
    target_sequence_key: str,
    drug_sequence_key: str,
    ground_truth_key: int | None = None,
    target_max_seq_length: int = 1250,
    drug_max_seq_length: int = 256,
    encoder_input_max_seq_len: int = 1512,
    tokenizer_op: ModularTokenizerOp,
    norm_y_mean: float,
    norm_y_std: float,
    device: str | torch.device = "cpu",
) -> dict[str, Any]:
    """照搬上游 DtiBindingdbKdTask.data_preprocessing。"""
    target_sequence = sample_dict[target_sequence_key]
    drug_sequence = sample_dict[drug_sequence_key]
    ground_truth_value = sample_dict.get(ground_truth_key, None)

    sample_dict[ENCODER_INPUTS_STR] = (
        "<@TOKENIZER-TYPE=AA><MASK>"
        f"<@TOKENIZER-TYPE=AA@MAX-LEN={target_max_seq_length}><MOLECULAR_ENTITY><MOLECULAR_ENTITY_GENERAL_PROTEIN><SEQUENCE_NATURAL_START>{target_sequence}<SEQUENCE_NATURAL_END>"
        f"<@TOKENIZER-TYPE=SMILES@MAX-LEN={drug_max_seq_length}><MOLECULAR_ENTITY><MOLECULAR_ENTITY_SMALL_MOLECULE><SEQUENCE_NATURAL_START>{drug_sequence}<SEQUENCE_NATURAL_END>"
        "<EOS>"
    )
    tokenizer_op(
        sample_dict,
        key_in=ENCODER_INPUTS_STR,
        key_out_tokens_ids=ENCODER_INPUTS_TOKENS,
        key_out_attention_mask=ENCODER_INPUTS_ATTENTION_MASK,
        max_seq_len=encoder_input_max_seq_len,
        key_out_scalars=ENCODER_INPUTS_SCALARS,
    )

    sample_dict[ENCODER_INPUTS_TOKENS] = torch.tensor(
        sample_dict[ENCODER_INPUTS_TOKENS], device=device
    )
    sample_dict[ENCODER_INPUTS_ATTENTION_MASK] = torch.tensor(
        sample_dict[ENCODER_INPUTS_ATTENTION_MASK], device=device
    )

    if ground_truth_value is not None:
        ground_truth_value = (ground_truth_value - norm_y_mean) / norm_y_std
        pad_id = tokenizer_op.get_token_id("<PAD>")
        ignore_token_value = -100
        sample_dict[LABELS_STR] = (
            f"<@TOKENIZER-TYPE=SCALARS_LITERALS>{ground_truth_value}<@TOKENIZER-TYPE=AA>"
            + "".join(["<PAD>"] * (encoder_input_max_seq_len - 1))
        )
        tokenizer_op(
            sample_dict,
            key_in=LABELS_STR,
            key_out_tokens_ids=LABELS_TOKENS,
            key_out_attention_mask=LABELS_ATTENTION_MASK,
            max_seq_len=encoder_input_max_seq_len,
            key_out_scalars=LABELS_SCALARS,
            validate_ends_with_eos=False,
        )
        sample_dict[LABELS_TOKENS] = torch.tensor(
            sample_dict[LABELS_TOKENS], device=device
        )
        sample_dict[LABELS_ATTENTION_MASK] = torch.tensor(
            sample_dict[LABELS_ATTENTION_MASK], device=device
        )
        pad_id_tns = torch.tensor(pad_id)
        sample_dict[LABELS_TOKENS][
            (sample_dict[LABELS_TOKENS][..., None] == pad_id_tns).any(-1).nonzero()
        ] = ignore_token_value
        sample_dict[LABELS_SCALARS_VALUES] = sample_dict[LABELS_SCALARS_VALUES].to(
            device=device
        )
        sample_dict[LABELS_SCALARS_VALID_MASK] = sample_dict[
            LABELS_SCALARS_VALID_MASK
        ].to(device=device)

    return sample_dict


def process_model_output(
    batch_dict: dict,
    *,
    scalars_preds_key: str = SCALARS_PREDICTION_HEAD_LOGITS,
    scalars_preds_processed_key: str = "model.out.dti_bindingdb_kd",
    norm_y_mean: float,
    norm_y_std: float,
) -> dict:
    """照搬上游 DtiBindingdbKdTask.process_model_output。"""
    scalars_preds = batch_dict[scalars_preds_key]
    batch_dict[scalars_preds_processed_key] = (
        scalars_preds[:, 0] * norm_y_std + norm_y_mean
    )
    return batch_dict


# BindingDB pKd 的官方归一化参数(上游 task 配置里给定)
NORM_Y_MEAN = 5.79384684128215
NORM_Y_STD = 1.33808027428196
