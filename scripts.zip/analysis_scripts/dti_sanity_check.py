# -*- coding: utf-8 -*-
"""
M4 — Sanity check:已知药物 × 真实靶点  vs  打乱配对

目的:模型"能跑"不等于"输出有信息"。这里用一组**已知药物-靶点对**(药物 + 其主要靶点)
与**打乱配对**(同样这些药,配到无关蛋白)做对照,验证:
  1) 预测值有限且在合理区间
  2) 真配对的 pKd 显著高于打乱配对 → 模型确实携带结合亲和力信息

靶点清单特意混入本项目的癫痫相关靶点(ADORA2A / GABRA1),顺带预检我们关心的蛋白。
序列来自 UniProt,SMILES 来自 PubChem —— 均走网络,结果落盘缓存。
"""
import os
import json
import time
import urllib.parse
import urllib.request

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(HERE), "results")
os.makedirs(OUT, exist_ok=True)
CACHE = os.path.join(os.path.dirname(HERE), "cache", "m4")
os.makedirs(CACHE, exist_ok=True)

LOCAL_MODEL = r"G:\HHH\openclaw-workspace\downloads\dti_models\ibm-ted-dti"
TOKENIZER_DIR = os.path.join(LOCAL_MODEL, "tokenizer")

import torch
from fuse.data.tokenizers.modular_tokenizer.op import ModularTokenizerOp
from mammal.model import Mammal
from dti_mammal import data_preprocessing, process_model_output, NORM_Y_MEAN, NORM_Y_STD


def fetch(url, name, timeout=60):
    cf = os.path.join(CACHE, name)
    if os.path.isfile(cf):
        with open(cf, "r", encoding="utf-8") as f:
            return json.load(f)
    req = urllib.request.Request(url, headers={"User-Agent": "netpharm-m4"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    with open(cf, "w", encoding="utf-8") as f:
        json.dump(data, f)
    time.sleep(0.4)
    return data


def uniprot_seq(acc):
    url = ("https://rest.uniprot.org/uniprotkb/search?format=json&size=1&fields=sequence&query="
           + urllib.parse.quote("accession:" + acc))
    d = fetch(url, "seq_%s.json" % acc)
    return d["results"][0]["sequence"]["value"]


def pubchem_smiles(name):
    # 注意：本机 PubChem 返回的是 ConnectivitySMILES（不是 CanonicalSMILES），故多键兼容；
    # 优先取含立体信息的 IsomericSMILES。
    props = "IsomericSMILES,CanonicalSMILES,ConnectivitySMILES"
    url = ("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/%s/property/%s/JSON"
           % (urllib.parse.quote(name), props))
    d = fetch(url, "smiles_%s.json" % name.replace(" ", "_"))
    row = d["PropertyTable"]["Properties"][0]
    for k in ("IsomericSMILES", "CanonicalSMILES", "ConnectivitySMILES", "SMILES"):
        if k in row:
            return row[k]
    raise KeyError("PubChem 响应里没有可用的 SMILES 字段: %s" % list(row.keys()))


# 药物 → 真实靶点(UniProt)
PAIRS = [
    ("imatinib",      "P00519", "ABL1"),
    ("dasatinib",     "P00519", "ABL1"),
    ("erlotinib",     "P00533", "EGFR"),
    ("celecoxib",     "P35354", "PTGS2/COX2"),
    ("methotrexate",  "P00374", "DHFR"),
    ("acetazolamide", "P00918", "CA2"),
    ("caffeine",      "P29274", "ADORA2A"),   # 癫痫相关
    ("diazepam",      "P14867", "GABRA1"),    # 癫痫相关
]

print("[1] fetch targets(UniProt)+ drugs(PubChem) ...", flush=True)
targets, drugs = {}, {}
for drug, acc, tname in PAIRS:
    if acc not in targets:
        targets[acc] = (tname, uniprot_seq(acc))
        print("    target %-10s len=%d" % (tname, len(targets[acc][1])), flush=True)
    if drug not in drugs:
        drugs[drug] = pubchem_smiles(drug)
        print("    drug   %-14s smiles=%s" % (drug, drugs[drug][:44]), flush=True)

print("\n[2] load tokenizer + model ...", flush=True)
tokenizer_op = ModularTokenizerOp.from_pretrained(TOKENIZER_DIR)
model = Mammal.from_pretrained(LOCAL_MODEL)
model.eval()
dev = model.device
print("    device:", dev, flush=True)


def predict(drug, acc):
    s = {"target_seq": targets[acc][1], "drug_seq": drugs[drug]}
    s = data_preprocessing(sample_dict=s, tokenizer_op=tokenizer_op,
                           target_sequence_key="target_seq", drug_sequence_key="drug_seq",
                           norm_y_mean=None, norm_y_std=None, device=dev)
    with torch.no_grad():
        b = model.forward_encoder_only([s])
    b = process_model_output(b, scalars_preds_processed_key="model.out.dti_bindingdb_kd",
                             norm_y_mean=NORM_Y_MEAN, norm_y_std=NORM_Y_STD)
    return float(b["model.out.dti_bindingdb_kd"][0])


print("\n[3] true pairs ...", flush=True)
true_scores = []
for drug, acc, tname in PAIRS:
    v = predict(drug, acc)
    true_scores.append(v)
    print("    %-14s + %-10s -> pKd %.3f" % (drug, tname, v), flush=True)

print("\n[4] shuffled decoys(same drugs, wrong targets) ...", flush=True)
accs = [a for _, a, _ in PAIRS]
decoy_scores = []
for i, (drug, acc, tname) in enumerate(PAIRS):
    other = accs[(i + 1) % len(accs)]
    if other == acc:
        other = accs[(i + 2) % len(accs)]
    v = predict(drug, other)
    decoy_scores.append(v)
    print("    %-14s + %-10s -> pKd %.3f  (decoy)" % (drug, targets[other][0], v), flush=True)

def mean(x):
    return sum(x) / len(x)

mt, md = mean(true_scores), mean(decoy_scores)
# 简单 AUC(真配对得分 > 打乱配对的比例)
wins = sum(1 for a in true_scores for b in decoy_scores if a > b)
auc = wins / (len(true_scores) * len(decoy_scores))

summary = {
    "n_pairs": len(PAIRS),
    "mean_true": round(mt, 3), "mean_decoy": round(md, 3),
    "delta": round(mt - md, 3), "auc": round(auc, 3),
    "true": [round(v, 3) for v in true_scores],
    "decoy": [round(v, 3) for v in decoy_scores],
}
print("\n==== M4 SUMMARY ====", flush=True)
print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
with open(os.path.join(OUT, "m4_sanity_check.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)
print("\nM4 %s  (AUC=%.3f, delta=%+.3f)" % ("PASS" if auc >= 0.7 else "WEAK", auc, mt - md), flush=True)
