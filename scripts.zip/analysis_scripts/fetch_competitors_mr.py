# -*- coding: utf-8 -*-
"""
③ 精读竞品 —— 抓取「蛋白组/血浆蛋白 MR × 癫痫」同赛道论文,用于确定我们的差异化。

Hank 的稿件:cis-pQTL MR,SULT1A1/DNER × GGE(ILAE 2023 亚型分层),FinnGen R12。
需要知道:(a) 竞品做了什么、(b) 它们的结局定义是"癫痫"还是分亚型、(c) 我们哪里不同。
"""
import os
import sys
import json

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import np_survey as SV

OUT = os.path.join(ROOT, "results")
os.makedirs(OUT, exist_ok=True)

QUERIES = [
    ('血浆蛋白组 MR × 癫痫', 'TITLE:"plasma proteome" AND epilepsy AND "Mendelian"'),
    ('蛋白组宽 MR × 癫痫',   'TITLE:"proteome-wide" AND epilepsy AND "Mendelian"'),
    ('蛋白 MR × 癫痫(宽)',  '(proteome OR protein) AND epilepsy AND "Mendelian randomization" AND (pQTL OR "protein quantitative")'),
    ('炎症蛋白 MR × 癫痫',   '"inflammatory protein" AND epilepsy AND "Mendelian"'),
]

seen, rows = set(), []
for label, q in QUERIES:
    recs = SV.search(q, size=40)
    print("=== %s  命中 %d ===" % (label, len(recs)), flush=True)
    for r in recs:
        key = r.get("doi") or r.get("pmid") or (r.get("title") or "")[:60]
        if key in seen:
            continue
        seen.add(key)
        ji = r.get("journalInfo") or {}
        jt = ((ji.get("journal") or {}).get("title")) or ""
        row = {
            "label": label,
            "title": (r.get("title") or "").strip(),
            "journal": jt,
            "year": r.get("pubYear"),
            "doi": r.get("doi"),
            "pmid": r.get("pmid"),
            "abstract": (r.get("abstractText") or "").strip(),
        }
        rows.append(row)
    print()

# 只留与本课题同赛道(蛋白 + MR + 癫痫)的
KEYS = ["proteome", "protein", "pqtl", "inflammatory"]
rows = [r for r in rows if any(k in (r["title"] + " " + r["abstract"]).lower() for k in KEYS)]
rows.sort(key=lambda r: (r.get("year") or "0"), reverse=True)

with open(os.path.join(OUT, "competitors_mr_epilepsy.json"), "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)

print("==== 同赛道候选 %d 篇(按年份倒序)====" % len(rows))
for i, r in enumerate(rows, 1):
    print("%2d. [%s] %s" % (i, r["year"], r["journal"][:44]))
    print("     %s" % r["title"][:150])
    print("     DOI:%s PMID:%s" % (r["doi"], r["pmid"]))
    print("     摘要长度:%d" % len(r["abstract"]))
print("\n落盘:", os.path.join(OUT, "competitors_mr_epilepsy.json"))
