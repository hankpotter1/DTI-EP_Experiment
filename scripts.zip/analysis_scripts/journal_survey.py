# -*- coding: utf-8 -*-
"""
Empirical journal selection survey for a DTI benchmark/negative-results manuscript.
Sources: Europe PMC REST + OpenAlex REST (both verified reachable).
No journal name is written by hand as a "finding"; every count comes from a live API response.
"""
import json, time, os, urllib.parse, sys
import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results")
os.makedirs(OUT, exist_ok=True)

EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
OPENALEX = "https://api.openalex.org"
MAILTO = "survey@example.org"
UA = {"User-Agent": "journal-survey/1.0 (mailto:%s)" % MAILTO}

SESSION = requests.Session()
SESSION.headers.update(UA)

def epmc(query, page_size=100, sort=None):
    p = {"query": query, "format": "json", "pageSize": page_size, "resultType": "core"}
    if sort:
        p["sort"] = sort
    for attempt in range(3):
        try:
            r = SESSION.get(EPMC, params=p, timeout=60)
            if r.status_code == 200:
                return r.json()
            time.sleep(2)
        except Exception as e:
            time.sleep(3)
    return {"error": "failed", "query": query}

def openalex_search(search, per_page=100, extra_filter=""):
    f = "from_publication_date:2022-01-01,to_publication_date:2026-12-31"
    if extra_filter:
        f += "," + extra_filter
    p = {
        "search": search,
        "filter": f,
        "per-page": per_page,
        "mailto": MAILTO,
        "select": "id,doi,display_name,publication_year,primary_location,type,cited_by_count",
    }
    for attempt in range(3):
        try:
            r = SESSION.get(OPENALEX + "/works", params=p, timeout=60)
            if r.status_code == 200:
                return r.json()
            if r.status_code == 429:
                time.sleep(5)
            else:
                time.sleep(2)
        except Exception:
            time.sleep(3)
    return {"error": "failed", "search": search}

# ---------------------------------------------------------------- search groups
GROUPS = [
    {
        "id": "G1_dti_benchmark_critique",
        "label": "DTI evaluation / benchmark critique",
        "epmc": '("drug-target interaction" OR "drug target interaction" OR "drug-target interactions") AND (benchmark OR benchmarking OR evaluation OR pitfalls OR pitfall OR "data leakage" OR "shortcut learning" OR "performance inflation") AND ("machine learning" OR "deep learning") AND (SRC:MED) AND (PUB_YEAR:[2022 TO 2026])',
        "openalex": "drug-target interaction benchmark evaluation pitfalls data leakage deep learning",
    },
    {
        "id": "G2_split_leakage_optimism",
        "label": "Splitting / data leakage / optimistic bias in molecular ML",
        "epmc": '("scaffold split" OR "scaffold splitting" OR "data leakage" OR "random split" OR "analog bias" OR "activity cliff") AND ("molecular property prediction" OR "property prediction" OR "QSAR" OR "drug discovery") AND ("machine learning" OR "deep learning") AND (SRC:MED) AND (PUB_YEAR:[2022 TO 2026])',
        "openalex": "scaffold split data leakage optimistic bias molecular property prediction benchmark",
    },
    {
        "id": "G3_decoy_enrichment_bias",
        "label": "Decoy bias / artificial enrichment in virtual screening",
        "epmc": '("decoy" OR "decoys") AND ("bias" OR "biased" OR "artificial enrichment" OR "enrichment factor" OR "enrichment evaluation") AND ("virtual screening" OR "molecular docking") AND (SRC:MED) AND (PUB_YEAR:[2022 TO 2026])',
        "openalex": "decoy bias artificial enrichment enrichment factor virtual screening evaluation",
    },
    {
        "id": "G4_negative_reproducibility",
        "label": "Negative results / reproducibility failure in molecular ML",
        "epmc": '("negative results" OR "reproducibility crisis" OR "reproducibility" OR "replication" OR "benchmark") AND ("machine learning" OR "deep learning" OR "artificial intelligence") AND ("drug discovery" OR "cheminformatics" OR "chemistry" OR "molecular") AND (SRC:MED) AND (PUB_YEAR:[2022 TO 2026])',
        "openalex": "negative results reproducibility crisis benchmark failure machine learning drug discovery",
    },
    {
        "id": "G5_trivial_baseline",
        "label": "Simple/trivial baselines vs deep learning",
        "epmc": '("simple baselines" OR "trivial baseline" OR "simple descriptors" OR "outperform deep learning" OR "classical machine learning" OR "baseline comparison") AND ("molecular property prediction" OR "drug discovery" OR "QSAR" OR "ADMET") AND (SRC:MED) AND (PUB_YEAR:[2022 TO 2026])',
        "openalex": "simple baseline outperform deep learning molecular property prediction descriptors",
    },
]

def norm_journal(name):
    if not name:
        return "UNKNOWN"
    n = " ".join(name.split())
    return n

def run_group_search():
    raw = []
    for g in GROUPS:
        print("[epmc]", g["id"], flush=True)
        j = epmc(g["epmc"])
        hits = j.get("resultList", {}).get("result", []) if isinstance(j, dict) else []
        print("   -> %d hits (total %s)" % (len(hits), j.get("hitCount") if isinstance(j, dict) else "?"), flush=True)
        for h in hits:
            ji = h.get("journalInfo", {}) or {}
            jr = ji.get("journal", {}) or {}
            raw.append({
                "source": "europepmc",
                "group": g["id"],
                "group_label": g["label"],
                "title": h.get("title"),
                "journal": norm_journal(jr.get("title")),
                "issn": jr.get("issn"),
                "year": h.get("pubYear"),
                "doi": h.get("doi"),
                "pmid": h.get("pmid"),
                "cited": h.get("citedByCount"),
            })
        time.sleep(0.4)

        print("[openalex]", g["id"], flush=True)
        j2 = openalex_search(g["openalex"])
        hits2 = j2.get("results", []) if isinstance(j2, dict) else []
        print("   -> %d hits (total %s)" % (len(hits2), j2.get("meta", {}).get("count") if isinstance(j2, dict) else "?"), flush=True)
        for h in hits2:
            pl = h.get("primary_location") or {}
            src = pl.get("source") or {}
            raw.append({
                "source": "openalex",
                "group": g["id"],
                "group_label": g["label"],
                "title": h.get("display_name"),
                "journal": norm_journal(src.get("display_name")),
                "issn": src.get("issn_l"),
                "year": h.get("publication_year"),
                "doi": (h.get("doi") or "").replace("https://doi.org/", "") or None,
                "pmid": None,
                "cited": h.get("cited_by_count"),
            })
        time.sleep(0.4)
    return raw

# ---------------------------------------------------------------- candidates
CANDIDATES = [
    "Bioinformatics",
    "Briefings in Bioinformatics",
    "Bioinformatics Advances",
    "Briefings in Functional Genomics",
    "Journal of Chemical Information and Modeling",
    "Journal of Cheminformatics",
    "BMC Bioinformatics",
    "PLOS Computational Biology",
    "PLOS ONE",
    "Scientific Reports",
    "Patterns",
    "Digital Discovery",
    "Molecular Systems Biology",
    "Nature Machine Intelligence",
    "Machine Learning: Science and Technology",
    "Frontiers in Bioinformatics",
    "Frontiers in Pharmacology",
    "Frontiers in Genetics",
]

CRIT_TERMS = ('(benchmark OR "negative results" OR critique OR pitfall OR "data leakage" '
              'OR reproducibility OR "baseline" OR "evaluation")')

def openalex_source(name):
    p = {"search": name, "per-page": 5, "mailto": MAILTO}
    for attempt in range(3):
        try:
            r = SESSION.get(OPENALEX + "/sources", params=p, timeout=60)
            if r.status_code == 200:
                return r.json()
            time.sleep(2)
        except Exception:
            time.sleep(3)
    return {}

def run_candidate_check():
    out = []
    for c in CANDIDATES:
        print("[cand]", c, flush=True)
        rec = {"candidate": c, "openalex_source": None, "recent_critical_papers": [], "notes": []}
        sj = openalex_source(c)
        for s in (sj.get("results") or []):
            if (s.get("display_name") or "").lower().strip() == c.lower().strip():
                rec["openalex_source"] = {
                    "display_name": s.get("display_name"),
                    "issn_l": s.get("issn_l"),
                    "is_oa": s.get("is_oa"),
                    "is_in_doaj": s.get("is_in_doaj"),
                    "apc_usd": s.get("apc_usd"),
                    "apc_prices": s.get("apc_prices"),
                    "publisher": s.get("host_organization_name"),
                    "works_count": s.get("works_count"),
                    "type": s.get("type"),
                }
                break
        if rec["openalex_source"] is None and (sj.get("results") or []):
            s = sj["results"][0]
            rec["openalex_source"] = {
                "display_name": s.get("display_name"), "issn_l": s.get("issn_l"),
                "is_oa": s.get("is_oa"), "is_in_doaj": s.get("is_in_doaj"),
                "apc_usd": s.get("apc_usd"), "apc_prices": s.get("apc_prices"),
                "publisher": s.get("host_organization_name"),
                "works_count": s.get("works_count"), "type": s.get("type"),
                "_match": "fuzzy",
            }
        q = 'JOURNAL:"%s" AND %s AND (SRC:MED) AND (PUB_YEAR:[2024 TO 2026])' % (c, CRIT_TERMS)
        j = epmc(q, page_size=25, sort="CITED desc")
        hits = j.get("resultList", {}).get("result", []) if isinstance(j, dict) else []
        for h in hits[:8]:
            ji = (h.get("journalInfo") or {}).get("journal", {}) or {}
            rec["recent_critical_papers"].append({
                "title": h.get("title"), "year": h.get("pubYear"),
                "doi": h.get("doi"), "pmid": h.get("pmid"),
                "journal": ji.get("title"), "cited": h.get("citedByCount"),
            })
        rec["epmc_hit_count"] = j.get("hitCount") if isinstance(j, dict) else None
        time.sleep(0.4)
        out.append(rec)
    return out

def aggregate(raw):
    from collections import Counter
    agg = Counter()
    per_group = {}
    for r in raw:
        agg[r["journal"]] += 1
        per_group.setdefault(r["group"], Counter())[r["journal"]] += 1
    return agg, per_group

def main():
    raw = run_group_search()
    agg, per_group = aggregate(raw)

    print("\n=== TOTAL HITS:", len(raw), flush=True)
    print("=== TOP JOURNALS (all groups) ===", flush=True)
    for j, c in agg.most_common(40):
        print("%4d  %s" % (c, j), flush=True)

    print("\n=== PER GROUP TOP 12 ===", flush=True)
    for g in GROUPS:
        c = per_group.get(g["id"], None)
        if c:
            print("--", g["id"], flush=True)
            for j, n in c.most_common(12):
                print("   %3d  %s" % (n, j), flush=True)

    cand = run_candidate_check()

    payload = {
        "generated": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "sources": ["Europe PMC REST", "OpenAlex REST"],
        "groups": GROUPS,
        "raw_hits": raw,
        "journal_counts": [{"journal": j, "count": n} for j, n in agg.most_common()],
        "per_group_counts": {g: [{"journal": j, "count": n} for j, n in per_group.get(g, {}).most_common()] for g in per_group},
        "candidates": cand,
    }
    with open(os.path.join(OUT, "journal_survey.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print("\nwrote results/journal_survey.json", flush=True)

if __name__ == "__main__":
    main()
