# -*- coding: utf-8 -*-
"""Normalize + aggregate journal_survey.json; print candidate evidence."""
import json, os, re
from collections import Counter, defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results")
d = json.load(open(os.path.join(OUT, "journal_survey.json"), encoding="utf-8"))

CANON = {
    "journal of cheminformatics": "Journal of Cheminformatics",
    "journal of chemical information and modeling": "Journal of Chemical Information and Modeling",
    "plos one": "PLOS ONE",
    "plos computational biology": "PLOS Computational Biology",
    "briefings in bioinformatics": "Briefings in Bioinformatics",
    "bioinformatics (oxford, england)": "Bioinformatics",
    "bioinformatics": "Bioinformatics",
    "scientific reports": "Scientific Reports",
    "international journal of molecular sciences": "International Journal of Molecular Sciences",
    "molecules (basel, switzerland)": "Molecules",
    "pharmaceuticals (basel, switzerland)": "Pharmaceuticals",
    "bmc bioinformatics": "BMC Bioinformatics",
    "nature communications": "Nature Communications",
    "chemical science": "Chemical Science",
    "acs omega": "ACS Omega",
    "npj computational materials": "npj Computational Materials",
    "nature machine intelligence": "Nature Machine Intelligence",
    "frontiers in pharmacology": "Frontiers in Pharmacology",
    "frontiers in bioinformatics": "Frontiers in Bioinformatics",
    "frontiers in artificial intelligence": "Frontiers in Artificial Intelligence",
    "frontiers in genetics": "Frontiers in Genetics",
    "computational and structural biotechnology journal": "Computational and Structural Biotechnology Journal",
    "journal of computer-aided molecular design": "Journal of Computer-Aided Molecular Design",
    "digital discovery": "Digital Discovery",
    "patterns": "Patterns",
    "molecular systems biology": "Molecular Systems Biology",
    "machine learning: science and technology": "Machine Learning: Science and Technology",
    "briefings in functional genomics": "Briefings in Functional Genomics",
    "bioinformatics advances": "Bioinformatics Advances",
    "rsc advances": "RSC Advances",
    "advanced science (weinheim, baden-wurttemberg, germany)": "Advanced Science",
    "communications chemistry": "Communications Chemistry",
    "current issues in molecular biology": "Current Issues in Molecular Biology",
    "cpt: pharmacometrics & systems pharmacology": "CPT: Pharmacometrics & Systems Pharmacology",
    "signal transduction and targeted therapy": "Signal Transduction and Targeted Therapy",
    "pharmaceutics": "Pharmaceutics",
    "cancers": "Cancers",
    "arxiv (cornell university)": "arXiv (preprint)",
    "biorxiv (cold spring harbor laboratory)": "bioRxiv (preprint)",
    "chemrxiv": "ChemRxiv (preprint)",
    "research square": "Research Square (preprint)",
}
PREPRINTS = {"arXiv (preprint)", "bioRxiv (preprint)", "ChemRxiv (preprint)", "Research Square (preprint)"}

def canon(name):
    if not name:
        return "UNKNOWN / not indexed"
    key = " ".join(name.split()).lower()
    return CANON.get(key, " ".join(name.split()))

raw = d["raw_hits"]
for r in raw:
    r["journal_canon"] = canon(r["journal"])
    r["is_preprint"] = r["journal_canon"] in PREPRINTS

agg_all = Counter(r["journal_canon"] for r in raw)
agg_jr = Counter(r["journal_canon"] for r in raw if not r["is_preprint"])
prep = Counter(r["journal_canon"] for r in raw if r["is_preprint"])

print("=== TOTAL hits:", len(raw))
print("=== preprints:", sum(prep.values()), "| peer-reviewed/journal:", sum(agg_jr.values()))
print("\n=== TOP PEER-REVIEWED VENUES (merged case variants) ===")
for j, n in agg_jr.most_common(45):
    print("%4d  %s" % (n, j))
print("\n=== PREPRINT SERVERS ===")
for j, n in prep.most_common():
    print("%4d  %s" % (n, j))

# per-group, peer-reviewed only
per_group = defaultdict(Counter)
for r in raw:
    if not r["is_preprint"]:
        per_group[r["group"]][r["journal_canon"]] += 1
print("\n=== PER-GROUP TOP 10 (peer-reviewed only) ===")
for g in [x["id"] for x in d["groups"]]:
    print("--", g)
    for j, n in per_group[g].most_common(10):
        print("   %3d  %s" % (n, j))

# examples: 2 sample DOIs per top journal (for citation evidence)
samples = defaultdict(list)
seen = set()
for r in raw:
    j = r["journal_canon"]
    if r["is_preprint"] or not r.get("doi"):
        continue
    k = (j, r["doi"])
    if k in seen:
        continue
    seen.add(k)
    if len(samples[j]) < 3:
        samples[j].append({"title": r["title"], "year": r["year"], "doi": r["doi"], "pmid": r.get("pmid"), "group": r["group"]})

print("\n=== SAMPLE PAPERS PER TOP JOURNAL ===")
for j, _ in agg_jr.most_common(20):
    print("##", j)
    for s in samples[j]:
        print("   -", s["year"], "|", (s["title"] or "")[:110], "| doi:", s["doi"])
    if j not in samples or not samples[j]:
        print("   (no DOI-bearing sample in this run)")

# candidates
print("\n=== CANDIDATE CHECK ===")
for c in d["candidates"]:
    src = c.get("openalex_source") or {}
    print("##", c["candidate"])
    print("   OA=%s DOAJ=%s APC_USD=%s publisher=%s type=%s works=%s issn_l=%s%s" % (
        src.get("is_oa"), src.get("is_in_doaj"), src.get("apc_usd"),
        src.get("publisher"), src.get("type"), src.get("works_count"), src.get("issn_l"),
        " [FUZZY-MATCHED: " + str(src.get("display_name")) + "]" if src.get("_match") else ""))
    print("   EPMC 2024-2026 critical-term hits:", c.get("epmc_hit_count"))
    for p in (c.get("recent_critical_papers") or [])[:5]:
        print("     ·", p["year"], "|", (p["title"] or "")[:100], "| doi:", p["doi"])

# persist normalized counts back into json
d["journal_counts_normalized"] = [{"journal": j, "count": n} for j, n in agg_jr.most_common()]
d["preprint_counts"] = [{"server": j, "count": n} for j, n in prep.most_common()]
d["per_group_counts_normalized"] = {g: [{"journal": j, "count": n} for j, n in per_group[g].most_common()] for g in per_group}
d["samples_by_journal"] = {j: samples[j] for j in samples}
json.dump(d, open(os.path.join(OUT, "journal_survey.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("\nupdated results/journal_survey.json")
