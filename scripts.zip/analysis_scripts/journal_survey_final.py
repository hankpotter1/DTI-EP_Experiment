# -*- coding: utf-8 -*-
"""Assemble final results/journal_survey.json from all collected evidence."""
import json, os, time
from collections import Counter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results")
L = lambda n: json.load(open(os.path.join(OUT, n), encoding="utf-8"))

bulk = L("journal_survey.json")
prec = L("journal_survey_precision.json")
targ = L("journal_survey_targeted.json")
genre = L("journal_survey_genre.json")

POLICY = {
    "PLOS ONE": {
        "status": "evidence_found",
        "quote": "Studies reporting negative results — In keeping with our mission to publish all valid research, we consider negative and null results.",
        "source": "https://journals.plos.org/plosone/s/criteria-for-publication (fetched 2026-09-23)",
        "gate_on_pure_computational": "no explicit requirement for wet-lab validation found on the criteria page; article types explicitly include methods/software/databases/tools",
    },
    "Frontiers (in the group's own experience)": {
        "status": "first_hand_reported_by_requester",
        "detail": "Sister MR manuscript was rejected at publisher level for lack of independent validation of bioinformatics analysis.",
        "counter_evidence": "The empirical record DOES show Frontiers venues publishing pure-computational benchmark/evaluation papers: Frontiers in Bioinformatics 14 title-scope 2023-2026 hits (e.g. doi:10.3389/fbinf.2026.1844838 'Benchmarking computational decontamination of ambient RNA'), Frontiers in Pharmacology 33 hits, Frontiers in Genetics 30 hits.",
        "conclusion": "A blanket publisher-wide ban on computational work is NOT supported by this survey. The gate appears genre/section-specific (Mendelian-randomisation / bioinformatics-only association studies), and cannot be confirmed as applying to benchmark-critique papers.",
    },
    "all other candidates": {
        "status": "unconfirmed",
        "detail": "Publisher policy pages could not be retrieved (OUP behind Cloudflare 403; Nature/Scientific Reports and BMC blocked by redirect loops). No quotable policy text obtained. Behavioural evidence (papers actually published, see candidate_evidence) is the available substitute.",
    },
}

def cand_rows():
    out = []
    for c in bulk["candidates"]:
        name = c["candidate"]
        src = c.get("openalex_source") or {}
        ev = (prec.get("candidate_title_evidence") or {}).get(name) or {}
        out.append({
            "journal": name,
            "openalex_issn_l": src.get("issn_l"),
            "openalex_is_oa": src.get("is_oa"),
            "openalex_is_in_doaj": src.get("is_in_doaj"),
            "apc_usd_openalex": src.get("apc_usd"),
            "publisher": src.get("publisher"),
            "openalex_works_count": src.get("works_count"),
            "title_scope_critique_hits_2023_2026": ev.get("title_scope_hits_2023_2026"),
            "example_critique_papers": (ev.get("examples") or [])[:8],
            "policy_gate": POLICY.get(name, POLICY["all other candidates"]),
        })
    return out

final = {
    "generated": time.strftime("%Y-%m-%dT%H:%M:%S"),
    "manuscript_genre": "DTI benchmark evaluation + negative result + methodological critique",
    "apis_used": {
        "europepmc_rest": "https://www.ebi.ac.uk/europepmc/webservices/rest/search — reachable, used",
        "openalex_rest": "https://api.openalex.org/works and /sources — reachable, used",
    },
    "search_design": {
        "broad_groups": bulk["groups"],
        "precision_sweeps": list((prec.get("global_sweeps") and {r['sweep'] for r in prec['global_sweeps']}) or []),
        "targeted_sweeps": {k: v["query"] for k, v in targ["genre_sweeps"].items()},
        "canonical_queries": [c["query"] for c in targ["canonical"]],
    },
    "A_volume": {
        "broad_search_total_hits": len(bulk["raw_hits"]),
        "broad_search_venue_counts_peer_reviewed": bulk["journal_counts_normalized"],
        "broad_search_preprint_counts": bulk["preprint_counts"],
        "genre_matching_papers": len(genre["genre_rows"]),
        "genre_venue_counts": genre["venue_counts"],
    },
    "A_genre_papers": genre["genre_rows"],
    "A_canonical_works_verified_venues": genre["canonical_venues"],
    "B_candidates": cand_rows(),
    "policy_findings": POLICY,
    "unconfirmed": [
        "APC for Digital Discovery (OpenAlex apc_usd = null)",
        "Article-type acceptance (does the journal accept 'critique'/'negative result' as an article type) for all candidates — could not load author guidelines (403/redirect blocks)",
        "Publisher policy text on 'pure computational, no experimental validation' for OUP, ACS, RSC, Elsevier/Patterns, BMC, Springer Nature, IOP — pages not retrievable",
        "Machine Learning: Science and Technology showed 0 title-scope critique hits in 2023-2026 (may be index coverage, not true absence)",
        "Journal names reported as 'UNKNOWN / not indexed' (15 broad hits) — Europe PMC core record lacked journalInfo",
    ],
}

json.dump(final, open(os.path.join(OUT, "journal_survey.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("wrote final results/journal_survey.json")
print("keys:", list(final.keys()))
print("genre venues top10:", genre["venue_counts"][:10])
print("candidates:", len(final["B_candidates"]))
