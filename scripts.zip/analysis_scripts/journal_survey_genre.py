# -*- coding: utf-8 -*-
"""Mine collected hits for genuine critique/benchmark/negative-result papers (title regex),
then aggregate their venues. Produces the evidence table for section A."""
import json, os, re
from collections import Counter, defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results")
d = json.load(open(os.path.join(OUT, "journal_survey.json"), encoding="utf-8"))
t = json.load(open(os.path.join(OUT, "journal_survey_targeted.json"), encoding="utf-8"))

PREPRINTS = {"arXiv (preprint)", "bioRxiv (preprint)", "ChemRxiv (preprint)", "Research Square (preprint)"}

PAT = re.compile(r"(benchmark|evaluat|pitfall|leakage|bias|reproducib|replicat|critique|critical|"
                 r"re-?evaluat|reassess|overestimat|inflated|no better than|trivial baseline|"
                 r"simple baseline|systematic(ally)? (assess|review|compar)|audit|shortcut|"
                 r"flaw|misleading|lessons|caution|dubious|hidden|rethink|re-?think|"
                 r"assessment|comparative|does not|fails?|not outperform)", re.I)

rows = []
seen = set()
def add(source, title, journal, year, doi, pmid, cited):
    if not title:
        return
    key = (title or "").strip().lower()
    if key in seen:
        return
    seen.add(key)
    rows.append({"source": source, "title": title, "journal": journal, "year": year,
                 "doi": doi, "pmid": pmid, "cited": cited})

for r in d["raw_hits"]:
    if r["journal_canon"] in PREPRINTS:
        continue
    if PAT.search(r["title"] or ""):
        add("bulk", r["title"], r["journal_canon"], r["year"], r["doi"], r["pmid"], r["cited"])

for sid, s in t["genre_sweeps"].items():
    for h in s["hits"]:
        jn = " ".join((h["journal"] or "").split())
        if PAT.search(h["title"] or ""):
            add(sid, h["title"], jn, h["year"], h["doi"], h["pmid"], h["cited"])

# canonical works: mark separately (they are the "classics")
canon_rows = []
for c in t["canonical"]:
    if c["matches"]:
        m = c["matches"][0]
        canon_rows.append({"queried_for": c["query"], "title": m["title"],
                           "journal": m["journal"], "year": m["year"], "doi": m["doi"],
                           "cited": m["cited"]})

cnt = Counter(r["journal"] for r in rows)
print("=== genre-matching papers found:", len(rows))
print("\n=== VENUE DISTRIBUTION (genre-matching papers, peer-reviewed only) ===")
for j, n in cnt.most_common(30):
    print("%4d  %s" % (n, j))

print("\n=== ALL genre-matching papers (journal | year | doi) ===")
for r in sorted(rows, key=lambda x: (-(x["cited"] or 0))):
    print("[%s] %s (%s) | doi:%s | cited:%s\n      %s" % (
        r["journal"], (r["title"] or "")[:130], r["year"], r["doi"], r["cited"], r["source"]))

print("\n=== CANONICAL WORKS (verified venues) ===")
for r in canon_rows:
    print("%-60s | %s (%s) | doi:%s | cited:%s" % (
        (r["journal"] or "?")[:60], (r["title"] or "")[:80], r["year"], r["doi"], r["cited"]))

json.dump({"genre_rows": rows,
           "venue_counts": [{"journal": j, "count": n} for j, n in cnt.most_common()],
           "canonical_venues": canon_rows},
          open(os.path.join(OUT, "journal_survey_genre.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\nwrote results/journal_survey_genre.json")
