# -*- coding: utf-8 -*-
"""Precision sweep: TITLE-scoped critique/benchmark/negative-result terms.
(a) global DTI-topic critique sweep -> journal distribution (evidence for section A)
(b) per-candidate-journal critique sweep -> concrete example papers (evidence for section B)
"""
import json, os, time
from collections import Counter
import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results")
EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
S = requests.Session()
S.headers.update({"User-Agent": "journal-survey/1.0 (mailto:survey@example.org)"})

def epmc(query, page_size=100, sort=None):
    p = {"query": query, "format": "json", "pageSize": page_size, "resultType": "core"}
    if sort:
        p["sort"] = sort
    for _ in range(3):
        try:
            r = S.get(EPMC, params=p, timeout=60)
            if r.status_code == 200:
                return r.json()
            time.sleep(2)
        except Exception:
            time.sleep(3)
    return {}

def jname(h):
    ji = (h.get("journalInfo") or {}).get("journal", {}) or {}
    return " ".join((ji.get("title") or "").split())

# ---- (a) global critique sweep on the manuscript's own topic
TOPIC_QUERIES = {
    "A1_dti_title_eval": '(TITLE:"drug-target" OR TITLE:"drug target" OR TITLE:"drug−target") AND (TITLE:benchmark* OR TITLE:evaluation OR TITLE:evaluating OR TITLE:pitfall* OR TITLE:leakage OR TITLE:bias OR TITLE:critique OR TITLE:assessing OR TITLE:assessment OR TITLE:reliability OR TITLE:"not better") AND (PUB_YEAR:[2022 TO 2026]) AND SRC:MED',
    "A2_molml_leakage_title": '(TITLE:"data leakage" OR TITLE:"scaffold split" OR TITLE:"shortcut" OR TITLE:"information leakage" OR TITLE:"optimistic" OR TITLE:"overestimat*" OR TITLE:"inflated") AND (TITLE:molecular OR TITLE:chemistr* OR TITLE:drug OR TITLE:protein OR TITLE:"machine learning" OR TITLE:"deep learning" OR TITLE:benchmark*) AND (PUB_YEAR:[2022 TO 2026]) AND SRC:MED',
    "A3_negative_repro_title": '(TITLE:"negative results" OR TITLE:reproducib* OR TITLE:replicat* OR TITLE:"no better than" OR TITLE:"trivial baseline" OR TITLE:"simple baselines" OR TITLE:"random baseline") AND (TITLE:"machine learning" OR TITLE:"deep learning" OR TITLE:"artificial intelligence" OR TITLE:molecular OR TITLE:chemistr* OR TITLE:drug OR TITLE:protein) AND (PUB_YEAR:[2022 TO 2026]) AND SRC:MED',
    "A4_vs_decoy_title": '(TITLE:"virtual screening" OR TITLE:docking OR TITLE:"decoy*" OR TITLE:"enrichment") AND (TITLE:bias* OR TITLE:pitfall* OR TITLE:evaluation OR TITLE:evaluating OR TITLE:benchmark* OR TITLE:assessment OR TITLE:"artificial enrichment" OR TITLE:"overestimat*") AND (PUB_YEAR:[2022 TO 2026]) AND SRC:MED',
    "A5_tox_admet_benchmark": '(TITLE:ADMET OR TITLE:ADME OR TITLE:toxicity OR TITLE:"property prediction") AND (TITLE:benchmark* OR TITLE:evaluation OR TITLE:evaluating OR TITLE:pitfall* OR TITLE:critique OR TITLE:reliability OR TITLE:reproducib* OR TITLE:bias) AND (PUB_YEAR:[2022 TO 2026]) AND SRC:MED',
}

CANDIDATES = [
    "Bioinformatics", "Briefings in Bioinformatics", "Bioinformatics Advances",
    "Briefings in Functional Genomics", "Journal of Chemical Information and Modeling",
    "Journal of Cheminformatics", "BMC Bioinformatics", "PLOS Computational Biology",
    "PLOS ONE", "Scientific Reports", "Patterns", "Digital Discovery",
    "Molecular Systems Biology", "Nature Machine Intelligence",
    "Machine Learning: Science and Technology", "Frontiers in Bioinformatics",
    "Frontiers in Pharmacology", "Frontiers in Genetics",
]

def main():
    global_raw = []
    print("### (a) GLOBAL PRECISION SWEEPS")
    for qid, q in TOPIC_QUERIES.items():
        j = epmc(q, page_size=100, sort="CITED desc")
        hits = j.get("resultList", {}).get("result", [])
        print("--", qid, "| hits:", len(hits), "| total:", j.get("hitCount"))
        c = Counter(jname(h) for h in hits)
        for jn, n in c.most_common(12):
            print("     %3d  %s" % (n, jn))
        for h in hits:
            global_raw.append({"sweep": qid, "title": h.get("title"), "journal": jname(h),
                               "year": h.get("pubYear"), "doi": h.get("doi"), "pmid": h.get("pmid"),
                               "cited": h.get("citedByCount")})
        time.sleep(0.4)

    print("\n### (b) PER-CANDIDATE TITLE-SCOPED CRITIQUE EVIDENCE")
    cand_ev = {}
    for c in CANDIDATES:
        q = ('JOURNAL:"%s" AND (TITLE:benchmark* OR TITLE:"negative results" OR TITLE:reproducib* '
             'OR TITLE:pitfall* OR TITLE:leakage OR TITLE:bias OR TITLE:overestimat* OR TITLE:critique '
             'OR TITLE:"re-evaluation" OR TITLE:reassessment OR TITLE:pitfalls OR TITLE:"best practices" '
             'OR TITLE:"more data" OR TITLE:"simple" OR TITLE:"baseline*") AND (PUB_YEAR:[2023 TO 2026]) AND SRC:MED') % c
        j = epmc(q, page_size=25, sort="CITED desc")
        hits = j.get("resultList", {}).get("result", [])
        cand_ev[c] = {"title_scope_hits_2023_2026": j.get("hitCount"), "examples": [
            {"title": h.get("title"), "year": h.get("pubYear"), "doi": h.get("doi"),
             "pmid": h.get("pmid"), "cited": h.get("citedByCount")} for h in hits[:12]]}
        print("--", c, "| total:", j.get("hitCount"))
        for h in hits[:8]:
            print("     ·", h.get("pubYear"), "|", (h.get("title") or "")[:110], "| doi:", h.get("doi"))
        time.sleep(0.4)

    p = os.path.join(OUT, "journal_survey_precision.json")
    json.dump({"generated": time.strftime("%Y-%m-%dT%H:%M:%S"),
               "global_sweeps": global_raw,
               "candidate_title_evidence": cand_ev},
              open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("\nwrote", p)

    # aggregate the global DTI sweep journals
    print("\n### (a-agg) journals in A1+A2 (DTI/molML critique) ")
    c = Counter(r["journal"] for r in global_raw if r["sweep"] in ("A1_dti_title_eval", "A2_molml_leakage_title"))
    for jn, n in c.most_common(20):
        print("   %3d  %s" % (n, jn))

if __name__ == "__main__":
    main()
