# -*- coding: utf-8 -*-
"""Targeted genre searches: confirm venues of canonical DTI-benchmark-critique,
decoy-bias, leakage and negative-result papers. All results come from live APIs."""
import json, os, time
from collections import Counter
import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results")
EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
OA = "https://api.openalex.org"
S = requests.Session()
S.headers.update({"User-Agent": "journal-survey/1.0 (mailto:survey@example.org)"})

def epmc(q, ps=25, sort="CITED desc"):
    p = {"query": q, "format": "json", "pageSize": ps, "resultType": "core"}
    if sort:
        p["sort"] = sort
    for _ in range(3):
        try:
            r = S.get(EPMC, params=p, timeout=60)
            if r.status_code == 200:
                return r.json()
            time.sleep(2)
        except Exception:
            time.sleep(3)
    return {}

def oa(search, ps=4):
    p = {"search": search, "per-page": ps, "mailto": "survey@example.org",
         "select": "id,doi,display_name,publication_year,primary_location,type,cited_by_count"}
    for _ in range(3):
        try:
            r = S.get(OA + "/works", params=p, timeout=60)
            if r.status_code == 200:
                return r.json()
            time.sleep(2)
        except Exception:
            time.sleep(3)
    return {}

def jn(h):
    ji = (h.get("journalInfo") or {}).get("journal", {}) or {}
    return " ".join((ji.get("title") or "").split())

# ---- canonical works in this exact genre (verify venue, don't assert it)
CANON = [
    "Most ligand-based classification benchmarks reward memorization rather than generalization",
    "In need of bias control evaluating chemical data for machine learning in structure-based virtual screening",
    "LIT-PCBA an unbiased data set for machine learning and virtual screening",
    "Beyond the hype deep neural networks outperform established methods using a ChEMBL bioactivity benchmark set",
    "Leakage and the reproducibility crisis in machine-learning-based science",
    "Artificial intelligence for drug discovery are we there yet",
    "Deep learning for drug-target interaction prediction critical evaluation",
    "Simple controls exceed best deep learning algorithms foundation model effectiveness",
    "Data splitting to avoid information leakage with DataSAIL",
    "Auditing widely used biomolecular benchmarks reveals systematic data inconsistencies",
    "The impact of negative sampling on the generalization of drug-target interaction models",
    "Machine learning in chemoinformatics and drug discovery data leakage scaffold split",
    "Are we there yet deep learning virtual screening benchmark evaluation",
    "Decoy bias artificial enrichment docking evaluation critical assessment",
    "No free lunch drug discovery machine learning negative results",
]

def main():
    res = {"canonical": [], "genre_sweeps": {}}
    print("### CANONICAL WORKS (OpenAlex top match)")
    for t in CANON:
        j = oa(t, ps=3)
        row = {"query": t, "matches": []}
        for w in (j.get("results") or []):
            pl = w.get("primary_location") or {}
            src = pl.get("source") or {}
            row["matches"].append({
                "title": w.get("display_name"),
                "journal": src.get("display_name"),
                "year": w.get("publication_year"),
                "doi": (w.get("doi") or "").replace("https://doi.org/", ""),
                "cited": w.get("cited_by_count"),
            })
        res["canonical"].append(row)
        print("--", t[:70])
        for m in row["matches"]:
            print("     ", m["year"], "|", (m["title"] or "")[:95])
            print("        journal:", m["journal"], "| doi:", m["doi"], "| cited:", m["cited"])
        time.sleep(0.4)

    # ---- genre sweeps in Europe PMC (title+abstract, DTI/virtual-screening specific)
    SWEEPS = {
        "S1_dti_eval_critique": '(("drug-target interaction" OR "drug target interaction") AND ("benchmark" OR "evaluation" OR "pitfalls" OR "critical" OR "leakage" OR "bias" OR "reproducibility") AND ("prediction")) AND (PUB_YEAR:[2022 TO 2026]) AND SRC:MED AND (TITLE:"evaluation" OR TITLE:"benchmark" OR TITLE:"critical" OR TITLE:"pitfall" OR TITLE:"leakage" OR TITLE:"bias" OR TITLE:"assessment" OR TITLE:"reproducibility" OR TITLE:"flaw")',
        "S2_decoy_vs": '(("virtual screening" OR "docking") AND ("decoy" OR "decoy bias" OR "artificial enrichment" OR "enrichment factor") AND ("bias" OR "evaluation" OR "benchmark" OR "unbiased")) AND (PUB_YEAR:[2022 TO 2026]) AND SRC:MED',
        "S3_neg_results_mol": '(("negative results" OR "null results" OR "failed to outperform" OR "no better than" OR "trivial baseline" OR "random forest baseline") AND ("machine learning" OR "deep learning") AND ("drug" OR "molecular" OR "chemistry" OR "cheminformatics" OR "QSAR")) AND (PUB_YEAR:[2022 TO 2026]) AND SRC:MED',
    }
    for sid, q in SWEEPS.items():
        j = epmc(q, ps=100, sort="CITED desc")
        hits = j.get("resultList", {}).get("result", [])
        c = Counter(jn(h) for h in hits)
        print("\n### ", sid, "| total:", j.get("hitCount"), "| retrieved:", len(hits))
        for jj, n in c.most_common(15):
            print("   %3d  %s" % (n, jj))
        res["genre_sweeps"][sid] = {
            "query": q, "total": j.get("hitCount"),
            "journal_counts": [{"journal": k, "count": v} for k, v in c.most_common()],
            "hits": [{"title": h.get("title"), "journal": jn(h), "year": h.get("pubYear"),
                      "doi": h.get("doi"), "pmid": h.get("pmid"), "cited": h.get("citedByCount")}
                     for h in hits],
        }
        time.sleep(0.4)

    json.dump(res, open(os.path.join(OUT, "journal_survey_targeted.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print("\nwrote results/journal_survey_targeted.json")

if __name__ == "__main__":
    main()
