# -*- coding: utf-8 -*-
"""Transfer-survey literature evidence: Europe PMC journal-scoped counts + OpenAlex source metrics.

All conclusions must come from real API responses. Nothing is invented.
"""
import json, time, urllib.parse, urllib.request, os

EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
OA = "https://api.openalex.org"
OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results")

def _get(url, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": "ref-verify/1.0 (mailto:none@example.com)"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def epmc(q, n=25, resultType="core"):
    url = EPMC + "?" + urllib.parse.urlencode(
        {"query": q, "format": "json", "pageSize": str(n), "resultType": resultType})
    d = _get(url)
    return d

def slim(res):
    out = []
    for r in res:
        out.append({
            "title": r.get("title"),
            "journal": (r.get("journalInfo") or {}).get("journal", {}).get("title"),
            "year": r.get("pubYear"),
            "doi": r.get("doi"),
            "pmid": r.get("pmid"),
            "type": r.get("pubTypeList", {}).get("pubType"),
        })
    return out

# ---- Search design: keep scope constant (Europe PMC all-fields) across venues ----
JOURNALS = {
    "plos_one": 'JOURNAL:"PLoS One"',
    "j_ethnopharmacol": 'JOURNAL:"Journal of Ethnopharmacology"',
    "phytomedicine": 'JOURNAL:"Phytomedicine"',
    "bmc_cam_therapies": 'JOURNAL:"BMC Complementary Medicine and Therapies"',
    "bmc_cam_alt": 'JOURNAL:"BMC Complementary and Alternative Medicine"',
    "chinese_medicine": 'JOURNAL:"Chinese Medicine"',
    "scientific_reports": 'JOURNAL:"Scientific Reports"',
    "bmc_research_notes": 'JOURNAL:"BMC Research Notes"',
    "frontiers_pharmacol": 'JOURNAL:"Frontiers in Pharmacology"',
    "j_tradit_complement_med": 'JOURNAL:"Journal of Traditional and Complementary Medicine"',
    "chin_j_integr_med": 'JOURNAL:"Chinese Journal of Integrative Medicine"',
    "integr_med_res": 'JOURNAL:"Integrative Medicine Research"',
    "heliyon": 'JOURNAL:"Heliyon"',
    "peerj": 'JOURNAL:"PeerJ"',
    "j_herbal_medicine": 'JOURNAL:"Journal of Herbal Medicine"',
    "pharmaceutical_biology": 'JOURNAL:"Pharmaceutical Biology"',
    "evid_based_cam": 'JOURNAL:"Evidence-Based Complementary and Alternative Medicine"',
    "acupunct_electrother": 'JOURNAL:"Acupuncture and Electro-Therapeutics Research"',
    "front_netw_pharm": 'JOURNAL:"Frontiers in Pharmacology"',
    "bmc_bioinformatics": 'JOURNAL:"BMC Bioinformatics"',
}

TOPIC = {
    "np": 'TITLE:"network pharmacology"',
    "tcm": '(TITLE:"traditional Chinese medicine" OR TITLE:"Chinese herbal" OR TITLE:"herbal medicine")',
    "herbpair": '(TITLE:"herb pair" OR TITLE:"herbal pair" OR TITLE:"herb-pair" OR TITLE:"drug pair" OR TITLE:"herb combination")',
    "neg_results": '(TITLE:"negative results" OR TITLE:"negative findings" OR TITLE:"null results")',
    "np_critique": '(TITLE:"network pharmacology" AND (TITLE:pitfall OR TITLE:critical OR TITLE:limitation OR TITLE:reproducib OR TITLE:"methodological" OR TITLE:challenge OR TITLE:review))',
    "np_epilepsy": '("network pharmacology" AND epilepsy)',
    "epilepsy_herb": '(epilepsy AND (TITLE:"Gastrodia" OR TITLE:"Uncaria" OR TITLE:"tian ma" OR TITLE:"gou teng" OR TITLE:"herbal"))',
    "synergy": '("network pharmacology" AND (synergy OR synergistic))',
    "geu": '(TITLE:"Gastrodia elata" OR TITLE:"Uncaria rhynchophylla")',
}

searches = {}
for jk, jq in JOURNALS.items():
    for tk, tq in TOPIC.items():
        searches["%s__%s" % (jk, tk)] = "%s AND %s" % (jq, tq)

raw = {}
for key, q in searches.items():
    try:
        d = epmc(q, n=15)
        res = d.get("resultList", {}).get("result", [])
        raw[key] = {"query": q, "hitCount": d.get("hitCount"), "results": slim(res)}
        print("%-46s hits=%-7s returned=%d" % (key, d.get("hitCount"), len(res)), flush=True)
    except Exception as e:
        raw[key] = {"query": q, "error": str(e), "results": []}
        print("%-46s ERROR %s" % (key, e), flush=True)
    time.sleep(0.35)

with open(os.path.join(OUT_DIR, "_transfer_epmc_raw.json"), "w", encoding="utf-8") as f:
    json.dump(raw, f, ensure_ascii=False, indent=1)

# ---- OpenAlex sources metrics ----
SRC_NAMES = ["PLOS ONE", "Journal of Ethnopharmacology", "Phytomedicine",
             "BMC Complementary Medicine and Therapies", "Chinese Medicine",
             "Scientific Reports", "BMC Research Notes", "Frontiers in Pharmacology",
             "Journal of Traditional and Complementary Medicine",
             "Chinese Journal of Integrative Medicine", "Integrative Medicine Research",
             "Heliyon", "PeerJ", "Journal of Herbal Medicine", "Pharmaceutical Biology",
             "BMC Bioinformatics", "PLOS Computational Biology"]
sources = {}
for s in SRC_NAMES:
    try:
        d = _get(OA + "/sources?" + urllib.parse.urlencode({"per-page": "5", "search": s}))
        items = []
        for it in d.get("results", []):
            items.append({
                "id": it.get("id"), "display_name": it.get("display_name"),
                "issn_l": it.get("issn_l"), "publisher": it.get("host_organization_name"),
                "is_oa": it.get("is_oa"), "is_in_doaj": it.get("is_in_doaj"),
                "apc_usd": it.get("apc_usd"),
                "works_count": it.get("works_count"),
                "2yr_mean_citedness": (it.get("summary_stats") or {}).get("2yr_mean_citedness"),
                "h_index": (it.get("summary_stats") or {}).get("h_index"),
            })
        sources[s] = {"query": s, "results": items}
        print("SRC %-45s -> %s" % (s, [i["display_name"] for i in items[:3]]), flush=True)
    except Exception as e:
        sources[s] = {"query": s, "error": str(e)}
        print("SRC %-45s ERROR %s" % (s, e), flush=True)
    time.sleep(0.35)

with open(os.path.join(OUT_DIR, "_transfer_openalex_sources.json"), "w", encoding="utf-8") as f:
    json.dump(sources, f, ensure_ascii=False, indent=1)

print("DONE")
