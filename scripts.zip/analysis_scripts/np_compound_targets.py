# -*- coding: utf-8 -*-
"""
np_compound_targets.py — 成分收集 + OB/DL 筛选 + 成分->靶点预测

数据通路:
  1) 成分来源: 用户提供 / TCMSP(网页) / ChEMBL / PubChem / 文献
  2) 类药性筛选: OB(口服生物利用度)、DL(类药性)；若无 TCMSP 参数则用
     SwissADME 式规则 (Lipinski/Veber) + RDKit 描述符近似
  3) 成分->靶点: ChEMBL activity > PubChem bioassay > 可选 SwissTarget 网页

用法:
  from np_compound_targets import load_compounds, filter_obdl, predict_targets
"""
import os
import json
import time
import requests

import sources as S

UA = S.UA
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(BASE, "data")
os.makedirs(DATA, exist_ok=True)


# --------------------- 1. 成分来源 ---------------------
def chembl_molecule(name):
    """优先按 pref_name 精确匹配（ChEMBL 支持 __iexact），再退回全文检索。

    原实现只用 /molecule/search，很多常见成分（adenosine/ferulic acid 等）
    因为 pref_name 与查询串不完全一致而被静默丢弃。
    """
    r = S.cached_get_json("https://www.ebi.ac.uk/chembl/api/data/molecule",
                          params={"pref_name__iexact": name, "format": "json", "limit": 5})
    mols = ((r.get("json") or {}).get("molecules") or [])
    if mols:
        return mols
    r = S.cached_get_json("https://www.ebi.ac.uk/chembl/api/data/molecule/search",
                          params={"q": name, "format": "json", "limit": 5})
    js = r.get("json") or {}
    return js.get("molecules", [])


def pubchem_cid(name):
    r = S.cached_get("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/%s/cids/TXT" % name)
    if r.get("status") == 200 and r.get("text", "").strip():
        return r["text"].strip().split("\n")[0]
    return None


def pubchem_descriptors(cid):
    props = "MolecularFormula,MolecularWeight,XLogP,TPSA,HBondDonorCount,HBondAcceptorCount,RotatableBondCount"
    r = S.cached_get_json(
        "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/%s/property/%s/JSON" % (cid, props))
    js = r.get("json") or {}
    arr = js.get("PropertyTable", {}).get("Properties", [])
    return arr[0] if arr else {}


# --------------------- 2. OB/DL 筛选 ---------------------
def _f(v):
    try:
        return float(v)
    except Exception:
        return None


def lipinski_veber(props):
    """基于 PubChem 描述符的类药性近似 (Lipinski 五规则 + Veber)。"""
    mw = _f(props.get("MolecularWeight"))
    logp = _f(props.get("XLogP"))
    hbd = _f(props.get("HBondDonorCount"))
    hba = _f(props.get("HBondAcceptorCount"))
    tpsa = _f(props.get("TPSA"))
    rotb = _f(props.get("RotatableBondCount"))
    viol = 0
    if mw and mw > 500: viol += 1
    if logp is not None and logp > 5: viol += 1
    if hbd and hbd > 5: viol += 1
    if hba and hba > 10: viol += 1
    ro5_ok = viol <= 1
    veber_ok = (tpsa is not None and tpsa <= 140) and (rotb is not None and rotb <= 10)
    return {"ro5_violations": viol, "ro5_pass": ro5_ok, "veber_pass": veber_ok,
            "druglike": ro5_ok and veber_ok}


def filter_obdl(compounds, ob_min=30.0, dl_min=0.18):
    """TCMSP 口径筛选：OB>=ob_min 且 DL>=dl_min。缺参数则保留并标记。"""
    kept, dropped = [], []
    for c in compounds:
        ob, dl = c.get("ob"), c.get("dl")
        if ob is None or dl is None:
            c["obdl_status"] = "missing"
            kept.append(c)
        elif ob >= ob_min and dl >= dl_min:
            c["obdl_status"] = "pass"
            kept.append(c)
        else:
            c["obdl_status"] = "fail"
            dropped.append(c)
    return kept, dropped


# --------------------- 3. 成分->靶点预测 ---------------------
JUNK_TARGET_NAMES = {"ADMET", "NON-PROTEIN TARGET", "UNCHECKED", "MULTIPLE PROTEINS",
                    "HUMAN IMMUNODEFICIENCY VIRUS TYPE 1 INTEGRASE"}


def chembl_targets(name, max_activities=300, min_pchembl=None, human_only=True):
    """ChEMBL: 化合物实测活性 -> 蛋白靶点 (首选，实验证据)。

    实测发现（别再用 target_type！）：activities 接口**不返回** target_type（恒为 None），
    所以不能用它过滤。可靠的判别字段是 target_tax_id / target_organism，
    再用名字黑名单排掉 ADMET(CHEMBL612558)、NON-PROTEIN TARGET(CHEMBL3879801) 这类占位靶点。
    细胞系（HT-1080/COLO 205/PC-3 等）tax_id 为空，一并被排除。
    """
    mols = chembl_molecule(name)
    out = {}
    for m in mols:
        cid = m.get("molecule_chembl_id")
        if not cid or (m.get("pref_name") or "").lower() != name.lower():
            continue
        start = 0
        while start < max_activities:
            r = S.cached_get_json("https://www.ebi.ac.uk/chembl/api/data/activity",
                                  params={"molecule_chembl_id": cid, "format": "json",
                                          "limit": 1000, "offset": start,
                                          "pchembl_value__isnull": "false"})
            acts = (r.get("json") or {}).get("activities", [])
            if not acts:
                break
            for a in acts:
                tgt = a.get("target_pref_name")
                pc = a.get("pchembl_value")
                if not tgt:
                    continue
                # --- 靶点质量过滤：物种 + 名字黑名单 ---
                tax = a.get("target_tax_id")
                if human_only:
                    if str(tax) != "9606":      # 排掉 菌/病毒/大鼠 + 细胞系(tax 空)
                        continue
                    if tgt.upper() in JUNK_TARGET_NAMES:
                        continue
                try:
                    pc = float(pc) if pc is not None else None
                except Exception:
                    pc = None
                if min_pchembl is not None and (pc is None or pc < min_pchembl):
                    continue
                d = out.setdefault(tgt, {"target": tgt, "target_chembl_id": a.get("target_chembl_id"),
                                         "organism": a.get("target_organism"), "tax_id": tax,
                                         "max_pchembl": 0, "n_activities": 0})
                d["n_activities"] += 1
                if pc and pc > d["max_pchembl"]:
                    d["max_pchembl"] = pc
            start += len(acts)
            if len(acts) < 1000:
                break
        break  # 只取首个精确匹配
    return list(out.values())


def pubchem_activities(cid):
    """PubChem bioassay summary (备选)。"""
    r = S.cached_get("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/%s/assaysummary/JSON" % cid)
    if r.get("status") == 200:
        try:
            return json.loads(r["text"])
        except Exception:
            return None
    return None


def predict_targets(compound_name, method="chembl", min_pchembl=None):
    if method == "chembl":
        return chembl_targets(compound_name, min_pchembl=min_pchembl)
    if method == "pubchem":
        cid = pubchem_cid(compound_name)
        return pubchem_activities(cid) if cid else None
    return []


# --------------------- 入口 ---------------------
def build_compound_table(compound_names, method="chembl", min_pchembl=None):
    """给定化合物名列表，输出 (成分表, 成分-靶点表)。"""
    rows, ct = [], []
    for name in compound_names:
        cid = pubchem_cid(name)
        props = pubchem_descriptors(cid) if cid else {}
        dl = lipinski_veber(props)
        rows.append({"compound": name, "pubchem_cid": cid,
                     "MW": _f(props.get("MolecularWeight")), "XLogP": _f(props.get("XLogP")),
                     "TPSA": _f(props.get("TPSA")), "HBD": _f(props.get("HBondDonorCount")),
                     "HBA": _f(props.get("HBondAcceptorCount")), **dl})
        tgts = predict_targets(name, method=method, min_pchembl=min_pchembl)
        if isinstance(tgts, list):
            for t in tgts:
                ct.append({"compound": name, "target": t["target"],
                           "max_pchembl": t.get("max_pchembl"), "n_activities": t.get("n_activities")})
        time.sleep(0.2)
    return rows, ct


if __name__ == "__main__":
    import sys
    names = sys.argv[1:] or ["Quercetin", "Ursolic acid", "Rhynchophylline"]
    rows, ct = build_compound_table(names, method="chembl", min_pchembl=5.0)
    print("compounds:", len(rows), "ct-pairs:", len(ct))
    for r in rows:
        print(" ", r["compound"], "druglike=", r["druglike"], "MW=", r["MW"])
    print("sample targets:")
    for x in ct[:10]:
        print("  ", x["compound"], "->", x["target"], x["max_pchembl"])
