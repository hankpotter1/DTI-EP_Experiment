# -*- coding: utf-8 -*-
"""
np_cytoscape.py — Cytoscape 3.10.4 本地调用层（路径解析 + 启动 + Automation REST）

本机实测安装: G:\\Cytoscape_v3.10.4\\Cytoscape.exe（内置 JRE，不需要系统 Java）
自动化由自带 apps/cy-rest-3.13.3.jar 提供（Cytoscape Automation / cyREST v1，默认端口 1234）。

启动参数来源: G:\\Cytoscape_v3.10.4\\cytoscape.bat --help 原文 —— 非臆造:
  -s,--session <file>   Load a cytoscape session (.cys) file.
  -N,--network <file>   Load a network file (any format).
  -S,--script <file>    Execute commands from script file.
  -R,--rest <port>      Start a rest service.

REST 端点（全部在本机 3.10.4 上实测通过，见文末“实测记录”）:
  GET  /v1/version                                    -> {"apiVersion":"v1","cytoscapeVersion":"3.10.4"}
  GET  /v1/networks                                   -> [196, ...]
  POST /v1/commands/network/import%20file {"file":..} -> {"data":{"networks":[..],"views":[..]}}
  POST /v1/commands/layout/<name>                     -> 200
  POST /v1/commands/network/set%20current {"network":"SUID:196"}
  POST /v1/commands/view/set%20current    {"view":"SUID:300"}
  POST /v1/commands/view/fit%20content
  GET  /v1/networks/<netSUID>/views/<viewSUID>.png    -> PNG 字节流  ← 出图走这个

⚠️ 已知坑: POST /v1/commands/view/export%20png 在 3.10.4 上必崩
   (NullPointerException @ AbstractExportNetworkImageTask:51, 拿不到 rendering engine)。
   出图请用 networks/.../views/....png 那个端点（见 export_view_png）。

用法:
  py -X utf8 np_cytoscape.py --resolve
  py -X utf8 np_cytoscape.py --status
  py -X utf8 np_cytoscape.py --launch --wait
  py -X utf8 np_cytoscape.py --open ..\\data\\ppi_demo.sif
  py -X utf8 np_cytoscape.py --import ..\\data\\ppi_demo.sif --layout force-directed --render ..\\figures\\ppi.png
"""
import argparse
import glob
import json
import os
import subprocess
import sys
import time

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_DEFAULT = os.path.join(BASE, "config.example.json")

CANDIDATE_GLOBS = [
    r"G:\Cytoscape_v*\Cytoscape.exe",
    r"G:\Cytoscape*\Cytoscape.exe",
    r"C:\Program Files\Cytoscape*\Cytoscape.exe",
    r"C:\Program Files (x86)\Cytoscape*\Cytoscape.exe",
    r"D:\Cytoscape*\Cytoscape.exe",
    r"E:\Cytoscape*\Cytoscape.exe",
]


# ---------------------------------------------------------------- config / exe

def load_config(path=None):
    path = path or CONFIG_DEFAULT
    if path and os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def resolve_exe(config=None):
    """配置 → 环境变量 → 常见安装路径。找不到返回 None。"""
    config = config if config is not None else load_config()
    cy = (config or {}).get("cytoscape") or {}
    for key in ("exe", "path", "home"):
        v = cy.get(key)
        if not v:
            continue
        cand = v if v.lower().endswith(".exe") else os.path.join(v, "Cytoscape.exe")
        if os.path.isfile(cand):
            return os.path.abspath(cand)
    for env in ("CYTOSCAPE_EXE", "CYTOSCAPE_HOME"):
        v = os.environ.get(env)
        if v:
            cand = v if v.lower().endswith(".exe") else os.path.join(v, "Cytoscape.exe")
            if os.path.isfile(cand):
                return os.path.abspath(cand)
    for pattern in CANDIDATE_GLOBS:
        hits = sorted(glob.glob(pattern))
        if hits:
            return os.path.abspath(hits[0])
    return None


def rest_port(config=None):
    cy = (config or load_config() or {}).get("cytoscape") or {}
    return int(cy.get("rest_port", 1234))


def rest_base(port=1234):
    return "http://127.0.0.1:%d/v1" % port


# ---------------------------------------------------------------- http

def _http(method, url, payload=None, timeout=30, raw=False):
    """连接失败/超时统一返回 (None, 错误串)，不抛异常。raw=True 时返回 bytes。"""
    try:
        import requests  # viz 环境已装
        try:
            fn = getattr(requests, method.lower())
            r = fn(url, json=payload, timeout=timeout)
            return r.status_code, (r.content if raw else r.text)
        except Exception as e:
            return None, str(e)
    except ImportError:
        import urllib.request
        data = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(url, data=data, method=method.upper())
        if data:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read()
                return resp.status, (body if raw else body.decode("utf-8", "replace"))
        except Exception as e:
            return None, str(e)


def _parse(text):
    try:
        return json.loads(text)
    except Exception:
        return {"raw": text}


# ---------------------------------------------------------------- REST API

def is_running(port=1234):
    code, _ = _http("GET", rest_base(port) + "/version", timeout=5)
    return code == 200


def rest_version(port=1234):
    code, text = _http("GET", rest_base(port) + "/version")
    return _parse(text) if code == 200 else None


def run_command(namespace, command, params=None, port=1234, timeout=120):
    """执行 Cytoscape 命令。

    namespace: e.g. "network" / "layout" / "view"
    command:   e.g. "import file" / "force-directed" / "fit content"
    URL 形如 /v1/commands/<namespace>/<command，空格换成 %20>（实测唯一可用形式）
    """
    cmd = command.strip().replace(" ", "%20")
    url = "%s/commands/%s/%s" % (rest_base(port), namespace.strip(), cmd)
    code, text = _http("POST", url, payload=params or {}, timeout=timeout)
    return {"status": code, "result": _parse(text) if text else None}


def list_networks(port=1234):
    code, text = _http("GET", rest_base(port) + "/networks")
    return _parse(text) if code == 200 else None


def load_network(path, port=1234):
    """载入网络文件（.sif/.cyjs/边表 等）。返回 {status, networks, views}。"""
    r = run_command("network", "import file", {"file": os.path.abspath(path)}, port=port)
    if r["status"] == 200 and isinstance(r.get("result"), dict):
        d = r["result"].get("data") or {}
        r["networks"] = d.get("networks") or []
        r["views"] = d.get("views") or []
    return r


def set_current(network_suid=None, view_suid=None, port=1234):
    out = {}
    if network_suid:
        out["network"] = run_command("network", "set current",
                                     {"network": "SUID:%s" % network_suid}, port=port)
    if view_suid:
        out["view"] = run_command("view", "set current",
                                  {"view": "SUID:%s" % view_suid}, port=port)
    return out


def apply_layout(name="force-directed", port=1234):
    return run_command("layout", name, {}, port=port)


def fit_content(port=1234):
    return run_command("view", "fit content", {}, port=port)


def export_view_png(network_suid, view_suid, out_path, port=1234):
    """把某个 network view 渲染成 PNG。

    ⚠️ 不用 `view export png` 命令（3.10.4 上 NPE）。改用 cyREST 的视图渲染端点:
       GET /v1/networks/<netSUID>/views/<viewSUID>.png
    """
    url = "%s/networks/%s/views/%s.png" % (rest_base(port), network_suid, view_suid)
    code, body = _http("GET", url, timeout=300, raw=True)
    if code != 200 or not isinstance(body, (bytes, bytearray)):
        return {"status": code, "error": str(body)[:200]}
    out_path = os.path.abspath(out_path)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "wb") as f:
        f.write(body)
    return {"status": 200, "file": out_path, "bytes": len(body)}


# ---------------------------------------------------------------- launch

def launch(exe=None, port=1234, network=None, script=None, extra=None,
           wait=False, timeout=300, config=None):
    """启动 Cytoscape。network=网络文件(-N)，script=命令脚本(-S)，port=REST 端口(-R)。"""
    config = config if config is not None else load_config()
    exe = exe or resolve_exe(config)
    if not exe:
        raise FileNotFoundError("找不到 Cytoscape.exe：请在 config 的 cytoscape.exe 指定，或设 CYTOSCAPE_EXE")

    args = [exe]
    if port:
        args += ["-R", str(port)]
    if network:
        args += ["-N", os.path.abspath(network)]
    if script:
        args += ["-S", os.path.abspath(script)]
    if extra:
        args += list(extra)

    DETACHED = 0x00000008
    p = subprocess.Popen(args, cwd=os.path.dirname(exe), close_fds=True, creationflags=DETACHED)
    info = {"pid": p.pid, "exe": exe, "args": args, "rest_port": port}
    if wait:
        info["ready"] = wait_for_rest(port, timeout=timeout)
    return info


def wait_for_rest(port=1234, timeout=300, interval=3):
    """Cytoscape 首次启动慢（GUI + OSGi bundle），耐心等。"""
    deadline = time.time() + timeout
    while time.time() < deadline:
        if is_running(port):
            return True
        time.sleep(interval)
    return False


# ---------------------------------------------------------------- CLI

def main():
    ap = argparse.ArgumentParser(description="Cytoscape 3.10.4 调用层")
    ap.add_argument("--config", default=None)
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--resolve", action="store_true")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--launch", action="store_true")
    ap.add_argument("--open", metavar="NETWORK")
    ap.add_argument("--import", dest="import_file", metavar="FILE")
    ap.add_argument("--layout", metavar="NAME")
    ap.add_argument("--render", metavar="OUTPNG", help="把载入的网络渲染成 PNG")
    ap.add_argument("--wait", action="store_true")
    ap.add_argument("--timeout", type=int, default=300)
    a = ap.parse_args()

    cfg = load_config(a.config)
    port = a.port or rest_port(cfg)

    if a.resolve:
        print(resolve_exe(cfg) or "(未找到)")
        return 0
    if a.status:
        v = rest_version(port)
        print("REST OK %s" % json.dumps(v, ensure_ascii=False) if v else "REST 不可达 port=%d" % port)
        return 0 if v else 1
    if a.open:
        print(json.dumps(launch(network=a.open, port=port, config=cfg,
                                wait=a.wait, timeout=a.timeout), ensure_ascii=False, indent=2))
        return 0
    if a.launch:
        print(json.dumps(launch(port=port, config=cfg, wait=a.wait, timeout=a.timeout),
                         ensure_ascii=False, indent=2))
        return 0

    net_suid = view_suid = None
    if a.import_file:
        r = load_network(a.import_file, port=port)
        print("import:", json.dumps(r, ensure_ascii=False))
        if r.get("networks"):
            net_suid = r["networks"][0]
        if r.get("views"):
            view_suid = r["views"][0]
    if net_suid and view_suid:
        set_current(net_suid, view_suid, port=port)
    if a.layout:
        print("layout:", json.dumps(apply_layout(a.layout, port=port), ensure_ascii=False))
        fit_content(port=port)
    if a.render:
        nets = [net_suid] if net_suid else (list_networks(port) or [])
        ok = False
        for n in nets:
            code, text = _http("POST", "%s/networks/%s/views" % (rest_base(port), n), None, timeout=30)
            views = view_suid and [view_suid] or []
            if not views:
                c2, t2 = _http("GET", "%s/networks/%s/views" % (rest_base(port), n))
                try:
                    views = json.loads(t2)
                except Exception:
                    views = []
            for v in views:
                r = export_view_png(n, v, a.render, port=port)
                print("render:", json.dumps(r, ensure_ascii=False))
                ok = ok or r.get("status") == 200
        if not ok:
            print("render: 失败，请确认 Cytoscape 已载入网络且有 view")
    return 0


if __name__ == "__main__":
    sys.exit(main())
