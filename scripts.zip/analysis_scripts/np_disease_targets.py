# -*- coding: utf-8 -*-
"""
np_disease_targets.py — 疾病靶点获取与整合

数据源 (替代/补充 GeneCards, DisGeNET, OMIM):
  - Open Targets Platform (GraphQL)   — 首选，可编程，含证据打分
  - mygene.info                       — 基因标准化
  - Open Targets 遗传证据 (genetic_association / somatic_mutation / known_drug)
  - 用户自定义列表 (如 GeneCards 导出、OMIM 手工整理)

用法:
  from np_disease_targets import disease_targets_ot, get_disease_id
"""
import os
import json
import time

import sources as S

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(BASE, "data")


def get_disease_id(term, size=5):
    """在 Open Targets 中检索疾病 EFO/MONDO id。"""
    r = S.ot_search(term, entity="disease", size=size)
    hits = ((r.get("json") or {}).get("data", {}) or {}).get("search", {}).get("hits", [])
    return hits


def disease_targets_ot(efo_id, size=300, min_score=0.0, datatypes=None):
    """Open Targets 疾病关联靶点。datatypes 可过滤证据类型。"""
    q = """
    query($id:String!,$size:Int!){
      disease(efoId:$id){
        id name
        associatedTargets(page:{index:0,size:$size}){
          count
          rows{
            score
            target{ id approvedSymbol approvedName }
            datatypeScores{ id score }
          }
        }
      }
    }"""
    r = S.opentargets_graphql(q, {"id": efo_id, "size": size})
    dis = (((r.get("json") or {}).get("data", {}) or {}).get("disease", {}) or {})
    rows = ((dis.get("associatedTargets", {}) or {}).get("rows", []) or [])
    out = []
    for row in rows:
        score = row.get("score", 0)
        if score < min_score:
            continue
        t = row.get("target", {})
        dts = {d["id"]: d["score"] for d in (row.get("datatypeScores") or [])}
        if datatypes:
            keep = {k: v for k, v in dts.items() if k in datatypes}
            if not keep:
                continue
            dts = keep
        out.append({"target": t.get("approvedSymbol"), "target_id": t.get("id"),
                    "name": t.get("approvedName"), "score": round(score, 4),
                    "datatypes": dts})
    return {"disease": dis.get("name"), "disease_id": efo_id, "count": len(out), "targets": out}


def normalize_symbols(symbols):
    """用 mygene 标准化基因符号（别名 -> 官方符号）。"""
    r = S.cached_get_json("https://mygene.info/v3/query", method="POST",
                          data={"q": ",".join(symbols), "scopes": "symbol,alias",
                                "fields": "symbol,entrezgene,ensembl.gene", "species": "human"})
    out = {}
    for item in (r.get("json") or []):
        if item.get("notfound"):
            continue
        q = item.get("query")
        sym = item.get("symbol")
        if q and sym:
            out[q] = {"symbol": sym, "entrez": item.get("entrezgene")}
    return out


def load_disease_targets_from_csv(path, col="target"):
    import pandas as pd
    df = pd.read_csv(path)
    return sorted(set(df[col].dropna().astype(str)))


if __name__ == "__main__":
    import sys
    term = sys.argv[1] if len(sys.argv) > 1 else "epilepsy"
    hits = get_disease_id(term)
    print("disease hits:")
    for h in hits:
        print("  ", h["id"], h["name"])
    if hits:
        res = disease_targets_ot(hits[0]["id"], size=50)
        print(f"\n{res['disease']} ({res['disease_id']}): {res['count']} targets (top50)")
        for t in res["targets"][:15]:
            print(f"   {t['target']:12s} score={t['score']}")
