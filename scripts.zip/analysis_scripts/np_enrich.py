# -*- coding: utf-8 -*-
"""
np_enrich.py — GO/KEGG/Reactome 富集分析 (替代 Metascape / DAVID)

主通路: Enrichr API (可编程, 免注册)
备选:   STRING enrichment, Reactome Analysis Service
输出:   Enrichr 标准结果表 + 用于绘图的结构化数据
"""
import os
import pandas as pd

import sources as S

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(BASE, "results")
os.makedirs(RES, exist_ok=True)

LIBRARIES = {
    "GO_BP": "GO_Biological_Process_2023",
    "GO_MF": "GO_Molecular_Function_2023",
    "GO_CC": "GO_Cellular_Component_2023",
    "KEGG": "KEGG_2021_Human",
    "Reactome": "Reactome_2022",
    "WikiPathways": "WikiPathways_2024_Human",
    "DisGeNET": "DisGeNET",
    "MSigDB_Hallmark": "MSigDB_Hallmark_2020",
}


def enrich(genes, library="KEGG_2021_Human", top_n=50):
    """调用 Enrichr 做一次富集，返回 DataFrame。"""
    r = S.enrichr_enrich(genes, library=library)
    data = r.get("json")
    if not data:
        return pd.DataFrame()
    rows = []
    for item in data[:top_n]:
        rows.append({
            "rank": item[0], "term": item[1], "p_value": item[2],
            "z_score": item[3], "combined_score": item[4],
            "overlapping_genes": ";".join(item[5]) if isinstance(item[5], list) else item[5],
            "adjusted_p_value": item[6] if len(item) > 6 else None,
            "old_p_value": item[7] if len(item) > 7 else None,
        })
    df = pd.DataFrame(rows)
    return df


def enrich_all(genes, libs=None, top_n=30):
    """批量对多个库做富集，返回 {name: df}。"""
    libs = libs or ["GO_BP", "KEGG"]
    out = {}
    for name in libs:
        lib = LIBRARIES.get(name, name)
        df = enrich(genes, library=lib, top_n=top_n)
        out[name] = df
        if not df.empty:
            df.to_csv(os.path.join(RES, f"enrich_{name}.csv"), index=False, encoding="utf-8-sig")
    return out


def string_enrichment(genes, species=9606):
    r = S.string_enrichment(genes, species=species)
    if r.get("status") != 200:
        return []
    rows = []
    import io
    df = pd.read_csv(io.StringIO(r["text"]), sep="\t")
    return df


if __name__ == "__main__":
    import sys
    genes = sys.argv[1:] or ["SCN1A", "SCN2A", "GABRG2", "GABRA1", "CACNA1A", "TNF", "IL6", "AKT1", "MAPK1"]
    res = enrich_all(genes, libs=["GO_BP", "KEGG", "Reactome"], top_n=10)
    for k, df in res.items():
        print(f"=== {k}: {len(df)} terms ===")
        if not df.empty:
            print(df[["term", "p_value", "overlapping_genes"]].head(5).to_string(index=False))
