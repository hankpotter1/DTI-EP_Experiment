# -*- coding: utf-8 -*-
"""
np_map.py — 靶点/基因标识符标准化

解决跨库命名空间不一致: ChEMBL 用蛋白名, Open Targets/STRING 用基因符号。
通路:
  - UniProt accession -> gene symbol (批量, REST)
  - mygene               -> 符号/别名归一
  - ChEMBL target_id     -> UniProt accession
"""
import time
import requests

import sources as S


def uniprot_acc_to_symbol(accessions, chunk=100):
    """UniProt accession 批量 -> 主基因符号。"""
    out = {}
    accessions = [a for a in set(accessions) if a]
    for i in range(0, len(accessions), chunk):
        part = accessions[i:i + chunk]
        q = " OR ".join(f"accession:{a}" for a in part)
        r = S.cached_get_json("https://rest.uniprot.org/uniprotkb/search",
                              params={"query": f"({q}) AND organism_id:9606",
                                      "fields": "accession,gene_primary", "format": "json",
                                      "size": chunk})
        js = r.get("json") or {}
        for entry in js.get("results", []):
            acc = entry.get("primaryAccession")
            genes = entry.get("genes", [])
            if genes and genes[0].get("geneName"):
                out[acc] = genes[0]["geneName"]["value"]
        time.sleep(0.2)
    return out


def chembl_target_to_acc(target_chembl_id):
    r = S.cached_get_json(f"https://www.ebi.ac.uk/chembl/api/data/target/{target_chembl_id}.json")
    js = r.get("json") or {}
    if js.get("target_type") and js["target_type"] != "SINGLE PROTEIN":
        return None
    comps = js.get("target_components", [])
    accs = [c.get("accession") for c in comps if c.get("accession")]
    return accs[0] if accs else None


def resolve_chembl_targets(target_dicts):
    """给 ChEMBL 靶点补充 uniprot / gene symbol 字段（用于跨库交集）。"""
    ids = sorted({t.get("target_chembl_id") for t in target_dicts if t.get("target_chembl_id")})
    id2acc = {}
    for tid in ids:
        try:
            id2acc[tid] = chembl_target_to_acc(tid)
        except Exception:
            id2acc[tid] = None
    acc2sym = uniprot_acc_to_symbol([a for a in id2acc.values() if a])
    for t in target_dicts:
        acc = id2acc.get(t.get("target_chembl_id"))
        t["uniprot"] = acc
        t["symbol"] = acc2sym.get(acc) if acc else None
    return target_dicts


def mygene_sym_to_entrez(symbols):
    r = S.cached_get_json("https://mygene.info/v3/query", method="POST",
                          data={"q": ",".join(symbols), "scopes": "symbol",
                                "fields": "entrezgene,symbol", "species": "human"})
    out = {}
    for item in (r.get("json") or []):
        if "symbol" in item:
            out[item.get("query")] = item["symbol"]
    return out
