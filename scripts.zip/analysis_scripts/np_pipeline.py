# -*- coding: utf-8 -*-
"""
np_pipeline.py — 端到端网络药理学流水线

流程:
  1. 成分表 (CSV: compound / ob / dl / smiles)  -> OB/DL 筛选
  2. 成分 -> 靶点 (ChEMBL 实验活性 + 可选 PubChem)
  3. 疾病 -> 靶点 (Open Targets) 或用户自备 CSV
  4. 交集靶点 -> PPI 网络 (STRING) -> 拓扑核心靶点
  5. GO/KEGG/Reactome 富集 (Enrichr)
  6. 出图: 药物-成分-靶点-疾病网络 / Venn / 富集气泡图 / PPI网络

运行:
  python np_pipeline.py --config config.example.json
"""
import os
import sys
import json
import argparse
import pandas as pd

import np_compound_targets as CT
import np_disease_targets as DT
import np_ppi as PPI
import np_enrich as EN
import np_viz as VIZ
import np_map as MAP

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(BASE, "data")
RES = os.path.join(BASE, "results")
os.makedirs(DATA, exist_ok=True)
os.makedirs(RES, exist_ok=True)


def run(cfg):
    # 1. 成分
    comp_path = cfg.get("compounds_csv")
    herbs = cfg.get("herbs", {})  # {herb: [compound,...]}
    all_ct = []
    compound_rows = []

    if comp_path and os.path.exists(comp_path):
        df = pd.read_csv(comp_path)
        if "ob" in df.columns and "dl" in df.columns:
            df = df[(df["ob"] >= cfg.get("ob_min", 30)) & (df["dl"] >= cfg.get("dl_min", 0.18))]
        names = df["compound"].tolist()
        compound_rows = df.to_dict("records")
    elif herbs:
        names = []
        compound_rows = []
        for herb, comps in herbs.items():
            names += comps
    else:
        names = cfg.get("compound_names", [])
    names = sorted(set(names))
    print(f"[1] 成分: {len(names)} 个")

    # 2. 成分->靶点
    method = cfg.get("target_method", "chembl")
    targets_by_compound = {}
    for name in names:
        try:
            ts = CT.predict_targets(name, method=method, min_pchembl=cfg.get("min_pchembl", 5.0))
        except Exception as e:
            print("   target pred fail:", name, e)
            ts = []
        targets_by_compound[name] = ts
        if isinstance(ts, list):
            for t in ts:
                all_ct.append({"compound": name, "target": t["target"],
                               "target_chembl_id": t.get("target_chembl_id"),
                               "max_pchembl": t.get("max_pchembl"), "n_activities": t.get("n_activities")})
    ct_df = pd.DataFrame(all_ct)

    # 2b. 靶点标准化: ChEMBL 蛋白名 + target_id -> UniProt -> 基因符号
    if not ct_df.empty and cfg.get("resolve_symbols", True):
        unique = ct_df.drop_duplicates("target_chembl_id")[["target", "target_chembl_id"]].to_dict("records")
        MAP.resolve_chembl_targets(unique)
        sym_map = {u["target"]: u.get("symbol") for u in unique}
        uni_map = {u["target"]: u.get("uniprot") for u in unique}
        ct_df["symbol"] = ct_df["target"].map(sym_map)
        ct_df["uniprot"] = ct_df["target"].map(uni_map)
        # 回填 targets_by_compound (供出图用)
        for cname, ts in targets_by_compound.items():
            if not isinstance(ts, list):
                continue
            for t in ts:
                t["symbol"] = sym_map.get(t["target"])
                t["uniprot"] = uni_map.get(t["target"])
        # 无符号的用 mygene 回退
        miss = sorted(set(ct_df.loc[ct_df["symbol"].isna(), "target"]))
        if miss:
            mg = MAP.mygene_sym_to_entrez(miss)  # 仅取符号
            ct_df.loc[ct_df["symbol"].isna(), "symbol"] = ct_df["target"].map(lambda x: mg.get(x))

    if not ct_df.empty:
        ct_df.to_csv(os.path.join(DATA, "compound_targets.csv"), index=False, encoding="utf-8-sig")
    if not ct_df.empty and "symbol" in ct_df.columns:
        drug_targets = sorted(set(ct_df["symbol"].dropna()))
    elif not ct_df.empty:
        drug_targets = sorted(set(ct_df["target"]))
    else:
        drug_targets = []
    print(f"[2] 成分-靶点: {len(all_ct)} 对, 药物靶点(符号) {len(drug_targets)}")

    # 3. 疾病靶点
    dis_targets = []
    if cfg.get("disease_efo"):
        res = DT.disease_targets_ot(cfg["disease_efo"], size=cfg.get("disease_size", 300),
                                    min_score=cfg.get("disease_min_score", 0.0))
        dis_targets = [t["target"] for t in res["targets"]]
        print(f"[3] 疾病靶点 (OT {res['disease']}): {len(dis_targets)}")
    elif cfg.get("disease_csv") and os.path.exists(cfg["disease_csv"]):
        dis_targets = DT.load_disease_targets_from_csv(cfg["disease_csv"])
        print(f"[3] 疾病靶点 (CSV): {len(dis_targets)}")

    # 4. 交集
    inter = sorted(set(drug_targets) & set(dis_targets)) if dis_targets else []
    pd.DataFrame({"target": inter}).to_csv(os.path.join(DATA, "intersection_targets.csv"),
                                           index=False, encoding="utf-8-sig")
    print(f"[4] 交集靶点: {len(inter)}")

    # 5. PPI
    G = None
    if inter:
        G, _ = PPI.build_ppi(inter, score=cfg.get("string_score", 400))
        topo = PPI.topology(G)
        if not topo.empty:
            topo.to_csv(os.path.join(RES, "PPI_topology.csv"), index=False, encoding="utf-8-sig")
        PPI.export_cytoscape(G, "ppi")
        print(f"[5] PPI: {G.number_of_nodes()} 节点 / {G.number_of_edges()} 边")

    # 6. 富集
    if inter:
        er = EN.enrich_all(inter, libs=cfg.get("enrich_libs", ["GO_BP", "KEGG", "Reactome"]), top_n=30)
        print(f"[6] 富集: {[k for k,v in er.items() if not v.empty]}")

    # 7. 出图
    figs = {}
    # 药物-成分-靶点-疾病 网络
    if herbs:
        import networkx as nx
        GN = nx.Graph()
        GN.add_node(cfg.get("disease_name", "Disease"), node_type="disease")
        for herb, comps in herbs.items():
            GN.add_node(herb, node_type="herb")
            for c in comps:
                if c not in targets_by_compound:
                    continue
                GN.add_node(c, node_type="compound"); GN.add_edge(herb, c)
                for t in targets_by_compound[c]:
                    sym = t.get("symbol") or t["target"]
                    if sym in inter:
                        GN.add_node(sym, node_type="target")
                        GN.add_edge(c, sym); GN.add_edge(sym, cfg.get("disease_name", "Disease"))
        figs["network"] = VIZ.plot_network(GN, "fig1_compound_target_disease", title="Herb–Compound–Target–Disease Network")
    if G is not None and G.number_of_nodes():
        figs["ppi"] = VIZ.plot_network(G, "fig2_PPI", title="PPI Network (STRING)")
    if dis_targets:
        figs["venn"] = VIZ.plot_venn({"Drug targets": drug_targets, "Disease targets": dis_targets}, "fig3_venn")
    if inter:
        er = EN.enrich_all(inter, libs=cfg.get("enrich_libs", ["GO_BP", "KEGG"]), top_n=20)
        for k, df in er.items():
            if not df.empty:
                figs[f"bubble_{k}"] = VIZ.plot_enrichment_bubble(df, f"fig4_enrich_{k}", title=f"{k} Enrichment")
    print("[7] 出图:", json.dumps({k: os.path.basename(str(v)) for k, v in figs.items()}, ensure_ascii=False))

    summary = {"n_compounds": len(names), "n_compound_target_pairs": len(all_ct),
               "n_drug_targets": len(drug_targets), "n_disease_targets": len(dis_targets),
               "n_intersection": len(inter),
               "ppi_nodes": G.number_of_nodes() if G else 0,
               "ppi_edges": G.number_of_edges() if G else 0,
               "intersection_targets": inter}
    with open(os.path.join(RES, "pipeline_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    s = run(cfg)
    print(json.dumps(s, ensure_ascii=False, indent=2)[:1500])
