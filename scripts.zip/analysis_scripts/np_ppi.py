# -*- coding: utf-8 -*-
"""
np_ppi.py — PPI 网络构建 + 拓扑分析 (替代/扩展到 Cytoscape)

使用 STRING API 获取互作边，networkx 计算拓扑指标。
可选: 导出 Cytoscape 兼容的 .sif / .cyjs / 边表，供 Cytoscape 直接导入。
"""
import os
import io
import json
import pandas as pd
import networkx as nx

import sources as S

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(BASE, "data")
os.makedirs(DATA, exist_ok=True)


def string_edges(genes, species=9606, score=400):
    r = S.string_network(genes, species=species, score=score)
    if r.get("status") != 200:
        return []
    text = r["text"]
    df = pd.read_csv(io.StringIO(text), sep="\t")
    return df


def build_ppi(genes, score=400, species=9606):
    df = string_edges(genes, species=species, score=score)
    G = nx.Graph()
    G.add_nodes_from(genes)
    if df is not None and len(df) > 0:
        for _, row in df.iterrows():
            a, b = row.get("preferredName_A"), row.get("preferredName_B")
            w = float(row.get("score", 0.4))
            if a and b:
                G.add_edge(a, b, weight=w)
    return G, df


def topology(G):
    if G.number_of_nodes() == 0:
        return pd.DataFrame()
    deg = dict(G.degree())
    dc = nx.degree_centrality(G)
    bc = nx.betweenness_centrality(G)
    cl = nx.closeness_centrality(G)
    try:
        pr = nx.pagerank(G)
    except Exception:
        pr = {}
    rows = []
    for n in G.nodes():
        rows.append({"target": n, "degree": deg[n], "degree_centrality": round(dc[n], 5),
                     "betweenness": round(bc[n], 5), "closeness": round(cl[n], 5),
                     "pagerank": round(pr.get(n, 0), 5)})
    df = pd.DataFrame(rows).sort_values("degree", ascending=False).reset_index(drop=True)
    return df


def hub_targets(G, top_n=15, by="degree"):
    df = topology(G)
    if df.empty:
        return []
    return df.head(top_n)["target"].tolist()


def export_cytoscape(G, name="ppi"):
    """导出 Cytoscape 可直接导入的边表/节点表/SIF。"""
    edgelist = os.path.join(DATA, f"{name}_edges.txt")
    nodelist = os.path.join(DATA, f"{name}_nodes.txt")
    sif = os.path.join(DATA, f"{name}.sif")
    with open(edgelist, "w", encoding="utf-8") as f:
        f.write("source\tinteraction\ttarget\tweight\n")
        for a, b, d in G.edges(data=True):
            f.write(f"{a}\tpp\t{b}\t{d.get('weight', 1)}\n")
    topo = topology(G)
    topo.to_csv(nodelist, sep="\t", index=False, encoding="utf-8")
    with open(sif, "w", encoding="utf-8") as f:
        for a, b in G.edges():
            f.write(f"{a}\tpp\t{b}\n")
    try:
        cyjs = nx.cytoscape_data(G)
        with open(os.path.join(DATA, f"{name}.cyjs"), "w", encoding="utf-8") as f:
            json.dump(cyjs, f)
    except Exception:
        pass
    return {"edges": edgelist, "nodes": nodelist, "sif": sif}


if __name__ == "__main__":
    import sys
    genes = sys.argv[1:] or ["SCN1A", "SCN2A", "GABRG2", "GABRA1", "CACNA1A", "TNF", "IL6", "AKT1", "MAPK1"]
    G, df = build_ppi(genes)
    print(f"PPI: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    topo = topology(G)
    print(topo.head(15).to_string(index=False))
    paths = export_cytoscape(G, "ppi_demo")
    print("exported:", paths)
