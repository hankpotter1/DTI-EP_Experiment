# -*- coding: utf-8 -*-
"""
np_survey.py — 癫痫网络药理学文献普查 v2（修 bug + 扩大搜索面）

## 修掉的 5 个 bug（v1 实测暴露的）
1. **限流**: python requests 对 Europe PMC 会 read timeout → 改 curl + 指数退避 + 磁盘缓存
2. **静默失败**: 单次失败就写 None（v1 有多行 epilepsy_total=None）→ 失败重试 + 末轮补跑 + 明确标记
3. **查询过宽**: v1 把 "berberine"/"licorice"/"ginsenoside" 这类通用成分名混进 OR,
   导致计数虚高、不可比 → v2 只用 药材拉丁名/拼音,不用成分名
4. **无节流**: 连续打接口 → v2 每次请求间隔 + 缓存命中不重打
5. **gap 判定太粗**: v1 只看 n_np<=3（几乎所有药材都是"小"）→ v2 用覆盖率
   `np_ratio = n_np / n_all` + 绝对量双阈值,并排除 n_all 太小的噪音项

## 扩大搜索面（v1 只有 24 味药 + 6 个方）
- 药材 42 味（平肝熄风/豁痰开窍/安神/活血/补益 五类）
- 复方 22 首（癫痫经典方 + 熄风化痰方）
- 邻近病种: 耐药性癫痫 / 癫痫持续状态 / 热性惊厥（找不拥挤的细分入口）
- **方法学维度**: 抓 NP×癫痫 论文摘要,统计它们用的靶点来源
  (TCMSP / SwissTargetPrediction / PharmMapper / STITCH / ChEMBL …)
  —— 这直接回答 v1 暴露的"生物学空心"问题

输出:
  results/np_survey_v2.json
  notes/np_survey_v2.md
"""
import os
import sys
import json
import time
import hashlib
import subprocess
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLKIT = os.path.dirname(HERE)
NOTES = os.path.join(TOOLKIT, "notes")
RESULTS = os.path.join(TOOLKIT, "results")
CACHE = os.path.join(TOOLKIT, "cache", "epmc")
for d in (NOTES, RESULTS, CACHE):
    os.makedirs(d, exist_ok=True)

EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
PACE = 1.2          # 每次真实请求之间的间隔（秒）

_stats = {"net": 0, "cache": 0, "fail": 0}


def _cache_file(url):
    return os.path.join(CACHE, hashlib.md5(url.encode()).hexdigest() + ".json")


def epmc(url, timeout=40, retries=4):
    """curl 取 Europe PMC，带磁盘缓存 + 指数退避。返回 dict 或 None。"""
    cf = _cache_file(url)
    if os.path.isfile(cf):
        try:
            with open(cf, "r", encoding="utf-8") as f:
                _stats["cache"] += 1
                return json.load(f)
        except Exception:
            pass
    delay = 2.0
    for attempt in range(retries):
        time.sleep(PACE)
        try:
            p = subprocess.run(["curl.exe", "-s", "--max-time", str(timeout), url],
                               capture_output=True, timeout=timeout + 20)
            _stats["net"] += 1
            if p.returncode == 0 and p.stdout and p.stdout.strip().startswith(b"{"):
                data = json.loads(p.stdout.decode("utf-8", "replace"))
                with open(cf, "w", encoding="utf-8") as f:
                    json.dump(data, f)
                return data
        except Exception:
            pass
        print("      (retry %d/%d after %.0fs)" % (attempt + 1, retries, delay), flush=True)
        time.sleep(delay)
        delay *= 1.8
    _stats["fail"] += 1
    return None


def count(query):
    url = EPMC + "?" + urllib.parse.urlencode(
        {"query": query, "format": "json", "pageSize": 1, "resultType": "lite"})
    d = epmc(url)
    return None if d is None else d.get("hitCount", 0)


def search(query, size=100):
    url = EPMC + "?" + urllib.parse.urlencode(
        {"query": query, "format": "json", "pageSize": size, "resultType": "core"})
    d = epmc(url)
    if not isinstance(d, dict):
        return []
    return d.get("resultList", {}).get("result", [])


# ---------------- 搜索面 1: 药材（只用拉丁名/拼音，不掺成分名） ----------------
HERBS = [
    ("天麻", 'Gastrodia elata OR Tianma'),
    ("钩藤", 'Uncaria rhynchophylla OR Gouteng'),
    ("全蝎", 'Scorpio OR Quanxie'),
    ("蜈蚣", 'Scolopendra OR Wugong'),
    ("僵蚕", 'Bombyx batryticatus OR Jiangcan'),
    ("地龙", 'Pheretima OR Dilong OR earthworm'),
    ("白附子", 'Typhonium giganteum OR Baifuzi'),
    ("天南星", 'Arisaema erubescens OR Tiannanxing'),
    ("胆南星", 'Arisaema cum Bile OR Dannanxing'),
    ("半夏", 'Pinellia ternata OR Banxia'),
    ("白芍", 'Paeonia lactiflora OR Baishao'),
    ("石决明", 'Haliotis OR Shijueming'),
    ("牡蛎", 'Ostrea gigas OR Muli'),
    ("龙骨", 'Os Draconis OR Longgu'),
    ("代赭石", 'Haematite OR Daizheshi'),
    ("石菖蒲", 'Acorus tatarinowii OR Acorus gramineus OR Shichangpu'),
    ("郁金", 'Curcuma wenyujin OR Curcuma aromatica OR Yujin'),
    ("冰片", 'Borneol OR Bingpian'),
    ("竹茹", 'Bambusa tuldoides OR Zhuru'),
    ("枳实", 'Citrus aurantium OR Zhishi'),
    ("橘红", 'Citrus reticulata OR Juhong'),
    ("茯苓", 'Poria cocos OR Fuling'),
    ("黄芩", 'Scutellaria baicalensis OR Huangqin'),
    ("黄连", 'Coptis chinensis OR Huanglian'),
    ("栀子", 'Gardenia jasminoides OR Zhizi'),
    ("龙胆", 'Gentiana scabra OR Gentiana OR Longdan'),
    ("生地", 'Rehmannia glutinosa OR Dihuang'),
    ("知母", 'Anemarrhena asphodeloides OR Zhimu'),
    ("酸枣仁", 'Ziziphus jujuba OR Suanzaoren'),
    ("远志", 'Polygala tenuifolia OR Yuanzhi'),
    ("柏子仁", 'Platycladus orientalis OR Baiziren'),
    ("丹参", 'Salvia miltiorrhiza OR Danshen'),
    ("川芎", 'Ligusticum chuanxiong OR Chuanxiong'),
    ("桃仁", 'Prunus persica OR Taoren'),
    ("红花", 'Carthamus tinctorius OR Honghua'),
    ("当归", 'Angelica sinensis OR Danggui'),
    ("赤芍", 'Paeonia lactiflora Rubra OR Chishao'),
    ("人参", 'Panax ginseng OR Renshen'),
    ("党参", 'Codonopsis pilosula OR Dangshen'),
    ("黄芪", 'Astragalus membranaceus OR Huangqi'),
    ("甘草", 'Glycyrrhiza uralensis OR Gancao'),
    ("五味子", 'Schisandra chinensis OR Wuweizi'),
]

# ---------------- 搜索面 2: 复方 ----------------
FORMULAS = [
    ("定痫丸", 'Dingxian Wan OR Dingxian pill'),
    ("涤痰汤", 'Ditan Tang OR Ditan decoction'),
    ("温胆汤", 'Wendan Tang OR Wendan decoction'),
    ("导痰汤", 'Daotan Tang OR Daotan decoction'),
    ("半夏白术天麻汤", 'Banxia Baizhu Tianma'),
    ("柴胡疏肝散", 'Chaihu Shugan'),
    ("柴胡加龙骨牡蛎汤", 'Chaihu Longgu Muli'),
    ("六君子汤", 'Liujunzi Tang OR Liujunzi decoction'),
    ("逍遥散", 'Xiaoyao San OR Xiaoyao powder'),
    ("归脾汤", 'Guipi Tang OR Guipi decoction'),
    ("甘麦大枣汤", 'Ganmai Dazao'),
    ("天麻钩藤饮", 'Tianma Gouteng'),
    ("镇肝熄风汤", 'Zhengan Xifeng'),
    ("羚角钩藤汤", 'Lingjiao Gouteng'),
    ("大定风珠", 'Dadingfengzhu OR Da Ding Feng Zhu'),
    ("止痉散", 'Zhijing San'),
    ("牵正散", 'Qianzheng San'),
    ("礞石滚痰丸", 'Mengshi Guntan'),
    ("安宫牛黄丸", 'Angong Niuhuang'),
    ("血府逐瘀汤", 'Xuefu Zhuyu'),
    ("通窍活血汤", 'Tongqiao Huoxue'),
    ("补阳还五汤", 'Buyang Huanwu'),
]

# ---------------- 搜索面 3: 邻近病种 ----------------
ADJACENT = [
    ("癫痫(总)", 'epilepsy'),
    ("耐药性癫痫", '"drug-resistant epilepsy" OR "refractory epilepsy" OR "intractable epilepsy"'),
    ("癫痫持续状态", '"status epilepticus"'),
    ("热性惊厥", '"febrile seizure" OR "febrile convulsion"'),
    ("颞叶癫痫", '"temporal lobe epilepsy"'),
    ("小儿癫痫", 'epilepsy AND (children OR pediatric OR paediatric)'),
]

# ---------------- 搜索面 4: 方法学（靶点来源） ----------------
TARGET_SOURCES = [
    "TCMSP", "SwissTargetPrediction", "PharmMapper", "STITCH", "ChEMBL",
    "PubChem", "BATMAN", "HERB", "SymMap", "ETCM", "DrugBank", "SuperPred",
    "TargetNet", "SEA", "SwissDock", "AutoDock", "Vina", "Discovery Studio",
    "STRING", "Cytoscape", "DAVID", "Metascape", "Enrichr", "clusterProfiler",
    "GeneCards", "DisGeNET", "OMIM", "Open Targets",
]


def main():
    out = {"herbs": [], "formulas": [], "adjacent": [], "methods": {}, "meta": {}}

    def save():
        with open(os.path.join(RESULTS, "np_survey_v2.json"), "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)

    NPQ = '"network pharmacology"'

    print("== 1) 药材 gap (%d 味) ==" % len(HERBS), flush=True)
    for zh, expr in HERBS:
        n_all = count('(%s) AND epilepsy' % expr)
        n_np = count('(%s) AND epilepsy AND %s' % (expr, NPQ))
        row = {"zh": zh, "expr": expr, "n_epilepsy": n_all, "n_np": n_np}
        if n_all and n_np is not None:
            row["np_ratio"] = round(n_np / n_all, 3)
        out["herbs"].append(row)
        print("  %-14s 癫痫=%-5s NP=%-5s ratio=%s" % (
            zh, n_all, n_np, row.get("np_ratio", "-")), flush=True)
        save()

    print("== 2) 复方 gap (%d 首) ==" % len(FORMULAS), flush=True)
    for zh, expr in FORMULAS:
        n_all = count('(%s) AND epilepsy' % expr)
        n_np = count('(%s) AND epilepsy AND %s' % (expr, NPQ))
        row = {"zh": zh, "expr": expr, "n_epilepsy": n_all, "n_np": n_np}
        if n_all and n_np is not None:
            row["np_ratio"] = round(n_np / n_all, 3)
        out["formulas"].append(row)
        print("  %-18s 癫痫=%-5s NP=%-5s ratio=%s" % (
            zh, n_all, n_np, row.get("np_ratio", "-")), flush=True)
        save()

    print("== 3) 邻近病种拥挤度 ==", flush=True)
    for zh, expr in ADJACENT:
        n_all = count('(%s)' % expr)
        n_np = count('(%s) AND %s' % (expr, NPQ))
        row = {"zh": zh, "n_all": n_all, "n_np": n_np}
        out["adjacent"].append(row)
        print("  %-14s 全部=%-7s NP=%-6s" % (zh, n_all, n_np), flush=True)
        save()

    print("== 4) 方法学: NP×癫痫 论文用了哪些靶点来源 ==", flush=True)
    recs = search('%s AND epilepsy' % NPQ, size=100)
    print("  取回 %d 篇" % len(recs), flush=True)
    texts = []
    for r in recs:
        blob = " ".join([(r.get("title") or ""), (r.get("abstractText") or "")])
        texts.append(blob)
    joined = " \n".join(texts)
    counts = {}
    for s in TARGET_SOURCES:
        c = joined.lower().count(s.lower())
        counts[s] = c
    out["methods"] = {"n_papers_scanned": len(recs), "source_mentions": counts}
    ranked = sorted(counts.items(), key=lambda kv: -kv[1])
    for k, v in ranked[:18]:
        print("  %-22s %d" % (k, v), flush=True)

    out["meta"] = {"stats": _stats, "pace_sec": PACE,
                   "n_herbs": len(HERBS), "n_formulas": len(FORMULAS)}
    save()
    print("\nstats:", _stats)
    print("written:", os.path.join(RESULTS, "np_survey_v2.json"))


if __name__ == "__main__":
    main()
