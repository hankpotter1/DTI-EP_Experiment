# -*- coding: utf-8 -*-
"""np_survey_formulas.py — 并行跑 np_survey 的复方/邻近病种/方法学三段。

主脚本 np_survey.py 正在跑 42 味药材（吞吐受限），这里把另外三段拆出来并行，
写到独立文件，避免互相覆盖。完成后由收尾步骤合并。
"""
import os
import sys
import json

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLKIT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import np_survey as SV

RESULTS = os.path.join(TOOLKIT, "results")
os.makedirs(RESULTS, exist_ok=True)
OUT = os.path.join(RESULTS, "np_survey_v2_extra.json")
NPQ = '"network pharmacology"'

out = {"formulas": [], "adjacent": [], "methods": {}}


def save():
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)


print("== A) 复方 gap (%d 首) ==" % len(SV.FORMULAS), flush=True)
for zh, expr in SV.FORMULAS:
    n_all = SV.count('(%s) AND epilepsy' % expr)
    n_np = SV.count('(%s) AND epilepsy AND %s' % (expr, NPQ))
    row = {"zh": zh, "expr": expr, "n_epilepsy": n_all, "n_np": n_np}
    if n_all and n_np is not None:
        row["np_ratio"] = round(n_np / n_all, 3)
    out["formulas"].append(row)
    print("  %-18s 癫痫=%-6s NP=%-5s ratio=%s" % (
        zh, n_all, n_np, row.get("np_ratio", "-")), flush=True)
    save()

print("== B) 邻近病种 ==", flush=True)
for zh, expr in SV.ADJACENT:
    n_all = SV.count('(%s)' % expr)
    n_np = SV.count('(%s) AND %s' % (expr, NPQ))
    out["adjacent"].append({"zh": zh, "n_all": n_all, "n_np": n_np})
    print("  %-14s 全部=%-7s NP=%-6s" % (zh, n_all, n_np), flush=True)
    save()

print("== C) 方法学: NP×癫痫 论文的靶点来源 ==", flush=True)
recs = SV.search('%s AND epilepsy' % NPQ, size=100)
print("  取回 %d 篇" % len(recs), flush=True)
joined = " \n".join([(r.get("title") or "") + " " + (r.get("abstractText") or "") for r in recs])
counts = {s: joined.lower().count(s.lower()) for s in SV.TARGET_SOURCES}
out["methods"] = {"n_papers_scanned": len(recs), "source_mentions": counts}
save()
for k, v in sorted(counts.items(), key=lambda kv: -kv[1])[:20]:
    print("  %-24s %d" % (k, v), flush=True)

print("\nextra done:", OUT)
