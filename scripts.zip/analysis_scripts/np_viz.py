# -*- coding: utf-8 -*-
"""
np_viz.py — 网络药理学可视化 (替代 Cytoscape / Venny / Metascape 出图部分)

⚠️ 本机 matplotlib savefig 崩溃 (0xc06d007f, DLL delay-load) ->
   全部改用 Plotly + kaleido 输出交互式 HTML 和 300 DPI 级 PNG。

- 药物-成分-靶点-疾病 多层网络
- Venn 图 (2-4 集合, Plotly 绘制) / >4 集合改交集矩阵
- 富集分析气泡图 / 条形图
- PPI 网络图 (节点大小=degree)
"""
import os
import numpy as np
import pandas as pd
import networkx as nx

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(BASE, "figures")
os.makedirs(FIG, exist_ok=True)

PALETTE = {
    "herb": "#E74C3C", "disease": "#2C3E50", "compound": "#3498DB",
    "target": "#27AE60", "pathway": "#F39C12",
}
# Venn 填充色
VENN_COLORS = ["rgba(52,152,219,0.45)", "rgba(231,76,60,0.45)",
               "rgba(46,204,113,0.45)", "rgba(243,156,18,0.45)"]


def _save(fig, out_base, width=1400, height=1000):
    """保存 HTML + PNG (PNG 失败则仅 HTML)。"""
    html = os.path.join(FIG, out_base + ".html")
    fig.write_html(html)
    try:
        fig.write_image(os.path.join(FIG, out_base + ".png"), scale=3, width=width, height=height)
    except Exception as e:
        print("  png export skipped:", e)
    return html


# ---------------- 网络图 ----------------
def plot_network(G, out="network", title="Drug–Compound–Target–Disease Network",
                 node_type_attr="node_type", width=1400, height=1000):
    import plotly.graph_objects as go
    pos = nx.spring_layout(G, k=1.4 / np.sqrt(max(G.number_of_nodes(), 2)), iterations=80, seed=42)
    edge_x, edge_y = [], []
    for a, b in G.edges():
        edge_x += [pos[a][0], pos[b][0], None]
        edge_y += [pos[a][1], pos[b][1], None]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=edge_x, y=edge_y, mode="lines",
                             line=dict(width=0.5, color="#cccccc"), hoverinfo="none"))
    groups = {}
    for n in G.nodes():
        t = G.nodes[n].get(node_type_attr, "target")
        groups.setdefault(t, []).append(n)
    for t, nodes in groups.items():
        xs = [pos[n][0] for n in nodes]
        ys = [pos[n][1] for n in nodes]
        deg = [G.degree(n) for n in nodes]
        labels = [str(G.nodes[n].get("label", n))[:18] for n in nodes]
        fig.add_trace(go.Scatter(
            x=xs, y=ys, mode="markers+text", name=t,
            text=labels, textposition="top center", textfont=dict(size=8),
            marker=dict(size=[10 + d * 4 for d in deg], color=PALETTE.get(t, "#888888"),
                        line=dict(width=0.5, color="white")),
            hovertext=[f"{n} (deg={d})" for n, d in zip(nodes, deg)], hoverinfo="text"))
    fig.update_layout(title=title, showlegend=True, template="simple_white",
                      margin=dict(l=10, r=10, t=50, b=10),
                      xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                      yaxis=dict(showgrid=False, zeroline=False, showticklabels=False))
    return _save(fig, out, width, height)


# ---------------- Venn (Plotly) ----------------
def plot_venn(sets_dict, out="venn", title="Target Overlap", width=800, height=750):
    import plotly.graph_objects as go
    names = list(sets_dict.keys())
    sets = [set(sets_dict[k]) for k in names]
    n = len(names)
    if n > 4:
        return plot_intersection_matrix(sets_dict, out=out, title=title)

    fig = go.Figure()
    # 圆周布局圆心
    if n == 2:
        centers = [(-0.35, 0), (0.35, 0)]
        radius = 0.62
    elif n == 3:
        centers = [(0, 0.35), (-0.35, -0.28), (0.35, -0.28)]
        radius = 0.62
    else:  # 4
        centers = [(-0.3, 0.3), (0.3, 0.3), (-0.3, -0.3), (0.3, -0.3)]
        radius = 0.52
    for i, (cx, cy) in enumerate(centers):
        fig.add_shape(type="circle", x0=cx - radius, y0=cy - radius,
                      x1=cx + radius, y1=cy + radius,
                      fillcolor=VENN_COLORS[i % len(VENN_COLORS)],
                      line=dict(color="gray", width=1))

    def reg(cx, cy):
        return {k: sets[k] for k in range(n) if (centers[k][0] - cx) ** 2 + (centers[k][1] - cy) ** 2 < (radius * 0.95) ** 2}

    # 采样区域求各分区计数
    ann = {}
    for i, (cx, cy) in enumerate(centers):
        # 单独区域（不含其它圆心）
        ann[(i,)] = None
    # 数值：用网格采样
    xs = np.linspace(-1.1, 1.1, 161)
    ys = np.linspace(-1.1, 1.1, 161)
    from collections import Counter
    cnt = Counter()
    for x in xs:
        for y in ys:
            inside = tuple(sorted(k for k in range(n)
                                  if (centers[k][0] - x) ** 2 + (centers[k][1] - y) ** 2 < radius ** 2))
            if inside:
                cnt[inside] += 1
    # 把像素计数量映射到各集合元素
    labels_pos = {}
    for combo in cnt:
        if len(combo) == 0:
            continue
        # 计算 combo 的实际交集大小
        inter = set.intersection(*[sets[k] for k in combo]) if combo else set()
        others = [k for k in range(n) if k not in combo]
        if others:
            others_int = set.union(*[sets[k] for k in others])
            val = len(inter - others_int)
        else:
            val = len(inter)
        # 质心
        mx = np.mean([centers[k][0] for k in combo])
        my = np.mean([centers[k][1] for k in combo])
        labels_pos[combo] = (mx, my, val)

    # 每个集合的独有/总数标注
    for i, name in enumerate(names):
        fig.add_annotation(x=centers[i][0] * 1.9, y=centers[i][1] * 1.9 if n != 3 else centers[i][1] * 2.0,
                           text=f"<b>{name}</b><br>({len(sets[i])})", showarrow=False, font=dict(size=13))
    for combo, (mx, my, val) in labels_pos.items():
        if val > 0:
            fig.add_annotation(x=mx, y=my, text=f"<b>{val}</b>", showarrow=False, font=dict(size=12))
    fig.update_layout(title=title, template="simple_white", width=width, height=height,
                      xaxis=dict(range=[-1.3, 1.3], showgrid=False, zeroline=False, showticklabels=False),
                      yaxis=dict(range=[-1.3, 1.3], showgrid=False, zeroline=False, showticklabels=False,
                                 scaleanchor="x"))
    return _save(fig, out, width, height)


def plot_intersection_matrix(sets_dict, out="intersection", title="Intersection Sizes",
                             width=1000, height=800, top_n=25):
    """>4 集合时的交集矩阵 (UpSet 风格)。"""
    import plotly.graph_objects as go
    from itertools import combinations
    names = list(sets_dict.keys())
    sets = {k: set(v) for k, v in sets_dict.items()}
    rows = []
    for r in range(1, len(names) + 1):
        for combo in combinations(names, r):
            inter = set.intersection(*[sets[c] for c in combo])
            excl = inter - set.union(*[sets[c] for c in names if c not in combo]) if len(combo) < len(names) else inter
            if excl:
                rows.append({"combo": " & ".join(combo), "size": len(excl)})
    df = pd.DataFrame(rows).sort_values("size", ascending=False).head(top_n)
    df = df.iloc[::-1]
    fig = go.Figure(go.Bar(x=df["size"], y=df["combo"], orientation="h",
                           marker_color="#3498DB", text=df["size"], textposition="outside"))
    fig.update_layout(title=title, template="simple_white", height=max(400, 30 * len(df)),
                      xaxis_title="Intersection size", yaxis_title="")
    return _save(fig, out, width, max(400, 30 * len(df)))


# ---------------- 富集气泡 / 条形 ----------------
def plot_enrichment_bubble(df, out="enrich_bubble", title="Enrichment", top_n=20, width=1100, height=None):
    import plotly.express as px
    if df is None or df.empty:
        return None
    d = df.head(top_n).copy()
    d["neg_log_p"] = -np.log10(d["p_value"].astype(float).clip(lower=1e-300))
    d["gene_count"] = d["overlapping_genes"].apply(lambda s: len(str(s).split(";")) if pd.notna(s) else 0)
    d["term_short"] = d["term"].apply(lambda x: (x[:55] + "…") if len(str(x)) > 55 else x)
    h = height or max(400, 26 * len(d))
    fig = px.scatter(d, x="neg_log_p", y="term_short", size="gene_count", color="neg_log_p",
                     color_continuous_scale="YlOrRd", hover_data=["overlapping_genes"],
                     labels={"neg_log_p": "-log10(P)", "term_short": ""}, title=title)
    fig.update_layout(template="simple_white", height=h, yaxis=dict(autorange="reversed"))
    return _save(fig, out, width, h)


def plot_enrichment_bar(df, out="enrich_bar", title="Enrichment", top_n=20, width=1100, height=None):
    import plotly.express as px
    if df is None or df.empty:
        return None
    d = df.head(top_n).copy().iloc[::-1]
    d["neg_log_p"] = -np.log10(d["p_value"].astype(float).clip(lower=1e-300))
    d["term_short"] = d["term"].apply(lambda x: (x[:60] + "…") if len(str(x)) > 60 else x)
    h = height or max(400, 24 * len(d))
    fig = px.bar(d, x="neg_log_p", y="term_short", orientation="h",
                 color="neg_log_p", color_continuous_scale="RdYlBu_r", title=title,
                 labels={"neg_log_p": "-log10(P)", "term_short": ""})
    fig.update_layout(template="simple_white", height=h)
    return _save(fig, out, width, h)


if __name__ == "__main__":
    G = nx.Graph()
    G.add_node("Herb", node_type="herb"); G.add_node("Disease", node_type="disease")
    for c in ["C1", "C2"]:
        G.add_node(c, node_type="compound"); G.add_edge("Herb", c)
    for t in ["SCN1A", "TNF", "AKT1"]:
        G.add_node(t, node_type="target"); G.add_edge("C1", t); G.add_edge("Disease", t)
    print("net:", plot_network(G, "selftest_net"))
    print("venn:", plot_venn({"Drug": ["a", "b", "c"], "Disease": ["b", "c", "d"]}, "selftest_venn"))
    df = pd.DataFrame({"term": ["T1", "T2", "T3"], "p_value": [1e-6, 1e-4, 1e-3],
                       "overlapping_genes": ["A;B", "A", "B;C;D"]})
    print("bubble:", plot_enrichment_bubble(df, "selftest_bubble"))
    print("OK")
