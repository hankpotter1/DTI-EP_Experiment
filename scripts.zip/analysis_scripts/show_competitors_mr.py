# -*- coding: utf-8 -*-
"""从抓到的竞品里,筛出「癫痫 × 蛋白/蛋白组 × MR」的核心对手,打印设计要点。"""
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
f = os.path.join(ROOT, "results", "competitors_mr_epilepsy.json")
rows = json.load(open(f, encoding="utf-8"))

CORE = []
for r in rows:
    t = (r["title"] or "").lower()
    ab = (r["abstract"] or "").lower()
    if "epilep" not in t:
        continue
    if not any(k in (t + ab) for k in ["proteome", "protein", "pqtl", "inflammatory", "cytokine", "bioactive"]):
        continue
    CORE.append(r)

CORE.sort(key=lambda r: (r.get("year") or "0"), reverse=True)

print("==== 核心对手(癫痫 × 蛋白类 × MR):%d 篇 ====" % len(CORE))
for i, r in enumerate(CORE, 1):
    print("\n[%d] [%s] %s" % (i, r["year"], r["journal"]))
    print("    标题: %s" % r["title"])
    print("    DOI: %s | PMID: %s" % (r["doi"], r["pmid"]))
    ab = r["abstract"]
    # 抽关键设计信息
    for pat, label in [
        (r"(cis[- ]?pQTL|cis[- ]?pqtl)", "cis-pQTL"),
        (r"(deCODE|UKB[- ]?PPP|UK Biobank Pharma|Fenland|INTERVAL|SCALLOP|Zhao)", "蛋白组数据源"),
        (r"(ILAE|generalized epilepsy|focal epilepsy|GGE|juvenile myoclonic|JME|subtype|sub-?type)", "亚型"),
        (r"(FinnGen|GWAS|IEU|consortium)", "结局 GWAS 源"),
        (r"(colocaliz\w+)", "共定位"),
        (r"(replicat\w+)", "重复验证"),
        (r"(drug target|druggab\w+)", "成药性"),
    ]:
        m = re.search(pat, ab, re.I)
        if m:
            s = max(0, m.start() - 90)
            print("    · %-12s …%s…" % (label, re.sub(r"\s+", " ", ab[s:m.end() + 120])))
print("\n\n======== 摘要全文(前 4 篇核心对手)========")
for r in CORE[:4]:
    print("\n########## [%s] %s" % (r["year"], r["journal"]))
    print("TITLE:", r["title"])
    print("DOI:", r["doi"])
    print(r["abstract"][:2600])
    print()
