# -*- coding: utf-8 -*-
"""
sources.py — 网络药理学 / 中药数据源统一访问层
统一封装所有在线数据库的调用，带重试、缓存、限速。

覆盖用户清单中的：
  中药库: TCMSP, HERB, TCMID, BATMAN-TCM, SymMap, ETCM
  疾病库: GeneCards, DisGeNET, OMIM, Open Targets, mygene, Ensembl
  靶点预测: SwissTargetPrediction, PharmMapper, SwissADME
  PPI: STRING, DGIdb
  富集: Enrichr, Metascape, Reactome, KEGG
  化学: PubChem, ChEMBL
  基因映射: mygene.info, UniProt
"""
import os
import json
import time
import hashlib
import requests

CACHE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cache")
os.makedirs(CACHE_DIR, exist_ok=True)
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) netpharm-toolkit/1.0"}
TIMEOUT = 60


# ----------------------------- 缓存/重试 -----------------------------
def _cache_path(key):
    h = hashlib.md5(key.encode("utf-8")).hexdigest()
    return os.path.join(CACHE_DIR, h + ".json")


def cached_get(url, params=None, method="GET", data=None, cache=True, retries=3, sleep=1.0):
    """带缓存 + 重试的请求。返回解析后的 JSON 文本/字典字符串。"""
    key = method + "|" + url + "|" + json.dumps(params or data or {}, sort_keys=True, ensure_ascii=False)
    cp = _cache_path(key)
    if cache and os.path.exists(cp):
        with open(cp, "r", encoding="utf-8") as f:
            return json.load(f)
    last = None
    for i in range(retries):
        try:
            if method == "GET":
                r = requests.get(url, params=params, headers=UA, timeout=TIMEOUT)
            else:
                r = requests.post(url, data=data, params=params, headers=UA, timeout=TIMEOUT)
            if r.status_code == 200:
                out = {"status": 200, "text": r.text}
                if cache:
                    with open(cp, "w", encoding="utf-8") as f:
                        json.dump(out, f, ensure_ascii=False)
                return out
            last = {"status": r.status_code, "text": r.text[:500]}
        except Exception as e:
            last = {"status": -1, "text": f"{type(e).__name__}: {e}"}
        time.sleep(sleep * (i + 1))
    return last or {"status": -1, "text": "unknown error"}


def cached_get_json(url, params=None, method="GET", data=None, cache=True):
    r = cached_get(url, params=params, method=method, data=data, cache=cache)
    try:
        return {"status": r["status"], "json": json.loads(r["text"])}
    except Exception:
        return {"status": r["status"], "json": None, "raw": r["text"][:500]}


# ----------------------------- 基因/靶点 -----------------------------
def mygene_query(q, fields="symbol,name,entrezgene,ensembl.gene", species="human", size=5):
    """mygene.info — 基因符号别名解析/标准化。"""
    return cached_get_json(
        "https://mygene.info/v3/query",
        params={"q": q, "fields": fields, "species": species, "size": size},
    )


def mygene_symbol_to_entrez(symbols):
    """批量基因符号 -> Entrez ID。"""
    if not symbols:
        return {}
    r = cached_get_json(
        "https://mygene.info/v3/query",
        method="POST",
        data={"q": ",".join(symbols), "scopes": "symbol", "fields": "entrezgene,symbol", "species": "human"},
    )
    out = {}
    if r.get("json"):
        for item in r["json"]:
            if item.get("notfound"):
                continue
            if "entrezgene" in item:
                out[item.get("query", item.get("symbol"))] = item["entrezgene"]
    return out


def uniprot_search(query, organism=9606, size=25):
    """UniProt REST — 按基因名/关键词检索蛋白。"""
    return cached_get_json(
        "https://rest.uniprot.org/uniprotkb/search",
        params={"query": f"{query} AND organism_id:{organism}", "size": size, "format": "json"},
    )


def ensembl_lookup(symbol, species="homo_sapiens"):
    return cached_get_json(
        f"https://rest.ensembl.org/lookup/symbol/{species}/{symbol}",
        params={"content-type": "application/json"},
    )


# ----------------------------- 疾病靶点 -----------------------------
def _post_json(url, payload, cache=True):
    """带缓存的 JSON POST（带正确的 Content-Type）。"""
    key = "POSTJ|" + url + "|" + json.dumps(payload, sort_keys=True, ensure_ascii=False)
    cp = _cache_path(key)
    if cache and os.path.exists(cp):
        with open(cp, "r", encoding="utf-8") as f:
            return json.load(f)
    hdr = dict(UA)
    hdr["Content-Type"] = "application/json"
    last = None
    for i in range(3):
        try:
            r = requests.post(url, data=json.dumps(payload), headers=hdr, timeout=TIMEOUT)
            if r.status_code == 200:
                out = {"status": 200, "json": r.json()}
                if cache:
                    with open(cp, "w", encoding="utf-8") as f:
                        json.dump(out, f, ensure_ascii=False)
                return out
            last = {"status": r.status_code, "json": None, "raw": r.text[:300]}
        except Exception as e:
            last = {"status": -1, "json": None, "raw": f"{type(e).__name__}: {e}"}
        time.sleep(1.0 * (i + 1))
    return last


def opentargets_graphql(query, variables=None):
    payload = {"query": query}
    if variables:
        payload["variables"] = variables
    return _post_json("https://api.platform.opentargets.org/api/v4/graphql", payload)


def ot_disease_associations(efo_id, size=200, datatype="known_drug"):
    """Open Targets — 疾病关联靶点（可替代/补充 DisGeNET, GeneCards）。"""
    q = """
    query($id:String!,$size:Int!){
      disease(efoId:$id){
        id name
        associatedTargets(page:{index:0,size:$size}){
          rows{ target{id approvedSymbol} score datatypeScores{id score} }
        }
      }
    }"""
    return opentargets_graphql(q, {"id": efo_id, "size": size})


def ot_search(term, entity="disease", size=5):
    q = "query($t:String!,$n:Int!){search(queryString:$t,entityNames:[%s],page:{index:0,size:$n}){hits{id name}}}" % json.dumps(entity)
    return opentargets_graphql(q, {"t": term, "n": size})


# ----------------------------- 化学/成分 -----------------------------
def pubchem_cid_by_name(name):
    return cached_get_json(f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{name}/cids/TXT")


def pubchem_properties(cid, props="MolecularFormula,MolecularWeight,XLogP,TPSA,HBondDonorCount,HBondAcceptorCount"):
    return cached_get_json(
        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/property/{props}/JSON"
    )


def chembl_target_search(q):
    return cached_get_json(
        "https://www.ebi.ac.uk/chembl/api/data/target/search",
        params={"q": q, "format": "json"},
    )


# ----------------------------- PPI -----------------------------
def string_network(genes, species=9606, score=400):
    r = cached_get(
        "https://string-db.org/api/tsv/network",
        method="POST",
        data={"identifiers": "\r".join(genes), "species": species, "required_score": score,
              "caller_identity": "netpharm-toolkit"},
    )
    return r


def string_enrichment(genes, species=9606):
    return cached_get(
        "https://string-db.org/api/tsv/enrichment",
        method="POST",
        data={"identifiers": "\r".join(genes), "species": species},
    )


def dgidb_interactions(genes):
    q = """query($genes:[String!]!){genes(names:$genes){nodes{name interactions{drug{name} interactionScore interactionTypes{type}}}}}}"""
    return cached_get_json("https://dgidb.org/api/graphql", method="POST", data=json.dumps({"query": q, "variables": {"genes": genes}}))


# ----------------------------- 富集 -----------------------------
def enrichr_add_list(genes, desc="netpharm"):
    """Enrichr addList 需 multipart/form-data 上传。"""
    try:
        r = requests.post(
            "https://maayanlab.cloud/Enrichr/addList",
            files={"list": (None, "\n".join(genes))},
            data={"description": desc},
            headers=UA, timeout=TIMEOUT,
        )
        if r.status_code == 200:
            return {"status": 200, "json": r.json()}
        return {"status": r.status_code, "json": None, "raw": r.text[:300]}
    except Exception as e:
        return {"status": -1, "json": None, "raw": f"{type(e).__name__}: {e}"}


def enrichr_enrich(genes, library="KEGG_2021_Human", desc="netpharm"):
    a = enrichr_add_list(genes, desc)
    if not a.get("json") or "userListId" not in (a["json"] or {}):
        return {"status": a.get("status"), "json": None}
    uid = a["json"]["userListId"]
    r = cached_get_json(
        "https://maayanlab.cloud/Enrichr/enrich",
        params={"userListId": uid, "backgroundType": library},
    )
    if r.get("json"):
        return {"status": 200, "json": r["json"].get(library, [])}
    return r


def reactome_analysis(genes):
    return cached_get_json(
        "https://reactome.org/PathwayBrowser/AnalysisService/identifiers/projection",
        method="POST", data="\n".join(genes),
    )


# ----------------------------- 中药库（网页型，尽力抓取） -----------------------------
def herb_ac_cn(keyword, action="search", fmt=None):
    """HERB 站点探测（返回原始 HTML，供进一步解析）。"""
    urls = {
        "search": f"http://herb.ac.cn/api/search?keyword={keyword}",
        "home": "http://herb.ac.cn/",
    }
    return cached_get(urls.get(action, urls["home"]))


def symmap_search(keyword):
    return cached_get("http://www.symmap.org/search/", params={"search_type": "herb", "q": keyword})


if __name__ == "__main__":
    print("self-test ...")
    print("mygene:", mygene_query("SCN1A").get("status"))
    print("string:", string_network(["TNF", "IL6", "AKT1"])["status"])
    print("enrichr:", enrichr_enrich(["TNF", "IL6", "AKT1"])["status"])
    print("pubchem:", pubchem_cid_by_name("quercetin")["status"])
